// V5 adaptation of the retained standard-tar development archive route.
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { root, guard } = require('./p44-run.cjs');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const folder = 'docs/ota-exec-notes/P4-4-acceptance-preparation-2026-10-19/v5';
const archive = guard(path.join(root, folder, 'development.zip'));
const inventory = guard(path.join(root, folder, 'inventory.json'));
assert(!fs.existsSync(archive) && !fs.existsSync(inventory), 'PRESERVE_ORIGINAL_ARCHIVE');
const files = ['.cache/p44-v5-preparation-archive.cjs', ...process.argv.slice(2)];
assert(files.length >= 5 && new Set(files).size === files.length, 'DEVELOPMENT_INPUT_SET');
const entries = files.map(name => {
  assert(name.startsWith('.cache/') && !/(?:^|\/)private(?:\/|$)/i.test(name), 'DEVELOPMENT_INPUT_PATH');
  const bytes = fs.readFileSync(guard(path.join(root, name)));
  assert(!/(?:gh[posur]_|github_pat_)[A-Za-z0-9_]{20,}/.test(bytes.toString('utf8')), 'TOKEN_SHAPE');
  return { path: name, size_bytes: bytes.length, sha256: sha(bytes) };
});
const sources = ['Tools/ota/p44-after-recovery.cjs', 'Tools/ota/p44-after-bundle.py',
  'tests/ota/test_p44_after_recovery.cjs', 'tests/ota/test_p44_after_bundle.py']
  .map(name => ({ path: name, sha256: sha(fs.readFileSync(guard(path.join(root, name)))) }));
guard(path.dirname(archive)); fs.mkdirSync(path.dirname(archive), { recursive: true }); guard(archive);
const options = { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024,
  timeout: 60000, env: process.env };
const created = cp.spawnSync('tar', ['-a', '-cf', archive, ...files], options);
assert.equal(created.status, 0, 'TAR_CREATION_FAILED');
const listing = cp.spawnSync('tar', ['-tf', archive], options);
assert.equal(listing.status, 0, 'TAR_LIST_FAILED');
assert.deepEqual(listing.stdout.toString('utf8').trim().split(/\r?\n/).sort(), [...files].sort());
for (const entry of entries) {
  const result = cp.spawnSync('tar', ['-xOf', archive, entry.path], options);
  assert.equal(result.status, 0, 'TAR_MEMBER_FAILED');
  assert.equal(result.stdout.length, entry.size_bytes);
  assert.equal(sha(result.stdout), entry.sha256);
}
const bytes = fs.readFileSync(archive);
fs.writeFileSync(guard(inventory), JSON.stringify({ schema: 'p44-preparation-inventory-v1',
  created_at: new Date().toISOString(),
  nature: 'V5 after-only tool development and V4 delivery originals; no repeated workflow, upload or registration',
  predecessor_bundle_commit: 'da37711799a21c4eb2c5d082dab1a7b81d028511',
  predecessor_index_commit: '7168568489ab0eb67a9e7a05106f245e7243421e',
  product_commit: '2756ca95e26ec636216313271708b3304d61a5cc',
  archive: { path: 'development.zip', size_bytes: bytes.length, sha256: sha(bytes) }, entries,
  source_hashes_at_archive_time: sources,
  source_note: 'Earlier results retain their actual source/time; these hashes do not retroactively bind earlier tests',
  preserved_limits: ['Generated fixtures remain in ignored cache; original failures and completed self-tests are retained',
    'No development result is a live after-state observation or P4-4 PASS',
    'Prior advisory summaries and external-cache attribution are not expanded into unproved conclusions'],
  byte_exact_member_check: true }, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ files: files.length, bytes: bytes.length, archive,
  byte_exact_member_check: true }) + '\n');
