// Reuse the existing standard-tar development archive route; no platform call.
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { root, guard } = require('./p44-run.cjs');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const version = process.argv[2];
assert(['v2', 'v3', 'v4'].includes(version), 'REVIEWED_ARCHIVE_VERSION');
const folder = 'docs/ota-exec-notes/P4-4-acceptance-preparation-2026-10-19/' + version;
const archive = guard(path.join(root, folder, 'development.zip'));
const inventory = guard(path.join(root, folder, 'inventory.json'));
assert(!fs.existsSync(archive) && !fs.existsSync(inventory), 'PRESERVE_ORIGINAL_ARCHIVE');
const files = ['.cache/p44-v2-preparation-archive.cjs', ...process.argv.slice(3)];
if (version === 'v3') files.push('.cache/p44/diagnostics/gzip-public-api-01.body',
  '.cache/p44/diagnostics/gzip-public-api-01.json', '.cache/p44/logs/p44-gzip-public-api-01.log',
  '.cache/p44/logs/p44-gzip-public-api-01.json');
const logs = '.cache/p44/logs';
const testsPattern = new RegExp('^p44-' + version + '-(?:capture|bundle|run|inspect|records|source|root-review)-.*\\.(?:log|json)$');
const indexPattern = new RegExp('^p44-v' + (Number(version.slice(1)) - 1) + '-index-check-01\\.(?:log|json)$');
for (const name of fs.readdirSync(guard(path.join(root, logs))).sort()) {
  if (testsPattern.test(name) || indexPattern.test(name)) files.push(logs + '/' + name);
}
assert(files.length >= 9 && new Set(files).size === files.length, 'DEVELOPMENT_INPUT_SET');
const entries = files.map(name => {
  assert(name.startsWith('.cache/') && !/(?:^|\/)private(?:\/|$)/i.test(name), 'DEVELOPMENT_INPUT_PATH');
  const bytes = fs.readFileSync(guard(path.join(root, name)));
  assert(!/(?:gh[posur]_|github_pat_)[A-Za-z0-9_]{20,}/.test(bytes.toString('utf8')), 'TOKEN_SHAPE');
  return { path: name, size_bytes: bytes.length, sha256: sha(bytes) };
});
const sources = ['Tools/acceptance/p44/run.cjs', 'Tools/acceptance/p44/capture.cjs',
  'Tools/acceptance/p44/bundle.py', 'Tools/acceptance/p44/inspect.py', 'Tools/acceptance/p44/README.md',
  'tests/ota/test_p44_capture.cjs', 'tests/ota/test_p44_acceptance_tools.py']
  .map(name => ({ path: name, sha256: sha(fs.readFileSync(guard(path.join(root, name)))) }));
guard(path.dirname(archive)); fs.mkdirSync(path.dirname(archive), { recursive: true }); guard(archive);
const options = { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024,
  timeout: 60000, env: process.env };
const created = cp.spawnSync('tar', ['-a', '-cf', archive, ...files], options);
assert.equal(created.status, 0, 'TAR_CREATION_FAILED');
const listing = cp.spawnSync('tar', ['-tf', archive], options);
assert.equal(listing.status, 0, 'TAR_LIST_FAILED');
assert.deepEqual(listing.stdout.toString('utf8').trim().split(/\r?\n/).sort(), [...files].sort());
for (const entry of entries) {
  const result = cp.spawnSync('tar', ['-xOf', archive, entry.path], options);
  assert.equal(result.status, 0, 'TAR_MEMBER_FAILED');
  assert.equal(result.stdout.length, entry.size_bytes);
  assert.equal(sha(result.stdout), entry.sha256);
}
const bytes = fs.readFileSync(archive);
fs.writeFileSync(guard(inventory), JSON.stringify({ schema: 'p44-preparation-inventory-v1',
  created_at: new Date().toISOString(),
  nature: 'Bounded ' + version + ' development checks and declared preparation probes; no repeated historical CI/deployment',
  predecessor_bundle_commit: { v2: 'e5994fb28466e46c99a1f247494473e6cba9cc03',
    v3: '84268ac2ad34727b76250ff944211b7efba1cfb3', v4: '20febda2ac2e05e5f4b761a9f365091b177516b6' }[version],
  archive: { path: 'development.zip', size_bytes: bytes.length, sha256: sha(bytes) }, entries,
  source_hashes_at_archive_time: sources,
  source_note: 'Earlier results retain their own source/time; final source hashes do not retroactively bind earlier tests',
  preserved_limits: ['Generated test fixtures remain in ignored cache; original stdout/results and committed test source are retained',
    'Earlier mock success does not prove actual predecessor integration or live D1 compression',
    'The public gzip probe used no credentials and does not constitute a D1 snapshot or product acceptance'],
  byte_exact_member_check: true }, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ files: files.length, bytes: bytes.length, archive,
  byte_exact_member_check: true }) + '\n');
