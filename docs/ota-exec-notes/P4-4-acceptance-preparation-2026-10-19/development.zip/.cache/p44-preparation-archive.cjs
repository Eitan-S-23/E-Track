// One-shot standard-tar packaging of already completed development checks.
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { root, guard } = require('./p44-run.cjs');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const folder = 'docs/ota-exec-notes/P4-4-acceptance-preparation-2026-10-19';
const archive = guard(path.join(root, folder, 'development.zip'));
const inventory = guard(path.join(root, folder, 'inventory.json'));
assert(!fs.existsSync(archive) && !fs.existsSync(inventory), 'PRESERVE_ORIGINAL_ARCHIVE');
const files = ['.cache/p44-preparation-archive.cjs', '.cache/p44-delivery-audit.cjs'];
for (const label of ['01', '02', '03']) {
  for (const name of ['unittest-original.txt', 'result.json']) files.push('.cache/p44-runner-tests-20261019/selftest-' + label + '/' + name);
}
for (const [base, pattern] of [
  ['.cache/p44-original-tests-20261019', /^(?:development-tests-\d+|bundle05-originals-tests-\d+)\.log$/],
  ['.cache/p44/logs', /^p44-(?:capture-selftest|bundle-selftest|records-and-profile)-\d+\.(?:log|json)$/],
]) {
  for (const name of fs.readdirSync(guard(path.join(root, base))).sort()) if (pattern.test(name)) files.push(base + '/' + name);
}
const entries = files.map(name => {
  const bytes = fs.readFileSync(guard(path.join(root, name)));
  assert(!/(?:gh[posur]_|github_pat_)[A-Za-z0-9_]{20,}/.test(bytes.toString('utf8')), 'TOKEN_SHAPE');
  return { path: name, size_bytes: bytes.length, sha256: sha(bytes) };
});
const sources = ['Tools/acceptance/p44/run.cjs', 'Tools/acceptance/p44/capture.cjs', 'Tools/acceptance/p44/bundle.py',
  'Tools/acceptance/p44/inspect.py', 'Tools/acceptance/p44/origins.py', 'Tools/provenance/manifest_profiles.json',
  'tests/ota/test_p44_capture.cjs', 'tests/ota/test_p44_acceptance_tools.py', 'tests/ota/test_p44_originals.py']
  .map(name => ({ path: name, sha256: sha(fs.readFileSync(guard(path.join(root, name)))) }));
guard(path.dirname(archive)); fs.mkdirSync(path.dirname(archive), { recursive: true }); guard(archive);
const options = { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024, timeout: 60000, env: process.env };
const created = cp.spawnSync('tar', ['-a', '-cf', archive, ...files], options);
assert.equal(created.status, 0, 'TAR_CREATION_FAILED');
const listing = cp.spawnSync('tar', ['-tf', archive], options);
assert.equal(listing.status, 0, 'TAR_LIST_FAILED');
assert.deepEqual(listing.stdout.toString('utf8').trim().split(/\r?\n/).sort(), [...files].sort());
for (const entry of entries) {
  const result = cp.spawnSync('tar', ['-xOf', archive, entry.path], options);
  assert.equal(result.status, 0, 'TAR_MEMBER_FAILED');
  assert.equal(result.stdout.length, entry.size_bytes); assert.equal(sha(result.stdout), entry.sha256);
}
const bytes = fs.readFileSync(archive);
fs.writeFileSync(guard(inventory), JSON.stringify({ schema: 'p44-preparation-inventory-v1', created_at: new Date().toISOString(),
  nature: 'Development checks only; no formal observation or repeated historical CI/deployment',
  archive: { path: 'development.zip', size_bytes: bytes.length, sha256: sha(bytes) }, entries,
  source_hashes_at_archive_time: sources,
  source_note: 'Earlier development results retain their own source/time; the final source list does not retroactively bind old tests',
  preserved_limits: ['Early original-evaluator parse failures exist only in tool receipts 02e541 and 172087',
    'Generated test fixtures remain in ignored cache; test stdout/results and committed test source are archived'],
  byte_exact_member_check: true }, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ files: files.length, bytes: bytes.length, archive, byte_exact_member_check: true }) + '\n');
