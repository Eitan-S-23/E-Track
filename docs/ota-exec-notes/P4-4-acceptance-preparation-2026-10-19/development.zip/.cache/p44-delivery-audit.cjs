// Scoped pre-delivery audit; reads credentials only as in-memory scan sentinels.
const s = require('./p44-run.cjs');
const io = require('../../p44-root-acceptance-20261019/io.cjs');
const { fs, path, assert, sha256 } = io;
const cp = require('node:child_process');
const root = s.root;
const indexed = process.argv[2] === 'index';
const command = args => {
  const result = cp.spawnSync('git', ['--no-optional-locks', ...args], {
    cwd: root, env: process.env, windowsHide: true, timeout: 30000, maxBuffer: 32 * 1024 * 1024,
  });
  assert.equal(result.status, 0, 'GIT_READ_FAILED'); return result.stdout;
};
const paths = new Set(command(indexed ? ['diff', '--cached', '--name-only', '-z'] : ['diff', '--name-only', '-z']).toString('utf8').split('\0').filter(Boolean));
if (!indexed) for (const name of command(['ls-files', '--others', '--exclude-standard', '-z']).toString('utf8').split('\0').filter(Boolean)) paths.add(name);
const exact = new Set(['PLAN-OTA-EXEC.md', 'Tools/provenance/manifest_profiles.json',
  'docs/ota-exec-notes/P4-4-configuration-2026-10-18.md', 'docs/ota-exec-notes/P4-4-s3-preacceptance-2026-10-19.md',
  'tests/ota/test_p44_acceptance_tools.py', 'tests/ota/test_p44_originals.py', 'tests/ota/test_p44_capture.cjs']);
const prefixes = ['Tools/acceptance/p44/', 'docs/ota-exec-notes/P4-4-credential-handoff-2026-10-19-v2/',
  'docs/ota-exec-notes/P4-4-credential-resume-2026-10-19/', 'docs/ota-exec-notes/P4-4-acceptance-preparation-2026-10-19/'];
for (const name of paths) assert(exact.has(name) || prefixes.some(prefix => name.startsWith(prefix)), 'UNREVIEWED_DELIVERY_SCOPE');
io.cloudInputs();
const fields = new Set(['cloudflare_account_id', 'cloudflare_api_token', 'ota_aes_key', 'trace_deploy_token',
  'download_hmac_key_current', 'download_hmac_key_previous', 'token_id_access_key_id', 'token_value', 'secret_access_key_sha256', 'keyhex']);
function collect(value) {
  if (!value || typeof value !== 'object') return;
  for (const [name, item] of Object.entries(value)) {
    if (typeof item === 'string' && item.length >= 16 && fields.has(name.toLowerCase())) io.sensitive.add(item);
    collect(item);
  }
}
for (const name of ['app/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json',
  '.cache/p44-cred-20261019/private/p44-s3-credentials-20261019.json',
  '.cache/p4-4-integration-20261018/.cache/p44/private/production-secrets.json',
  '.cache/p41-dev-20261015/.cache/cf-auth-input/firmware-test-secrets.json',
  '.cache/p41-dev-20261015/.cache/cf-auth-input/p41-rehearsal-ota-key.json']) collect(io.readJson(io.guard(path.join(io.project, name))));
const directory = io.readJson(io.guard(path.join(io.project, '.cache/p44-root-acceptance-20261019/private/credential-readback-01/03.json')));
for (const item of directory.result) { assert(/^[0-9a-f]{32}$/.test(item.id)); io.sensitive.add(item.id); }
io.githubToken(process.env);
for (const value of [...io.sensitive]) { assert(value); io.sensitive.add(Buffer.from(value).toString('base64')); }
const sentinels = [...io.sensitive].map(value => Buffer.from(value));
const failures = [];
let members = 0;
function check(name, data) {
  if (sentinels.some(value => data.includes(value)) || /(?:gh[posur]_|github_pat_)[A-Za-z0-9_]{20,}/.test(data.toString('utf8'))) failures.push(name);
}
for (const name of [...paths].sort()) {
  const file = s.guard(path.join(root, name)), data = indexed ? command(['show', ':' + name]) : fs.readFileSync(file);
  check(name, data);
  if (name.endsWith('.zip')) {
    assert.equal(sha256(fs.readFileSync(file)), sha256(data), 'ZIP_INDEX_DRIFT');
    const options = { cwd: root, env: process.env, windowsHide: true, timeout: 60000, maxBuffer: 32 * 1024 * 1024 };
    const listed = cp.spawnSync('tar', ['-tf', file], options); assert.equal(listed.status, 0, 'ZIP_LIST_FAILED');
    const names = listed.stdout.toString('utf8').trim().split(/\r?\n/).filter(value => value && !value.endsWith('/'));
    assert(names.length <= 1024, 'ZIP_MEMBER_LIMIT');
    for (const member of names) {
      const read = cp.spawnSync('tar', ['-xOf', file, member], options); assert.equal(read.status, 0, 'ZIP_READ_FAILED');
      members++; check(name + '::' + member, read.stdout);
    }
  }
}
process.stdout.write(JSON.stringify({ ok: failures.length === 0, indexed, files: paths.size, archive_members: members,
  failed_paths: failures, scan: 'Known credentials/encodings and token shapes; no private values are reported', platform_operations: 0 }) + '\n');
process.exitCode = failures.length ? 1 : 0;
