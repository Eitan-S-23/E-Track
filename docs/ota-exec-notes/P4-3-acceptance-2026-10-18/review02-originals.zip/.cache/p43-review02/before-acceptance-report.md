# P4-3 Independent Acceptance Pre-Review

Review ID: `P43-REVIEW-20261018-01`.
Reviewer: Codex, the user-assigned non-implementing P4-3 acceptance session.
Disposition: **PRODUCT_FAIL**, one required product correction, `P43-ACCEPT-02`.
Task status remains IN_PROGRESS; the implementation owner is unchanged.

This is the concentrated pre-review and original-evidence reconciliation required
by acceptance execution contract sections 0.1 and 7.3. The known blocker prevents
formal admission. Formal execution and final bundle validation are **NOT_RUN**;
no FROZEN contract, formal PASS, REUSED origin, bundle commit or freeze-index entry
has been fabricated. There is no earlier P4-3 formal bundle in FREEZE-INDEX.
The sole Spec remains `docs/ota-prompts/prompt-P4-3-implementation.md`.

## Inputs And Boundary

| Input | Identity |
| --- | --- |
| Active writable worktree | `D:/github/my/E-Track/.cache/p4-3-implementation-20261017` |
| Branch | `dev/p4-3/admin-controls-20261017` |
| Delivered implementation baseline | `a96aa03da14a912aaf783d875d6a379846c21289` |
| Product candidate | `972e74c43cd36b7a308e457296aaf7bb06120e78` |
| Local evidence commit / review HEAD | `08277242b3326541b27f306aee16233cd344ea95` |
| Review HEAD tree | `9e9fd6ceb612e638ba153ec3eb978ec8e225e341` |
| Profile configuration blob | `bb590b65c20e600bfa4748e64ed46b88b6f400d4` |
| Original native CI | `39084376785/1`, exact product candidate |
| Original isolated deployment | `406adf06-caf4-49b6-a83d-9554ba393da1` |

The canonical root rules, task-worktree rules, collaboration index, P4-2 handoff,
sole Spec and applicable frozen OTA-XC clauses were read. Root/worktree differences
in the execution contract consist of the P4-1-only delegation section; that grant
is not reused. The task worktree contains the newer published P4-1/P4-2 index
entries. The dirty shared root and local main were not modified. No `.trellis`
directory exists here, so no replacement task/Spec was created.

Read-only GitHub API receipts at `2026-10-18T02:54:53Z` through `02:54:57Z` confirm
remote main is `a96aa03...`, the task branch still points to `972e74c...`, and CI
39084376785 is completed/success at that same candidate. Thus `0827724` is actually
local-only, not merely an outdated remote-tracking-ref assumption. This review did
not push it or infer commit/push/deployment authority from the acceptance request.

## Required Finding: P43-ACCEPT-02

**DECIDED: P2, required product fix.** This is an unknown-result lifecycle defect,
not a failure of the repaired shared-cookie CAS path and not an Access bypass.

Entry: `admin/public/index.html`, `runFirmwareReleaseAction`, line 5215:
every HTTP error below 500 unconditionally clears `state.firmwarePendingAction`.
The retry path at lines 5167-5177 has not established the original outcome merely
because a later replay was rejected by authentication, CSRF, authorization or
rate limiting. Its following successful GET refresh clears the other write lock.

Reproduced sequence using the unchanged actual UI functions:

1. A recovery request commits, but its response is lost. The UI correctly retains
   the original actor, body and Idempotency-Key.
2. The operator explicitly reconciles that request. Reads occur first, and the
   identical key/body are submitted, but this replay receives a JSON 401, 403 or
   429 before its durable result is returned.
3. The catch clears the pending request. A successful state refresh cannot reveal
   whether the earlier recovery capability was issued. Nevertheless both locks
   are now gone.
4. Another operator confirmation generates a new key and can issue a second
   recovery capability for the same unresolved intent. The original key is no
   longer available through the UI. This is not an automatic second POST: the
   defect permits it after an additional confirmation while losing reconciliation.

Basis: the sole Spec's unknown-result/release-action requirements,
`OTA-XC-ADMIN-IDEMPOTENCY`, and the UI's explicit requirement to reconcile the
original request before another release action. A replay's pre-business rejection
is not evidence that the original transaction failed. Do not infer its outcome
from release state, reason, requestId or an unrelated successful GET.

The bounded offline probe extracts `setFirmwareData`, refresh/failure handling,
`runFirmwareReleaseAction`, `mutate` and `api` directly from the current HTML.
Transport/dialog/render dependencies and small role/ready/UUID fixture helpers
are simulated; this is not a browser integration test. It uses no real token,
network, browser, D1, R2 or device. It reports **4 failing scenarios and 2 passing
controls**, exit 1:

| Replay response | Pending key retained | New key accepted / durable mock effects | Oracle |
| --- | --- | --- | --- |
| 401 TOKEN_EXPIRED | No | Yes / 2 | FAIL |
| 403 CSRF_INVALID | No | Yes / 2 | FAIL |
| 403 ROLE_FORBIDDEN | No | Yes / 2 | FAIL |
| 429 RATE_LIMITED | No | Yes / 2 | FAIL |
| 503 BACKEND_UNAVAILABLE | Yes | No / 1 | PASS control |
| 409 IDEMPOTENCY_RESULT_EXPIRED | No | Yes / 2, separately confirmed | PASS control |

Preferred correction: distinguish a first request's definitive rejection from an
unresolved original request's reconciliation. Preserve the pending actor, exact
body and key, and block unrelated/new-key actions after pre-business or uncertain
replay failures. Release it only on a validated definitive outcome, including the
explicit expired-result branch that permits a newly confirmed intent. Do not
weaken CSRF/Access, auto-replay writes or replace the key on session refresh.

Next owner: P4-3 implementation agent. Add the missing interrupted-reconciliation
cases beside the current unknown-release tests in
`admin/test/firmware-ui.spec.ts`. After restoring auth/CSRF, an explicitly confirmed
same-key replay must return the original URL/requestId with exactly one effect.
Keep the 503, expired-result and changed-actor controls. Rerun this source-reading
probe and affected UI tests, then obtain source-bound native CI for the repaired
batch under actual existing authority. No product fix was authored by this reviewer.

## Existing Evidence Reconciled

All six development archives were independently listed and every entry was
extracted to stdout for size/SHA-256 verification: **1,199 archive entries** in
total. This is a count across increments, not 1,199 distinct experiments. The
latest increment has 585 entries, 25,197,295 bytes and SHA-256
`865730da8d32bba4de6cab9cc821639c8b41638f8e119928e3cd4f0eadef942b`.
Its 220 local drill-file copies also match the archived bytes. An altered-byte
negative was rejected. No archive or historical failure was changed.

| Area | Independent observation |
| --- | --- |
| Native CI and checked input | Original ZIP/logs, workflow metadata and serving manifests agree on candidate 972e74c: Worker 270/270, mock UI 12/12, compiled router 3/3. This review re-evaluated originals, not reran those tests. |
| Deployment reconciliation | The saved original platform JSON matches the independent readback digest, source and successful deployment ID. Before/after/readback configurations are identical and bind only the named test D1/R2. The original CLI null exit/SIGTERM remains a failure receipt; no second deployment was sent. |
| Live owner and served bytes | Saved session status 200/owner, actor hash and response requestId agree. Saved served HTML matches the checked CI HTML SHA-256. This does not establish real publisher/viewer sessions. |
| Original HTTP and D1 | 55 raw D1 responses, 53 sanitized snapshot projections, 54 Admin request/response originals and 18 public response bodies were independently reconciled. Private values were not printed or repackaged. Successful D1 SELECT receipts have zero rows written and changed_db=false. |
| Audit/state chain | 24 channel changes, 3 recovery issuances and 1 disable match unique successful original responses, reasons and actor identity. Both revision chains are continuous. Original audits remain unchanged; matching release-action result rows are completed with the specified retention/expiry. |
| CAS and cancellation | Both repaired stale-tab requests really returned CAS_CONFLICT/409, with no loser state/audit change. The cancellation before/after snapshots are identical. The drill-05 403-versus-409 product failure is retained, not relabeled. |
| Selection and stop flags | Both channels' low clients select 20801, upgraded 20801/30208 clients get NO_UPDATE, and the identical old URL is served or rejected according to independent flags. Successful binary bytes match asset size/digest, not merely HTTP status. |
| Recovery and final disable | Actual recovery bytes match the asset; the same URL later returns TOKEN_EXPIRED/401 and the original key returns IDEMPOTENCY_RESULT_EXPIRED/409. Conditional low disable/replay/new-key rejection leave one effect. Backfill/reference checks precede the disable. |
| Final recorded state | At drill-06 completion, stable revision 13 and beta revision 11 both point to high 3.2.8 with both stops set. Low 2.8.1 is disabled. High identity and all six asset rows are unchanged. These are timestamped historical observations, not a fresh live-state assertion. |

All nine original probe/drill outcomes, including setup, transport, collector and
product failures, remain explicit in the offline output. The evaluator also
rejects a modified final stop flag and an unbound audit requestId. It does not
execute the original live collector or treat its summary PASS as the oracle.

All 21 declared screenshot hashes match. Five were visually inspected: English
cancel confirmation, Chinese retract success, English CAS conflict, Chinese fresh
confirmation, and Chinese final state. Wording, fresh empty reason, revisions,
stop flags and masked identities agree with the original HTTP/D1 records. No new
screenshots or mock-as-live images were created.

## Remaining Limits

- Real publisher/viewer Access sessions remain absent, as explicitly allowed to
  remain a disclosed gap in LIVE-02. Signed-fixture API tests and mock role controls
  do not prove the full deployed role matrix. Do not fabricate those identities,
  borrow owner results or silently close P4-4/production configuration obligations.
- Inherited dependency findings are retained: Admin/Public 4 high each; Worker
  8 high and 3 moderate. The inspected source/dependency reachability analysis is
  not a risk waiver. Root still owns a separate assessed dependency update.
- Current CI originals contain 24 npm warning lines across four jobs, two Actions
  warning annotations and four expected native negative-test exception lines.
  Drill-06 has two browser error lines corresponding to the expected HTTP 409s.
  This is not a warning-free result.
- The previously reported Cryptnet cache exception remains open. The four exact
  files below were inspected read-only, not cleaned, moved or overwritten. One
  metadata timestamp advanced after the prior report; attribution remains unknown.
- Local evidence commit 0827724 and this review are not delivered to main. Remote
  synchronization and eventual commits/bundle-index closeout remain root-owned
  actions requiring their actual authorization.

### Read-Only CRL Follow-Up

Base: `C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/`.
Observed at approximately `2026-10-18T02:39Z`:

| Relative path | Bytes | UTC mtime |
| --- | --- | --- |
| `Content/ABD721CDC3648033BA8C827AF15A4543` | 309 | 2026-10-18T01:02:18.774Z |
| `MetaData/ABD721CDC3648033BA8C827AF15A4543` | 192 | 2026-10-18T02:03:16.368Z |
| `Content/B6E4D06BF128A1673A8DAFB4E25B990D` | 308 | 2026-10-18T01:03:00.875Z |
| `MetaData/B6E4D06BF128A1673A8DAFB4E25B990D` | 192 | 2026-10-18T01:03:00.875Z |

The earlier report recorded the ABD metadata at 01:02:18.777Z. The newer timestamp
does not prove which process refreshed it. This session used cmd.exe and
Node/OpenSSL for its public reads, not PowerShell, native curl/Schannel or a browser.
No cache cleanup is recommended without path-specific user authorization, and no
machine-wide zero-external-write or exclusive-causation claim is made.

## Commands, Delivery And Next Step

The existing `.cache/p43-run.cjs` adapter supplied contained logs, receipts and
TEMP/home/cache overrides. The archive and CI inspectors were reused. The two new
bounded scripts only interpret original data or execute original UI functions
against synthetic transport; they do not replace any production protocol/tool.

| Receipt label | Executed command after the existing adapter | Exit |
| --- | --- | --- |
| `p43-acceptance-ui-reconcile-01` | `node .cache/p43-acceptance-20261018/ui-reconcile-probe.cjs` | 1, product oracle failure |
| `p43-acceptance-archives-01` | Recorded inline Node assertions and `tar -tf`/`tar -xOf` for all six inventories | 0 |
| `p43-acceptance-ci-01` | `node .cache/p43-evidence.cjs inspect-csrf` | 0 |
| `p43-acceptance-originals-01` | `node .cache/p43-acceptance-20261018/inspect-originals.cjs` | 0 |
| `p43-acceptance-identity-01` | Recorded inline Node assertions on original deployment/session/served bytes | 0 |
| `p43-acceptance-platform-01` | Recorded read-only Node/OpenSSL GitHub API requests for task/main refs and CI identity | 0 |

Exact commands, timestamps, exit codes, raw outputs and diagnostic source are
preserved in `P4-3-acceptance-2026-10-18/review-originals.zip` and its inventory.
The review archive contains 14 byte-verified entries, 18,497 bytes, SHA-256
`81efe70aaf1c35c70584c882ec5fbd84feefc390ef7154484bfcda5f0dc85092`.
It is a diagnostic review archive, not a v3 formal acceptance bundle. The local
probe's source bytes use the existing checkout line endings; normalizing CRLF
confirms exact equality to the source-bound CI HTML, without editing either file.
Both new scripts pass `node --check`. No whole host suite, native CI, build,
deployment, live mutation, recovery issuance, asset deletion or device operation
was repeated. No sub-agent was delegated. Product files were not edited.

All actively chosen writes are confined to this worktree: the two diagnostic
scripts under `.cache/p43-acceptance-20261018`, prefixed receipts/logs under
`.cache/p43/logs`, this report/evidence directory, and scoped additions to the
existing implementation issue table and P4-3 board/log. Output guards checked
directory boundaries and existing parent reparse points before writes. Shared Git
metadata was not intentionally written; its index mtime remains 01:48:21.801Z,
matching the pre-review evidence commit, and the staged diff is empty. This is a
bounded path/timestamp audit, not a machine-wide write trace. All 22 selected
output/edited paths passed the final directory-boundary and reparse-point audit;
no new project-external write was identified in this bounded audit. No
project-external cleanup was performed.

Next: implementation addresses P43-ACCEPT-02 as one batch, retaining this failed
probe and adding affected browser regressions. The independent reviewer then
checks the entire remediation batch and formal admission. Historical successful
cloud observations remain available as hash-bound external inputs under section
0.1, not fictitious REUSED formal PASS entries. Re-evaluate applicability and only
obtain genuinely missing/changed observations; do not replay the completed cloud
campaign, re-enable the low release or silently issue more recovery URLs. Formal
contracts, input/profile gates, negative oracles and bundle validation remain
required before whole-card PASS and authorized closeout.
