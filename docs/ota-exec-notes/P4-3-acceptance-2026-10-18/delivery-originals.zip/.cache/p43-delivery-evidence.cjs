const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const mode = process.argv[2];
assert.ok(['inspect', 'archive', 'audit'].includes(mode));
const dir = '.cache/p43-delivery';
const logs = '.cache/p43/logs';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = file => fs.readFileSync(path.resolve(root, file));
const json = file => JSON.parse(read(file));
function run(command, args, binary = false) {
  const result = spawnSync(command, args, { cwd: root, windowsHide: true,
    encoding: binary ? undefined : 'utf8', timeout: 120000, maxBuffer: 64 * 1024 * 1024 });
  assert.equal(result.status, 0, `${command} failed`);
  return result.stdout;
}
function guard(...files) {
  run(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'delivery-evidence-guard', '.', 'preflight', ...files]);
}
const relative = file => path.relative(root, file).replaceAll('\\', '/');
const entry = file => {
  const full = path.resolve(root, file);
  assert.equal(fs.realpathSync(full).toLowerCase(), full.toLowerCase());
  const bytes = read(full);
  return { path: relative(full), sizeBytes: bytes.length, sha256: sha(bytes) };
};
const clean = text => text.replace(/\u001b\[[0-9;]*m/g, '');
const member = (zip, name) => clean(run('tar', ['-xOf', path.resolve(root, zip), name]));
const source = '0067b6c3caa9ee263c53ae372fdc63cc7f74250f';
const merged = 'ebe6c16b87fce20467e8a17ccd96c070b65400ec';
if (mode === 'audit') {
  const selected = [];
  const namespaces = [dir, '.cache/p43/private/delivery', '.cache/p43/private/platform-login',
    'docs/ota-exec-notes/P4-3-acceptance-2026-10-18'];
  guard(...namespaces, logs, '.cache/p43/tmp', '.cache/p43/home', '.cache/p43/appdata', '.cache/p43/localappdata',
    '.cache/p43/gh', '.cache/p43/xdg-config', '.cache/p43/xdg-cache', '.cache/p43/xdg-data');
  function collect(directory) {
    for (const item of fs.readdirSync(path.join(root, directory), { withFileTypes: true })) {
      const file = path.join(directory, item.name);
      assert.ok(!item.isSymbolicLink(), 'Unexpected linked output');
      if (item.isDirectory()) collect(file);
      else selected.push(entry(file));
    }
  }
  for (const namespace of namespaces) collect(namespace);
  for (const name of fs.readdirSync(path.join(root, logs)).filter(name => name.startsWith('delivery-')
    && (name.endsWith('.json') || fs.existsSync(path.join(root, logs, name.replace(/\.log$/, '.json')))))) selected.push(entry(`${logs}/${name}`));
  for (const file of ['.cache/p43-delivery-pages.mjs', '.cache/p43-delivery-evidence.cjs',
    'docs/ota-exec-notes/P4-3-acceptance-2026-10-18.md', 'PLAN-OTA-EXEC.md']) selected.push(entry(file));
  const outside = [
    'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/Content/ABD721CDC3648033BA8C827AF15A4543',
    'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/MetaData/ABD721CDC3648033BA8C827AF15A4543',
    'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/Content/B6E4D06BF128A1673A8DAFB4E25B990D',
    'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/MetaData/B6E4D06BF128A1673A8DAFB4E25B990D',
    'C:/Users/SU/AppData/Local/Microsoft/PowerShell/StartupProfileData-NonInteractive',
    'C:/Users/SU/AppData/Local/Microsoft/Windows/PowerShell/StartupProfileData-NonInteractive'
  ].map(file => { const stat = fs.statSync(file); return { path: file, sizeBytes: stat.size, modified: stat.mtime.toISOString() }; });
  const processes = run('wmic.exe', ['process', 'get', 'CommandLine,ProcessId,ParentProcessId', '/format:csv']);
  const remaining = processes.split(/\r?\n/).filter(line => line.replaceAll('\\', '/').toLowerCase().includes(root.replaceAll('\\', '/').toLowerCase())
    && line.includes('wrangler') && line.includes(source) && line.includes('e-track-firmware-p43-admin-test'))
    .map(line => { const match = line.match(/,(\d+),(\d+)\s*$/); assert.ok(match); return { parentPid: Number(match[1]), pid: Number(match[2]) }; });
  const rootHead = run('git', ['--no-optional-locks', '-C', 'D:/github/my/E-Track', 'rev-parse', 'HEAD']).trim();
  const result = { observedAt: new Date().toISOString(), activeRoot: root, selectedFiles: selected.length,
    selectedNamespaces: namespaces, selectedFileHashes: selected, remainingDeploymentProcesses: remaining,
    externalCacheObservations: outside, externalCleanup: false,
    attribution: 'Read-only cache metadata, not process attribution or a machine-wide zero-write claim',
    sharedMainWorktree: { head: rootHead, intentionallyModified: false },
    result: remaining.length === 0 ? 'PASS' : 'OWNED_PROCESS_REQUIRES_RECONCILIATION' };
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  process.exit(remaining.length === 0 ? 0 : 1);
}
if (mode === 'inspect') {
  const target = path.join(dir, 'inspection.json'); guard(target);
  const merge = json(`${logs}/delivery-pr-readback-02.log`);
  assert.equal(merge.merged, true); assert.equal(merge.merge_commit_sha, merged);
  run('git', ['merge-base', '--is-ancestor', '1ddd948bbf7d0dc2097c14d87def767314342f8f', merged]);
  run('git', ['merge-base', '--is-ancestor', '7e11e96c4acb2735710d626682a6d1a018efadf6', merged]);
  assert.equal(run('git', ['diff', '--name-only', merge.head, merged]).trim(), '');
  assert.equal(run('git', ['diff', '--name-only', source, merged, '--', 'app/bluetooth_flutter_Trace/cloudflare/update-service']).trim(), '');
  assert.equal(run('git', ['diff', '--name-only', '7e11e96c4acb2735710d626682a6d1a018efadf6', 'HEAD', '--',
    'docs/acceptance-contracts/P4-3-v1', 'docs/acceptance-contracts/P4-3-v1.contract.json']).trim(), '');
  const runs = json(`${logs}/delivery-main-runs-01.log`);
  assert.equal(runs.length, 4);
  assert.ok(runs.every(item => item.headSha === merged && item.status === 'completed' && item.conclusion === 'success'));
  const ci = [];
  for (const [name, runId] of [['pr', '39118954124'], ['main', '39119436825']]) {
    const zip = `${dir}/${name}-cloudflare-${runId}.zip`;
    const worker = member(zip, 'Worker Typecheck and Invariants/7_Run invariant tests.txt');
    const ui = member(zip, 'Admin Typecheck and Mock UI/8_Run mock Admin UI tests.txt');
    assert.match(worker, /\bTests\s+270 passed\s+\(270\)/);
    assert.match(ui, /\b36 passed \(/);
    assert.doesNotMatch(ui, /\b\d+ (failed|skipped|flaky|interrupted)\b/);
    const listing = run('tar', ['-tf', zip]).trim().split(/\r?\n/).filter(file => /^[0-9]+_/.test(file));
    const text = listing.map(file => member(zip, file)).join('\n');
    if (name === 'main') assert.ok(text.includes(merged));
    ci.push({ name, runId, workerPassed: 270, uiPassed: 36,
      warningAnnotations: (text.match(/##\[warning\]/g) || []).length,
      errorAnnotations: (text.match(/##\[error\]/g) || []).length,
      expectedNegativeExceptionLines: (worker.match(/uncaught exception;/g) || []).length,
      npmWarningLines: (text.match(/npm warn/g) || []).length,
      dependencyAuditSummaries: text.split('\n').filter(line => /\b\d+ (?:high severity )?vulnerabilities\b/.test(line)),
      original: entry(zip) });
  }
  const governanceZip = `${dir}/main-governance-39119436832.zip`;
  const governanceLogs = run('tar', ['-tf', governanceZip]).trim().split(/\r?\n/)
    .filter(file => /^[0-9]+_/.test(file)).map(file => member(governanceZip, file)).join('\n');
  const deployed = json(`${dir}/delivery-deploy-01.json`);
  const readback = json(`${dir}/delivery-readback-01.json`);
  assert.equal(deployed.result, 'PASS'); assert.equal(deployed.deploymentCommands, 1);
  assert.equal(readback.result, 'PASS'); assert.equal(readback.deploymentCommands, 0);
  assert.equal(readback.deployment.id, deployed.deployment.id);
  assert.equal(readback.deployment.sourceCommit, source);
  assert.equal(readback.businessStateUnchanged, true); assert.equal(readback.settingsUnchanged, true);
  assert.equal(readback.access.actualOwnerVerified, true); assert.equal(readback.access.policyUnchanged, true);
  const state = json('.cache/p43/private/delivery/delivery-readback-01-business-state.json');
  const releases = state.releases.firmwareReleases;
  const channels = state.channels.firmwareChannels.map(item => ({ channel: item.channel, revision: item.revision,
    disableLatest: item.disableLatest, disableDownloads: item.disableDownloads,
    currentReleaseId: item.currentReleaseId }));
  const result = { observedAt: new Date().toISOString(), result: 'PASS', mainIntegration: merge,
    unchangedAcceptedProduct: true, freezeAndBundleAncestorsPreserved: true, frozenBundleFilesUnchanged: true,
    mainRuns: runs, ci, governance: { original: entry(governanceZip),
      warningAnnotations: (governanceLogs.match(/##\[warning\]/g) || []).length,
      errorAnnotations: (governanceLogs.match(/##\[error\]/g) || []).length },
    deployment: deployed.deployment, deploymentCli: deployed.cli, readback: {
      servedHtml: readback.servedHtml, access: readback.access, stateSha256: readback.stateSha256,
      settingsUnchanged: true, businessStateUnchanged: true, channels,
      releases: releases.map(item => ({ releaseId: item.releaseId, versionName: item.versionName, state: item.state,
        assetCount: item.assets?.length })) },
    actualDeploymentCommands: 1, cloudBusinessMutations: 0, actualDeviceOperations: 0,
    formalAcceptanceUnchanged: 'P4-3-v1 / P43-20261018-01, 7/7 PASS',
    limits: ['Real publisher/viewer sessions are not supplied by this owner readback',
      'Dependency advisories and external cache attribution remain open',
      'No production release or P4-4/P5 completion is asserted'] };
  fs.writeFileSync(path.join(root, target), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  process.exit(0);
}
const inspection = json(`${dir}/inspection.json`); assert.equal(inspection.result, 'PASS');
const files = ['.cache/p43-delivery-pages.mjs', '.cache/p43-delivery-evidence.cjs', '.cache/p43-run.cjs'];
for (const name of fs.readdirSync(path.join(root, logs))) {
  if (!/^delivery-[a-z0-9-]+\.json$/.test(name)) continue;
  const log = name.replace(/\.json$/, '.log');
  if (fs.existsSync(path.join(root, logs, log))) files.push(`${logs}/${name}`, `${logs}/${log}`);
}
for (const name of fs.readdirSync(path.join(root, dir))) {
  if (/^(?:delivery-[a-z0-9-]+\.json|(?:pr|main)-[a-z0-9-]+\.zip|inspection\.json|pr-body\.md|delivery-commit\.txt)$/.test(name)) files.push(`${dir}/${name}`);
}
const oauth = fs.readFileSync(path.join(root, '.cache/p43/private/platform-login/xdg-config/.wrangler/config/default.toml'), 'utf8');
const secrets = [...oauth.matchAll(/^(?:oauth_token|refresh_token)\s*=\s*"([^"]+)"/mg)].map(item => item[1]);
secrets.push(json('.cache/p43/private/delivery/delivery-session-refresh-01-new-session.json').value,
  fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/p41-ci-token.txt', 'utf8').trim(),
  fs.readFileSync(path.join(root, '.cache/p43/private/access-connect/home/.cloudflared/sulovehuang.cloudflareaccess.com-org-token'), 'utf8').trim());
function scan(bytes, file) {
  const text = bytes.toString('utf8');
  assert.ok(!secrets.some(value => value.length > 12 && text.includes(value)), `Credential value found in ${file}`);
  assert.doesNotMatch(text, /\b(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{30,}|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)\b/);
}
const entries = [...new Set(files)].sort().map(file => {
  scan(read(file), file);
  if (file.endsWith('.zip')) for (const name of run('tar', ['-tf', file]).trim().split(/\r?\n/)) {
    scan(run('tar', ['-xOf', file, name], true), `${file}:${name}`);
  }
  return entry(file);
});
const out = 'docs/ota-exec-notes/P4-3-acceptance-2026-10-18';
const archive = `${out}/delivery-originals.zip`;
const inventory = `${out}/delivery.inventory.json`;
const list = `${dir}/evidence-files.txt`;
guard(archive, inventory, list);
for (const file of [archive, inventory, list]) assert.ok(!fs.existsSync(path.join(root, file)), 'Preserve existing original');
fs.writeFileSync(path.join(root, list), entries.map(item => item.path).join('\n') + '\n', { flag: 'wx' });
run('tar', ['-a', '-cf', archive, '-T', list]);
assert.deepEqual(run('tar', ['-tf', archive]).trim().split(/\r?\n/).sort(), entries.map(item => item.path).sort());
for (const item of entries) {
  const bytes = run('tar', ['-xOf', archive, item.path], true);
  assert.equal(bytes.length, item.sizeBytes); assert.equal(sha(bytes), item.sha256);
}
const privateDir = '.cache/p43/private/delivery';
const privateOriginals = fs.readdirSync(path.join(root, privateDir)).filter(name => name.endsWith('.json'))
  .map(name => entry(`${privateDir}/${name}`));
const result = { createdAt: new Date().toISOString(), nature: 'Authorized P4-3 main integration and isolated Admin delivery; not a new formal acceptance round',
  archive: { ...entry(archive), entries: entries.length }, inspection, entries, privateOriginals,
  checks: { allArchiveEntrySizesAndHashesVerified: true, knownCredentialAndTokenShapeScan: 'PASS' },
  exclusions: ['Private session, OAuth, Access headers and raw authenticated responses remain project-local',
    'Frozen acceptance and historical evidence were not modified', 'Package command receipt and subsequent documentation-delivery receipts are retained locally'] };
fs.writeFileSync(path.join(root, inventory), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ archive: result.archive, privateOriginals: privateOriginals.length, checks: result.checks }, null, 2) + '\n');
