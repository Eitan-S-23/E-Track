import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const { ProxyAgent, request } = require('../app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici');
const [mode, label] = process.argv.slice(2);
assert.ok(['precheck', 'deploy', 'readback', 'refresh-session'].includes(mode));
assert.match(label || '', /^delivery-[a-z0-9-]+$/);
const project = 'e-track-firmware-p43-admin-test';
const origin = `https://${project}.pages.dev`;
const issuer = 'https://sulovehuang.cloudflareaccess.com';
const appId = 'ca168030-0227-49a5-bd0c-bf030c9c86ea';
const source = '0067b6c3caa9ee263c53ae372fdc63cc7f74250f';
const oldSource = '972e74c43cd36b7a308e457296aaf7bb06120e78';
const oldDeployment = '406adf06-caf4-49b6-a83d-9554ba393da1';
const run = '39098302062';
const artifact = path.join(root, `.cache/p43/ci/artifacts-${run}/admin-deployment-input-${source}`);
const publicDir = path.join(root, '.cache/p43-delivery');
const privateDir = path.join(root, '.cache/p43/private/delivery');
const platformDir = path.join(root, '.cache/p43/private/platform-login');
const oauthPath = path.join(platformDir, 'xdg-config/.wrangler/config/default.toml');
const wrangler = path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/wrangler/bin/wrangler.js');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const guard = (...files) => {
  const result = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'delivery-pages-guard', '.', 'preflight', ...files],
    { cwd: root, windowsHide: true, encoding: 'utf8', timeout: 120000 });
  assert.equal(result.status, 0, 'Output boundary/reparse preflight failed');
};
const contained = { HOME: path.join(platformDir, 'home'), USERPROFILE: path.join(platformDir, 'home'),
  APPDATA: path.join(platformDir, 'appdata'), LOCALAPPDATA: path.join(platformDir, 'localappdata'),
  XDG_CONFIG_HOME: path.join(platformDir, 'xdg-config'), XDG_CACHE_HOME: path.join(platformDir, 'xdg-cache'),
  XDG_DATA_HOME: path.join(platformDir, 'xdg-data') };
guard(publicDir, privateDir, oauthPath, artifact, ...Object.values(contained));
fs.mkdirSync(privateDir, { recursive: true });
const summaryPath = path.join(publicDir, `${label}.json`);
assert.ok(!fs.existsSync(summaryPath), 'Never overwrite a delivery observation');
const report = { label, mode, startedAt: new Date().toISOString(), project, sourceCommit: source,
  sourceRun: `${run}/1`, businessMutations: 0, deploymentCommands: 0, observations: [] };
function save(name, value, isPrivate = true) {
  const target = path.join(isPrivate ? privateDir : publicDir, `${label}-${name}.json`);
  guard(target);
  fs.writeFileSync(target, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
  return target;
}
const expected = [
  ['public/index.html', 266118, '1a5feb4ffb04bf164c139cc1f221baabee3296ca51caf6f02f4e3c13411a0a58'],
  ['public/_worker.js/index.js', 107859, 'ba966cfd178dce339de9d211e631da78663503b5c7ae0dd463c62163bed18d90'],
  ['public/_routes.json', 124, '5e6709f7f844688026950a719cb30e514a4e9d4c546a418b6b914672ab866247']
];
function verifyArtifact() {
  assert.equal(fs.readFileSync(path.join(artifact, 'source-commit.txt'), 'utf8').trim(), source);
  assert.equal(fs.readFileSync(path.join(artifact, 'source-run.txt'), 'utf8').trim(), `${run}/1`);
  assert.deepEqual(fs.readdirSync(path.join(artifact, 'public')).sort(), ['_routes.json', '_worker.js', 'index.html']);
  assert.deepEqual(fs.readdirSync(path.join(artifact, 'public/_worker.js')), ['index.js']);
  for (const [file, size, hash] of expected) {
    const bytes = fs.readFileSync(path.join(artifact, file));
    assert.equal(bytes.length, size); assert.equal(sha(bytes), hash);
  }
  report.artifact = expected.map(([file, sizeBytes, sha256]) => ({ file, sizeBytes, sha256 }));
}
const account = read('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json').account_id;
assert.match(account, /^[a-f0-9]{32}$/);
const ciToken = fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/p41-ci-token.txt', 'utf8').trim();
const credential = () => {
  const text = fs.readFileSync(oauthPath, 'utf8');
  return { token: text.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1],
    expiry: text.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1],
    scopes: [...(text.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1] || '').matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]).sort() };
};
let oauth = credential();
function cliEnv(operation) {
  const log = path.join(privateDir, `${label}-${operation}-wrangler.log`);
  guard(log, path.join(privateDir, '.wrangler'), ...['TEMP', 'TMP', 'TMPDIR'].map(name => {
    assert.ok(process.env[name], 'Use the contained p43-run adapter'); return process.env[name];
  }));
  const env = { ...process.env, ...contained, CI: 'true', CLOUDFLARE_ACCOUNT_ID: account,
    WRANGLER_LOG_PATH: log, WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false', NODE_USE_ENV_PROXY: '0' };
  for (const key of Object.keys(env)) if (/^(?:https?_proxy|all_proxy|no_proxy)$/i.test(key)) delete env[key];
  for (const key of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY', 'CLOUDFLARE_EMAIL', 'CF_EMAIL']) delete env[key];
  return env;
}
async function http(name, url, headers = {}, method = 'GET') {
  assert.ok([origin, issuer, 'https://api.cloudflare.com'].includes(new URL(url).origin));
  assert.ok(['GET', 'HEAD'].includes(method));
  for (let attempt = 1; attempt <= 2; attempt++) {
  const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
  try {
    const result = await request(url, { dispatcher, method, headers, maxRedirections: 0,
      headersTimeout: 30000, bodyTimeout: 30000, signal: AbortSignal.timeout(60000) });
    const chunks = []; let size = 0;
    for await (const chunk of result.body) { size += chunk.length; assert.ok(size <= 4 * 1024 * 1024); chunks.push(chunk); }
    const bytes = Buffer.concat(chunks);
    save(name, { method, url, status: result.statusCode, headers: result.headers, body: bytes.toString('utf8') });
    const observation = { name, method, attempt, observedAt: new Date().toISOString(), status: result.statusCode,
      bodySize: bytes.length, bodySha256: sha(bytes), cfRay: result.headers['cf-ray'] };
    report.observations.push(observation);
    return { status: result.statusCode, headers: result.headers, bytes, observation };
  } catch (error) {
    if (attempt !== 1 || !['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN', 'UND_ERR_CONNECT_TIMEOUT'].includes(error.code)) throw error;
    save(`${name}-attempt-${attempt}-failure`, { method, url, name: error.name, code: error.code, observedAt: new Date().toISOString() });
    report.observations.push({ name, method, attempt, status: null, networkError: error.code, readOnlyRetry: true });
  } finally { await dispatcher.destroy(); }
  }
}
async function refreshSession() {
  const org = fs.readFileSync(path.join(root, '.cache/p43/private/access-connect/home/.cloudflared/sulovehuang.cloudflareaccess.com-org-token'), 'utf8').trim();
  const claims = JSON.parse(Buffer.from(org.split('.')[1], 'base64url'));
  assert.equal(claims.iss, issuer); assert.ok(claims.exp > Date.now() / 1000);
  const app = read(path.join(root, '.cache/p43/private/pages/access-policy-ci-01-isolated-access-app.json')).result;
  let next = new URL(origin + '/'); let appSession;
  report.sessionRefresh = { mechanism: 'Official cloudflared token.go exchangeOrgToken HEAD/redirect flow over the existing verified Node TLS transport',
    source: '.cache/p43/logs/delivery-cloudflared-source-01.log', orgExpiresAt: claims.exp,
    newLogin: false, browserLaunched: false, policyChanges: 0, newPlatformCredentialsOrScopes: false };
  for (let index = 0; index < 6; index++) {
    assert.ok([origin, issuer].includes(next.origin));
    const headers = { 'User-Agent': 'cloudflared/2026.9.1 (P4-3 Node TLS transport adapter)' };
    if (next.origin === issuer && next.pathname.startsWith('/cdn-cgi/access/login')) headers.Cookie = `CF_Authorization=${org}`;
    else if (next.origin === origin && next.pathname === '/cdn-cgi/access/authorized') {
      if (appSession) headers.Cookie = `CF_AppSession=${appSession}`;
    } else assert.equal(next.href, origin + '/', 'No identity-provider or interactive login navigation');
    const response = await http(`sso-${index}`, next.href, headers, 'HEAD');
    const cookies = [response.headers['set-cookie'] || []].flat();
    for (const line of cookies) {
      const pair = line.split(';')[0];
      if (pair.startsWith('CF_AppSession=')) appSession = pair.slice('CF_AppSession='.length);
      if (next.origin === origin && pair.startsWith('CF_Authorization=')) {
        const value = pair.slice('CF_Authorization='.length);
        const issued = JSON.parse(Buffer.from(value.split('.')[1], 'base64url'));
        assert.equal(issued.iss, issuer); assert.ok(issued.aud.includes(app.aud));
        assert.ok(issued.exp > Date.now() / 1000);
        save('new-session', { value, origin, expiresAt: issued.exp, obtainedAt: new Date().toISOString() });
        report.sessionRefresh.applicationExpiresAt = issued.exp;
        report.sessionRefresh.exchangedWithoutLogin = true;
        return;
      }
    }
    assert.ok([302, 303, 307, 308].includes(response.status) && response.headers.location,
      'Existing SSO cannot exchange without interaction; no OTP or login started');
    next = new URL(response.headers.location, next);
  }
  throw new Error('SSO redirect bound reached without an application token');
}
async function api(name, suffix, token = oauth.token) {
  assert.ok([`pages/projects/${project}`, `access/apps/${appId}`, `access/apps/${appId}/policies`].includes(suffix));
  const response = await http(name, `https://api.cloudflare.com/client/v4/accounts/${account}/${suffix}`, { Authorization: `Bearer ${token}` });
  assert.equal(response.status, 200);
  const json = JSON.parse(response.bytes); assert.equal(json.success, true);
  return json.result;
}
function validateProject(value, expectedSource) {
  assert.equal(value.name, project); assert.equal(value.production_branch, 'main');
  const config = value.deployment_configs.production;
  assert.equal(config.d1_databases.DB.id, '2617e1e1-956f-42ce-a465-da56d84abf06');
  assert.equal(config.r2_buckets.RELEASES_BUCKET.name, 'e-track-firmware-p41-test-releases');
  for (const key of ['ACCESS_JWT_ISSUER', 'ACCESS_JWT_AUD', 'ADMIN_OWNER_EMAILS', 'ADMIN_ALLOWED_ORIGINS']) assert.equal(config.env_vars[key].type, 'secret_text');
  const deployment = value.canonical_deployment;
  assert.equal(deployment.deployment_trigger.metadata.commit_hash, expectedSource);
  assert.equal(deployment.environment, 'production'); assert.equal(deployment.latest_stage.status, 'success');
  report.deployment = { id: deployment.id, sourceCommit: expectedSource, url: deployment.url, origin,
    actualStage: deployment.latest_stage, configurationSha256: sha(JSON.stringify(value.deployment_configs)) };
  return value;
}
async function accessAndState(expectedHtml) {
  const app = await api('access-app', `access/apps/${appId}`, ciToken);
  const policies = await api('access-policies', `access/apps/${appId}/policies`, ciToken);
  assert.equal(app.domain, new URL(origin).hostname); assert.ok(app.aud);
  const historical = read(path.join(root, '.cache/p43/private/pages/access-policy-ci-01-isolated-policies-after.json')).result;
  const policyFields = list => list.map(({ id, decision, include, exclude, require, precedence }) => ({ id, decision, include, exclude, require, precedence }));
  assert.deepEqual(policyFields(policies), policyFields(historical));
  const gate = await http('unauthenticated-gate', origin + '/');
  assert.equal(gate.status, 302); assert.equal(new URL(gate.headers.location).origin, issuer);
  report.access = { domain: app.domain, policyUnchanged: true, unauthenticatedRedirectVerified: true };
  const state = read(path.join(root, '.cache/p43/private/owner-login/owner-login-05-storage-state.json'));
  const refreshedPath = path.join(privateDir, 'delivery-session-refresh-01-new-session.json');
  const cookie = fs.existsSync(refreshedPath) ? read(refreshedPath)
    : state.cookies.find(item => item.name === 'CF_Authorization' && item.domain === new URL(origin).hostname);
  assert.ok(cookie, 'Existing authorized origin cookie is required; do not fabricate a session');
  const claims = JSON.parse(Buffer.from(cookie.value.split('.')[1], 'base64url'));
  assert.equal(claims.iss, issuer); assert.ok(claims.aud.includes(app.aud));
  report.existingSession = { expiresAt: claims.exp, validByMetadata: claims.exp > Date.now() / 1000,
    authority: fs.existsSync(refreshedPath) ? 'Existing organization SSO exchanged through the official redirect flow; API authentication still required'
      : 'Existing owner-login-05 origin session; metadata is not a substitute for API authentication' };
  assert.ok(report.existingSession.validByMetadata, 'Existing session expired; do not request a new role or export browser credentials');
  const headers = { Cookie: `CF_Authorization=${cookie.value}`, 'Cache-Control': 'no-cache' };
  const html = await http('served-html', origin + '/', headers);
  assert.equal(html.status, 200); assert.equal(sha(html.bytes), expectedHtml);
  report.servedHtml = { sizeBytes: html.bytes.length, sha256: sha(html.bytes), matchesExpectedArtifact: true };
  const session = await http('owner-session', origin + '/api/admin/session', headers);
  assert.equal(session.status, 200);
  const user = JSON.parse(session.bytes); assert.equal(user.ok, true); assert.equal(user.role, 'owner');
  const historicalOwner = read(path.join(root, '.cache/p43/live/owner-login-05.json'));
  assert.equal(sha(user.actor.trim().toLowerCase()), historicalOwner.session.authenticatedActorSha256);
  report.access.actualOwnerVerified = true;
  const stateProjection = {};
  for (const resource of ['channels', 'releases']) {
    const response = await http(resource, `${origin}/api/admin/firmware/${resource}?appId=trace&deviceModel=e-track-at32f435`, headers);
    assert.equal(response.status, 200);
    const json = JSON.parse(response.bytes); assert.equal(json.ok, true);
    delete json.requestId;
    stateProjection[resource] = json;
  }
  report.stateSha256 = sha(JSON.stringify(stateProjection));
  save('business-state', stateProjection);
}
try {
  verifyArtifact();
  if (mode === 'refresh-session') {
    await refreshSession();
  } else {
  if (!(oauth.token && Date.parse(oauth.expiry) > Date.now())) {
    const before = oauth;
    const args = [wrangler, 'pages', 'project', 'list', '--json'];
    const cli = spawnSync(process.execPath, args, { cwd: privateDir, env: cliEnv('refresh'), windowsHide: true,
      timeout: 90000, encoding: 'utf8', maxBuffer: 4 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
    save('oauth-refresh-cli', { args, exitCode: cli.status, signal: cli.signal, stdout: cli.stdout, stderr: cli.stderr });
    oauth = credential();
    assert.deepEqual(oauth.scopes, before.scopes, 'Normal refresh must not expand scopes');
    assert.ok(oauth.token && Date.parse(oauth.expiry) > Date.now(), 'No usable existing OAuth after official refresh');
    report.oauthRefresh = { exitCode: cli.status, signal: cli.signal, priorExpiry: before.expiry,
      expiry: oauth.expiry, scopesUnchanged: true, noNewLogin: true };
  }
  const current = await api('project-before', `pages/projects/${project}`);
  if (report.oauthRefresh) report.oauthRefresh.authenticatedReadConfirmed = true;
  if (mode === 'precheck') {
    validateProject(current, oldSource); assert.equal(current.canonical_deployment.id, oldDeployment);
    const historical = read(path.join(root, '.cache/p43/private/pages/pages-csrf-02-readback.json')).result;
    assert.deepEqual(current.deployment_configs, historical.deployment_configs);
    await accessAndState('94a3337689719a2cc93eeb5820db15926b60abe701b13e5e560869bc39bf9d8c');
    report.settingsMatchHistoricalReadback = true;
  } else {
    const before = read(path.join(privateDir, 'delivery-precheck-03-project-before.json'));
    const baseline = JSON.parse(before.body);
    const precheck = read(path.join(publicDir, 'delivery-precheck-03.json'));
    assert.equal(precheck.result, 'PASS');
    assert.deepEqual(current.deployment_configs, baseline.result.deployment_configs);
    if (mode === 'deploy') {
      validateProject(current, oldSource); assert.equal(current.canonical_deployment.id, oldDeployment);
      for (let directory = privateDir; directory !== path.dirname(root); directory = path.dirname(directory)) {
        for (const name of ['wrangler.toml', 'wrangler.json', 'wrangler.jsonc']) assert.ok(!fs.existsSync(path.join(directory, name)), 'Unexpected inherited Wrangler config');
      }
      const args = [wrangler, 'pages', 'deploy', path.join(artifact, 'public'), '--project-name', project,
        '--branch', 'main', '--commit-hash', source, '--commit-dirty=false', '--no-bundle', '--upload-source-maps=false'];
      const marker = path.join(privateDir, 'accepted-deployment-attempt.json');
      guard(marker);
      fs.writeFileSync(marker, JSON.stringify({ label, source, project, startedAt: new Date().toISOString(), args }) + '\n', { flag: 'wx' });
      report.deploymentCommands = 1;
      const cli = spawnSync(process.execPath, args, { cwd: privateDir, env: cliEnv('deploy'), windowsHide: true,
        encoding: 'utf8', timeout: 180000, maxBuffer: 8 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
      save('deployment-cli', { args, exitCode: cli.status, signal: cli.signal, stdout: cli.stdout, stderr: cli.stderr });
      report.cli = { exitCode: cli.status, signal: cli.signal, uncertainResultRequiresReadback: cli.status !== 0 };
      const after = await api('project-after', `pages/projects/${project}`);
      validateProject(after, source);
      assert.deepEqual(after.deployment_configs, baseline.result.deployment_configs);
      report.settingsUnchanged = true;
      report.cliResultPreserved = true;
    } else {
      validateProject(current, source);
      assert.ok(fs.existsSync(path.join(privateDir, 'accepted-deployment-attempt.json')));
      await accessAndState(expected[0][2]);
      const stateBefore = read(path.join(privateDir, 'delivery-precheck-03-business-state.json'));
      const stateAfter = read(path.join(privateDir, `${label}-business-state.json`));
      assert.deepEqual(stateAfter, stateBefore);
      report.businessStateUnchanged = true;
      report.settingsUnchanged = true;
    }
    verifyArtifact();
  }
  }
  report.result = 'PASS';
} catch (error) {
  report.result = 'FAIL';
  save('failure', { name: error.name, code: error.code, message: error.message, stack: error.stack });
  report.error = { name: error.name, code: error.code, detailPrivate: true };
  process.exitCode = 1;
} finally {
  report.endedAt = new Date().toISOString();
  guard(summaryPath);
  fs.writeFileSync(summaryPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
}
