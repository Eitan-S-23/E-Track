const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const directory = guard(path.join(root, 'docs/ota-exec-notes/P4-4-integration-2026-10-18'));
const archive = guard(path.join(directory, 'initial.zip'));
const inventory = guard(path.join(directory, 'initial.inventory.json'));
const list = guard(path.join(root, '.cache/p44/seal-files.txt'));
for (const file of [archive, inventory, list]) assert.ok(!fs.existsSync(file), 'Never overwrite evidence');
const files = ['.cache/p44-run.cjs', '.cache/p44-platform.cjs', '.cache/p44-github-config.cjs', '.cache/p44-seal.cjs'];
for (const sub of ['evidence', 'logs']) {
  const base = guard(path.join(root, '.cache/p44', sub));
  for (const name of fs.readdirSync(base).sort()) {
    if (name.startsWith('seal-initial-02.')) continue;
    const file = '.cache/p44/' + sub + '/' + name;
    assert.ok(fs.lstatSync(path.join(root, file)).isFile()); files.push(file);
  }
}
const secretRoot = 'D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/';
const secrets = ['p41-ci-token.txt', 'token.txt'].map(name => fs.readFileSync(secretRoot + name, 'utf8').trim());
for (const name of ['firmware-test-secrets.json', 'p41-rehearsal-ota-key.json']) {
  for (const [key, value] of Object.entries(JSON.parse(fs.readFileSync(secretRoot + name, 'utf8')))) {
    if (typeof value === 'string' && /key|token/i.test(key) && !/sha|hash|path|source|name/i.test(key) && value.length >= 16) secrets.push(value);
  }
}
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const entries = files.map(file => {
  const bytes = fs.readFileSync(guard(path.join(root, file)));
  for (const value of secrets) assert.ok(!bytes.includes(Buffer.from(value)), 'Known credential in selected evidence');
  assert.ok(!/gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}/.test(bytes.toString('utf8')), 'GitHub credential shape in evidence');
  return { path: file, sizeBytes: bytes.length, sha256: digest(bytes) };
});
fs.mkdirSync(directory, { recursive: true });
fs.writeFileSync(list, files.join('\n') + '\n', { flag: 'wx' });
const created = spawnSync('tar', ['-a', '-cf', archive, '-T', list], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(created.status, 0, created.stderr);
const listing = spawnSync('tar', ['-tf', archive], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(listing.status, 0);
assert.deepEqual(listing.stdout.trim().split(/\r?\n/).sort(), [...files].sort());
for (const entry of entries) {
  const member = spawnSync('tar', ['-xOf', archive, entry.path], { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  assert.equal(member.status, 0); assert.equal(member.stdout.length, entry.sizeBytes); assert.equal(digest(member.stdout), entry.sha256);
}
const bytes = fs.readFileSync(archive);
const result = { createdAt: new Date().toISOString(), nature: 'P4-4 implementation observations, not independent acceptance',
  archive: { path: path.relative(root, archive).replaceAll('\\', '/'), sizeBytes: bytes.length, sha256: digest(bytes) },
  entries, credentialsScanned: true, extractionVerified: true,
  excludes: ['Private inputs/credentials', 'Historical frozen bundles', 'Pre-worktree host transcript', 'This archive creation receipt'] };
fs.writeFileSync(inventory, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ ...result.archive, entries: entries.length, credentialsScanned: true, extractionVerified: true }) + '\n');
