const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const output = guard(path.join(root, '.cache/p44/evidence/final-audit-01.json'));
assert.ok(!fs.existsSync(output));
const scopes = ['.cache/p44', '.cache/firmware-workflow-tests',
  'docs/ota-exec-notes/P4-4-integration-2026-10-18'];
let files = 0, directories = 0, bytes = 0;
function visit(target) {
  const stat = fs.lstatSync(target);
  assert.ok(!stat.isSymbolicLink(), 'Linked output');
  const resolved = fs.realpathSync(target), relative = path.relative(root, resolved);
  assert.ok(relative !== '..' && !relative.startsWith('..' + path.sep) && !path.isAbsolute(relative));
  if (stat.isDirectory()) {
    guard(target); directories++;
    for (const name of fs.readdirSync(target)) visit(path.join(target, name));
  } else { files++; bytes += stat.size; }
}
for (const scope of scopes) visit(guard(path.join(root, scope)));
for (const file of ['.cache/p44-run.cjs', '.cache/p44-platform.cjs', '.cache/p44-github-config.cjs', '.cache/p44-seal.cjs', '.cache/p44-audit.cjs',
  'PLAN-OTA-EXEC.md', 'tests/ota/test_acceptance_bundle.py', 'tests/ota/test_firmware_workflow.mjs',
  'docs/ota-exec-notes/P4-4-implementation-2026-10-18.md', 'docs/ota-exec-notes/P4-4-configuration-2026-10-18.md']) visit(guard(path.join(root, file)));
const knownExternal = [
  'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/Content/ABD721CDC3648033BA8C827AF15A4543',
  'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/MetaData/ABD721CDC3648033BA8C827AF15A4543',
  'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/Content/B6E4D06BF128A1673A8DAFB4E25B990D',
  'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache/MetaData/B6E4D06BF128A1673A8DAFB4E25B990D',
  'C:/Users/SU/AppData/Local/Microsoft/PowerShell/StartupProfileData-NonInteractive',
  'C:/Users/SU/AppData/Local/Microsoft/Windows/PowerShell/StartupProfileData-NonInteractive',
].map(file => {
  if (!fs.existsSync(file)) return { path: file, exists: false };
  const stat = fs.statSync(file); return { path: file, bytes: stat.size, mtime: stat.mtime.toISOString() };
});
const git = args => {
  const r = spawnSync('git', ['--no-optional-locks', ...args], { cwd: root, encoding: 'utf8', windowsHide: true });
  assert.equal(r.status, 0); return r.stdout.trim();
};
const privateInput = path.join(root, '.cache/p44/private/production-ci-token.txt');
assert.equal(fs.readFileSync(privateInput, 'utf8').trim(), '', 'Protected input arrived: return to implementation instead of closing as blocked');
const report = { observedAt: new Date().toISOString(), root, scopes, files, directories, bytes,
  head: git(['rev-parse', 'HEAD']), branch: git(['branch', '--show-current']), status: git(['status', '--short']),
  commonGitException: 'Only task worktree metadata, task refs/reflogs, task remote-tracking ref and necessary shared objects',
  protectedInputEmpty: true, knownExternalReadOnlyObservations: knownExternal,
  auditScope: 'Selected controlled outputs and inspected commands; not a machine-wide filesystem trace or external-cache attribution',
  externalCleanup: false, productChanges: git(['diff', '--name-only', '0779f677507fa2c8a88c1799c8d2909bbae5a0a0', 'HEAD', '--', 'app', 'Libraries', 'USER', 'boot', '.github/workflows', '.github/scripts']),
  initialArchiveSha256: crypto.createHash('sha256').update(fs.readFileSync(path.join(root, 'docs/ota-exec-notes/P4-4-integration-2026-10-18/initial.zip'))).digest('hex') };
assert.equal(report.productChanges, '');
guard(output); fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
