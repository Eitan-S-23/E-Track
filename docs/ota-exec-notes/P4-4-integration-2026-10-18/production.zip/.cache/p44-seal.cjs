const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const batch = process.argv[2] || 'initial';
assert.ok(['initial', 'ci', 'registry', 'resume', 'production'].includes(batch));
const directory = guard(path.join(root, 'docs/ota-exec-notes/P4-4-integration-2026-10-18'));
const archive = guard(path.join(directory, batch + '.zip'));
const inventory = guard(path.join(directory, batch + '.inventory.json'));
const list = guard(path.join(root, '.cache/p44', batch === 'initial' ? 'seal-files.txt' : 'seal-' + batch + '-files.txt'));
for (const file of [archive, inventory, list]) assert.ok(!fs.existsSync(file), 'Never overwrite evidence');
const files = ['.cache/p44-run.cjs', '.cache/p44-platform.cjs', '.cache/p44-github-config.cjs', '.cache/p44-seal.cjs'];
if (batch !== 'initial') files.push('.cache/p44-audit.cjs');
if (batch === 'resume') files.push('.cache/p44/environment-schema-query.json');
if (batch === 'production') files.push('.cache/p44-production.cjs', '.cache/p44-production-tests.cjs',
  '.cache/p44/production/state.json', '.cache/p44/production/current-runtime/index.js', '.cache/p44/production/current-worker/index.js.map', '.cache/p44/production/accepted-migrations.sql');
const predecessors = batch === 'production' ? ['initial', 'ci', 'registry', 'resume'] : batch === 'resume' ? ['initial', 'ci', 'registry'] : batch === 'registry' ? ['initial', 'ci'] : batch === 'ci' ? ['initial'] : [];
const prior = new Set(predecessors.flatMap(name => JSON.parse(fs.readFileSync(path.join(directory, name + '.inventory.json'), 'utf8')).entries.map(entry => entry.path)));
for (const sub of ['evidence', 'logs']) {
  const base = guard(path.join(root, '.cache/p44', sub));
  for (const name of fs.readdirSync(base).sort()) {
    if (name.startsWith(batch === 'initial' ? 'seal-initial-02.' : 'seal-ci-01.')) continue;
    if (batch === 'registry' && !name.startsWith('registry-')) continue;
    if (batch === 'resume' && !(sub === 'logs' ? name.startsWith('p44-resume-') :
      ['targets-01.json', 'r2-targets-02.json', 'auth-negative-01.json', 'resume-audit-01.json'].includes(name))) continue;
    if (batch === 'production' && !(sub === 'logs' ? (name.startsWith('p44-prod-') || name.startsWith('p44-owner-')) && !name.endsWith('-wrangler.log') : name.startsWith('production-'))) continue;
    const file = '.cache/p44/' + sub + '/' + name;
    if (prior.has(file)) continue;
    assert.ok(fs.lstatSync(path.join(root, file)).isFile()); files.push(file);
  }
}
const secretRoot = 'D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/';
const secrets = ['p41-ci-token.txt', 'token.txt'].map(name => fs.readFileSync(secretRoot + name, 'utf8').trim());
if (batch === 'production') secrets.push(...Object.entries(JSON.parse(fs.readFileSync(path.join(root, '.cache/p44/private/production-secrets.json'), 'utf8')))
  .filter(([key, value]) => /TOKEN|HMAC/.test(key) && typeof value === 'string').map(([, value]) => value));
for (const name of ['firmware-test-secrets.json', 'p41-rehearsal-ota-key.json']) {
  for (const [key, value] of Object.entries(JSON.parse(fs.readFileSync(secretRoot + name, 'utf8')))) {
    if (typeof value === 'string' && /key|token/i.test(key) && !/sha|hash|path|source|name/i.test(key) && value.length >= 16) secrets.push(value);
  }
}
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const entries = files.map(file => {
  const bytes = fs.readFileSync(guard(path.join(root, file)));
  for (const value of secrets) assert.ok(!bytes.includes(Buffer.from(value)), 'Known credential in selected evidence');
  assert.ok(!/gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}/.test(bytes.toString('utf8')), 'GitHub credential shape in evidence');
  return { path: file, sizeBytes: bytes.length, sha256: digest(bytes) };
});
fs.mkdirSync(directory, { recursive: true });
fs.writeFileSync(list, files.join('\n') + '\n', { flag: 'wx' });
const created = spawnSync('tar', ['-a', '-cf', archive, '-T', list], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(created.status, 0, created.stderr);
const listing = spawnSync('tar', ['-tf', archive], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(listing.status, 0);
assert.deepEqual(listing.stdout.trim().split(/\r?\n/).sort(), [...files].sort());
for (const entry of entries) {
  const member = spawnSync('tar', ['-xOf', archive, entry.path], { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  assert.equal(member.status, 0); assert.equal(member.stdout.length, entry.sizeBytes); assert.equal(digest(member.stdout), entry.sha256);
}
const bytes = fs.readFileSync(archive);
const result = { createdAt: new Date().toISOString(), nature: 'P4-4 implementation observations, not independent acceptance',
  archive: { path: path.relative(root, archive).replaceAll('\\', '/'), sizeBytes: bytes.length, sha256: digest(bytes) },
  entries, credentialsScanned: true, extractionVerified: true,
  excludes: ['Private inputs/credentials', 'Historical frozen bundles', 'Pre-worktree host transcript', 'This archive creation receipt'] };
fs.writeFileSync(inventory, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ ...result.archive, entries: entries.length, credentialsScanned: true, extractionVerified: true }) + '\n');
