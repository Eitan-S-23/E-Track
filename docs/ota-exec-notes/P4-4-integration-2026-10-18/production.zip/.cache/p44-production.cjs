const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const p41 = 'D:/github/my/E-Track/.cache/p41-dev-20261015';
const { ProxyAgent, request } = require('D:/github/my/E-Track/.cache/p4-3-implementation-20261017/app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici');
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const authRoot = p41 + '/.cache/cf-auth-input';
const account = json(p41 + '/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json').account_id;
assert.equal(sha(account), '01910e669500c221e2154f608e9f4e856b0a08297026e1ea98f1d18dd8cf9742');
const ci = fs.readFileSync(authRoot + '/p41-ci-token.txt', 'utf8').trim();
const setup = () => fs.readFileSync(authRoot + '/token.txt', 'utf8').trim();
const names = { worker: 'e-track-firmware-production', d1: 'e-track-firmware-production', r2: 'e-track-firmware-production-releases' };
const [mode, label] = process.argv.slice(2);
assert.ok(['inspect', 'resources', 'prepare', 'schema-before', 'schema-import', 'schema-after', 'deploy', 'redeploy-clean', 'build-current', 'deploy-current', 'log-redact', 'worker-secrets', 'github', 'readback', 'smoke', 'ci-discovery'].includes(mode));
assert.match(label || '', /^[a-z0-9-]+$/);
const base = guard(path.join(root, '.cache/p44/production'));
const statePath = guard(path.join(base, 'state.json'));
const configPath = guard(path.join(base, 'wrangler.json'));
const privatePath = guard(path.join(root, '.cache/p44/private/production-secrets.json'));
const receiptPath = guard(path.join(root, '.cache/p44/evidence', label + '.json'));
assert.ok(!fs.existsSync(receiptPath), 'Never overwrite an observation');
fs.mkdirSync(base, { recursive: true });
let state = fs.existsSync(statePath) ? json(statePath) : { names, accountSha256: sha(account), created: {} };
assert.deepEqual(state.names, names); assert.equal(state.accountSha256, sha(account));
const report = { mode, label, startedAt: new Date().toISOString(), accountSha256: sha(account), names, operations: [] };
const sensitive = [ci, account];
const redact = text => sensitive.filter(Boolean).reduce((s, value) => s.split(value).join('[REDACTED]'), String(text || ''));
function saveState() { guard(statePath); fs.writeFileSync(statePath, JSON.stringify(state, null, 2) + '\n'); }
function secretValues() { const value = json(privatePath); sensitive.push(...Object.values(value).filter(v => typeof v === 'string' && v.length >= 32)); return value; }
function ownerAuth() {
  const env = { ...process.env, GH_CONFIG_DIR: 'C:/Users/SU/AppData/Roaming/GitHub CLI' };
  delete env.GH_TOKEN; delete env.GITHUB_TOKEN;
  const r = spawnSync('gh', ['auth', 'token', '--hostname', 'github.com', '--user', 'Eitan-S-23'], { cwd: root, env, encoding: 'utf8', timeout: 30000, windowsHide: true });
  assert.equal(r.status, 0); const token = r.stdout.trim(); assert.ok(token); sensitive.push(token); return token;
}
function gh(route, options = {}) {
  const env = { ...process.env, GH_TOKEN: ownerAuth(), GH_DEBUG: '', GH_HTTP_DEBUG: '' };
  const args = options.secret ? ['secret', 'set', options.secret, '--env', 'firmware-production', '--repo', 'Eitan-S-23/E-Track'] :
    ['api', 'repos/Eitan-S-23/E-Track/' + route, '--method', options.body ? 'POST' : 'GET', ...(options.body ? ['--input', '-'] : [])];
  const r = spawnSync('gh', args, { cwd: root, env, input: options.secret ? options.value : options.body ? JSON.stringify(options.body) : undefined,
    encoding: 'utf8', timeout: 45000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
  report.operations.push({ platform: 'GitHub', route: options.secret ? 'environments/firmware-production/secrets/' + options.secret : route,
    method: options.secret ? 'SECRET_SET_STDIN' : options.body ? 'POST' : 'GET', exitCode: r.status, endedAt: new Date().toISOString(),
    stdout: options.secret ? undefined : redact(r.stdout), stderr: redact(r.stderr) });
  assert.equal(r.status, 0, 'GitHub operation failed; no automatic write retry');
  return options.secret || !r.stdout.trim() ? {} : JSON.parse(r.stdout);
}
async function cf(route, { method = 'GET', body, credential = ci } = {}) {
  sensitive.push(credential);
  if (method !== 'GET') {
    assert.ok((method === 'POST' && ((route === '/d1/database' && body.name === names.d1) || (route === '/r2/buckets' && body.name === names.r2))) ||
      (method === 'PUT' && route === '/workers/scripts/' + names.worker + '/secrets' && body.type === 'secret_text' &&
        ['DEPLOY_TOKEN_SHA256', 'DOWNLOAD_HMAC_KEY_CURRENT'].includes(body.name)) ||
      (method === 'PATCH' && route === '/workers/scripts/' + names.worker + '/script-settings' && Object.keys(body).join() === 'observability' && body.observability.redact_query_string === true),
      'Not an authorized configuration operation');
  }
  const url = 'https://api.cloudflare.com/client/v4/' + (route.startsWith('/user/') ? route.slice(1) : 'accounts/' + account + route);
  const op = { platform: 'Cloudflare', route, method, credentialClass: credential === ci ? 'existing-e-track-ci' : 'local-provisioning-never-exported', startedAt: new Date().toISOString() };
  report.operations.push(op);
  const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
  try {
    const r = await request(url, { dispatcher, method, headers: { Authorization: 'Bearer ' + credential, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined, maxRedirections: 0, headersTimeout: 30000, bodyTimeout: 30000, signal: AbortSignal.timeout(60000) });
    const bytes = Buffer.from(await r.body.arrayBuffer()); assert.ok(bytes.length < 4 * 1024 * 1024);
    const value = JSON.parse(bytes);
    Object.assign(op, { status: r.statusCode, bodySha256: sha(bytes), cfRay: r.headers['cf-ray'], endedAt: new Date().toISOString(), errors: value.errors?.map(e => ({ code: e.code, message: e.message })) });
    if (r.statusCode < 200 || r.statusCode >= 300 || value.success === false) return { denied: true, status: r.statusCode, errors: op.errors };
    return value;
  } catch (error) { op.transportError = error.code || error.name; op.endedAt = new Date().toISOString(); throw Error('Uncertain ' + method + ' ' + route + ': ' + op.transportError); }
  finally { await dispatcher.destroy(); }
}
async function inventory() {
  const workers = await cf('/workers/scripts'); assert.ok(Array.isArray(workers.result));
  const databases = await cf('/d1/database?per_page=100&page=1'); assert.ok(Array.isArray(databases.result));
  assert.equal(databases.result.length, databases.result_info.total_count, 'Pagination incomplete');
  const buckets = await cf('/r2/buckets?per_page=1000'); assert.ok(Array.isArray(buckets.result?.buckets));
  assert.equal(buckets.result.buckets.length, buckets.result_info.total_count, 'Pagination incomplete');
  const found = { worker: workers.result.filter(v => v.id === names.worker), d1: databases.result.filter(v => v.name === names.d1), r2: buckets.result.buckets.filter(v => v.name === names.r2) };
  report.targetInventory = found;
  for (const key of ['worker', 'd1', 'r2']) {
    assert.ok(found[key].length <= 1, 'Ambiguous target');
    if (found[key].length) assert.ok(state.created[key], 'Unknown existing resource: stop before overwrite');
  }
  if (found.d1.length) assert.equal(found.d1[0].uuid, state.created.d1.id);
  return found;
}
function runWrangler(args, input, configuration = configPath, useCredential = true) {
  const token = useCredential ? setup() : ''; sensitive.push(token);
  const env = { ...process.env, CLOUDFLARE_API_TOKEN: token, CLOUDFLARE_ACCOUNT_ID: account,
    CI: '1', NODE_USE_ENV_PROXY: '1', WRANGLER_LOG: 'log', WRANGLER_SEND_METRICS: 'false', WRANGLER_LOG_SANITIZE: 'true',
    WRANGLER_OUTPUT_FILE_DIRECTORY: base, WRANGLER_OUTPUT_FILE_PATH: guard(path.join(base, 'wrangler-' + label + '.ndjson')),
    HTTP_PROXY: 'http://127.0.0.1:7897', HTTPS_PROXY: 'http://127.0.0.1:7897' };
  delete env.GH_TOKEN; delete env.GITHUB_TOKEN;
  const executable = p41 + '/app/bluetooth_flutter_Trace/cloudflare/update-service/worker/node_modules/wrangler/bin/wrangler.js';
  const r = spawnSync(process.execPath, [executable, ...args, '--config', configuration], { cwd: root, env, input,
    encoding: 'utf8', windowsHide: true, timeout: 180000, maxBuffer: 16 * 1024 * 1024 });
  report.operations.push({ platform: 'Wrangler', args, exitCode: r.status, signal: r.signal,
    stdout: redact(r.stdout), stderr: redact(r.stderr), endedAt: new Date().toISOString() });
  assert.equal(r.status, 0, 'Wrangler operation failed; no blind mutation retry');
  return r.stdout;
}
async function main() {
  if (mode === 'build-current') {
    const diff = spawnSync('git', ['diff', '--name-only', '0779f677507fa2c8a88c1799c8d2909bbae5a0a0', '--',
      'app/bluetooth_flutter_Trace/cloudflare/update-service/worker', 'app/bluetooth_flutter_Trace/cloudflare/update-service/scripts/firmware-schema.mjs'],
      { cwd: root, encoding: 'utf8', windowsHide: true });
    assert.equal(diff.status, 0); assert.equal(diff.stdout.trim(), '');
    const config = json(configPath); config.main = path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/worker/src/index.ts');
    const buildConfig = guard(path.join(base, 'current-build.json'));
    fs.writeFileSync(buildConfig, JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
    const folder = guard(path.join(base, 'current-worker'));
    runWrangler(['deploy', '--dry-run', '--outdir', folder], undefined, buildConfig, false);
    const map = json(path.join(folder, 'index.js.map'));
    const verified = [];
    for (let i = 0; i < map.sources.length; i++) {
      if (map.sources[i].includes('node_modules')) continue;
      const source = path.resolve(folder, map.sources[i]); guard(source);
      const current = fs.readFileSync(source, 'utf8').replace(/\r\n/g, '\n');
      assert.equal(current, map.sourcesContent[i].replace(/\r\n/g, '\n'), 'Built source mismatch: ' + path.relative(root, source));
      verified.push({ path: path.relative(root, source).replaceAll('\\', '/'), sha256: sha(Buffer.from(current)) });
    }
    assert.equal(verified.length, 15);
    const bytes = fs.readFileSync(path.join(folder, 'index.js'));
    const runtime = guard(path.join(base, 'current-runtime')); fs.mkdirSync(runtime, { recursive: true });
    fs.writeFileSync(guard(path.join(runtime, 'index.js')), bytes, { flag: 'wx' });
    const deployConfig = json(configPath); deployConfig.main = './current-runtime/index.js';
    fs.writeFileSync(configPath, JSON.stringify(deployConfig, null, 2) + '\n');
    state.currentBundleSha256 = sha(bytes); state.currentSourceCommit = '0779f677507fa2c8a88c1799c8d2909bbae5a0a0';
    state.currentSourceFilesVerified = verified.length; saveState();
    report.build = { sourceCommit: state.currentSourceCommit, bundleSha256: state.currentBundleSha256, sizeBytes: bytes.length, sourceFiles: verified }; return;
  }
  if (mode === 'deploy-current') {
    assert.ok(state.currentBundleSha256 && !state.currentSourceDeployedAt);
    const versions = await cf('/workers/scripts/' + names.worker + '/deployments');
    assert.equal(versions.result?.deployments?.[0]?.versions?.[0]?.version_id, 'f030a990-1d6d-4584-811f-0b6da4b60783', 'Unexpected current version');
    assert.equal(sha(fs.readFileSync(path.resolve(base, json(configPath).main))), state.currentBundleSha256);
    const output = runWrangler(['deploy', '--no-bundle']); assert.ok(!output.includes('accepted-migrations.sql'));
    state.currentSourceDeployedAt = new Date().toISOString(); saveState(); return;
  }
  if (mode === 'inspect') {
    await inventory();
    const subdomain = await cf('/workers/subdomain'); assert.ok(subdomain.result?.subdomain);
    state.origin = 'https://' + names.worker + '.' + subdomain.result.subdomain + '.workers.dev'; saveState();
    const production = gh('environments/firmware-production/secrets');
    report.productionSecrets = production.secrets.map(v => ({ name: v.name, updated_at: v.updated_at }));
    report.productionVariables = gh('environments/firmware-production/variables').variables;
    assert.equal(report.productionVariables.find(v => v.name === 'OTA_BOOT_CHAIN_READY')?.value, 'false');
    report.repoGate = gh('actions/variables/OTA_BOOT_CHAIN_READY').value; assert.equal(report.repoGate, 'false');
    const key = json(authRoot + '/p41-rehearsal-ota-key.json'); sensitive.push(key.keyHex);
    assert.match(key.keyHex, /^[0-9a-fA-F]{32}$/); assert.equal(sha(Buffer.from(key.keyHex, 'hex')), key.keySha256);
    report.aesSource = { file: 'p41-rehearsal-ota-key.json', keyName: key.keyName, createdAt: key.createdAt, integrityVerified: true };
    report.knownProductionCiInputPresent = fs.readFileSync(path.join(root, '.cache/p44/private/production-ci-token.txt'), 'utf8').trim().length > 0;
    return;
  }
  if (mode === 'resources') {
    const found = await inventory();
    if (!found.d1.length) {
      const r = await cf('/d1/database', { method: 'POST', body: { name: names.d1 }, credential: setup() });
      assert.ok(r.result?.uuid, 'D1 create did not return owned identity'); state.created.d1 = { id: r.result.uuid, created_at: r.result.created_at }; saveState();
    }
    if (!found.r2.length) {
      const r = await cf('/r2/buckets', { method: 'POST', body: { name: names.r2 }, credential: setup() });
      assert.ok(r.result && !r.denied, 'R2 create failed'); state.created.r2 = { name: names.r2, created_at: r.result.creation_date }; saveState();
    }
    report.ownedResources = state.created; return;
  }
  if (mode === 'prepare') {
    assert.ok(state.created.d1 && state.created.r2 && state.origin);
    const bundle = fs.readFileSync(p41 + '/.cache/cf-firmware-setup-20261015/worker-bundle/index.js');
    assert.equal(bundle.length, 144770); assert.equal(sha(bundle), '9ff814b0fd1731418a2250a3ae941ff1f6ce0db99233f6f1db42a1ba2c161082');
    fs.writeFileSync(guard(path.join(base, 'index.js')), bundle, { flag: 'wx' });
    const config = { name: names.worker, main: './index.js', account_id: account, compatibility_date: '2026-06-28', compatibility_flags: ['nodejs_compat'], workers_dev: true,
      vars: { ENVIRONMENT: 'prod', APP_ID: 'trace', GITHUB_OWNER: 'Eitan-S-23', GITHUB_REPO: 'E-Track', DOWNLOAD_TOKEN_TTL_SECONDS: '300', DOWNLOAD_TOKEN_KEY_VERSION: 'p44-prod-1',
        FIRMWARE_V2_CUTOVER_EPOCH: '1792039926', ENABLE_DIRECT_ADMIN_API: 'false' },
      d1_databases: [{ binding: 'DB', database_name: names.d1, database_id: state.created.d1.id }], r2_buckets: [{ binding: 'RELEASES_BUCKET', bucket_name: names.r2 }],
      triggers: { crons: ['0 * * * *'] }, observability: { enabled: true, head_sampling_rate: 1, logs: { enabled: true, invocation_logs: true } } };
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
    if (!fs.existsSync(privatePath)) {
      const deploy = crypto.randomBytes(32).toString('base64url'), hmac = crypto.randomBytes(48).toString('base64url');
      sensitive.push(deploy, hmac);
      fs.writeFileSync(privatePath, JSON.stringify({ TRACE_DEPLOY_TOKEN: deploy, DEPLOY_TOKEN_SHA256: sha(deploy), DOWNLOAD_HMAC_KEY_CURRENT: hmac,
        keyVersion: 'p44-prod-1', createdAt: new Date().toISOString() }) + '\n', { flag: 'wx' });
    }
    secretValues();
    report.prepared = { bundleSha256: sha(bundle), privateValuesGeneratedOrReused: true, aesGenerated: false, origin: state.origin,
      bindingScope: 'Firmware-only DB/R2 and scheduled idempotency cleanup; legacy Trace App KV/DO routes are not configured or qualified' };
    return;
  }
  if (mode === 'schema-before' || mode === 'schema-after') {
    const output = runWrangler(['d1', 'execute', names.d1, '--remote', '--command', "SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name; PRAGMA foreign_key_check;", '--json']);
    const result = JSON.parse(output); assert.ok(result.every(v => v.success));
    if (mode === 'schema-before') {
      assert.ok(result[0].results.every(v => ['_cf_KV', 'sqlite_sequence'].includes(v.name)), 'Database not empty');
      state.emptyVerifiedAt = new Date().toISOString(); saveState();
    } else {
      assert.equal(result[1].results.length, 0);
      const { DatabaseSync } = require('node:sqlite'); const db = new DatabaseSync(':memory:');
      try {
        db.exec(fs.readFileSync(path.join(base, 'accepted-migrations.sql'), 'utf8'));
        const normalize = rows => rows.filter(v => v.name !== '_cf_KV').map(v => ({ type: v.type, name: v.name, tbl_name: v.tbl_name, sql: v.sql?.replace(/\r\n/g, '\n') ?? null }));
        assert.deepEqual(normalize(result[0].results), normalize(db.prepare('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').all()));
        report.schemaComparison = 'All sqlite_master rows match accepted SQL; CRLF normalization only';
      } finally { db.close(); }
      report.schemaObjects = result[0].results.length; state.schemaVerifiedAt = new Date().toISOString(); saveState();
    }
    return;
  }
  if (mode === 'schema-import') {
    assert.ok(state.emptyVerifiedAt && !state.schemaImportedAt);
    const files = ['0001_init.sql', '0002_patch_formats.sql', '0003_firmware_releases.sql', '0004_announcements.sql', '0005_firmware_multi_asset.sql'];
    const chunks = [Buffer.from('CREATE TABLE IF NOT EXISTS d1_migrations (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL);\n')];
    report.migrations = files.map(name => {
      const bytes = fs.readFileSync(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/migrations', name));
      chunks.push(bytes, Buffer.from(`\nINSERT INTO d1_migrations (name) VALUES ('${name}');\n`));
      return { name, sizeBytes: bytes.length, sha256: sha(bytes) };
    });
    const file = guard(path.join(base, 'accepted-migrations.sql'));
    if (fs.existsSync(file)) assert.ok(fs.readFileSync(file).equals(Buffer.concat(chunks)), 'Preserved import input changed');
    else fs.writeFileSync(file, Buffer.concat(chunks), { flag: 'wx' });
    runWrangler(['d1', 'execute', names.d1, '--remote', '--file', file, '--yes', '--json']);
    state.schemaImportedAt = new Date().toISOString(); saveState(); return;
  }
  if (mode === 'deploy' || mode === 'redeploy-clean') {
    assert.ok(state.schemaVerifiedAt);
    if (mode === 'deploy') {
      assert.ok(!state.created.worker);
      const existing = await cf('/workers/scripts'); assert.ok(Array.isArray(existing.result)); assert.ok(!existing.result.some(v => v.id === names.worker), 'Worker conflict');
    } else {
      assert.ok(state.created.worker && !state.cleanPackageDeployedAt && !state.workerSecretsWrittenAt);
      const deployments = await cf('/workers/scripts/' + names.worker + '/deployments');
      const latest = deployments.result?.deployments?.[0];
      assert.equal(latest?.versions?.[0]?.version_id, 'e340056f-8393-432a-8199-b1f816f35fdf', 'Unexpected deployment; stop before overwrite');
      const folder = guard(path.join(base, 'bundle')); fs.mkdirSync(folder, { recursive: true });
      const bundle = fs.readFileSync(path.join(base, 'index.js'));
      assert.equal(sha(bundle), '9ff814b0fd1731418a2250a3ae941ff1f6ce0db99233f6f1db42a1ba2c161082');
      fs.writeFileSync(guard(path.join(folder, 'index.js')), bundle, { flag: 'wx' });
      const config = json(configPath); config.main = './bundle/index.js';
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n');
    }
    const output = runWrangler(['deploy', '--no-bundle']);
    if (mode === 'redeploy-clean') {
      assert.ok(!output.includes('accepted-migrations.sql'), 'Unexpected extra deployed module');
      state.cleanPackageDeployedAt = new Date().toISOString();
    }
    state.created.worker = { name: names.worker, deployedAt: new Date().toISOString() }; saveState(); return;
  }
  if (mode === 'worker-secrets') {
    assert.ok(state.created.worker && !state.workerSecretsWrittenAt); const values = secretValues();
    state.workerSecretNames ||= [];
    const route = '/workers/scripts/' + names.worker + '/secrets';
    const existing = await cf(route); assert.ok(Array.isArray(existing.result));
    for (const name of ['DEPLOY_TOKEN_SHA256', 'DOWNLOAD_HMAC_KEY_CURRENT']) {
      if (existing.result.some(v => v.name === name)) { assert.ok(state.workerSecretNames.includes(name), 'Unknown Worker secret; do not overwrite'); continue; }
      const result = await cf(route, { method: 'PUT', body: { name, type: 'secret_text', text: values[name] } });
      assert.ok(result.result && !result.denied, 'Secret configuration failed');
      state.workerSecretNames.push(name); saveState();
    }
    state.workerSecretsWrittenAt = new Date().toISOString(); saveState(); return;
  }
  if (mode === 'log-redact') {
    assert.ok(state.created.worker);
    const route = '/workers/scripts/' + names.worker;
    const before = await cf(route + '/script-settings'); assert.ok(before.result?.observability);
    const settings = await cf(route + '/settings'); assert.ok(settings.result);
    const expected = structuredClone(before.result); expected.observability.redact_query_string = true;
    if (before.result.observability.redact_query_string !== true) {
      const result = await cf(route + '/script-settings', { method: 'PATCH', body: { observability: expected.observability } });
      assert.ok(result.result && !result.denied);
    }
    const after = await cf(route + '/script-settings'); assert.deepEqual(after.result, expected);
    const afterSettings = await cf(route + '/settings'); assert.deepEqual(afterSettings.result.bindings, settings.result.bindings);
    report.redactionReadback = afterSettings.result.observability; state.queryRedactionVerifiedAt = new Date().toISOString(); saveState(); return;
  }
  if (mode === 'github') {
    assert.ok(state.workerSecretsWrittenAt); const values = secretValues(), key = json(authRoot + '/p41-rehearsal-ota-key.json'); sensitive.push(key.keyHex);
    const prefix = 'environments/firmware-production/';
    const secrets = gh(prefix + 'secrets').secrets; const variables = gh(prefix + 'variables').variables;
    assert.equal(variables.find(v => v.name === 'OTA_BOOT_CHAIN_READY')?.value, 'false');
    const desiredSecrets = { CLOUDFLARE_ACCOUNT_ID: account, TRACE_UPDATE_SERVICE_URL: state.origin, TRACE_DEPLOY_TOKEN: values.TRACE_DEPLOY_TOKEN, OTA_AES_KEY: key.keyHex };
    state.githubSecrets ||= [];
    for (const [name, value] of Object.entries(desiredSecrets)) {
      if (secrets.some(v => v.name === name)) { assert.ok(state.githubSecrets.includes(name), 'Unknown existing secret: do not replace'); continue; }
      gh('', { secret: name, value }); state.githubSecrets.push(name); saveState();
    }
    const desiredVariables = { TRACE_R2_BUCKET: names.r2, TRACE_D1_DATABASE_NAME: names.d1, TRACE_D1_DATABASE_ID: state.created.d1.id,
      TRACE_FIRMWARE_MIN_APP_VERSION_CODE: '0', TRACE_FIRMWARE_MIN_PROTOCOL_VERSION: '1' };
    for (const [name, value] of Object.entries(desiredVariables)) {
      const existing = variables.find(v => v.name === name);
      if (existing) { assert.equal(existing.value, value, 'Do not overwrite a conflicting variable'); continue; }
      gh(prefix + 'variables', { body: { name, value } });
    }
    report.ciTokenInstalled = false; report.approvalVariablesInstalled = false; return;
  }
  if (mode === 'ci-discovery') {
    const secrets = gh('environments/firmware-production/secrets').secrets;
    report.productionCiSecretPresent = secrets.some(v => v.name === 'CLOUDFLARE_API_TOKEN');
    report.knownProtectedProductionInputPresent = fs.readFileSync(path.join(root, '.cache/p44/private/production-ci-token.txt'), 'utf8').trim().length > 0;
    const tokens = await cf('/user/tokens', { credential: setup() });
    report.tokenCatalog = tokens.result ? tokens.result.map(t => ({ name: t.name, status: t.status, modified_on: t.modified_on })) : tokens;
    report.creationAttempted = false; report.existingTokenExpanded = false;
    report.next = 'Do not create from guessed policy. Owner must supply a redacted target-scoped policy/source when catalog is unavailable; native-preview Workers Scripts Edit isolation still requires qualification.';
    return;
  }
  if (mode === 'readback') {
    await inventory();
    const settings = await cf('/workers/scripts/' + names.worker + '/settings'); assert.ok(settings.result);
    report.workerSettings = { ...settings.result, bindings: settings.result.bindings.map(v => v.type === 'secret_text' ? { name: v.name, type: v.type } : v) };
    report.workerDeployments = (await cf('/workers/scripts/' + names.worker + '/deployments')).result;
    report.productionSecrets = gh('environments/firmware-production/secrets').secrets;
    report.productionVariables = gh('environments/firmware-production/variables').variables;
    report.productionProtection = gh('environments/firmware-production');
    report.productionBranchPolicies = gh('environments/firmware-production/deployment-branch-policies');
    report.rehearsalGate = gh('environments/firmware-rehearsal/variables/OTA_BOOT_CHAIN_READY').value; assert.equal(report.rehearsalGate, 'false');
    report.repoGate = gh('actions/variables/OTA_BOOT_CHAIN_READY').value; assert.equal(report.repoGate, 'false');
    assert.equal(report.productionVariables.find(v => v.name === 'OTA_BOOT_CHAIN_READY')?.value, 'false');
  }
  if (mode === 'smoke') {
    assert.ok(state.workerSecretsWrittenAt && state.queryRedactionVerifiedAt);
    assert.equal(state.origin, 'https://e-track-firmware-production.tangjichentudou.workers.dev');
    const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
    try {
      const r = await request(state.origin + '/healthz', { dispatcher, method: 'GET', maxRedirections: 0, signal: AbortSignal.timeout(30000) });
      const body = await r.body.json(); report.health = { status: r.statusCode, body, cfRay: r.headers['cf-ray'] };
      assert.equal(r.statusCode, 200); assert.equal(body.environment, 'prod'); assert.equal(body.ok, true);
    } finally { await dispatcher.destroy(); }
    const sql = 'SELECT (SELECT COUNT(*) FROM firmware_releases) AS releases, (SELECT COUNT(*) FROM firmware_release_assets) AS assets, (SELECT COUNT(*) FROM firmware_channels) AS channels, (SELECT COUNT(*) FROM firmware_releases_legacy) AS legacy_releases, (SELECT COUNT(*) FROM audit_logs) AS audit_logs; SELECT name FROM d1_migrations ORDER BY id;';
    const output = runWrangler(['d1', 'execute', names.d1, '--remote', '--command', sql, '--json']);
    const rows = JSON.parse(output); assert.ok(rows.every(r => r.success && r.meta.rows_written === 0));
    assert.ok(Object.values(rows[0].results[0]).every(v => v === 0), 'Unexpected business rows');
    assert.equal(rows[1].results.length, 5); report.businessCounts = rows[0].results[0]; report.appliedMigrations = rows[1].results; return;
  }
}
main().catch(error => { report.error = { name: error.name, message: redact(error.message) }; process.exitCode = 1; }).finally(() => {
  report.endedAt = new Date().toISOString();
  const output = redact(JSON.stringify(report, null, 2)) + '\n'; guard(receiptPath); fs.writeFileSync(receiptPath, output, { flag: 'wx' });
  process.stdout.write(output);
});
