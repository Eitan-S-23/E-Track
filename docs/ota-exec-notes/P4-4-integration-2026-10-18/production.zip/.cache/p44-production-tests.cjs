const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { root } = require('./p44-run.cjs');
const read = p => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const config = read('.cache/p44/production/wrangler.json');
const state = read('.cache/p44/production/state.json');
const values = read('.cache/p44/private/production-secrets.json');
const originalRoot = 'D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/';
const testSecrets = JSON.parse(fs.readFileSync(originalRoot + 'firmware-test-secrets.json', 'utf8'));
const aes = JSON.parse(fs.readFileSync(originalRoot + 'p41-rehearsal-ota-key.json', 'utf8'));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

test('owned production DB and R2 are distinct from both staging targets', () => {
  assert.equal(config.name, 'e-track-firmware-production');
  assert.equal(config.d1_databases[0].database_id, state.created.d1.id);
  assert.notEqual(state.created.d1.id, '2617e1e1-956f-42ce-a465-da56d84abf06');
  assert.notEqual(state.created.d1.id, '0133ad9e-d4a2-4fef-a659-4f2bf3d3a645');
  assert.equal(config.r2_buckets[0].bucket_name, 'e-track-firmware-production-releases');
});
test('firmware identity, fixed cutover and origin are explicit', () => {
  assert.equal(config.vars.ENVIRONMENT, 'prod');
  assert.equal(config.vars.GITHUB_REPO, 'E-Track');
  assert.equal(config.vars.FIRMWARE_V2_CUTOVER_EPOCH, '1792039926');
  assert.equal(state.origin, 'https://e-track-firmware-production.tangjichentudou.workers.dev');
  assert.equal(config.vars.ENABLE_DIRECT_ADMIN_API, 'false');
});
test('accepted Worker module is isolated from SQL and private files', () => {
  const entry = path.resolve(root, '.cache/p44/production', config.main);
  assert.deepEqual(fs.readdirSync(path.dirname(entry)), ['index.js']);
  assert.equal(sha(fs.readFileSync(entry)), 'ba2d5b526f2a423426ec985844a5ca89233506f9225bf5dbf56b03f19cddf5f8');
  assert.ok(state.currentSourceDeployedAt);
});
test('final module binds all current accepted project sources', () => {
  const build = read('.cache/p44/evidence/production-current-build-01.json').build;
  assert.equal(build.sourceCommit, '0779f677507fa2c8a88c1799c8d2909bbae5a0a0');
  assert.equal(build.sourceFiles.length, 15);
  for (const source of build.sourceFiles) {
    assert.equal(sha(Buffer.from(fs.readFileSync(path.join(root, source.path), 'utf8').replace(/\r\n/g, '\n'))), source.sha256);
  }
});
test('new deploy digest pairs with an independent generated token', () => {
  assert.ok(/^[A-Za-z0-9_-]{43}$/.test(values.TRACE_DEPLOY_TOKEN));
  assert.ok(sha(values.TRACE_DEPLOY_TOKEN) === values.DEPLOY_TOKEN_SHA256, 'Deploy pairing mismatch');
  assert.ok(values.TRACE_DEPLOY_TOKEN !== testSecrets.TRACE_DEPLOY_TOKEN, 'Test deploy token must not be reused');
});
test('new HMAC and key version are independent with no invented previous pair', () => {
  assert.ok(/^[A-Za-z0-9_-]{64}$/.test(values.DOWNLOAD_HMAC_KEY_CURRENT));
  assert.ok(values.DOWNLOAD_HMAC_KEY_CURRENT !== testSecrets.DOWNLOAD_HMAC_KEY_CURRENT, 'Test HMAC must not be reused');
  assert.equal(config.vars.DOWNLOAD_TOKEN_KEY_VERSION, 'p44-prod-1');
  assert.equal(values.keyVersion, config.vars.DOWNLOAD_TOKEN_KEY_VERSION);
  assert.equal(values.DOWNLOAD_HMAC_KEY_PREVIOUS, undefined);
  assert.equal(config.vars.DOWNLOAD_TOKEN_PREVIOUS_KEY_VERSION, undefined);
});
test('approved AES source is unchanged and internally hash-bound', () => {
  assert.ok(/^[a-fA-F0-9]{32}$/.test(aes.keyHex));
  assert.ok(sha(Buffer.from(aes.keyHex, 'hex')) === aes.keySha256, 'Protected AES source integrity failed');
  assert.equal(aes.createdAt, '2026-10-16T04:24:30.210Z');
});
test('live schema comparison and query redaction receipts are present', () => {
  const schema = read('.cache/p44/evidence/production-schema-after-01.json');
  assert.equal(schema.schemaObjects, 120);
  assert.equal(schema.error, undefined);
  const redact = read('.cache/p44/evidence/production-current-redact-01.json');
  assert.equal(redact.redactionReadback.redact_query_string, true);
});
test('production secret metadata does not claim runtime value verification', () => {
  const result = read('.cache/p44/evidence/production-readback-02.json');
  assert.equal(result.error, undefined);
  assert.deepEqual(result.productionSecrets.map(v => v.name).sort(), ['CLOUDFLARE_ACCOUNT_ID', 'OTA_AES_KEY', 'TRACE_DEPLOY_TOKEN', 'TRACE_UPDATE_SERVICE_URL']);
  assert.equal(result.repoGate, 'false');
  assert.equal(result.productionVariables.find(v => v.name === 'OTA_BOOT_CHAIN_READY').value, 'false');
  assert.equal(result.productionProtection.protection_rules.find(v => v.type === 'required_reviewers').prevent_self_review, true);
  assert.ok(!result.productionVariables.some(v => v.name.startsWith('OTA_APPROVED_')), 'Do not invent protected approvals');
});
test('production read-only smoke leaves the firmware business tables empty', () => {
  const result = read('.cache/p44/evidence/production-smoke-02.json');
  assert.equal(result.health.status, 200);
  assert.equal(result.health.body.environment, 'prod');
  assert.ok(Object.values(result.businessCounts).every(v => v === 0));
  assert.equal(result.appliedMigrations.length, 5);
});
test('controlled logs and redacted receipts contain no actual credential values', () => {
  const known = [values.TRACE_DEPLOY_TOKEN, values.DEPLOY_TOKEN_SHA256, values.DOWNLOAD_HMAC_KEY_CURRENT, aes.keyHex,
    fs.readFileSync(originalRoot + 'p41-ci-token.txt', 'utf8').trim(), fs.readFileSync(originalRoot + 'token.txt', 'utf8').trim()];
  for (const folder of ['logs', 'evidence']) {
    for (const file of fs.readdirSync(path.join(root, '.cache/p44', folder))) {
      if (!(file.startsWith('p44-prod-') || file.startsWith('production-'))) continue;
      const bytes = fs.readFileSync(path.join(root, '.cache/p44', folder, file));
      assert.ok(!known.some(value => bytes.includes(Buffer.from(value))), 'Credential exposure in ' + file);
    }
  }
});
