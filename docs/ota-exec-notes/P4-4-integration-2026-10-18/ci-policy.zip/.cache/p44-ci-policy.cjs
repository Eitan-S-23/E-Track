const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { root, guard } = require('./p44-run.cjs');
const { ProxyAgent, request } = require('D:/github/my/E-Track/.cache/p4-3-implementation-20261017/app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici');

// Public documentation only. This helper never loads credentials or calls APIs.
const [label, url] = process.argv.slice(2);
assert.match(label || '', /^[a-z0-9-]+$/);
const parsed = new URL(url);
assert.ok(['https://developers.cloudflare.com', 'https://raw.githubusercontent.com'].includes(parsed.origin));
assert.ok(!parsed.username && !parsed.password && !parsed.search && !parsed.hash);
if (parsed.origin === 'https://raw.githubusercontent.com') assert.ok(parsed.pathname.startsWith('/cloudflare/'));
const directory = guard(path.join(root, '.cache/p44/ci-policy'));
const bodyPath = guard(path.join(directory, label + '.txt'));
const receiptPath = guard(path.join(directory, label + '.json'));
assert.ok(!fs.existsSync(bodyPath) && !fs.existsSync(receiptPath), 'Preserve original observations');
fs.mkdirSync(directory, { recursive: true });
const receipt = { url, method: 'GET', startedAt: new Date().toISOString(), credentialUse: false };
const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
(async () => {
  try {
    const response = await request(url, { dispatcher, headers: { accept: 'text/markdown' },
      maxRedirections: 0, headersTimeout: 30000, bodyTimeout: 30000, signal: AbortSignal.timeout(60000) });
    const chunks = [];
    let size = 0;
    for await (const chunk of response.body) {
      size += chunk.length;
      assert.ok(size <= 4 * 1024 * 1024, 'Public document exceeds bounded capture');
      chunks.push(chunk);
    }
    const bytes = Buffer.concat(chunks);
    Object.assign(receipt, { status: response.statusCode, contentType: response.headers['content-type'],
      location: response.headers.location, bytes: bytes.length,
      sha256: crypto.createHash('sha256').update(bytes).digest('hex') });
    fs.writeFileSync(bodyPath, bytes, { flag: 'wx' });
    if (response.statusCode !== 200) process.exitCode = 1;
  } catch (error) {
    receipt.error = error.code || error.name;
    process.exitCode = 1;
  } finally {
    await dispatcher.destroy();
    receipt.endedAt = new Date().toISOString();
    fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
    process.stdout.write(JSON.stringify(receipt) + '\n');
  }
})();
