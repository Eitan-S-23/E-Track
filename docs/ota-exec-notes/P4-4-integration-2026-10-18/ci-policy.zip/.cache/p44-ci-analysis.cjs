const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const output = guard(path.join(root, '.cache/p44/ci-policy/source-analysis.json'));
assert.ok(!fs.existsSync(output));
const main = '0779f677507fa2c8a88c1799c8d2909bbae5a0a0';
const base = 'app/bluetooth_flutter_Trace/cloudflare/update-service/';
const files = ['.github/workflows/firmware-build.yml', '.github/scripts/firmware-release.mjs',
  base + 'scripts/upload-firmware-r2-asset.mjs', base + 'scripts/firmware-release-pipeline.mjs',
  base + 'worker/package-lock.json'];
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const normalize = bytes => bytes.toString('utf8').replaceAll('\r\n', '\n');
const sources = files.map(file => {
  const bytes = fs.readFileSync(path.join(root, file));
  const committed = spawnSync('git', ['--no-optional-locks', 'show', main + ':' + file], { cwd: root, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
  assert.equal(committed.status, 0);
  assert.equal(normalize(bytes), normalize(committed.stdout), 'Product source changed');
  return { path: file, bytes: bytes.length, sha256: hash(bytes), matchesMainNormalized: true };
});
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const uploader = read(files[2]);
const pipeline = read(files[3]);
const installed = 'D:/github/my/E-Track/.cache/p41-dev-20261015/' + base + 'worker/node_modules/wrangler/';
const cliBytes = fs.readFileSync(installed + 'wrangler-dist/cli.js');
const cli = cliBytes.toString('utf8');
const version = JSON.parse(fs.readFileSync(installed + 'package.json', 'utf8')).version;
const locked = JSON.parse(read(files[4])).packages['node_modules/wrangler'].version;
const docs = name => read('.cache/p44/ci-policy/' + name + '.txt');
const checks = [];
function check(name, condition) { assert.ok(condition, name); checks.push({ name, result: 'OBSERVED' }); }
check('Installed Wrangler matches the committed version', version === '4.105.0' && locked === version);
check('Uploader requires explicit CF token and remote R2/D1 proxy', uploader.includes('"CLOUDFLARE_API_TOKEN"') && uploader.includes('remoteBindings: true') && uploader.includes('name: "trace-firmware-uploader"'));
check('Uploader methods are conditional put, head and get', ['bucket.put(', 'bucket.head(', 'bucket.get(', 'etagDoesNotMatch: "*"'].every(value => uploader.includes(value)) && !uploader.includes('bucket.delete('));
check('D1 publication preflight selects rather than updates business rows', pipeline.includes('SELECT COUNT(*)') && pipeline.includes('SELECT MAX(version_code)') && pipeline.includes('SELECT version_code,registration_json'));
check('Pinned SDK uses account preview and a named preview upload', cli.includes('/workers/subdomain/edge-preview') && cli.includes('/workers/scripts/${worker.name}/edge-preview') && cli.includes('workerName: workerConfigObject.name'));
check('Official subdomain API requires Scripts Read or Write', docs('worker-subdomain-api').includes('`Workers Scripts Write``Workers Scripts Read`'));
check('Ordinary token account resource and R2 bucket exception are documented', docs('create-via-api').includes('API token policies support three resource types') && docs('r2-tokens').includes('com.cloudflare.edge.r2.bucket.<ACCOUNT_ID>'));
check('R2 object permissions are S3-only, not REST', docs('r2-tokens').includes('permissions are only supported by the [S3-compatible API]'));
const lines = cli.split('\n');
const ranges = [[145215, 145259], [208743, 208835], [355137, 355164], [355277, 355311]];
const result = { observedAt: new Date().toISOString(), nature: 'Static source/document reconciliation, not runtime permission validation',
  sourceMain: main, sources, wrangler: { version, sha256: hash(cliBytes), bytes: cliBytes.length,
    readOnlyInput: installed + 'wrangler-dist/cli.js', excerpts: ranges.map(([first, last]) => ({ first, last, text: lines.slice(first - 1, last).join('\n') })) },
  checks, policyDecision: 'No token policy created: at least one required cold-session API needs an account-scoped permission; exact-target token boundary is not met by the documented ordinary token route.',
  previewMinimumPermissionSet: 'NOT_ESTABLISHED; do not infer it from the distinct permanent-module upload API',
  tokenCreationAttempted: false, runtimeSessionStarted: false, productEdits: false };
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ sourcesCompared: sources.length, staticChecks: checks.length, version, tokenCreationAttempted: false }) + '\n');
