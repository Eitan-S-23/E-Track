const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { root, guard } = require('./p44-run.cjs');
const { ProxyAgent, request } = require('D:/github/my/E-Track/.cache/p4-3-implementation-20261017/app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici');
const p41 = 'D:/github/my/E-Track/.cache/p41-dev-20261015';
const account = JSON.parse(fs.readFileSync(p41 + '/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8')).account_id;
assert.equal(crypto.createHash('sha256').update(account).digest('hex'), '01910e669500c221e2154f608e9f4e856b0a08297026e1ea98f1d18dd8cf9742');
const token = fs.readFileSync(p41 + '/.cache/cf-auth-input/token.txt', 'utf8').trim();
assert.ok(token && !/\s/.test(token));
const output = guard(path.join(root, '.cache/p44/ci-policy/account-permission-groups.json'));
assert.ok(!fs.existsSync(output));
const report = { method: 'GET', route: '/accounts/{approved-account}/tokens/permission_groups',
  startedAt: new Date().toISOString(), credential: 'Existing local provisioning input, never exported',
  mutations: 0, tokenCreationAttempted: false };
const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
(async () => {
  try {
    const response = await request('https://api.cloudflare.com/client/v4/accounts/' + account + '/tokens/permission_groups', {
      method: 'GET', dispatcher, headers: { authorization: 'Bearer ' + token }, maxRedirections: 0,
      headersTimeout: 30000, bodyTimeout: 30000, signal: AbortSignal.timeout(60000) });
    const chunks = []; let size = 0;
    for await (const chunk of response.body) { size += chunk.length; assert.ok(size <= 2 * 1024 * 1024); chunks.push(chunk); }
    const bytes = Buffer.concat(chunks);
    report.status = response.statusCode;
    report.bodySha256 = crypto.createHash('sha256').update(bytes).digest('hex');
    report.cfRay = response.headers['cf-ray'];
    const body = JSON.parse(bytes);
    report.success = body.success;
    report.errorCodes = body.errors?.map(e => e.code);
    if (Array.isArray(body.result)) {
      report.totalGroups = body.result.length;
      report.relevantGroups = body.result.filter(g => /Workers|\bD1\b|\bR2\b|API Tokens/i.test(g.name || ''))
        .map(g => ({ id: g.id, name: g.name, scopes: g.scopes, is_selectable: g.is_selectable }));
    }
  } catch (error) {
    report.error = error.code || error.name;
    process.exitCode = 1;
  } finally {
    await dispatcher.destroy();
    report.endedAt = new Date().toISOString();
    const text = JSON.stringify(report, null, 2) + '\n';
    assert.ok(!text.includes(token) && !text.includes(account), 'Refuse unsafe receipt');
    fs.writeFileSync(output, text, { flag: 'wx' });
    process.stdout.write(text);
  }
})();
