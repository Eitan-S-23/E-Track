const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const reportPath = guard(path.join(root, '.cache/p44/evidence/production-protection-01.json'));
assert.ok(!fs.existsSync(reportPath), 'Single-use configuration operation');
const env = { ...process.env, GH_CONFIG_DIR: 'C:/Users/SU/AppData/Roaming/GitHub CLI', GH_NO_UPDATE_NOTIFIER: '1', GH_PROMPT_DISABLED: '1' };
delete env.GH_TOKEN; delete env.GITHUB_TOKEN;
const auth = spawnSync('gh', ['auth', 'token', '--hostname', 'github.com', '--user', 'Eitan-S-23'], { cwd: root, env, encoding: 'utf8', timeout: 30000, windowsHide: true });
assert.equal(auth.status, 0); env.GH_TOKEN = auth.stdout.trim();
const report = { startedAt: new Date().toISOString(), authority: 'P4-4 full implementation delegation, 2026-10-18',
  target: 'Eitan-S-23/E-Track:firmware-production', reviewerBasis: 'Existing sole repository owner and existing protected-environment reviewer; no agent approval',
  productionExecution: 'NOT_RUN', operations: [] };
function api(method, route, body) {
  const args = ['api', 'repos/Eitan-S-23/E-Track/' + route, '--method', method];
  if (body) args.push('--input', '-');
  const startedAt = new Date().toISOString();
  const result = spawnSync('gh', args, { cwd: root, env, input: body ? JSON.stringify(body) : undefined,
    encoding: 'utf8', timeout: 45000, windowsHide: true, maxBuffer: 2 * 1024 * 1024 });
  let response = null;
  try { response = result.stdout.trim() ? JSON.parse(result.stdout) : null; } catch { throw Error('Unparseable API response; do not blindly retry: ' + route); }
  report.operations.push({ method, route, request: body, startedAt, endedAt: new Date().toISOString(), exitCode: result.status, response });
  assert.equal(result.status, 0, 'Uncertain/failed API operation; preserve receipt and reconcile before retry');
  return response;
}
try {
  const before = api('GET', 'environments');
  assert.ok(!before.environments.some(item => item.name === 'firmware-production'), 'Do not overwrite existing settings');
  const collaborators = api('GET', 'collaborators?per_page=100');
  assert.ok(collaborators.some(item => item.login === 'Eitan-S-23' && item.id === 204050265 && item.permissions.admin));
  api('PUT', 'environments/firmware-production', { wait_timer: 0, prevent_self_review: true,
    reviewers: [{ type: 'User', id: 204050265 }], deployment_branch_policy: { protected_branches: false, custom_branch_policies: true } });
  api('POST', 'environments/firmware-production/deployment-branch-policies', { name: 'main', type: 'branch' });
  api('POST', 'environments/firmware-production/variables', { name: 'OTA_BOOT_CHAIN_READY', value: 'false' });
  const variables = api('GET', 'actions/variables');
  const gate = variables.variables.find(item => item.name === 'OTA_BOOT_CHAIN_READY');
  if (!gate) api('POST', 'actions/variables', { name: 'OTA_BOOT_CHAIN_READY', value: 'false' });
  else assert.equal(gate.value, 'false', 'Do not silently rewrite an unexpected owner setting');
  const after = api('GET', 'environments/firmware-production');
  const rule = after.protection_rules.find(item => item.type === 'required_reviewers');
  assert.equal(rule.prevent_self_review, true);
  assert.deepEqual(rule.reviewers.map(item => item.reviewer.login), ['Eitan-S-23']);
  const branches = api('GET', 'environments/firmware-production/deployment-branch-policies');
  assert.deepEqual(branches.branch_policies.map(item => [item.name, item.type]), [['main', 'branch']]);
  assert.equal(api('GET', 'environments/firmware-production/variables').variables.find(item => item.name === 'OTA_BOOT_CHAIN_READY').value, 'false');
  assert.equal(api('GET', 'actions/variables').variables.find(item => item.name === 'OTA_BOOT_CHAIN_READY').value, 'false');
  report.configurationReadback = 'PASS';
  report.remaining = ['Production resource identity and independent dedicated credential', 'Secret/runtime verification', 'Real rejection event and role coverage'];
} catch (error) { report.error = error.message; process.exitCode = 1; }
finally {
  report.endedAt = new Date().toISOString();
  // Only public GitHub configuration metadata is retained; credentials are never output.
  const output = JSON.stringify(report, null, 2).split(env.GH_TOKEN).join('[REDACTED]') + '\n';
  guard(reportPath); fs.mkdirSync(path.dirname(reportPath), { recursive: true });
  fs.writeFileSync(reportPath, output, { flag: 'wx' });
  process.stdout.write(JSON.stringify({ path: reportPath, configurationReadback: report.configurationReadback, error: report.error, operations: report.operations.map(({ method, route, exitCode }) => ({ method, route, exitCode })) }, null, 2) + '\n');
}
