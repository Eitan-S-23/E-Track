const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { root, guard } = require('./p44-run.cjs');
const { ProxyAgent, request } = require('D:/github/my/E-Track/.cache/p4-3-implementation-20261017/app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici');
const p41 = 'D:/github/my/E-Track/.cache/p41-dev-20261015';
const p43 = 'D:/github/my/E-Track/.cache/p4-3-implementation-20261017';
const repo = 'Eitan-S-23/E-Track';
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const authRoot = p41 + '/.cache/cf-auth-input';
const account = json(p41 + '/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json').account_id;
assert.equal(sha(account), '01910e669500c221e2154f608e9f4e856b0a08297026e1ea98f1d18dd8cf9742');
const ciToken = fs.readFileSync(authRoot + '/p41-ci-token.txt', 'utf8').trim();
const sensitive = [ciToken, account];
const [mode, label] = process.argv.slice(2);
assert.ok(['inventory', 'capability', 'targets', 'r2-only', 'auth-negative'].includes(mode));
assert.match(label || '', /^[a-z0-9-]+$/);
const out = guard(path.join(root, '.cache/p44/evidence', label + '.json'));
assert.ok(!fs.existsSync(out), 'Never overwrite evidence');
const report = { label, startedAt: new Date().toISOString(), mode, mutations: 0,
  source: spawnSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).stdout.trim(), requests: [] };

function gh(route) {
  const env = { ...process.env, GH_CONFIG_DIR: 'C:/Users/SU/AppData/Roaming/GitHub CLI', GH_NO_UPDATE_NOTIFIER: '1', GH_PROMPT_DISABLED: '1' };
  delete env.GH_TOKEN; delete env.GITHUB_TOKEN;
  const auth = spawnSync('gh', ['auth', 'token', '--hostname', 'github.com', '--user', 'Eitan-S-23'], { cwd: root, env, encoding: 'utf8', windowsHide: true, timeout: 30000 });
  assert.equal(auth.status, 0, 'Existing owner authentication unavailable');
  env.GH_TOKEN = auth.stdout.trim(); sensitive.push(env.GH_TOKEN);
  env.GH_CONFIG_DIR = guard(path.join(root, '.cache/p44/gh'));
  const startedAt = new Date().toISOString();
  const result = spawnSync('gh', ['api', 'repos/' + repo + '/' + route], { cwd: root, env, encoding: 'utf8', windowsHide: true, timeout: 45000, maxBuffer: 4 * 1024 * 1024 });
  const receipt = { platform: 'GitHub', method: 'GET', route, startedAt, endedAt: new Date().toISOString(), exitCode: result.status, signal: result.signal, bodySha256: sha(result.stdout || '') };
  report.requests.push(receipt);
  let body;
  try { body = JSON.parse(result.stdout); } catch { receipt.transportError = true; throw Error('GitHub response unavailable: ' + route); }
  if (result.status !== 0) { receipt.status = body.status; return { unavailable: true, status: body.status }; }
  return body;
}
async function cf(suffix, token = ciToken) {
  const url = suffix.startsWith('user/') ? 'https://api.cloudflare.com/client/v4/' + suffix
    : 'https://api.cloudflare.com/client/v4/accounts/' + account + '/' + suffix;
  return http(url, { Authorization: 'Bearer ' + token }, suffix);
}
async function http(url, headers, route) {
  assert.ok(['https://api.cloudflare.com', 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev', 'https://e-track-firmware-p43-admin-test.pages.dev'].includes(new URL(url).origin));
  const receipt = { platform: 'Cloudflare', route, method: 'GET', startedAt: new Date().toISOString() };
  report.requests.push(receipt);
  const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
  try {
    const r = await request(url, { dispatcher, method: 'GET', headers, maxRedirections: 0, headersTimeout: 30000, bodyTimeout: 30000, signal: AbortSignal.timeout(60000) });
    let bytes = Buffer.alloc(0);
    for await (const chunk of r.body) { bytes = Buffer.concat([bytes, chunk]); assert.ok(bytes.length <= 4 * 1024 * 1024); }
    Object.assign(receipt, { status: r.statusCode, endedAt: new Date().toISOString(), sizeBytes: bytes.length, bodySha256: sha(bytes), cfRay: r.headers['cf-ray'] });
    if (r.statusCode === 302) return { status: 302, locationOrigin: new URL(r.headers.location).origin };
    let body; try { body = JSON.parse(bytes); } catch { return { status: r.statusCode, json: false }; }
    if (r.statusCode !== 200) return { unavailable: true, status: r.statusCode, codes: body.errors?.map(item => item.code) };
    return body;
  } catch (error) {
    receipt.networkError = error.code || error.name; receipt.endedAt = new Date().toISOString();
    return { unavailable: true, networkError: receipt.networkError };
  } finally { await dispatcher.destroy(); }
}

async function main() {
  if (mode === 'auth-negative') {
    const inventory = json(path.join(root, '.cache/p44/evidence/targets-01.json'));
    assert.equal(inventory.workers.matches.find(item => item.id === 'e-track-firmware-p41-test')?.etag,
      'e106f789a1385841130cc67dd462b33c1031d0bc89871b1f751b1c0d973f39bc');
    report.purpose = 'Two bounded test-Worker authentication denials; no real deploy credential or valid registration body';
    report.mutations = 'No successful business mutation requested; two expected-denied POSTs, normal request telemetry possible';
    report.expected = { status: 401, errorCode: 'TOKEN_INVALID', requestIdEcho: true };
    report.sourceFiles = ['firmware.ts', 'crypto.ts'].map(name => ({ path: 'app/bluetooth_flutter_Trace/cloudflare/update-service/worker/src/' + name,
      sha256: sha(fs.readFileSync(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/worker/src', name))) }));
    for (const testCase of ['missing-deploy-token', 'wrong-deploy-token']) {
      const requestId = crypto.randomUUID();
      const receipt = { platform: 'TestWorker', method: 'POST', route: '/api/ci/firmware/releases',
        testCase, requestId, startedAt: new Date().toISOString(), bodyClass: 'Empty JSON object, invalid registration metadata' };
      report.requests.push(receipt);
      const dispatcher = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
      try {
        const response = await request('https://e-track-firmware-p41-test.tangjichentudou.workers.dev/api/ci/firmware/releases', {
          dispatcher, method: 'POST', maxRedirections: 0, headersTimeout: 30000, bodyTimeout: 30000,
          signal: AbortSignal.timeout(60000), body: '{}', headers: { 'Content-Type': 'application/json', 'X-Request-Id': requestId,
            ...(testCase === 'wrong-deploy-token' ? { Authorization: 'Bearer p44-invalid-probe-not-a-real-secret' } : {}) } });
        const bytes = await response.body.arrayBuffer();
        assert.ok(bytes.byteLength <= 8192, 'Unexpected auth response size');
        const body = JSON.parse(Buffer.from(bytes));
        Object.assign(receipt, { status: response.statusCode, errorCode: body.errorCode,
          bodySha256: sha(Buffer.from(bytes)), responseRequestId: body.requestId,
          headerRequestId: response.headers['x-request-id'], cfRay: response.headers['cf-ray'], endedAt: new Date().toISOString() });
        assert.equal(receipt.status, 401, 'Unexpected result: stop, do not retry or supply a valid body');
        assert.equal(receipt.errorCode, 'TOKEN_INVALID');
        assert.equal(receipt.responseRequestId, requestId);
        assert.equal(receipt.headerRequestId, requestId);
      } finally { await dispatcher.destroy(); }
    }
    report.authDenialsObserved = 2;
    return;
  }
  if (mode === 'r2-only') {
    report.purpose = 'Retry only the transport-failed read-only R2 list; no successful operation replay';
    const response = await cf('r2/buckets?per_page=1000');
    report.r2 = response.result ? { returnedCount: response.result.buckets?.length, pagination: response.result_info,
      matches: response.result.buckets?.filter(item => /^(?:e-track-firmware|trace-update)/.test(item.name))
        .map(item => ({ name: item.name, creation_date: item.creation_date, location: item.location })) } : response;
    return;
  }
  if (mode === 'targets') {
    report.purpose = 'Current project resource/configuration discovery using existing e-track-ci; GET only, no token-management probes';
    const projectName = name => /^(?:e-track-firmware|trace-update)/.test(name || '');
    const scripts = await cf('workers/scripts');
    report.workers = scripts.result ? { returnedCount: scripts.result.length, pagination: scripts.result_info,
      matches: scripts.result.filter(item => projectName(item.id)).map(item => ({ id: item.id, etag: item.etag, modified_on: item.modified_on })) } : scripts;
    report.d1 = await cf('d1/database?per_page=100&page=1');
    if (report.d1.result) report.d1 = { returnedCount: report.d1.result.length,
      pagination: report.d1.result_info, firstPageOnly: true,
      matches: report.d1.result.filter(item => projectName(item.name)).map(item => ({ name: item.name, uuid: item.uuid, created_at: item.created_at, version: item.version })) };
    report.r2 = await cf('r2/buckets?per_page=1000');
    if (report.r2.result) report.r2 = { returnedCount: report.r2.result.buckets?.length,
      pagination: report.r2.result_info, firstPageOnly: true,
      matches: report.r2.result.buckets?.filter(item => projectName(item.name)).map(item => ({ name: item.name, creation_date: item.creation_date, location: item.location })) };
    const safeVars = new Set(['ENVIRONMENT', 'APP_ID', 'GITHUB_OWNER', 'GITHUB_REPO',
      'FIRMWARE_V2_CUTOVER_EPOCH', 'DOWNLOAD_TOKEN_KEY_VERSION', 'DOWNLOAD_TOKEN_TTL_SECONDS', 'ENABLE_DIRECT_ADMIN_API']);
    report.settings = [];
    for (const worker of report.workers.matches || []) {
      const response = await cf('workers/scripts/' + worker.id + '/settings');
      report.settings.push({ id: worker.id, ...(response.result ? { bindings: response.result.bindings.map(binding => ({ name: binding.name, type: binding.type,
        ...(binding.type === 'plain_text' && safeVars.has(binding.name) ? { text: binding.text } : {}),
        ...(binding.type === 'd1' ? { databaseId: binding.id } : {}),
        ...(binding.type === 'r2_bucket' ? { bucketName: binding.bucket_name } : {}) })), observability: response.result.observability } : response) });
    }
    report.github = {};
    const safeVariables = new Set(['OTA_BOOT_CHAIN_READY', 'TRACE_R2_BUCKET', 'TRACE_D1_DATABASE_ID', 'TRACE_D1_DATABASE_NAME']);
    for (const name of ['firmware-rehearsal', 'firmware-production']) {
      const base = 'environments/' + name;
      const environment = gh(base), secrets = gh(base + '/secrets'), variables = gh(base + '/variables');
      report.github[name] = { updated_at: environment.updated_at, protection_rules: environment.protection_rules?.map(rule => ({ type: rule.type,
        prevent_self_review: rule.prevent_self_review, reviewers: rule.reviewers?.map(item => ({ type: item.type, login: item.reviewer.login })) })),
        can_admins_bypass: environment.can_admins_bypass, deployment_branch_policy: environment.deployment_branch_policy,
        branchPolicies: gh(base + '/deployment-branch-policies'), secrets: secrets.secrets?.map(item => ({ name: item.name, updated_at: item.updated_at })),
        variables: variables.variables?.map(item => ({ name: item.name, updated_at: item.updated_at,
          ...(safeVariables.has(item.name) ? { value: item.value } : { valueSha256: sha(item.value) }) })) };
    }
    report.github.repositoryGate = gh('actions/variables/OTA_BOOT_CHAIN_READY');
    report.pages = await cf('pages/projects/e-track-firmware-p43-admin-test');
    if (report.pages.result) report.pages = { configured: true, deploymentId: report.pages.result.canonical_deployment?.id,
      source: report.pages.result.canonical_deployment?.deployment_trigger?.metadata?.commit_hash,
      environmentNames: Object.keys(report.pages.result.deployment_configs || {}) };
    return;
  }
  if (mode === 'capability') {
    report.purpose = 'Read-only qualification of a separate production CI credential route; no token creation or scope change';
    report.ciPermissionCatalog = await cf('user/tokens/permission_groups');
    if (report.ciPermissionCatalog.result) report.ciPermissionCatalog = { success: true,
      groups: report.ciPermissionCatalog.result.map(item => ({ id: item.id, name: item.name, scopes: item.scopes })) };
    const provisioning = fs.readFileSync(authRoot + '/token.txt', 'utf8').trim();
    sensitive.push(provisioning);
    const verified = await cf('user/tokens/verify', provisioning);
    report.localProvisioning = { active: verified.result?.status === 'active', neverExportedToCI: true };
    if (verified.result?.id) report.localProvisioning.selfPolicy = await cf('user/tokens/' + verified.result.id, provisioning);
    report.localProvisioning.permissionCatalog = await cf('user/tokens/permission_groups', provisioning);
    if (report.localProvisioning.selfPolicy?.result) report.localProvisioning.selfPolicy = { readable: true };
    if (report.localProvisioning.permissionCatalog?.result) report.localProvisioning.permissionCatalog = { readable: true };
    return;
  }
  const environments = gh('environments');
  report.github = { environments: environments.environments?.map(item => ({ name: item.name, updated_at: item.updated_at,
    protection_rules: item.protection_rules.map(rule => ({ type: rule.type, prevent_self_review: rule.prevent_self_review,
      reviewers: rule.reviewers?.map(reviewer => ({ type: reviewer.type, login: reviewer.reviewer.login, id: reviewer.reviewer.id })) })),
    deployment_branch_policy: item.deployment_branch_policy })), repositorySecrets: gh('actions/secrets'),
    repositoryVariables: gh('actions/variables') };
  for (const name of ['firmware-rehearsal', 'firmware-production']) {
    if (!environments.environments?.some(item => item.name === name)) { report.github[name] = { exists: false }; continue; }
    report.github[name] = { exists: true, secrets: gh('environments/' + name + '/secrets'),
      variables: gh('environments/' + name + '/variables'), branchPolicies: gh('environments/' + name + '/deployment-branch-policies') };
  }
  report.github.collaborators = gh('collaborators?per_page=100').map(item => ({ login: item.login, id: item.id, role_name: item.role_name, permissions: item.permissions }));
  const run = gh('actions/runs/38946949709');
  report.canonical = { id: run.id, attempt: run.run_attempt, commit: run.head_sha, conclusion: run.conclusion,
    created_at: run.created_at, updated_at: run.updated_at,
    approvals: gh('actions/runs/38946949709/approvals').map(item => ({ state: item.state, comment: item.comment, actor: item.user.login, environments: item.environments.map(e => e.name) })) };
  const verification = await cf('user/tokens/verify');
  report.ciToken = { active: verification.result?.status === 'active' };
  if (verification.result?.id) {
    const detail = await cf('user/tokens/' + verification.result.id);
    report.ciToken.policy = detail.result ? { name: detail.result.name, modified_on: detail.result.modified_on,
      policies: detail.result.policies?.map(policy => ({ effect: policy.effect,
        permission_groups: policy.permission_groups?.map(group => ({ id: group.id, name: group.name })),
        resourcesSha256: sha(JSON.stringify(policy.resources)) })) } : detail;
  }
  const settings = await cf('workers/scripts/e-track-firmware-p41-test/settings');
  report.worker = settings.result ? { bindings: settings.result.bindings, observability: settings.result.observability } : settings;
  const scripts = await cf('workers/scripts');
  report.worker.identity = scripts.result?.filter(item => item.id === 'e-track-firmware-p41-test').map(item => ({ id: item.id, etag: item.etag, modified_on: item.modified_on }));
  const app = await cf('access/apps/ca168030-0227-49a5-bd0c-bf030c9c86ea');
  const policies = await cf('access/apps/ca168030-0227-49a5-bd0c-bf030c9c86ea/policies');
  report.access = { app: app.result ? { id: app.result.id, domain: app.result.domain, updated_at: app.result.updated_at, audienceSha256: sha(app.result.aud) } : app,
    policies: policies.result ? policies.result.map(item => ({ id: item.id, decision: item.decision, includeCount: item.include.length, excludeCount: item.exclude.length, requireCount: item.require.length, identityRulesSha256: sha(JSON.stringify({ include: item.include, exclude: item.exclude, require: item.require })) })) : policies };
  report.pages = await cf('pages/projects/e-track-firmware-p43-admin-test');
  if (report.pages.result) report.pages = { configured: true, id: report.pages.result.canonical_deployment.id,
    source: report.pages.result.canonical_deployment.deployment_trigger.metadata.commit_hash,
    configurationsSha256: sha(JSON.stringify(report.pages.result.deployment_configs)) };
  report.health = await http('https://e-track-firmware-p41-test.tangjichentudou.workers.dev/healthz', {}, 'test-healthz');
  report.unauthenticatedAdmin = await http('https://e-track-firmware-p43-admin-test.pages.dev/', {}, 'isolated-admin-gate');
}
main().catch(error => { report.error = { name: error.name, message: error.message }; process.exitCode = 1; }).finally(() => {
  report.endedAt = new Date().toISOString();
  let text = JSON.stringify(report, null, 2) + '\n';
  for (const value of new Set(sensitive.filter(Boolean))) text = text.split(value).join('[REDACTED]');
  guard(out); fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, text, { flag: 'wx' });
  process.stdout.write(text);
});
