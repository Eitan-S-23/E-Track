# P51-LONG-ENTRY Execution Pre-Review

Outcome: **HARNESS_FAIL**. Three required corrections below form one consolidated
batch. This is independent offline pre-review, not formal acceptance or a P5
verdict. Packaging review remains separately closed; do not reopen or rebuild it.

## Findings

### P51-LONG-EXEC-01 [P1]: Package admission accepts claims without original proof

DECIDED: required harness/evidence correction. Owner: root implementation.

`Tools/ota/p51-acceptance/benchmark.py:31` (`package_binding`) compares the three
JSON documents to each other, but never requires the original GCC/key lineage,
protected packaging delivery identity or original native process/log evidence.
The canonical Spec at `docs/ota-prompts/prompt-P5-1-acceptance.md:85` requires
those original proofs to be bound to the actual fixed-load package.

Independent counterexample: `review_probes.py:64`,
`test_claims_only_package_proof_must_not_pass`. A source proof containing only
base/target byte counts and hashes plus eleven hand-written successful native
observations is admitted. There are no native logs/receipts, GCC/key proof or
protected delivery originals. The expected rejection does not occur. This is
also the package used in the full `benchmark.validate` counterexample below;
the existing real ETU outer-header/CRC checks do not close this gap.

Smallest correction: bind the existing protected-delivery result and original
source proof, including its original GCC/key provenance, rather than adding a
new producer. Use the existing archived-input/native-evidence validators or a
strict independently checked delivery receipt whose dependencies are explicit.
Bind native stdout/observation/process receipts to their claimed cases and
success/cleanup state. Do not access a protected key or rerun packaging merely
to check these already-produced originals.

Oracle: a genuine archived delivery passes offline; the preserved claims-only
case, missing native original, nonzero native exit and mismatched original
source/protected delivery each fail before opening a network/device window.
Preserve fixed 30320/30321 finalized bytes, 1 MiB size, benchmark-only purpose,
the actual ETU checks and all normal-selection/functional gates.

### P51-LONG-EXEC-02 [P1]: APK/CI binding does not establish the actual artifact

DECIDED: required harness/evidence correction. Owner: root implementation.

`Tools/ota/p51-acceptance/benchmark.py:83` (`validate`) accepts a build claim if
several declared values agree and the supplied CI JSON says success. It does
not require the canonical repository/run/attempt/artifact relationship or
original evidence of the compiled endpoint and link profile. The Spec at
`docs/ota-prompts/prompt-P5-1-acceptance.md:93` requires an actual release APK,
application ID/version/source, successful CI and compiled endpoint binding.

Independent counterexample: `review_probes.py:69`,
`test_non_apk_and_unrelated_successful_ci_must_not_pass`. A literal
`NOT-AN-APK.bin` and a CI claim with `repository.full_name=unrelated/repository`
pass `benchmark.validate`. Its package goes through the real single-asset
service parser; no APK parser or device transport is mocked into passing.
This proves false offline admission, NOT that a device installed or accepted
the file. The later installed-package check is useful but cannot establish the
missing CI/compiled-profile evidence before the device window.

Smallest correction: extend the benchmark build binding to consume the existing
build workflow's pinned run/job/artifact/download and APK-inspection originals.
Cross-check canonical repository, exact source/run attempt, release-mode APK
hash/ID/version, compiled endpoint, `release_ota_link_profile`, isolated suffix
and `publish_release=false`. Reuse existing artifact verification; no new APK
builder or online request is needed inside admission.

Oracle: the actual dedicated APK and its original successful CI delivery pass;
non-APK, unrelated repository, different run/artifact/source and endpoint/profile
mismatch each fail before device actions. Preserve normal APK98 admission and
the normal application/channel; no production publication is authorized here.

### P51-LONG-EXEC-03 [P2]: C0 originals are repeatedly copied after verification

DECIDED: required lifecycle/capacity correction. Owner: root implementation.

`Tools/ota/p51-acceptance/benchmark.py:238` delegates an unknown original to the
old retrieval method without promoting it to a canonical pin. At
`Tools/ota/p51-acceptance/run.py:330`, the campaign only carries the newly created
block capture forward. Initial C0 originals therefore stay unknown after a
recorder restart and in later blocks, contrary to the no-per-block-copy rule at
`docs/ota-prompts/prompt-P5-1-acceptance.md:107`.

Independent counterexample: `review_probes.py:103`,
`test_first_unknown_archive_is_not_copied_again_after_restart`. A real,
structurally sealed synthetic idle archive is fully fetched, then requested
again: two `exec-out cat` downloads occur instead of one, and a second copy is
created. The actual seal verifier is used. The positive control at line130
passes: an already-known canonical pin is reused without copying, and a changed
phone SHA is rejected.

Smallest correction: after the first complete retrieval, seal and phone
length/SHA verification, promote that original to the canonical mapping. Carry
the entire verified mapping, including C0, across blocks, not just each new
block file. Keep this inside the existing Observer/campaign adapter; do not
create a general cache system or remove archives. With C0 greater than zero,
the present repeated copies invalidate the stated host-space estimate and can
reintroduce long preflight/restart delays. A fresh C0=0 install avoids this
particular path but does not fix the supported `32-C0` lifecycle.

Oracle: with C0>0, run first admission, real restart bookkeeping and two blocks;
each old original is downloaded exactly once, subsequent access verifies the
current phone filename set/length/SHA and returns the same canonical bytes.
Unknown/corrupt/changed originals must still fail or be fully retrieved as
appropriate. Verify the last-slot/32-C0 limit and host-space estimate without
deletion, overwritten evidence or any repeated OTA.

## Executed Evidence

All commands ran with `cmd.exe`, explicit workdir
`D:/github/my/E-Track/.cache/p35-integration-20261028/source`, and isolated Python.
Exact executable argv, output pins and process closure are in the named receipts.

- `python -I -S -B -X utf8 Tools/ota/p34-acceptance/selftest.py p51-benchmark --out D:/github/my/E-Track/.cache/p35-integration-20261028/source/.cache/p51-long-20261108-01/execution-review-01/entry`
  exited 0: 23 benchmark + 38 prior execution + 4 clock = **65 PASS**.
  Originals: `entry.started.json`, `entry.closed.json`, `entry/result.json`
  and the three `entry/*.log` files. Owned-process cleanup completed.
- `python -I -S -B -X utf8 D:/github/my/E-Track/.cache/p35-integration-20261028/source/.cache/p51-long-20261108-01/execution-review-01/review_probes.py`
  exited 1: **4 probes, 1 PASS, 3 assertion failures**, not a harness crash.
  Originals: `probes.started.json`, `probes.closed.json`, `probes.stderr` and
  generated fixtures. Owned-process cleanup completed. The three failures above
  are intentional rejection oracles demonstrating the current defects.

No firmware/APK build was executed by this reviewer. The synthetic ETU outer
containers in probes are NOT installable/encrypted packages. They neither replace
nor weaken the required original protected-package verification.

## Remaining Scope And Handoff

The absolute 18000-second campaign/MCU-cleanup bound was not independently
exercised under delayed readback/restoration. `run.py:259` and `run.py:270` call
the existing MCU owners with their relative limits, while the phone phase guard
does not directly bound those calls. This is a residual NEED_EVIDENCE item, not
a demonstrated fourth failure: root should use a bounded fake-clock test of
delayed MCU completion/restoration and verify the campaign deadline plus reserved
cleanup before the device window. If it overruns, pass the existing deadline
through those owners; do not solve it with abrupt device-process termination.

Root next fixes and self-tests this batch and returns the affected files and
oracle results to the same reviewer. Protected packaging delivery may proceed
separately under root authority. Actual APK delivery/installation, fixture
startup, two-block device smoke, first30, genuine four-hour span, common-final
candidate coverage, physical faults and same-parameter obligations remain
NOT_RUN by this review. No SD/BLE/web evidence is replayed or waived.

## Identity And Write Audit

`inputs.json` pins the nine reviewed code/Spec files; the closeout audit rechecks
all nine and the immutable packaging-review reports/inventories. Root may append
the task note independently. This report does not edit implementation or old
evidence, commit, dispatch CI, access a key, operate a device or perform network
requests. Controlled outputs are confined to `execution-review-01`.

The read-only external-cache comparison observed two changes, attribution
**UNKNOWN**, during concurrent root activity. Reviewer commands/owned test
receipts use cmd and isolated Python, not PowerShell. No causal attribution or
clean boundary claim is inferred from that fact. No external cleanup occurred.

- `C:/Users/SU/AppData/Local/Microsoft/PowerShell/StartupProfileData-NonInteractive`:
  initial 80176 bytes, SHA `9a579843193425eece45e0fd720816604f71755367bb42cd1440558a58563360`;
  observed 76108 bytes, SHA `332f56ea68ef07b1bb9683a9e302ce3ad0a709a5761c5d79ba6779ef4b6708c0`.
- `C:/Users/SU/AppData/Local/Microsoft/Windows/PowerShell/StartupProfileData-NonInteractive`:
  initial/observed 1004 bytes; SHA changed from
  `b4654bffa536c252384cbc705c564513eafcbae82f20ad0c0f632108007ce85e` to
  `f422bb3183265c2cb257293e64abb6a8fd551d1e8804d4e3390ec5f29a569e48`.

`write-audit.json` retains the exact initial/final snapshots and any later
differences, all output hashes, process receipts and the report hash. Preserve
both changed external caches without modification. Current work is local and
uncommitted; P5 remains incomplete.
