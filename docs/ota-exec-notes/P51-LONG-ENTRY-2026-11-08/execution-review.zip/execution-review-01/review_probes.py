"""Independent counterexamples; synthetic inputs, no sockets or devices."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / 'Tools/ota/p51-acceptance'), str(ROOT / 'tests/ota')]
import benchmark as b
import test_p51_benchmark_execution as fixtures

h = b.h
AREA = h.checked(Path(__file__).resolve().parent / 'fixtures/probes')


class ReviewProbes(unittest.TestCase):
    def setUp(self):
        self.out = h.fresh(AREA / self._testMethodName)

    def claims_only_plan(self):
        source = fixtures.BenchmarkTests.fixture(SimpleNamespace(out=self.out))
        current = dict(version=30320, sha256=source['images']['base']['image']['sha256'])
        target = dict(version=30321, sha256=source['images']['target']['image']['sha256'])
        fw = dict(current=current, target=target, package=source['package'],
            device_address='e3:49:e1:14:d6:cb', protocol=2,
            release_id='p51-benchmark-30320-30321',
            latest_url='https://fixture.trycloudflare.com/api/public/firmware/latest')
        proof = {key: {field: source['images'][key]['image'][field]
            for field in ('bytes', 'sha256')} for key in ('base', 'target')}
        assets = [dict(fileName='patch.etu', kind='patch',
            sizeBytes=source['package']['bytes'], sha256=source['package']['sha256'])]
        cases = [('positive', 'ok'), ('payload-crc', 'payload_crc'),
            ('truncated', 'package_length'), ('same-version', 'version'),
            ('wrong-base-sha', 'base_sha8'), ('wrong-base-image', 'base_sha8'),
            ('full-positive', 'ok'), ('full-crc', 'payload_crc'),
            ('full-truncated', 'package_length'), ('recovery-positive', 'ok'),
            ('recovery-crc', 'recovery_trailer')]
        verification = dict(assets=assets, fullByteEqual=True, patchByteEqual=True,
            recoveryByteEqual=True, native=dict(warnings=0, errors=0,
            checks=[dict(case=case, observation=dict(passed=True, result=expected,
                byte_identical=True, prepares=0)) for case, expected in cases]))
        h.save(self.out / 'claims-source.json', proof)
        h.save(self.out / 'claims-verification.json', verification)
        source_pin = h.record(self.out / 'claims-source.json')
        verify_pin = h.record(self.out / 'claims-verification.json')
        metadata = dict(schema='p51-archived-benchmark-v1',
            packagePurpose='fixed-load-benchmark', representativeFunctionalSample=False,
            productionPublishable=False, isFormalRelease=False, sourceCompilations=0,
            finalizations=0, sourceProofSha256=source_pin['sha256'],
            verificationSha256=verify_pin['sha256'], originalSourceProof=proof,
            assets=assets, baseImageSha256=current['sha256'], targetImageSha256=target['sha256'])
        h.save(self.out / 'claims-metadata.json', metadata)
        # Intentionally no original GCC/key proof, protected owner, archive or native logs.
        return dict(kind='patch', mcu=source, firmware=fw, benchmark=dict(
            purpose='fixed-load-benchmark', controls='semantic-v1', budget=copy.deepcopy(b.BUDGET),
            source_proof=source_pin, verification=verify_pin,
            metadata=h.record(self.out / 'claims-metadata.json')))

    def test_claims_only_package_proof_must_not_pass(self):
        plan = self.claims_only_plan()
        with self.assertRaises((RuntimeError, KeyError, ValueError)):
            b.package_binding(plan)

    def test_non_apk_and_unrelated_successful_ci_must_not_pass(self):
        plan = self.claims_only_plan()
        h.raw(self.out / 'NOT-AN-APK.bin', b'synthetic non-APK; never install\n')
        apk = h.record(self.out / 'NOT-AN-APK.bin')
        app = dict(id=b.APP_ID, release=True, version_code=100, sha256=apk['sha256'])
        h.save(self.out / 'unrelated-ci.json', dict(head_sha='a'*40,
            conclusion='success', path='.github/workflows/build.yml',
            event='workflow_dispatch', repository=dict(full_name='unrelated/repository')))
        h.save(self.out / 'claims-apk-build.json', dict(schema='p51-benchmark-apk-v1',
            apk=apk, app=app, latestUrl=plan['firmware']['latest_url'],
            publishRelease=False, source='a'*40,
            workflowRun=h.record(self.out / 'unrelated-ci.json')))
        h.save(self.out / 'claims-ready.json', dict(origin='https://fixture.trycloudflare.com',
            package=plan['mcu']['package']))
        plan.update(apk=apk, phone=dict(app=app))
        plan['benchmark'].update(app_build=h.record(self.out / 'claims-apk-build.json'),
            fixture_ready=h.record(self.out / 'claims-ready.json'))
        with self.assertRaises((RuntimeError, KeyError, ValueError)):
            b.validate(plan)

    def sealed_idle(self, cid):
        state = fixtures.state(fixtures.firmware(), idle=True)
        state.update(schema=1, captureId=cid, monoUs=1, targetVersionCode=0,
            bitmap=None, sendOffset=None, lost=0, error=None)
        b.r.validate_state(state)
        body = ('OTA_P35_STATE ' + json.dumps(state) + '\n').encode()
        opened = dict(schema=1, kind='open', captureId=cid)
        closed = dict(schema=1, kind='close', captureId=cid, records=1,
            sha256=hashlib.sha256(body).hexdigest(), healthy=True, lost=0, error=None)
        raw = ('OTA_P35_CAPTURE ' + json.dumps(opened) + '\n').encode() + body + (
            'OTA_P35_CAPTURE ' + json.dumps(closed) + '\n').encode()
        b.s.sealed_file(raw, cid)
        return raw

    def test_first_unknown_archive_is_not_copied_again_after_restart(self):
        cid = 'e'*32
        raw = self.sealed_idle(cid)
        calls = []
        driver = object.__new__(b.Observer)
        driver.h, driver.capture_id, driver.known_captures = h, None, {}
        driver.p = dict(app=dict(id=b.APP_ID))
        driver.record = Mock()
        def cmd(args, **kwargs):
            calls.append(args)
            if args[:3] == ['shell', 'wc', '-c']:
                return str(len(raw)).encode() + b' file\n'
            if args[:2] == ['exec-out', 'cat']:
                return raw
            if args[:2] == ['shell', 'sha256sum']:
                return hashlib.sha256(raw).hexdigest().encode() + b' file\n'
            raise AssertionError('unexpected simulated command')
        driver.cmd = cmd
        first = self.out / 'previous-captures' / (cid + '.jsonl')
        second = self.out / 'after-restart-captures' / (cid + '.jsonl')
        self.assertEqual(driver.original(cid, first), raw)
        b.s.sealed_file(first.read_bytes(), cid)
        self.assertEqual(driver.original(cid, second), raw)
        downloads = sum(args[:2] == ['exec-out', 'cat'] for args in calls)
        self.assertEqual(downloads, 1, 'C0 original was downloaded again after first verified retrieval')
        self.assertFalse(second.exists(), 'C0 original was duplicated instead of referenced')

    def test_known_archive_real_seal_and_phone_digest_are_preserved(self):
        cid = 'd'*32
        raw = self.sealed_idle(cid)
        original = self.out / 'canonical.jsonl'
        h.raw(original, raw)
        pin = h.record(original)
        driver = object.__new__(b.Observer)
        driver.known_captures, driver.p = {cid: pin}, dict(app=dict(id=b.APP_ID))
        driver.record = Mock()
        driver.cmd = Mock(side_effect=[str(len(raw)).encode(), pin['sha256'].encode()])
        target = self.out / 'must-not-copy.jsonl'
        self.assertEqual(driver.original(cid, target), raw)
        self.assertFalse(target.exists())
        driver.cmd.side_effect = [str(len(raw)).encode(), b'0'*64]
        with self.assertRaisesRegex(RuntimeError, 'archive changed'):
            driver.original(cid, target)


if __name__ == '__main__':
    unittest.main(verbosity=2)
