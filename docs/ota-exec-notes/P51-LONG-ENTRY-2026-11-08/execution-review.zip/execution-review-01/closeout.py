"""Seal this offline pre-review's receipts and read-only boundary observations."""
import json
from pathlib import Path
import re
import sys

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[2]
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(ROOT / 'Tools/ota/p34-acceptance'))
import live_host as h

assert h.ROOT == ROOT


def checked(path):
    value = h.checked(path)
    value.relative_to(AREA)
    return value


def main():
    for name in ('result.json', 'write-audit.json'):
        assert not checked(AREA / name).exists(), 'preserve prior closeout'
    inputs = h.read_json(AREA / 'inputs.json')
    for pin in inputs['files']:
        h.pinned(pin)
    h.pinned(inputs['priorPackagingReview'])
    prior_counts = {}
    for index in (1, 2):
        folder = AREA.parent / ('packaging-review-0' + str(index))
        audit = h.read_json(folder / 'write-audit.json')
        for pin in audit['files']:
            h.pinned(pin)
        h.pinned(audit['report'])
        prior_counts[str(index)] = len(audit['files'])
    receipts = {}
    for name, expected in (('entry', 0), ('probes', 1)):
        receipt = h.read_json(AREA / (name + '.closed.json'))
        assert receipt['exit_code'] == expected and receipt['cleanup_complete'] is True
        assert receipt['job_terminated'] and receipt['job_handle_closed'] and not receipt['cleanup_errors']
        assert not any('powershell' in str(arg).lower() or 'pwsh' in str(arg).lower() for arg in receipt['argv'])
        h.pinned(receipt['stdout'])
        h.pinned(receipt['stderr'])
        receipts[name] = h.record(AREA / (name + '.closed.json'))
    entry = h.read_json(AREA / 'entry/result.json')
    count = 0
    for test in entry['tests']:
        assert test['exit'] == 0 and not test['timed_out']
        log = h.pinned(test['log']).read_text(encoding='utf-8')
        count += int(re.search(r'Ran (\d+) tests in ', log)[1])
        assert '\nOK\n' in log
    assert count == 65 and entry['passed'] and not entry['independent_acceptance']
    assert 'Ran 4 tests in ' in (AREA / 'probes.stderr').read_text(encoding='utf-8')
    assert 'FAILED (failures=3)' in (AREA / 'probes.stderr').read_text(encoding='utf-8')
    h.save(checked(AREA / 'result.json'), dict(outcome='HARNESS_FAIL',
        scope='independent execution-adapter pre-review, not formal acceptance',
        findings=[dict(id='P51-LONG-EXEC-01', severity='P1', owner='root implementation'),
                  dict(id='P51-LONG-EXEC-02', severity='P1', owner='root implementation'),
                  dict(id='P51-LONG-EXEC-03', severity='P2', owner='root implementation')],
        existingTests=dict(total=65, passed=65, exit=0),
        reviewerProbes=dict(total=4, passed=1, failed=3, exit=1, crashes=0),
        reviewedSources=inputs['files'], processReceipts=receipts,
        report=h.record(AREA / 'report.md'), physicalAcceptance='NOT_RUN', P5='INCOMPLETE'))
    helper = h.host.load('readonly_external_snapshot', ROOT / '.cache/p51-normal-review-20261107-01/review.py')
    after = helper.snapshot()
    before = inputs['externalBefore']
    changes = [dict(path=name, before=before.get(name), after=after.get(name), attribution='UNKNOWN')
        for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
    files = [h.record(checked(path)) for path in sorted(AREA.rglob('*')) if path.is_file()]
    h.save(checked(AREA / 'write-audit.json'), dict(root=str(ROOT), authorizedOutputRoot=str(AREA),
        files=files, source=h.record(Path(__file__)), report=h.record(AREA / 'report.md'),
        allControlledOutputsInsideReviewRoot=True, controlledExternalWrites=0,
        implementationFilesUnchanged=True, sourcePinsVerified=len(inputs['files']),
        priorPackagingInventoryCounts=prior_counts, priorPackagingInventoriesUnchanged=True,
        taskNoteBefore=inputs['taskNote'], taskNoteAfter=h.record(ROOT / inputs['taskNote']['path']),
        processReceipts=receipts, allOwnedProcessesClosed=True, shells=['cmd.exe'],
        testRuntime='Python -I -S -B -X utf8', reviewerPowerShellLaunches=0,
        outputOverrides='Existing contained selftest/live_host environment; all reviewer fixtures under this area',
        networkOperations=0, deviceOperations=0, protectedKeyUse=False, ciDispatches=0,
        commits=0, externalCleanup=False, externalBefore=before, externalAfter=after,
        externalChanges=changes, externalAttribution='UNKNOWN; concurrent root and unrelated activity not excluded'))
    print(json.dumps(dict(outcome='HARNESS_FAIL', tests=65, probes=4, failedProbes=3,
        report=h.record(AREA / 'report.md'), externalChanges=changes), ensure_ascii=True))


if __name__ == '__main__':
    main()
