# P51-LONG-ENTRY Targeted Re-Review

Outcome: **SCOPED_REVIEW_PASS** for this execution-adapter remediation batch.
No new blocking implementation finding was identified in the reviewed scope.
The three stable findings below are CLOSED. This is not formal P5 acceptance,
actual APK acceptance, permission to bypass admission, or a physical-test result.

## Finding Dispositions

| Finding | Status | Independently Checked Basis |
| --- | --- | --- |
| P51-LONG-EXEC-01 | CLOSED | `benchmark.py:111` binds the original protected workflow/run/jobs/artifact ZIP, resolves the archived original GCC/key provenance, and compares the finalized images. `native_originals` at line75 checks native source hashes, compiler/case arguments, stdout/observation equality, exit/timeout/signal and cleanup receipts. The actual protected delivery passes; original claims-only and five targeted negative cases are rejected. |
| P51-LONG-EXEC-02 | CLOSED, code scope | `benchmark.py:182` rejects the original non-APK input and binds an APK ZIP, binary manifest, both ARM ELF payloads, compiled endpoint/profile, original dispatch, canonical run/attempt/artifact, both host results and qualified native badging/signature receipts. Synthetic relationship/mismatch tests pass. The actual dedicated APK is NOT_BUILT/NOT_INSPECTED here and remains a mandatory pre-device evidence gate. |
| P51-LONG-EXEC-03 | CLOSED | `benchmark.py:406` promotes an unknown original only after complete phone length/hash retrieval and real seal validation. `run.py:293` returns all canonical captures and line341 preserves/validates that mapping across blocks. The preserved independent probe now downloads the C0 original once; changed phone hashes still fail. Real Smoke restart bookkeeping and C0=17/15-block/30-cell/32-file boundary regressions pass. |

All implementation references above are relative to the active worktree
`D:/github/my/E-Track/.cache/p35-integration-20261028/source`, under
`Tools/ota/p51-acceptance/`. The previous HARNESS_FAIL report and its failing
original probes are retained unchanged in `execution-review-01`.

The prior deadline NEED_EVIDENCE item is HOST_VERIFIED, not a new physical
measurement. `benchmark.MCU.execute` at line334 forwards one absolute bound to
the existing native owner. `run.py:240` reserves 180 seconds before the earlier
recording/campaign end; a mutation needs its entire native allowance plus 30
seconds. Executed tests drive the original restore controller through eight
delayed stages with the same deadline, reject an exhausted read allowance, and
reject a near-deadline write before the native operation. No Flash command was
executed and no real four-hour duration was simulated into acceptance credit.

## Executed Evidence

Run directory: `.cache/p51-long-20261108-01/execution-review-02`.
All commands used explicit workdir R above, `cmd.exe`, and isolated Python.
Every owned test process exited 0 and its cleanup receipt is retained.

1. Existing CI entry, independently executed:
   `python -I -S -B -X utf8 Tools/ota/p34-acceptance/selftest.py p51-benchmark --out R/.cache/p51-long-20261108-01/execution-review-02/entry`
   **80 PASS**: 38 benchmark, 38 prior execution, 4 clock. Exact absolute argv
   and executable are in `entry.started.json`/`entry.closed.json`; individual
   logs and results are in `entry/`.
2. The same four original independent probes, not rewritten:
   `python -I -S -B -X utf8 .cache/p51-long-20261108-01/execution-review-02/review.py probes`
   **4 PASS**. The imported module's AREA is changed to the new `probe-fixtures`
   before running. `probes.stderr` preserves all four names and outcomes.
3. Existing protected-binding evaluator, independently executed without network,
   subprocess generation or key access:
   `python -I -S -B -X utf8 .cache/p51-long-20261108-01/execution-review-02/review.py package`
   **1 actual-package positive and 5 negative checks PASS**. New output plan is
   exactly equal to `package-binding-02/package-plan.json`; original-producer
   and negative results are in `package/result.json` and `package.closed.json`.

The orchestration command was
`python -I -S -B -X utf8 .cache/p51-long-20261108-01/execution-review-02/review.py run`,
exit0. It also read back the original successful 137-test live-route receipt and
log from `execution-check-06`, rather than rerunning them. Those 137 are reused
observations, not added to the independently executed 80-test count.

Actual protected package: run **42414090133**, attempt **1**, source
`d87a711631ab27c8b46e7cc9812d388afea27a57`, artifact **13590748725**.
`patch.etu` is exactly **1048576 bytes**, SHA-256
`d571decf296a62d65e0ae5fa1824aa25d773978e086c8478bc4e6abfcf5d3e62`.
This review consumes the existing output; it does not recompile, refinalize,
regenerate packages or reopen the closed packaging review.

## Remaining Gates And Next Owner

Owner: **root**, continuing the same batch under its existing authorization.

- Deliver the exact nine reviewed source/Spec pins and this review, then retain
  the actual governance CI results from both hosts. This local run does not
  claim remote two-host execution.
- Build and retrieve the dedicated release APK through the already selected
  workflow/immutable fixture origin. Retain its actual dispatch, source/run/jobs,
  artifact ZIP and native inspection originals. Run the real `apk_binding` and
  complete `benchmark.validate` positive before installing or opening a device
  window. Synthetic APK tests are not that positive and cannot waive it.
- Bind the actual preceding normal BLE result, supported complete-state restore,
  fixture owner/lifetime and exact successor contract inputs before the planned
  execution. Preserve existing SD/BLE/web evidence; do not replay it for this
  review. First30, real four-hour duration, common-final candidate, physical
  faults and same-parameter obligations remain open.

The reviewer does not require another speculative tooling or package review.
If real artifact admission fails, preserve its input/receipts and return that
specific incompatibility; do not weaken the gates or repeatedly rebuild blindly.

## Identity And Boundary Audit

The stable remediation manifest is
`.cache/p51-long-20261108-01/remediation-inputs.json`, SHA-256
`07c2672fa70dd221dabbe26305d95189ec83b89703e7bf3c735510e54c4a46ff`.
All nine source/Spec pins were checked before and after execution and are copied
into `result.json`. `inputs.json` also binds the original probe/report, protected
delivery, actual package plan and implementation self-test. Final sealing checks
the prior review inventory without changing it.

Controlled outputs are only under this new `execution-review-02` directory.
No implementation/main note, old evidence, package, device, network endpoint,
key or Git metadata was modified. No PowerShell process was launched. No firmware
or APK build occurred here; build warnings/errors are NOT_RUN, not claimed zero.

During this review window the read-only snapshot comparison observed an update
to `C:/Users/SU/AppData/Local/Microsoft/PowerShell/StartupProfileData-NonInteractive`.
Attribution is UNKNOWN during concurrent activity; no external cleanup occurred.
Exact initial/final metadata and hashes, including any later differences, are
retained in `write-audit.json`. Previously disclosed external cache changes are
not erased or reclassified by this review. P5 remains incomplete.
