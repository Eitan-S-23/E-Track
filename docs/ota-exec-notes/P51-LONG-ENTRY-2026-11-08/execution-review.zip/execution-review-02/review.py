"""Targeted offline re-review using existing regressions and preserved probes."""
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import unittest
from unittest.mock import patch

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[2]
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(ROOT / 'Tools/ota/p34-acceptance'))
import live_host as h

assert h.ROOT == ROOT
INPUT = AREA.parent / 'remediation-inputs.json'
INPUT_SHA = '07c2672fa70dd221dabbe26305d95189ec83b89703e7bf3c735510e54c4a46ff'
OLD = AREA.parent / 'execution-review-01'
boundary = h.host.load('review_readonly_boundary', ROOT / '.cache/p51-normal-review-20261107-01/review.py')


def checked(path):
    value = h.checked(path)
    value.relative_to(AREA)
    return value


def sources():
    assert hashlib.sha256(INPUT.read_bytes()).hexdigest() == INPUT_SHA
    value = h.read_json(INPUT)
    for pin in value['files']:
        h.pinned(pin)
    return value


def preflight():
    names = ('inputs.json', 'checks.json', 'result.json', 'report.md', 'write-audit.json',
        'host', 'fixtures', 'probe-fixtures', 'package', 'entry')
    for name in names:
        checked(AREA / name)
    for label in ('entry', 'probes', 'package'):
        for suffix in ('stdout', 'stderr', 'started.json', 'closed.json'):
            checked(AREA / (label + '.' + suffix))
    checked(AREA / 'package/package-plan.json')
    checked(AREA / 'package/result.json')


def probes():
    old = h.host.load('preserved_p51_review_probes', OLD / 'review_probes.py')
    old.AREA = checked(AREA / 'probe-fixtures')
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(old.ReviewProbes)
    with patch.object(socket, 'socket', side_effect=AssertionError('offline probes cannot open sockets')):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun == 4 and result.wasSuccessful(), 'preserved independent oracle still fails'


def package():
    owner = h.host.load('existing_protected_binding', AREA.parent / 'binding.py')
    with patch.object(socket, 'socket', side_effect=AssertionError('offline binding cannot open sockets')):
        owner.bind(checked(AREA / 'package'))
    original = h.read_json(AREA.parent / 'package-binding-02/result.json')
    assert h.read_json(h.pinned(original['plan'])) == h.read_json(AREA / 'package/package-plan.json')


def run():
    assert not (AREA / 'inputs.json').exists(), 'preserve earlier re-review'
    baseline = sources()
    old_audit = h.read_json(OLD / 'write-audit.json')
    old_pins = [pin for pin in old_audit['files'] if Path(pin['path']).name in
        ('review_probes.py', 'result.json', 'report.md') and Path(pin['path']).parent == OLD.relative_to(ROOT)]
    assert len(old_pins) == 3
    for pin in old_pins:
        h.pinned(pin)
    binding = h.read_json(h.pinned(baseline['packageBinding']))
    h.pinned(binding['adapter'])
    h.pinned(binding['plan'])
    h.pinned(binding['protectedDelivery'])
    h.save(checked(AREA / 'inputs.json'), dict(remediation=h.record(INPUT), files=baseline['files'],
        originalProbeAndReview=old_pins, priorReviewAudit=h.record(OLD / 'write-audit.json'),
        packageBinding=baseline['packageBinding'], packagePlan=binding['plan'],
        packageBindingAdapter=binding['adapter'], protectedDelivery=binding['protectedDelivery'],
        implementationSelftest=baseline['selftest'], externalBefore=boundary.snapshot(),
        scope='same-batch targeted offline re-review; actual dedicated APK not yet built'))
    env = h.environment(AREA)
    for name in list(env):
        if name.startswith(('OTA_', 'GH_', 'GITHUB_', 'P35_', 'CF_', 'CLOUDFLARE_', 'TRACE_', 'PIP_')) or name == 'SSLKEYLOGFILE':
            env.pop(name)
    env['P51_TEST_AREA'] = str(checked(AREA / 'fixtures'))
    for label, argv, seconds in (
        ('entry', [ROOT / 'Tools/ota/p34-acceptance/selftest.py', 'p51-benchmark', '--out', AREA / 'entry'], 300),
        ('probes', [Path(__file__), 'probes'], 60),
        ('package', [Path(__file__), 'package'], 300)):
        h.command(AREA, label, [sys.executable, '-I', '-S', '-B', '-X', 'utf8', *argv], env, seconds=seconds)
    entry = h.read_json(AREA / 'entry/result.json')
    total = 0
    for test in entry['tests']:
        assert test['exit'] == 0 and not test['timed_out']
        log = h.pinned(test['log']).read_text(encoding='utf-8')
        total += int(re.search(r'Ran (\d+) tests in ', log)[1])
        assert '\nOK\n' in log
    assert entry['passed'] and total == 80
    old_live = h.read_json(AREA.parent / 'execution-check-06/result.json')
    live = next(row for row in old_live['checks'] if row['test'] == 'tests/ota/test_p34_live_route.py')
    receipt = h.read_json(h.pinned(live['receipt']))
    assert live['count'] == 137 and receipt['exit_code'] == 0 and receipt['cleanup_complete']
    h.pinned(receipt['stdout'])
    log = h.pinned(receipt['stderr']).read_text(encoding='utf-8')
    assert 'Ran 137 tests in ' in log and '\nOK\n' in log
    sources()
    h.save(checked(AREA / 'checks.json'), dict(outcome='TARGETED_OFFLINE_CHECKS_PASS',
        independentTests=dict(total=total, entry=h.record(AREA / 'entry/result.json')),
        independentOriginalProbes=dict(total=4, passed=4, stderr=h.record(AREA / 'probes.stderr')),
        independentActualPackage=h.record(AREA / 'package/result.json'),
        reusedLiveRoute=dict(tests=137, receipt=live['receipt'], newlyExecuted=False),
        actualDedicatedApk='NOT_BUILT_NOT_INSPECTED', actualApkAdmission='NOT_RUN',
        devices=0, network=0, protectedKeyUse=False, packageGenerations=0))
    print('TARGETED_OFFLINE_CHECKS_PASS tests=80 old_probes=4 actual_package=1_positive_5_negative')


def seal():
    inputs = h.read_json(AREA / 'inputs.json')
    sources()
    h.pinned(inputs['priorReviewAudit'])
    old_inventory = h.read_json(h.pinned(inputs['priorReviewAudit']))
    for pin in old_inventory['files']:
        h.pinned(pin)
    for pin in inputs['originalProbeAndReview']:
        h.pinned(pin)
    for name in ('packageBinding', 'packagePlan', 'packageBindingAdapter', 'protectedDelivery', 'implementationSelftest'):
        h.pinned(inputs[name])
    for name in ('result.json', 'write-audit.json'):
        assert not checked(AREA / name).exists(), 'preserve earlier closeout'
    checks = h.read_json(AREA / 'checks.json')
    assert checks['outcome'] == 'TARGETED_OFFLINE_CHECKS_PASS'
    receipts = []
    for label in ('entry', 'probes', 'package'):
        pin = h.record(AREA / (label + '.closed.json'))
        receipt = h.read_json(h.pinned(pin))
        assert receipt['exit_code'] == 0 and receipt['cleanup_complete'] and receipt['job_handle_closed']
        assert receipt['job_terminated'] and not receipt['cleanup_errors']
        h.pinned(receipt['stdout'])
        h.pinned(receipt['stderr'])
        receipts.append(pin)
    result = dict(outcome='SCOPED_REVIEW_PASS', scope='execution-adapter remediation only; not physical/product acceptance',
        findings=[dict(id='P51-LONG-EXEC-01', status='CLOSED', disposition='original protected-package binding verified'),
            dict(id='P51-LONG-EXEC-02', status='CLOSED', disposition='admission defect fixed; actual dedicated APK still a pre-execution evidence gate'),
            dict(id='P51-LONG-EXEC-03', status='CLOSED', disposition='C0 promotion/restart/campaign mapping verified')],
        deadlineItem=dict(status='HOST_VERIFIED', physicalLimitObservation='NOT_RUN'),
        sources=inputs['files'], remediation=inputs['remediation'], checks=checks,
        report=h.record(AREA / 'report.md'), receipts=receipts,
        actualDedicatedApk=dict(status='NOT_BUILT_NOT_INSPECTED', admission='NOT_RUN', owner='root',
            requiredBeforeDevice=True, syntheticTestsAreNotArtifactAcceptance=True),
        nextOwner='root: deliver reviewed batch, complete dedicated APK/fixture evidence and freeze exact successor inputs',
        P5='INCOMPLETE', SD_BLE_web_replays=0, commits=0, devices=0, network=0)
    h.save(checked(AREA / 'result.json'), result)
    after, before = boundary.snapshot(), inputs['externalBefore']
    changes = [dict(path=name, before=before.get(name), after=after.get(name), attribution='UNKNOWN')
        for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
    h.save(checked(AREA / 'write-audit.json'), dict(root=str(ROOT), authorizedOutputRoot=str(AREA),
        files=[h.record(checked(path)) for path in sorted(AREA.rglob('*')) if path.is_file()],
        source=h.record(Path(__file__)), report=h.record(AREA / 'report.md'),
        allControlledOutputsInsideReviewRoot=True, controlledExternalWrites=0, sourcePinsVerified=9,
        implementationFilesUnchanged=True, priorReviewOriginalsUnchanged=True, allOwnedProcessesClosed=True,
        shells=['cmd.exe'], interpreter='Python -I -S -B -X utf8', processReceipts=receipts,
        reviewerPowerShellLaunches=0, externalCleanup=False, externalBefore=before, externalAfter=after,
        externalChanges=changes, attribution='UNKNOWN; concurrent root activity not excluded',
        devices=0, network=0, protectedKeyUse=False, packageGenerations=0, commits=0))
    print(json.dumps(dict(outcome=result['outcome'], report=result['report'], externalChanges=changes)))


if __name__ == '__main__':
    preflight()
    {'run': run, 'probes': probes, 'package': package, 'seal': seal}[sys.argv[1]]()
