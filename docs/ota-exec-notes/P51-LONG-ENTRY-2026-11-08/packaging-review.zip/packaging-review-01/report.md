# P51-LONG-ENTRY Packaging Review

Disposition: **SCOPED_REVIEW_CHANGES_REQUESTED**. One P2 CI-wiring finding.
This is bounded code readiness review, not protected-package or P5 acceptance.

## Finding P51-LONG-PACK-01

`.github/workflows/firmware-build.yml:42` and `:80`: neither automatic event
matches these new inputs:

- `Tools/ota/p51-benchmark-inputs.py`
- `Tools/ota/p51-benchmark-inputs.json`
- `tests/ota/test_p51_benchmark_inputs.py`

The benchmark tests were added to job steps, but a future PR or main push
changing only one of these files will not start this workflow. The Node test
is already covered by `tests/ota/*firmware*`. This batch happens to change the
workflow itself, which does not close the continuing dependency gap.

Actual YAML parsing plus Node `path.posix.matchesGlob` produced six missing
matches among eight event/file checks. See `test-07.stdout`; the command exited
1 with `BENCHMARK_AUTOMATIC_PATH_COVERAGE_FAIL`.

Smallest fix: add `Tools/ota/p51-benchmark-inputs.*` and
`tests/ota/test_p51_benchmark_inputs.py` to both `push.paths` and
`pull_request.paths`. Extend the existing workflow path assertions with all
four benchmark files and per-event/per-input negative removal cases. Do not
widen unrelated Flutter/device scopes. Root owns the edit and focused rerun.

## Scope And Identity

The seven delegated implementation/test files are pinned in `inputs.json`.
All remained byte-identical throughout this review. The three tracked-file
baseline SHA-256 values in `../baseline.json` exactly match their current HEAD
blobs; the other four files are reviewed additions. `review-analysis.json`
records that comparison and the finding. Concurrent execution/service adapter
work is outside this review.

No `.trellis/spec` directory was present in either the active worktree or the
canonical project root. Published collaboration and acceptance section 0
remain the applicable lightweight-review rules.

## Checks And Observations

- Actual archived admission reuses the normal source/preparation verifier,
  including archive inventory, artifact/run/attempt identity, original source
  bytes, build evidence, and finalized image validation. The exact pair remains
  30320 / 30321 with base SHA `5d86c6b3de6535004b4aef2333706511a27cb194b8353712684c9bcc17725741`
  and target SHA `1564ccee0a9a6bc019d8877fc832c7542c2e815ce05412b6511bf9f724936af3`.
- The benchmark adapter performs zero MCU source compilations and zero new
  firmware-header finalizations. Retained Boot length/SHA are taken from the
  original protected proof, not incorrectly forced to a padded 64 KiB image.
- Current Node admission checks reviewed checkout/workflow ownership, protected
  nonpublishing context, exact versions/profile, unchanged protected product
  tree, and disallowed staging/release credentials. Materialized inputs and
  source proof are checked again before and after packaging. Original build
  key/header/source fingerprints must match the protected key before search
  or native execution; the default-key negative test confirms early refusal.
- Existing legal reference search, ETU envelopes, complete-consumption and
  byte comparisons, and the real native decoder are reused. The expected
  native inventory is eleven cases. Metadata truthfully marks fixed-load
  benchmark purpose, nonrepresentative functional sample, nonrelease status,
  and hardware acceptance NOT_RUN.
- The workflow uses the protected artifact-only job, skips the new-source GCC
  and normal bsdiff-build steps for this mode, and does not route to staging
  registration, public selection, or production. Upload is a separate explicit
  allowlist gated on cleanup; private key/header/decoder paths are excluded.
- Shared cleanup preserves uncertain native ownership and rejects a foreign
  private owner. It is reused rather than replaced. Existing tests exercised
  cleanup with public fixtures, not a real protected package in this review.
- Existing normal assets are immutable read-only inputs. Auxiliary FULL and
  recovery outputs in the future benchmark artifact do not replace those
  originals. This review's normal unit tests generated only synthetic fixtures
  under the review directory, with public test material.

## Executed Host Checks

All commands ran from the active worktree using project-contained environment,
temporary/cache directories, and `P51_TEST_AREA` under this review directory.
Exact argv, exit codes, output hashes, and owned-process closure are retained
in each numbered `started.json` / `closed.json` pair.

| Receipt | Existing entry | Tests | Exit |
| --- | --- | ---: | ---: |
| test-01 | `python -I -S -B -X utf8 tests/ota/test_p51_benchmark_inputs.py` | 7 | 0 |
| test-02 | `node --test tests/ota/test_firmware_benchmark_candidate.mjs` | 20 | 0 |
| test-03 | `node --test tests/ota/test_firmware_candidate.mjs` | 67 | 0 |
| test-04 | `node --test tests/ota/test_firmware_normal_candidate.mjs` | 22 | 0 |
| test-05 | `node --test tests/ota/test_firmware_workflow.mjs` | 97 | 0 |

Total: 213 tests, zero failed tests, no warnings in their stderr logs.
`result.json` is only this host-test result, not the overall review disposition.

The reviewer's first additional path probe (`test-06`) failed because its
nested isolated Python omitted `-X utf8` while parsing UTF-8 YAML on Windows.
It is preserved as a reviewer harness failure, not a product finding. The
minimal correction in `test-07` produced the decisive six missing path matches.
Neither probe performed a network/device action or altered implementation.

## Boundary And Remaining Work

Only this review directory was written. The write audit inventories retained
outputs and verifies their resolved locations. Test fixtures and all controlled
HOME/USERPROFILE/APPDATA/LOCALAPPDATA/TEMP/TMP/cache locations are contained here.
No protected key was read or used; no network, CI dispatch, firmware build,
device operation, commit, deployment, or implementation/evidence edit occurred.
No external cleanup occurred; this review does not resolve attribution of any
external caches disclosed by earlier work.

Protected new package generation, actual new eleven-case native run, remote
cleanup/upload, device use, and P5 long campaign remain **NOT_RUN**. After the
small path-filter fix and its focused tests, the packaging sub-batch can return
to the same reviewer; neither a new reviewer nor repeated hardware work is
needed for this finding.
