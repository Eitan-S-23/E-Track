# P51-LONG CI Correction Review

Outcome: **SCOPED_CODE_REVIEW_PASS**. No new blocking code defect was found in
the seven-file correction. Code readiness and real CI confirmation are separate:
the new source-bound CI is still **NOT_RUN_REQUIRED**, not PASS.
EXEC-01/02/03 and the prior packaging review are not reopened.

## Dispositions

### P51-LONG-CI-01: Code Ready; New CI Confirmation Required

The original run42417700381/1 at source
`dca0900e601a9df0ceab125329f80a3ad8a59a5c` remains failed. Both host artifacts show
the new benchmark38 and clock4 passing; the prior execution suite ran16 tests
and reported one FunctionalSampleGuards setup error, not16 failed tests.
The two artifact archives/inventories and three original job logs were hash
checked without downloading or rerunning the old CI.

The correction adds the missing contained fixture dependency route rather than
skipping functional guards. `.github/workflows/acceptance-governance.yml:165`
prepares fixed pycryptodome3.23.0 under `--target` and builds the existing
`.github/scripts/bsdiff` target. Linux uses Ninja/Release; Windows uses VS17 x64
and Release. Expected paths agree with the vendor CMake runtime output directory:
`bin/bsdiff` and `bin/Release/bsdiff.exe`. No new bsdiff implementation is added.

`Tools/ota/p34-acceptance/selftest.py` checks the explicit project-local Crypto
and bsdiff inputs before launching the suite and propagates them through the
isolated child entry. `tests/ota/test_p51_execution.py:34` explicitly forwards
the dependency directory as PYTHONPATH into the real non-isolated fixture
Python subprocess, where Crypto is needed. The Node fixture takes BSDIFF_EXE,
not a guessed host default. CI uploads retain nested stdout/stderr/closed
receipts; the Python setup and Node finalizer forward failure diagnostics.

Independent oracles pass: missing Crypto with a valid vendor executable and
missing bsdiff with valid Crypto each reject before any test child runs. A real
Node-to-Python finalizer failure was injected using only a nonexistent
project-local child PYTHONHOME. Its original stderr was saved, forwarded by Node,
and forwarded again by FunctionalSampleGuards; no second preparation started.
The expected nested exit1 is retained, not hidden or classified as a product
failure. This diagnostic check never produced a candidate package.

The actual new Linux/Windows dependency builds still need the new CI. The saved
local VS17 configure exited1 because VS2022 is absent; its build is NOT_RUN.
This review does not use the available local vendor executable as proof of a
successful VS17 build. Do not reinterpret old failed CI as repaired execution.

### P51-LONG-CI-02: Closed Locally; New CI Confirmation Required

`docs/ota-spec-decisions.md:266` now gives DEC020 its exact `DECIDED` status line,
keeps the prior authority statement in a separate field, and adds the already
applicable P4-1/P4-2/P5-1 affected-task field. The exact before/after comparison
shows no change to selection, package, physical, evidence or publication gates.

The original affected test
`PostP26SpecGovernanceTests.test_decision_ids_are_monotonic_and_references_are_valid`
was independently executed and passes. The complete root145-test observation
was independently read back from test-04.closed.json/stdout/stderr: exit0,
145 tests, OK and process cleanup complete. It was not rerun.

The outer correction-check-01 exit1 belongs to its fifth direct-isolated
efficiency invocation, whose peer import failed. It does not invalidate the
fourth command's145 result. The subsequent existing selftest child route's
36-test efficiency result and original successful receipt were also checked,
without rewriting that failure or the tests.

## Actual Checks

All reviewer commands used `cmd.exe`, explicit workdir
`D:/github/my/E-Track/.cache/p35-integration-20261028/source` (R), and Python
`-I -S -B -X utf8`. Exact argv, output pins and process closure are retained.

- Existing entry: `Tools/ota/p34-acceptance/selftest.py p51-benchmark --out R/.cache/p51-long-20261108-01/execution-review-03/entry`, exit0;
  **83 PASS**, comprising40 benchmark +39 execution +4 clock tests. The normal
  fixtures use synthetic App bytes, not new device candidates.
- Independent targeted worker: `.cache/p51-long-20261108-01/execution-review-03/review.py probes`, exit0;
  **4 PASS**: two separate dependency negatives, the original DEC020 case and
  the real nested-diagnostic check. The controlled nested process exit1 is
  explicitly bound in `diagnostic-result.json` with cleanup complete.
- Original observations, not new executions:145 governance tests and36
  efficiency tests, both checked against their own successful raw receipts.
- Orchestration: `python -I -S -B -X utf8 .cache/p51-long-20261108-01/execution-review-03/review.py run`, exit0.

The local dependency used is Crypto3.23.0 from `R/.cache/p51-staging/python`.
The existing vendor executable is434382 bytes, SHA-256
`beb1903ebda6b34f63cf5d9abab5b0862e98c398124ceb42fdcf4e43c79f919a`.
No package installation, network call, protected key, new compiler build,
candidate generation, Git update or device operation occurred in this review.
New-build warning/error counts are NOT_RUN, not assumed zero.

## Identity And Next Owner

The seven fixed source pins are in `ci-correction-inputs.json`, SHA-256
`933284e8f861cab675cf5b58c1517f5606234d5ed8085812cf08361647f8d9af`, and copied into
`result.json`. `source-comparison.json` records exact diffs after matching every
before-image to its earlier pin. The original delivery intent supplies four
before-images; local Git HEAD blobs supply the other three after exact byte/hash
checks. The absent local dca0900 Git object was not fetched or fabricated.

Owner: root. Deliver this bounded correction and run one fresh, source-bound
governance CI. Confirm both host dependency preparation and all83 P51 tests,
the governance job, preserved nested diagnostics and actual artifact delivery.
If one fails, preserve its original result and fix that specific problem; do
not omit functional guards, relabel the prior run or repeat device operations.

After real CI confirmation, continue only the necessary successor-input/APK/
fixture preparation. Current code review does not grant a frozen execution
identity or close P5. No SD/BLE/web observation needs replay for these CI fixes.

## Boundary

All controlled outputs are inside this new `execution-review-03` directory.
The seven reviewed files and prior review artifacts are checked again at sealing;
old failures, packages and evidence are not modified. No PowerShell was launched.
Read-only external-cache snapshots and any UNKNOWN-attribution changes are
retained in `write-audit.json`; no external cleanup occurred. `result.json`
separates CI-01/CI-02 code status from the required new remote CI.
