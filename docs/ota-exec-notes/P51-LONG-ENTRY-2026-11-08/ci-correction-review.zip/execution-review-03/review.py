"""Offline re-review of the two observed CI integration corrections only."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import unittest
from unittest.mock import patch

AREA = Path(__file__).resolve().parent
ROOT = AREA.parents[2]
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(ROOT / 'Tools/ota/p34-acceptance'))
import live_host as h

assert h.ROOT == ROOT
SOURCE = AREA.parent / 'ci-correction-inputs.json'
SOURCE_SHA = '933284e8f861cab675cf5b58c1517f5606234d5ed8085812cf08361647f8d9af'
DEPS = h.checked(ROOT / '.cache/p51-staging/python')
BSDIFF = h.checked(ROOT / 'bsdiff_lzma_AES128-main/bsdiff/build/bin/bsdiff.exe')
snapshot_owner = h.host.load('ci_review_readonly_snapshot', ROOT / '.cache/p51-normal-review-20261107-01/review.py')


def checked(path):
    value = h.checked(path)
    value.relative_to(AREA)
    return value


def source_pins():
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_SHA
    data = h.read_json(SOURCE)
    for pin in data['files']:
        h.pinned(pin)
    return data


def preflight():
    for name in ('inputs.json', 'host', 'entry', 'missing-crypto', 'missing-bsdiff',
        'missing-crypto-deps', 'missing-bsdiff.exe', 'missing-python-home', 'diagnostic-fixtures',
        'diagnostic-result.json', 'checks.json', 'report.md', 'result.json', 'write-audit.json'):
        checked(AREA / name)
    for name in ('entry', 'probes'):
        for suffix in ('started.json', 'closed.json', 'stdout', 'stderr'):
            checked(AREA / (name + '.' + suffix))


class TargetedChecks(unittest.TestCase):
    def reject_missing(self, name, deps, bsdiff):
        entry = h.host.load('missing_' + name, ROOT / 'Tools/ota/p34-acceptance/selftest.py')
        out = checked(AREA / name)
        with patch.dict(os.environ, dict(P51_PYTHON_DEPS=str(deps), BSDIFF_EXE=str(bsdiff))), \
                patch.object(sys, 'argv', ['selftest.py', 'p51-benchmark', '--out', str(out)]), \
                patch.object(entry.host, 'run') as child:
            with self.assertRaisesRegex(RuntimeError, 'project-local pycryptodome'):
                entry.main()
            child.assert_not_called()
        self.assertFalse((out / 'result.json').exists())

    def test_missing_crypto_is_rejected_with_real_vendor_tool_available(self):
        self.reject_missing('missing-crypto', AREA / 'missing-crypto-deps', BSDIFF)

    def test_missing_bsdiff_is_rejected_with_real_crypto_available(self):
        self.reject_missing('missing-bsdiff', DEPS, AREA / 'missing-bsdiff.exe')

    def test_original_decision_case(self):
        module = h.host.load('original_acceptance_bundle_case', ROOT / 'tests/ota/test_acceptance_bundle.py')
        case = module.PostP26SpecGovernanceTests('test_decision_ids_are_monotonic_and_references_are_valid')
        result = unittest.TestResult()
        unittest.TestSuite([case]).run(result)
        self.assertEqual(result.testsRun, 1)
        self.assertTrue(result.wasSuccessful(), str(result.errors + result.failures))

    def test_real_nested_finalizer_failure_is_retained_and_forwarded(self):
        module = h.host.load('original_functional_fixture_diagnostics', ROOT / 'tests/ota/test_p51_execution.py')
        cls = type('DiagnosticFixture', (module.FunctionalSampleGuards,), {})
        original_environment = module.run.h.environment
        def broken_python_home(out):
            env = original_environment(out)
            env['PYTHONHOME'] = str(checked(AREA / 'missing-python-home'))
            return env
        forwarded = io.StringIO()
        with patch.dict(os.environ, dict(P51_TEST_AREA=str(checked(AREA / 'diagnostic-fixtures')),
                P51_PYTHON_DEPS=str(DEPS), BSDIFF_EXE=str(BSDIFF))), \
                patch.object(module.run.h, 'environment', side_effect=broken_python_home), \
                contextlib.redirect_stderr(forwarded):
            with self.assertRaises(RuntimeError):
                cls.setUpClass()
        folder = checked(cls.area)
        raw_error = (folder / 'normal/base-finalize.stderr').read_text(encoding='utf-8')
        self.assertIn('Fatal Python error:', raw_error)
        self.assertIn('encodings', raw_error)
        outer_error = (folder / 'prepare-normal.stderr').read_text(encoding='utf-8')
        self.assertIn(raw_error, outer_error)
        self.assertIn(raw_error, forwarded.getvalue())
        self.assertIn('Fixture base finalization failed; inspect retained outputs', outer_error)
        receipt = h.read_json(folder / 'prepare-normal.closed.json')
        self.assertEqual(receipt['exit_code'], 1)
        self.assertTrue(receipt['cleanup_complete'])
        self.assertFalse((folder / 'prepare-header-only.started.json').exists())
        h.save(checked(AREA / 'diagnostic-result.json'), dict(
            outcome='EXPECTED_NESTED_FAILURE_RETAINED_AND_FORWARDED',
            injection='nonexistent project-local PYTHONHOME in the fixture child only',
            realNodeAndPythonExecuted=True, candidateGeneration=False,
            originalFinalizerError=h.record(folder / 'normal/base-finalize.stderr'),
            fixtureError=h.record(folder / 'prepare-normal.stderr'),
            fixtureReceipt=h.record(folder / 'prepare-normal.closed.json'),
            forwardedCharacterCount=len(forwarded.getvalue()), secondPreparationStarted=False))


def probes():
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TargetedChecks))
    assert result.testsRun == 4 and result.wasSuccessful()


def run():
    assert not (AREA / 'inputs.json').exists(), 'preserve previous execution'
    baseline = source_pins()
    assert (DEPS / 'Crypto/Cipher/AES.py').is_file() and BSDIFF.is_file()
    for pin in baseline['selftestComponents']:
        h.pinned(pin)
    h.pinned(baseline['previousReview'])
    h.pinned(baseline['failedCi'])
    governance_pin = h.record(AREA.parent / 'ci-correction-check-01/test-04.closed.json')
    governance = h.read_json(h.pinned(governance_pin))
    assert governance['exit_code'] == 0 and governance['cleanup_complete']
    log = h.pinned(governance['stderr']).read_text(encoding='utf-8')
    assert 'Ran 145 tests in ' in log and '\nOK\n' in log
    h.pinned(governance['stdout'])
    h.save(checked(AREA / 'inputs.json'), dict(sourceManifest=h.record(SOURCE), files=baseline['files'],
        previousReview=baseline['previousReview'], failedCi=baseline['failedCi'],
        implementationSelftests=baseline['selftestComponents'],
        reusedGovernance=dict(tests=145, receipt=governance_pin, newlyExecuted=False),
        pythonDependencies=str(DEPS), cryptoModule=h.record(DEPS / 'Crypto/Cipher/AES.py'),
        bsdiff=h.record(BSDIFF), externalBefore=snapshot_owner.snapshot(),
        oldReviews=[h.record(AREA.parent / ('execution-review-0' + str(i)) / name)
            for i in (1, 2) for name in ('report.md', 'result.json', 'write-audit.json')]))
    env = h.environment(AREA)
    for name in list(env):
        if name.startswith(('OTA_', 'GH_', 'GITHUB_', 'P35_', 'TRACE_', 'CF_', 'CLOUDFLARE_')) or name == 'SSLKEYLOGFILE':
            env.pop(name)
    env.update(P51_PYTHON_DEPS=str(DEPS), BSDIFF_EXE=str(BSDIFF))
    h.command(AREA, 'entry', [sys.executable, '-I', '-S', '-B', '-X', 'utf8',
        ROOT / 'Tools/ota/p34-acceptance/selftest.py', 'p51-benchmark', '--out', AREA / 'entry'], env, seconds=300)
    h.command(AREA, 'probes', [sys.executable, '-I', '-S', '-B', '-X', 'utf8', Path(__file__), 'probes'], env, seconds=120)
    entry = h.read_json(AREA / 'entry/result.json')
    total = 0
    for test in entry['tests']:
        assert test['exit'] == 0 and not test['timed_out']
        log = h.pinned(test['log']).read_text(encoding='utf-8')
        total += int(re.search(r'Ran (\d+) tests in ', log)[1])
        assert '\nOK\n' in log
    assert entry['passed'] and total == 83
    source_pins()
    h.save(checked(AREA / 'checks.json'), dict(outcome='TARGETED_LOCAL_CI_CORRECTION_CHECKS_PASS',
        existingEntry=dict(tests=83, result=h.record(AREA / 'entry/result.json')),
        independentProbes=dict(tests=4, passed=4, stderr=h.record(AREA / 'probes.stderr')),
        nestedDiagnostic=h.record(AREA / 'diagnostic-result.json'),
        reusedGovernance=dict(tests=145, receipt=governance_pin, newlyExecuted=False),
        newRemoteCI='NOT_RUN', windowsVS17Build='NOT_RUN', candidateGenerations=0, devices=0, network=0))
    print('TARGETED_LOCAL_CI_CORRECTION_CHECKS_PASS tests=83 probes=4 reused_governance=145')


def seal():
    data = h.read_json(AREA / 'inputs.json')
    source_pins()
    for pin in data['oldReviews']:
        h.pinned(pin)
    h.pinned(data['failedCi'])
    for name in ('result.json', 'write-audit.json'):
        assert not checked(AREA / name).exists()
    checks = h.read_json(AREA / 'checks.json')
    assert checks['outcome'] == 'TARGETED_LOCAL_CI_CORRECTION_CHECKS_PASS'
    receipts = []
    for name in ('entry', 'probes'):
        pin = h.record(AREA / (name + '.closed.json'))
        receipt = h.read_json(h.pinned(pin))
        assert receipt['exit_code'] == 0 and receipt['cleanup_complete']
        h.pinned(receipt['stdout'])
        h.pinned(receipt['stderr'])
        receipts.append(pin)
    nested = h.read_json(h.pinned(checks['nestedDiagnostic']))
    receipt = h.read_json(h.pinned(nested['fixtureReceipt']))
    assert receipt['exit_code'] == 1 and receipt['cleanup_complete']
    result = dict(outcome='SCOPED_CODE_REVIEW_PASS', scope='CI-01/CI-02 correction only; no product or device acceptance',
        findings=[dict(id='P51-LONG-CI-01', codeStatus='READY', newRemoteCI='NOT_RUN_REQUIRED'),
            dict(id='P51-LONG-CI-02', codeStatus='CLOSED_LOCAL', newRemoteCI='NOT_RUN_REQUIRED')],
        sourceManifest=data['sourceManifest'], sources=data['files'], checks=checks,
        report=h.record(AREA / 'report.md'), receipts=receipts, previousReview=data['previousReview'],
        sourceComparison=h.record(AREA / 'source-comparison.json'),
        additionalOriginalEvaluation=h.record(AREA / 'receipt-evaluation.json'),
        previousExecFindings='CLOSED_UNCHANGED', packagingReview='CLOSED_NOT_REOPENED',
        failedCI=data['failedCi'], newRemoteCI='NOT_RUN_REQUIRED', localVS17Build='NOT_RUN',
        nextOwner='root: deliver only the reviewed correction and verify one new source-bound two-host governance CI',
        actualDedicatedApk='NOT_REVIEWED_THIS_SCOPE', P5='INCOMPLETE', devices=0, network=0,
        candidateGenerations=0, commits=0, SD_BLE_web_replays=0)
    h.save(checked(AREA / 'result.json'), result)
    after, before = snapshot_owner.snapshot(), data['externalBefore']
    changes = [dict(path=n, before=before.get(n), after=after.get(n), attribution='UNKNOWN')
        for n in sorted(set(before) | set(after)) if before.get(n) != after.get(n)]
    h.save(checked(AREA / 'write-audit.json'), dict(root=str(ROOT), authorizedOutputRoot=str(AREA),
        files=[h.record(checked(p)) for p in sorted(AREA.rglob('*')) if p.is_file()],
        report=result['report'], source=h.record(Path(__file__)), sourcePinsVerified=7,
        allControlledOutputsInsideReviewRoot=True, controlledExternalWrites=0,
        priorReviewArtifactsUnchanged=True, sourcesUnchanged=True, allOwnedProcessesClosed=True,
        processReceipts=receipts + [nested['fixtureReceipt']],
        expectedDiagnosticExit=1, shells=['cmd.exe'], reviewerPowerShellLaunches=0,
        externalBefore=before, externalAfter=after, externalChanges=changes,
        externalCleanup=False, attribution='UNKNOWN; other concurrent activity not excluded',
        devices=0, network=0, protectedKeyUse=False, candidateGenerations=0, commits=0))
    print(json.dumps(dict(outcome=result['outcome'], report=result['report'], externalChanges=changes)))


if __name__ == '__main__':
    preflight()
    {'run': run, 'probes': probes, 'seal': seal}[sys.argv[1]]()
