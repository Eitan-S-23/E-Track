"""Scoped source and checks-only delivery through the existing GitHub API owner."""
from pathlib import Path
import base64
import hashlib
import io
import json
import re
import stat
import sys
import time
import zipfile

ROOT = Path('D:/github/my/E-Track/.cache/p35-integration-20261028/source')
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path[:0] = [str(ROOT/'Tools/ota/p34-acceptance'), str(ROOT/'.cache')]
import live_host as h
import fw93 as f
AREA = h.checked(Path(__file__).resolve().parent)
BRANCH = 'dev/firmware/p51-packaging-20261104'
NOTE = 'docs/ota-exec-notes/P51-LONG-ENTRY-2026-11-08.md'
ARCHIVE = 'docs/ota-exec-notes/P51-LONG-ENTRY-2026-11-08/execution-review.zip'
CORRECTION = False
boundary = h.host.load('p51_execution_delivery_boundary', ROOT/'.cache/p51-normal-review-20261107-01/review.py')


def blob(raw):
    return hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()


def inputs():
    if CORRECTION:
        value = h.read_json(AREA/'ci-correction-inputs.json')
        assert len(value['files']) == 7 and value['tests'] == 83
        for pin in value['files']:
            h.pinned(pin)
        for pin in value['selftestComponents']:
            receipt = h.read_json(h.pinned(pin))
            assert receipt['exit_code'] == 0 and receipt['cleanup_complete'] is True
            h.pinned(receipt['stdout'])
            h.pinned(receipt['stderr'])
        h.pinned(value['failedCi'])
        h.pinned(value['previousReview'])
        return value
    value = h.read_json(AREA/'remediation-inputs.json')
    for pin in value['files']:
        h.pinned(pin)
    tests = h.read_json(h.pinned(value['selftest']))
    assert tests['outcome'] == 'SELFTEST_PASS' and sum(row['count'] for row in tests['checks']) == 80
    assert all(row['exit'] == 0 for row in tests['checks'])
    bound = h.read_json(h.pinned(value['packageBinding']))
    assert bound['outcome'] == 'ORIGINAL_PROTECTED_BENCHMARK_BINDING_PASS' and len(bound['negativeRejected']) == 5
    h.pinned(bound['source'])
    return value


def prepare(out, env):
    value = inputs()
    packaging = h.read_json(AREA/('execution-delivery-01/result.json' if CORRECTION else 'source-delivery-01/result.json'))
    parent = packaging['source']
    if CORRECTION:
        assert parent == 'dca0900e601a9df0ceab125329f80a3ad8a59a5c'
    assert f.api(out, env, 'branch', '/git/ref/heads/'+BRANCH)['object']['sha'] == parent
    commit = f.api(out, env, 'parent', '/git/commits/'+parent)
    tree = f.api(out, env, 'tree', '/git/trees/'+commit['tree']['sha']+'?recursive=1')
    assert tree['truncated'] is False
    blobs = {row['path']: row['sha'] for row in tree['tree'] if row['type'] == 'blob'}
    assert all(blobs.get(name) == digest for name, digest in packaging['gitBlobs'].items())
    pins = value['files']+[h.record(ROOT/NOTE)]
    changes = []
    for pin in pins:
        name = Path(pin['path']).as_posix()
        raw = h.pinned(pin).read_bytes().replace(b'\r\n', b'\n')
        changes.append(dict(path=name, old=blobs.get(name), new=blob(raw), local=pin))
    assert len(changes) == (8 if CORRECTION else 10) and all(row['old'] != row['new'] for row in changes)
    h.save(out/'result.json', dict(outcome='EXECUTION_SOURCE_DELIVERY_PREPARED', branch=BRANCH,
        parent=parent, tree=commit['tree']['sha'], changes=changes,
        reviewInputs=h.record(AREA/('ci-correction-inputs.json' if CORRECTION else 'remediation-inputs.json')),
        packageSource='d87a711631ab27c8b46e7cc9812d388afea27a57' if CORRECTION else parent,
        appBuildWorkflowBlob=blobs['.github/workflows/build.yml'],
        localSharedGitWrites=0, remoteMutations=0, devices=0))
    print('EXECUTION_SOURCE_DELIVERY_PREPARED '+str(len(value['files']))+' reviewed source/Spec inputs plus task note', flush=True)


def review_archive(approval):
    review = h.pinned(approval['review'])
    result = h.pinned(approval['result'])
    assert review.parent == result.parent == AREA/('execution-review-03' if CORRECTION else 'execution-review-02')
    saved = {}
    labels = ('execution-review-03', 'ci-correction-check-01', 'ci-correction-check-02',
        'execution-ci-logs-01', 'execution-ci-artifacts-01', 'windows-vendor-01') if CORRECTION else (
        'execution-review-01', 'execution-review-02', 'execution-check-06', 'execution-check-07', 'package-binding-02')
    for label in labels:
        for path in (AREA/label).rglob('*'):
            relative = path.relative_to(AREA/label)
            if not path.is_file() or any(part in ('host', 'fixtures', 'probe-fixtures', 'b') for part in relative.parts):
                continue
            if path.suffix not in ('.json', '.md', '.stdout', '.stderr', '.py', '.log'):
                continue
            raw = path.read_bytes()
            assert len(raw) < 8*1024*1024
            assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{35,}|-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----)', raw)
            saved[path.relative_to(AREA).as_posix()] = raw
    assert review.relative_to(AREA).as_posix() in saved and result.relative_to(AREA).as_posix() in saved
    with io.BytesIO() as stream:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, raw in sorted(saved.items()):
                archive.writestr(name, raw)
        raw = stream.getvalue()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert archive.testzip() is None and all(archive.read(name) == value for name, value in saved.items())
    return raw


def deliver(out, env):
    inputs()
    prefix = 'ci-correction' if CORRECTION else 'execution'
    assert not list(AREA.glob(prefix+'-delivery-*/commit-intent.json')), 'Reconcile prior remote mutation; do not repeat'
    prep = AREA/('ci-correction-prep-01/result.json' if CORRECTION else 'delivery-prep-01/result.json')
    scope = h.read_json(prep)
    approval = h.read_json(AREA/('ci-correction-review-admission.json' if CORRECTION else 'root-review-admission.json'))
    expected_findings = ['P51-LONG-CI-01', 'P51-LONG-CI-02'] if CORRECTION else [
        'P51-LONG-EXEC-01', 'P51-LONG-EXEC-02', 'P51-LONG-EXEC-03']
    assert approval['codeReadiness'] == 'SCOPED_REVIEW_PASS'
    assert approval['addressedFindings' if CORRECTION else 'closedFindings'] == expected_findings
    assert approval['inputs'] == scope['reviewInputs'] == h.record(AREA/(
        'ci-correction-inputs.json' if CORRECTION else 'remediation-inputs.json'))
    raw = review_archive(approval)
    archive_path = h.checked(ROOT/ARCHIVE)
    assert not archive_path.exists()
    h.raw(archive_path, raw)
    parent = scope['parent']
    assert f.api(out, env, 'branch-before', '/git/ref/heads/'+BRANCH)['object']['sha'] == parent
    h.save(out/'commit-intent.json', dict(parent=parent, branch=BRANCH, scope=h.record(prep),
        review=approval, artifact=h.record(archive_path), mainMutation=False, devices=0))
    entries, expected = [], {}
    for row in scope['changes']:
        data = h.pinned(row['local']).read_bytes().replace(b'\r\n', b'\n')
        assert blob(data) == row['new']
        entries.append(dict(path=row['path'], mode='100644', type='blob', content=data.decode('utf-8')))
        expected[row['path']] = row['new']
    created = f.api(out, env, 'review-blob', '/git/blobs', dict(content=base64.b64encode(raw).decode(), encoding='base64'), 'POST')
    assert created['sha'] == blob(raw)
    entries.append(dict(path=ARCHIVE, mode='100644', type='blob', sha=created['sha']))
    expected[ARCHIVE] = created['sha']
    tree = f.api(out, env, 'source-tree', '/git/trees', dict(base_tree=scope['tree'], tree=entries), 'POST')
    message = ('fix(ci): provision P51 host fixture dependencies and canonical decision fields\n\n'
        'Scoped CI-01/02 correction with preserved failed CI and independent review. '
        'No MCU rebuild, package regeneration, public selection change, release or device operation.') if CORRECTION else (
        'fix(ota): bind P51 benchmark provenance and bounded recording lifecycle\n\nReviewed execution/Spec batch with original remediation evidence. Dedicated APK and physical campaign remain separate. No MCU rebuild, public selection change, release or device operation.')
    commit = f.api(out, env, 'source-commit', '/git/commits', dict(tree=tree['sha'], parents=[parent], message=message), 'POST')
    diff = f.api(out, env, 'exact-diff', '/compare/'+parent+'...'+commit['sha'])
    assert diff['ahead_by'] == 1 and diff['behind_by'] == 0 and {row['filename']: row['sha'] for row in diff['files']} == expected
    assert f.api(out, env, 'branch-recheck', '/git/ref/heads/'+BRANCH)['object']['sha'] == parent
    f.api(out, env, 'branch-update', '/git/refs/heads/'+BRANCH, dict(sha=commit['sha'], force=False), 'PATCH')
    assert f.api(out, env, 'branch-after', '/git/ref/heads/'+BRANCH)['object']['sha'] == commit['sha']
    result = dict(outcome='REVIEWED_EXECUTION_SOURCE_DELIVERED', source=commit['sha'], tree=tree['sha'], parent=parent,
        branch=BRANCH, review=approval, archive=h.record(archive_path), gitBlobs=expected,
        localSharedGitWrites=0, devices=0, mainMerged=False, packageGenerations=0)
    h.save(out/'result.json', result)
    print(json.dumps({key: result[key] for key in ('outcome', 'source', 'tree', 'branch')}), flush=True)


def ci(mode, out, env):
    prefix = 'ci-correction' if CORRECTION else 'execution-ci'
    run_path = AREA/(prefix+'-run.json')
    delivery = h.read_json(AREA/('ci-correction-delivery-02/result.json' if CORRECTION else 'execution-delivery-01/result.json'))
    source = delivery['source']
    workflow = '/actions/workflows/acceptance-governance.yml'
    if mode == 'dispatch':
        assert not list(AREA.glob(prefix+'-dispatch-*/dispatch-intent.json'))
        assert not run_path.exists()
        assert f.api(out, env, 'branch', '/git/ref/heads/'+BRANCH)['object']['sha'] == source
        before = f.api(out, env, 'runs-before', workflow+'/runs?branch='+BRANCH+'&per_page=50')['workflow_runs']
        assert not any(row['head_sha'] == source for row in before), 'Observe existing exact-source CI instead'
        f.api(out, env, 'dispatch', workflow+'/dispatches', dict(ref=BRANCH), 'POST')
        old = {row['id'] for row in before}
        for index in range(12):
            time.sleep(3)
            rows = f.api(out, env, 'runs-after-%02d' % index, workflow+'/runs?branch='+BRANCH+'&per_page=50')['workflow_runs']
            found = [row for row in rows if row['id'] not in old and row['head_sha'] == source]
            if found:
                assert len(found) == 1 and found[0]['run_attempt'] == 1 and found[0]['event'] == 'workflow_dispatch'
                h.save(run_path, found[0])
                h.save(out/'result.json', dict(outcome='EXECUTION_GOVERNANCE_CI_DISPATCHED', runId=found[0]['id'], source=source))
                print('EXECUTION_GOVERNANCE_CI_DISPATCHED '+str(found[0]['id']), flush=True)
                return
        raise RuntimeError('Dispatch not observed; reconcile without repeating')
    run_id = h.read_json(run_path)['id']
    run = f.api(out, env, 'run', '/actions/runs/'+str(run_id))
    assert run['head_sha'] == source and run['run_attempt'] == 1 and run['path'] == '.github/workflows/acceptance-governance.yml'
    jobs = f.api(out, env, 'jobs', '/actions/runs/'+str(run_id)+'/jobs?per_page=100')
    if mode == 'artifacts':
        assets = f.api(out, env, 'artifacts', '/actions/runs/'+str(run_id)+'/artifacts?per_page=100')
        assert assets['total_count'] == len(assets['artifacts']) == 2
        saved = []
        for host in ('ubuntu-latest', 'windows-latest'):
            asset, = [item for item in assets['artifacts'] if item['name'] == 'p34-live-host-'+host+'-'+str(run_id)+'-1']
            assert not asset['expired'] and asset['workflow_run']['id'] == run_id and asset['workflow_run']['head_sha'] == source
            assert 0 < asset['size_in_bytes'] < 8*1024*1024
            raw = h.command(out, host, ['gh', 'api', 'repos/'+f.REPO+'/actions/artifacts/'+str(asset['id'])+'/zip'], env, seconds=150)
            assert len(raw) == asset['size_in_bytes'] and asset['digest'] == 'sha256:'+hashlib.sha256(raw).hexdigest()
            paths = []
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) < 200
                assert sum(item.file_size for item in archive.infolist()) < 32*1024*1024
                for item in archive.infolist():
                    name = item.filename
                    assert not item.is_dir() and not stat.S_ISLNK(item.external_attr >> 16)
                    assert ':' not in name and '\\' not in name and all(part not in ('', '.', '..') for part in name.split('/'))
                    assert name.split('/')[0] in ('p34-service-'+str(run_id)+'-1', 'p34-live-'+str(run_id)+'-1', 'p51-benchmark-'+str(run_id)+'-1')
                    assert name.endswith(('.json', '.log')) or (CORRECTION and
                        re.fullmatch(r'p51-benchmark-\d+-1/fixtures/normal-[^/]+/prepare-[^/]+\.(?:stdout|stderr)', name))
                    paths.append((h.checked(out/host/name), item))
                for path, item in paths:
                    h.raw(path, archive.read(item))
            saved.append(dict(artifact=asset, archive=h.record(out/(host+'.stdout')), files=[h.record(path) for path, _ in paths]))
        h.save(out/'result.json', dict(outcome='GOVERNANCE_SELFTEST_ORIGINAL_ARTIFACTS_RETRIEVED', runId=run_id,
            source=source, conclusion=run['conclusion'], artifacts=saved))
        print('GOVERNANCE_SELFTEST_ORIGINAL_ARTIFACTS_RETRIEVED 2', flush=True)
        return
    if mode == 'logs':
        originals = []
        for job in jobs['jobs']:
            if job['status'] != 'completed' or job['conclusion'] == 'skipped':
                continue
            label = 'job-'+str(job['id'])
            h.command(out, label, ['gh', 'api', 'repos/'+f.REPO+'/actions/jobs/'+str(job['id'])+'/logs'], env, seconds=150)
            originals.append(dict(job=job['id'], name=job['name'], conclusion=job['conclusion'],
                log=h.record(out/(label+'.stdout')), receipt=h.record(out/(label+'.closed.json'))))
        h.save(out/'result.json', dict(outcome='EXECUTION_GOVERNANCE_ORIGINAL_LOGS_RETRIEVED', runId=run_id,
            source=source, status=run['status'], conclusion=run['conclusion'], originals=originals,
            workflowRun=h.record(out/'run.stdout'), workflowJobs=h.record(out/'jobs.stdout')))
        print(json.dumps(dict(runId=run_id, logs=len(originals), conclusion=run['conclusion'])), flush=True)
        return
    h.save(out/'result.json', dict(outcome='EXECUTION_GOVERNANCE_CI_OBSERVED', runId=run_id, source=source,
        status=run['status'], conclusion=run['conclusion'], jobs=jobs,
        workflowRun=h.record(out/'run.stdout'), workflowJobs=h.record(out/'jobs.stdout')))
    print(json.dumps(dict(runId=run_id, status=run['status'], conclusion=run['conclusion'],
        jobs=[{key: row[key] for key in ('id', 'name', 'status', 'conclusion')} for row in jobs['jobs']])), flush=True)


def main():
    global CORRECTION, ARCHIVE
    mode, label = sys.argv[1:]
    if mode.endswith('-correction'):
        CORRECTION = True
        ARCHIVE = 'docs/ota-exec-notes/P51-LONG-ENTRY-2026-11-08/ci-correction-review.zip'
        mode = mode.removesuffix('-correction')
    assert mode in ('prepare', 'deliver', 'dispatch', 'status', 'logs', 'artifacts')
    pattern = r'ci-correction-(?:prep|delivery|dispatch|status|logs|artifacts)-[0-9]+' if CORRECTION else (
        r'(?:delivery-prep|execution-delivery|execution-ci-dispatch|execution-ci-status|execution-ci-logs|execution-ci-artifacts)-[0-9]+')
    assert re.fullmatch(pattern, label)
    out = h.checked(AREA/label)
    for name in ('host', 'source.py', 'result.json', 'audit.json', 'failed.json'):
        h.checked(out/name)
    if mode == 'deliver':
        h.checked(ROOT/ARCHIVE)
    if mode == 'dispatch':
        h.checked(AREA/('ci-correction-run.json' if CORRECTION else 'execution-ci-run.json'))
    assert not out.exists()
    before = boundary.snapshot()
    f.AREA = AREA
    out, env = f.init(label)
    h.raw(out/'source.py', Path(__file__).read_bytes())
    try:
        if mode == 'prepare':
            prepare(out, env)
        elif mode == 'deliver':
            deliver(out, env)
        else:
            ci(mode, out, env)
    except BaseException as error:
        h.save(out/'failed.json', dict(type=type(error).__name__, preserve=True, noAutomaticReplay=True))
        raise
    finally:
        env.pop('GH_TOKEN', None)
        after = boundary.snapshot()
        h.save(out/'audit.json', dict(root=str(ROOT), externalBefore=before, externalAfter=after,
            externalChanges=[dict(path=name, before=before.get(name), after=after.get(name))
                for name in sorted(set(before)|set(after)) if before.get(name) != after.get(name)],
            attribution='UNKNOWN', externalCleanup=False, localSharedGitWrites=0, devices=0))


if __name__ == '__main__':
    main()
