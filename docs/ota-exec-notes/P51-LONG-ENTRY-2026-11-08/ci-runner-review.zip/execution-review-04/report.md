# P51-LONG-CI-01 Runner Correction Review

Outcome: **CODE_READY_NEW_WINDOWS_CI_PENDING**. No new blocking code findings.

Scope is only the runner matrix change and its two regression assertions.
The before-images match review-03; the exact two-file comparison is in
`source-comparison.json`. EXEC-01/02/03, CI-02 and packaging are not reopened.

## Evidence And Result

- CI run 42420550410 failed before Windows P51 tests: its actual image was
  `windows-2025-vs2026`, with no `Visual Studio 17 2022` installation.
  Crypto installation succeeded; Linux and governance jobs passed.
- Pinning the matrix to `windows-2022` aligns with the explicitly requested
  VS 2022 generator. The existing test now guards both settings.
- Independently executed once:
  `python -I -S -B -X utf8 tests/ota/test_p51_benchmark_execution.py BenchmarkTests.test_ci_prepares_real_fixture_dependencies_on_both_hosts`.
  Result: 1 test PASS, 0.018 s, exit 0, no warnings/errors in the test stream;
  process cleanup completed. Exact invocation and streams are retained.
- Root's 40-test PASS was independently read back, not rerun.
  Original observations and receipts are bound in `result.json`.

## Source Pins

- `.github/workflows/acceptance-governance.yml`: 12459 bytes,
  SHA-256 `f7d62090055db1f16daa2fe20d40f7768811822dc323a6355b012fdd936223db`.
- `tests/ota/test_p51_benchmark_execution.py`: 49108 bytes,
  SHA-256 `351a3ecc21df34d91c2f107d4741d8eb93e48b8858ed60cb2eeb4faa076ca931`.

## Next Owner And Boundary

Root may deliver this correction and run fresh Windows CI. New Windows vendor
bsdiff build/tests remain **NOT_RUN** in this review; historical App builds do
not substitute for them. Retrieve the host artifact using `windows-2022`,
not the old `windows-latest` name. This is not physical acceptance; P5 remains
incomplete. No SD or other completed physical observation was repeated.

Reviewer outputs are confined to this review directory. No product edits,
Git writes, packaging, network, CI dispatch or device operations were performed.
One monitored external file changed during the review:
`C:/Users/SU/AppData/Local/Microsoft/Windows/PowerShell/StartupProfileData-NonInteractive`.
Attribution is UNKNOWN; it is preserved, with before/after pins in
`write-audit.json`. No external cleanup was attempted.
