"""Bounded root-owned GitHub operations using the existing command/credential adapter."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
AREA = Path(__file__).resolve().parent
BRANCH = 'dev/firmware/p51-packaging-20261104'
SOURCE = '446b0a99b8538714be7e54e640eeb6e58658e76b'
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(ROOT / '.cache'))
import fw93 as f
h = f.h
f.AREA = AREA
ENV = '/environments/firmware-rehearsal'
RUNS = '/actions/workflows/firmware-build.yml/runs?branch=' + BRANCH + '&event=workflow_dispatch&per_page=30'


def protected(out, env, prefix):
    routes = {'environment': ENV, 'branches': ENV + '/deployment-branch-policies?per_page=100',
        'repository-gate': '/actions/variables/OTA_BOOT_CHAIN_READY',
        'rehearsal-gate': ENV + '/variables/OTA_BOOT_CHAIN_READY',
        'production-gate': '/environments/firmware-production/variables/OTA_BOOT_CHAIN_READY'}
    result = {}
    for label, route in routes.items():
        result[label] = f.api(out, env, prefix + '-' + label, route)
    assert all(result[k]['value'] == 'false' for k in routes if k.endswith('-gate'))
    assert any(x['type'] == 'required_reviewers' and x.get('reviewers')
               for x in result['environment']['protection_rules'])
    assert result['branches']['total_count'] <= 100
    return result


def main():
    mode, label, *args = sys.argv[1:]
    assert mode in ('prepare', 'push', 'admit', 'dispatch', 'status', 'approve', 'artifacts')
    h.checked(AREA / label)
    out, env = f.init(label)
    for key in ('ANTHROPIC_API_KEY', 'WECHAT_WEBHOOK_KEY', 'GIT_NO_DEBUG_CHECK', 'GIT_NO_SECRET_CHECK'):
        env.pop(key, None)
    common = Path('D:/github/my/E-Track/.git')
    before = {name: hashlib.sha256((common / name).read_bytes()).hexdigest() for name in ('index', 'config', 'HEAD')}
    try:
        h.save(out / 'authority.json', dict(timeUtc=datetime.now(timezone.utc).isoformat(),
            userInstruction='Full authority for the previously specified P51 push/admit/dispatch/delegated approval chain; no repeated request.',
            source=SOURCE, branch=BRANCH, production=False, deviceOperations=0))
        if mode == 'prepare':
            state = protected(out, env, 'before')
            branches = f.api(out, env, 'remote-branch', '/git/matching-refs/heads/' + BRANCH)
            assert all(x['ref'] != 'refs/heads/' + BRANCH or x['object']['sha'] == SOURCE for x in branches)
            runs = f.api(out, env, 'firmware-runs', '/actions/workflows/firmware-build.yml/runs?per_page=50')
            assert all(x['status'] == 'completed' for x in runs['workflow_runs']), 'Active firmware run; reconcile'
            h.save(out / 'result.json', dict(outcome='READY', state=state, branchExists=bool(branches)))
        elif mode == 'push':
            for rel in ('objects', 'refs/remotes/origin/' + BRANCH, 'refs/remotes/origin/' + BRANCH + '.lock',
                        'logs/refs/remotes/origin/' + BRANCH, 'packed-refs', 'packed-refs.lock'):
                h.host.io.checked_output(common, common / rel)
            git = ['git', '-c', 'gc.auto=0', '-c', 'core.hooksPath=C:/Users/SU/.git-hooks',
                   '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential']
            assert h.command(out, 'head', git + ['rev-parse', 'HEAD'], env, seconds=20).decode().strip() == SOURCE
            remote = h.command(out, 'remote-before', git + ['ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH], env, seconds=60)
            if remote.strip():
                assert remote.decode().split()[0] == SOURCE, 'Unexpected remote branch; no overwrite'
            else:
                h.command(out, 'push', git + ['push', '--porcelain', 'origin', SOURCE + ':refs/heads/' + BRANCH], env, seconds=300)
            actual = f.api(out, env, 'remote-after', '/git/ref/heads/' + BRANCH)
            assert actual['object']['sha'] == SOURCE
            h.save(out / 'result.json', dict(outcome='EXACT_BRANCH_PUSHED', source=SOURCE, noForce=True))
        elif mode == 'admit':
            before_state = protected(out, env, 'before')
            old = before_state['branches']['branch_policies']
            matching = [x for x in old if x['name'] == BRANCH and x['type'] == 'branch']
            assert len(matching) <= 1
            if not matching:
                f.api(out, env, 'add-branch', ENV + '/deployment-branch-policies', dict(name=BRANCH, type='branch'), 'POST')
            after = protected(out, env, 'after')
            assert all(after[k] == before_state[k] for k in before_state if k != 'branches')
            new = after['branches']['branch_policies']
            assert all(x in new for x in old)
            assert len(new) == len(old) + (not matching)
            assert any(x['name'] == BRANCH and x['type'] == 'branch' for x in new)
            h.save(out / 'result.json', dict(outcome='EXACT_BRANCH_ADMITTED', additions=int(not matching), protectionsUnchanged=True))
        elif mode == 'dispatch':
            state = protected(out, env, 'before')
            assert any(x['name'] == BRANCH and x['type'] == 'branch' for x in state['branches']['branch_policies'])
            ref = f.api(out, env, 'source', '/git/ref/heads/' + BRANCH)
            assert ref['object']['sha'] == SOURCE
            old = f.api(out, env, 'runs-before', RUNS)['workflow_runs']
            assert not old, 'Existing task dispatch; reconcile rather than redispatch'
            inputs = dict(package_candidate='true', candidate_reviewed_commit=SOURCE, publish='false',
                rehearsal='false', check_bindings='false', version_name='3.3.16', firmware_build_profile='p34-v2-candidate')
            f.api(out, env, 'dispatch', '/actions/workflows/firmware-build.yml/dispatches', dict(ref=BRANCH, inputs=inputs), 'POST')
            for i in range(6):
                time.sleep(5)
                runs = f.api(out, env, 'runs-after-' + str(i), RUNS)['workflow_runs']
                if runs:
                    assert len(runs) == 1 and runs[0]['head_sha'] == SOURCE
                    h.save(AREA / 'ci-run.json', runs[0])
                    print(json.dumps({k:runs[0][k] for k in ('id','status','head_sha','html_url')}), flush=True)
                    break
            else:
                raise RuntimeError('Dispatch unresolved; do not redispatch')
        else:
            saved = h.read_json(AREA / 'ci-run.json')
            run_id = str(saved['id'])
            run = f.api(out, env, 'run', '/actions/runs/' + run_id)
            assert run['head_sha'] == SOURCE and run['run_attempt'] == 1 and run['head_branch'] == BRANCH
            jobs = f.api(out, env, 'jobs', '/actions/runs/' + run_id + '/jobs?per_page=100')['jobs']
            if mode in ('status', 'approve'):
                pending = f.api(out, env, 'pending', '/actions/runs/' + run_id + '/pending_deployments')
                if mode == 'approve':
                    protected(out, env, 'before-approval')
                    assert len(pending) == 1 and pending[0]['environment']['name'] == 'firmware-rehearsal'
                    assert pending[0]['current_user_can_approve']
                    assert all(x['conclusion'] == 'skipped' for x in jobs if x['name'] != 'Protected P5 candidate artifacts (no release or device operation)')
                    f.api(out, env, 'approve', '/actions/runs/' + run_id + '/pending_deployments',
                        dict(environment_ids=[pending[0]['environment']['id']], state='approved',
                        comment='User-delegated root approval: reviewed P51 artifact-only packaging, exact SHA ' + SOURCE + '; production gate remains closed; no device operation.'), 'POST')
                print(json.dumps(dict(id=run['id'], status=run['status'], conclusion=run['conclusion'],
                    jobs=[dict(name=x['name'],status=x['status'],conclusion=x['conclusion']) for x in jobs],
                    pending=[x['environment']['name'] for x in pending])), flush=True)
            else:
                assert run['status'] == 'completed'
                result = f.api(out, env, 'artifacts', '/actions/runs/' + run_id + '/artifacts')
                h.save(out / 'result.json', result)
                print(json.dumps(result), flush=True)
    finally:
        env.pop('GH_TOKEN', None)
        assert before == {name: hashlib.sha256((common / name).read_bytes()).hexdigest() for name in before}
        h.save(out / 'write-audit.json', dict(mainMetadataUnchanged=True, activeRoot=str(ROOT), mode=mode,
            externalGitScope='task remote-tracking ref only for push', devices=0))


if __name__ == '__main__':
    main()
