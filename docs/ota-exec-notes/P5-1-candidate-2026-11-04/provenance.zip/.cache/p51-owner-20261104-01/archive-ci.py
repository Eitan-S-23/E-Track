"""Preserve reviewed candidate bytes and original CI/owner receipts, not formal acceptance."""
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
AREA = Path(__file__).resolve().parent
DEST = ROOT / 'docs/ota-exec-notes/P5-1-candidate-2026-11-04'
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(ROOT / 'Tools/ota/p34-acceptance'))
import live_host as h

review = h.read_json(AREA / 'ci-verify-02/result.json')
assert review['outcome'] == 'PROTECTED_CANDIDATE_ORIGINALS_REVIEW_PASS'
before = h.read_json(AREA / 'ci-prepare-01/result.json')['state']
after = h.read_json(AREA / 'ci-final-state-01/result.json')['state']
assert all(before[k] == after[k] for k in before if k != 'branches')
old, new = before['branches']['branch_policies'], after['branches']['branch_policies']
assert all(x in new for x in old) and len(new) == len(old) + 1
assert [x['name'] for x in new if x not in old] == ['dev/firmware/p51-packaging-20261104']
common = Path('D:/github/my/E-Track/.git')
assert hashlib.sha256((common / 'index').read_bytes()).hexdigest() == '2907ee569cb8415877c8c688b3e09b5948a789d6430796eab99ae3ad43f3a3dd'
files = []
closed_count = 0
for folder in sorted(AREA.glob('ci-*')):
    if not folder.is_dir():
        continue
    for p in sorted(folder.iterdir()):
        if p.is_file():
            if p.name.endswith('.started.json'):
                receipt = p.with_name(p.name.replace('.started.json','.closed.json'))
                assert receipt.is_file() and h.read_json(receipt)['cleanup_complete']
                closed_count += 1
            if p.name not in ('archive.stdout','workflow-logs.stdout'):
                files.append(p)
for name in ('ci.py','ci-run.json','retrieve.py','verify-ci.py','verify-ci-attempt01.py',
             'verify-ci-attempt01.json','verify-ci-attempt02.py','archive-ci.py'):
    files.append(AREA / name)
index = {p.relative_to(ROOT).as_posix(): h.record(p) for p in files}
memory = io.BytesIO()
with zipfile.ZipFile(memory,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        z.writestr(p.relative_to(ROOT).as_posix(), p.read_bytes())
    z.writestr('index.json',json.dumps(index,indent=2)+'\n')
packet = memory.getvalue()
with zipfile.ZipFile(io.BytesIO(packet)) as z:
    assert z.testzip() is None
    for name, pin in index.items():
        data = z.read(name)
        assert len(data) == pin['bytes'] and hashlib.sha256(data).hexdigest() == pin['sha256']
outputs = {
    'artifact.zip': (AREA / 'ci-download-01/archive.stdout').read_bytes(),
    'workflow-logs.zip': (AREA / 'ci-download-01/workflow-logs.stdout').read_bytes(),
    'provenance.zip': packet,
    'review.json': (AREA / 'ci-verify-02/result.json').read_bytes(),
    'github-artifact.json': (AREA / 'ci-download-01/artifact-metadata.stdout').read_bytes(),
}
for name in [*outputs, 'index.json']:
    assert not h.checked(DEST / name).exists()
for name, data in outputs.items():
    h.raw(DEST / name, data)
h.save(DEST / 'index.json', dict(kind='P51_PREPARATION_EVIDENCE_NOT_FORMAL_ACCEPTANCE',
    files=[h.record(DEST/name) for name in outputs], source='446b0a99b8538714be7e54e640eeb6e58658e76b',
    runId=41778918087, attempt=1, artifactId=13298118510, closedOwnerCommands=closed_count,
    environmentAddedExactlyOneBranch=True, gatesAndReviewersUnchanged=True, mainIndexUnchanged=True,
    remoteMutations=dict(branchPush=1, environmentBranchAddition=1, workflowDispatch=1, delegatedApproval=1),
    deviceOperations=0, productionRelease=False, secretExport=False,
    writeScope='Active worktree; authorized task Git remote-tracking metadata; authorized GitHub branch/environment/CI only'))
print(json.dumps(dict(archived=str(DEST), files=len(outputs)+1, closedOwnerCommands=closed_count)), flush=True)
