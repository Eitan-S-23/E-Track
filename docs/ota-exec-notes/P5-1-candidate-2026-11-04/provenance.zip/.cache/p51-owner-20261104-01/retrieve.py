"""Retrieve one identified CI archive; never dispatch or access the protected key."""
import hashlib
import io
import json
from pathlib import Path
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
AREA = Path(__file__).resolve().parent
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(ROOT / '.cache'))
import fw93 as f
f.AREA = AREA
h = f.h
out, env = f.init('ci-download-01')
try:
    artifact = h.read_json(AREA / 'ci-artifacts-01/result.json')['artifacts'][0]
    assert artifact['id'] == 13298118510 and artifact['workflow_run']['id'] == 41778918087
    assert artifact['workflow_run']['head_sha'] == '446b0a99b8538714be7e54e640eeb6e58658e76b'
    fresh = f.api(out, env, 'artifact-metadata', '/actions/artifacts/' + str(artifact['id']))
    assert fresh == artifact and not fresh['expired']
    raw = h.command(out, 'archive', ['gh', 'api', 'repos/' + f.REPO + '/actions/artifacts/' + str(artifact['id']) + '/zip'], env, seconds=150)
    assert len(raw) == artifact['size_in_bytes'] and 'sha256:' + hashlib.sha256(raw).hexdigest() == artifact['digest']
    prepared = {'prepared/' + name for name in ('app-final.bin', 'X-Track-Boot.bin', 'full.etu', 'patch.etu',
                'reference-1MiB.etu', 'recovery.bin', 'candidate-metadata.json')}
    files = []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert sum(x.file_size for x in archive.infolist()) < 20 * 1024 * 1024
        assert archive.testzip() is None
        for item in archive.infolist():
            name = item.filename
            assert name and ':' not in name and '\\' not in name and not name.startswith('/')
            assert all(p not in ('', '.', '..') for p in name.rstrip('/').split('/'))
            assert not stat.S_ISLNK(item.external_attr >> 16)
            assert name in prepared or name.startswith('evidence/')
            target = h.checked(out / 'extracted' / name)
            if not item.is_dir():
                files.append((target, archive.read(item)))
        assert prepared <= set(archive.namelist())
        # All member destinations are checked before the first extraction write.
        for target, data in files:
            h.raw(target, data)
    logs = h.command(out, 'workflow-logs', ['gh', 'api', 'repos/' + f.REPO + '/actions/runs/41778918087/logs'], env, seconds=120)
    with zipfile.ZipFile(io.BytesIO(logs)) as archive:
        assert archive.testzip() is None
    h.save(out / 'result.json', dict(outcome='CI_ARCHIVE_DOWNLOADED_AND_REHASHED', artifact=artifact,
        archive=h.record(out / 'archive.stdout'), logs=h.record(out / 'workflow-logs.stdout'),
        files=[h.record(p) for p, _ in files], sourceUnchanged=True, deviceOperations=0))
    print(json.dumps(dict(outcome='DOWNLOADED', artifact=artifact['id'], bytes=len(raw), members=len(files))), flush=True)
finally:
    env.pop('GH_TOKEN', None)
