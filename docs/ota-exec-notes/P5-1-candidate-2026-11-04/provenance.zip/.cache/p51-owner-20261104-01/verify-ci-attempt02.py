"""Independent original-artifact inspection; no encryption key or device access."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import sysconfig
import zipfile

ROOT = Path(__file__).resolve().parents[2]
AREA = Path(__file__).resolve().parent
DOWNLOAD = AREA / 'ci-download-01'
DATA = DOWNLOAD / 'extracted'
SOURCE = '446b0a99b8538714be7e54e640eeb6e58658e76b'
assert Path.cwd() == ROOT and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path[:0] = [str(ROOT / 'Tools/ota/p34-acceptance'), str(ROOT / 'Tools'), sysconfig.get_path('platlib')]
import live_host as h
import etu_unpack as unpack
spec = importlib.util.spec_from_file_location('bootstrap', ROOT / 'Tools/jlink/prepare-bootstrap-app.py')
recovery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
sha = lambda data: hashlib.sha256(data).hexdigest()
out = h.fresh(AREA / 'ci-verify-01')
env = h.environment(out)
checks = []


def passed(name):
    checks.append(name)
    print(name + ' PASS', flush=True)


try:
    download = h.read_json(DOWNLOAD / 'result.json')
    for pin in download['files'] + [download['archive'], download['logs']]:
        h.pinned(pin)
    artifact = download['artifact']
    assert artifact['id'] == 13298118510 and artifact['size_in_bytes'] == 3082312
    assert artifact['digest'] == 'sha256:' + sha((DOWNLOAD / 'archive.stdout').read_bytes())
    run = json.loads((AREA / 'ci-status-02/run.stdout').read_bytes())
    assert run['conclusion'] == 'success' and run['id'] == 41778918087 and run['run_attempt'] == 1
    assert run['head_sha'] == SOURCE and artifact['workflow_run']['head_sha'] == SOURCE
    jobs = json.loads((AREA / 'ci-status-02/jobs.stdout').read_bytes())['jobs']
    selected = [j for j in jobs if j['conclusion'] != 'skipped']
    assert len(selected) == 1 and selected[0]['conclusion'] == 'success'
    assert all(s['conclusion'] == 'success' for s in selected[0]['steps'])
    passed('archive-and-executed-ci-identity')

    manifest_raw = (ROOT / 'Tools/ota/p51-candidate-inputs.json').read_bytes().replace(b'\r\n', b'\n')
    manifest = json.loads(manifest_raw)
    assert (DATA / 'evidence/inputs.json').read_bytes() == manifest_raw
    binding = h.read_json(DATA / 'evidence/input-binding.json')
    metadata = h.read_json(DATA / 'prepared/candidate-metadata.json')
    assert binding['manifestSha256'] == sha(manifest_raw)
    assert binding['owner'] == dict(commitSha=SOURCE, runId='41778918087', runAttempt='1') == metadata['runner']
    assert metadata['appSourceCommit'] == manifest['sourceCommit']
    assert metadata['originalCiRun'] == manifest['originalRun'] and metadata['originalCiArtifact'] == manifest['originalArtifact']
    assert metadata['sourceEvidenceCommit'] == manifest['sourceEvidenceCommit']
    assert metadata['key'] == dict(source='approved-ci-key-v1', exactOriginalBuildBindingMatched=True)
    assert metadata['isFormalRelease'] is False and metadata['productionPublishable'] is False
    assert metadata['readyRegistered'] is False and metadata['hardwareAcceptance'] == 'NOT_RUN'
    assert metadata['noCloudMutation'] and metadata['noDeviceOperation']
    passed('manifest-source-and-protected-key-execution')

    target = (DATA / 'prepared/app-final.bin').read_bytes()
    assert len(target) == metadata['targetBytes'] == 614092
    assert sha(target) == metadata['targetImageSha256'] == manifest['targetSha256']
    header = recovery.validate_app(target)
    assert header['version_code'] == metadata['versionCode'] == 30316
    assert header['version_name'] == metadata['versionName'] == '3.3.16'
    assert metadata['buildTimestamp'] == manifest['targetTimestamp'] == 1793038630
    recovered, kind = recovery.split_asset((DATA / 'prepared/recovery.bin').read_bytes(), 'recovery')
    assert kind == 'recovery' and recovered == target
    boot = (DATA / 'prepared/X-Track-Boot.bin').read_bytes()
    assert sha(boot) == metadata['boot']['sha256'] == manifest['boot']['sha256']
    assert len(boot) == metadata['boot']['bytes'] == manifest['boot']['bytes'] == 14800
    assert metadata['boot']['kind'] == 'external-approved-group16'
    assert metadata['boot']['evidenceCommit'] == manifest['bootEvidenceCommit']
    assert metadata['boot']['source'] == manifest['boot']['source'] and not metadata['boot']['firmwareRebuilt']
    passed('target-header-recovery-and-external-group16-boot')

    assert [a['kind'] for a in metadata['assets']] == ['full', 'patch', 'recovery']
    for asset in metadata['assets']:
        blob = (DATA / 'prepared' / asset['fileName']).read_bytes()
        assert len(blob) == asset['sizeBytes'] and sha(blob) == asset['sha256']
        if asset['kind'] != 'recovery':
            info = unpack.parse_etu_header(blob)
            patch = asset['kind'] == 'patch'
            assert len(blob) == info['payload_len'] + 64 and info['target_vcode'] == 30316
            assert info['base_vcode'] == asset['baseVersionCode'] == (30313 if patch else 0)
            assert info['flags'] == (7 if patch else 11) and info['alg_id'] == 1 and info['key_id'] == 1
            assert info['base_sha8'] == (bytes.fromhex(manifest['packet']['members']['base']['sha256'])[:8] if patch else bytes(8))
    patch = (DATA / 'prepared/patch.etu').read_bytes()
    assert patch == (DATA / 'prepared/reference-1MiB.etu').read_bytes() and len(patch) == 1048576
    assert metadata['reference']['sha256'] == sha(patch) and metadata['reference']['totalLength'] == len(patch)
    for bad in (patch[:-1], patch[:100] + bytes([patch[100] ^ 1]) + patch[101:]):
        try:
            unpack.parse_etu_header(bad)
        except ValueError:
            continue
        raise AssertionError('Corrupted artifact accepted')
    passed('asset-bytes-envelopes-reference-alias-and-negative-controls')

    result = h.read_json(DATA / 'evidence/verification.json')
    assert all(result[k] is True for k in ('fullByteEqual','patchByteEqual','recoveryByteEqual','referenceAliasesPatch'))
    assert result['referenceBytes'] == 1048576
    native = result['native']
    assert native['warnings'] == native['errors'] == 0
    assert [c['case'] for c in native['checks']] == ['positive','payload-crc','truncated','same-version','wrong-base-sha']
    for case in ['compile'] + [c['case'] for c in native['checks']]:
        folder = DATA / 'evidence/native'
        receipt = h.read_json(folder / (case + '.process.json'))
        assert receipt['exitCode'] == 0 and not receipt['timeout'] and receipt['signal'] is None
        assert receipt['treeCleanupComplete'] and not receipt['cleanupErrors'] and receipt['interrupted'] is None
        assert not (folder / (case + '.stderr.txt')).read_bytes()
        stream = (folder / (case + '.stdout.txt')).read_bytes()
        if case == 'compile':
            assert not stream
            continue
        observation = json.loads(stream)
        assert observation == h.read_json(folder / (case + '.observation.json'))
        assert observation == next(c['observation'] for c in native['checks'] if c['case'] == case)
        assert observation['passed'] and observation['guards_ok'] and observation['workspace_lifecycle_ok']
        if case == 'positive':
            assert observation['result'] == 'ok' and observation['byte_identical'] and observation['boot_ok']
            assert observation['package_bytes'] == 1048576 and observation['programmed_bytes'] == len(target)
        else:
            assert observation['result_code'] < 0 and observation['prepares'] == observation['program_calls'] == 0
    for name, digest in native['sources'].items():
        assert sha((ROOT / name).read_bytes().replace(b'\r\n',b'\n')) == digest
    source_paths = [p for p in native['sources'] if not p.startswith('Tools/')]
    assert not h.command(out, 'native-production-diff', ['git','--no-optional-locks','diff',manifest['sourceCommit'],SOURCE,'--',*source_paths], env, seconds=30)
    passed('native-decoder-originals-positive-four-negative-and-source-binding')

    assert h.read_json(DATA / 'evidence/cleanup.json') == dict(privateAbsent=True)
    for stage in ('inputs','package'):
        process = h.read_json(DATA / ('evidence/' + stage + '-process.json'))
        assert process['ok'] and process['exitCode'] == 0 and not process['timeout'] and process['signal'] is None
        assert not (DATA / ('evidence/' + stage + '.stderr.txt')).read_bytes()
    with zipfile.ZipFile(DOWNLOAD / 'workflow-logs.stdout') as archive:
        name = next(n for n in archive.namelist() if '/7_Run credential-free candidate regression tests.txt' in n)
        text = archive.read(name).decode('utf8')
        assert 'tests 23' in text and 'pass 23' in text and 'fail 0' in text
        assert re.search(r'Ran 10 tests in [0-9.]+s', text) and re.search(r'Z OK\r?\n', text)
        package_name = next(n for n in archive.namelist() if '/8_Package and native-verify' in n)
        assert b'P51_PROTECTED_CANDIDATE_PACKAGED' in archive.read(package_name)
    passed('linux-regressions-private-cleanup-and-stage-receipts')
    h.save(out / 'result.json', dict(outcome='PROTECTED_CANDIDATE_ORIGINALS_REVIEW_PASS', checks=checks,
        runId=41778918087, artifactId=13298118510, source=SOURCE, metadata=metadata,
        nativeWarnings=0, nativeErrors=0, linuxPythonTests=10, linuxNodeTests=23,
        firmwareRebuilt=False, deviceOperations=0, keyExported=False, formalP51Acceptance='NOT_RUN'))
except BaseException as error:
    h.save(out / 'failed.json', dict(completedChecks=checks, errorType=type(error).__name__, detail=str(error)))
    raise
