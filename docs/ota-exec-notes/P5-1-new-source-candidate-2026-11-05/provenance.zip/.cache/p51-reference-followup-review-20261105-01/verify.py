"""Independent inspection of bound CI originals, without the encryption key."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import sysconfig
import zipfile

ROOT = Path.cwd()
AREA = Path(__file__).resolve().parent
DATA = AREA / 'download-01/extracted'
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path[:0] = [str(ROOT / 'Tools/ota/p34-acceptance'), str(ROOT / 'Tools'), sysconfig.get_path('platlib')]
import live_host as h
import etu_pack as pack
import etu_unpack as unpack
import encoding
spec = importlib.util.spec_from_file_location('recovery', ROOT / 'Tools/jlink/prepare-bootstrap-app.py')
recovery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
out = h.fresh(AREA / 'verify-01')
source = h.read_json(AREA / 'source.json')['source']
run_id = h.read_json(AREA / 'run.json')['id']
sha = lambda data: hashlib.sha256(data).hexdigest()
read = h.read_json
checks = []


def original(name):
    return subprocess.check_output(['git', '--no-optional-locks', 'show', source + ':' + name], cwd=ROOT)


def passed(name):
    checks.append(name)
    print(name + ' PASS', flush=True)


try:
    download = read(AREA / 'download-01/result.json')
    assert download['source'] == source and download['runId'] == run_id and download['conclusion'] == 'success'
    for pin in download['files'] + [download['archive'], download['logs']]:
        h.pinned(pin)
    run = json.loads((AREA / 'download-01/run.stdout').read_bytes())
    assert run['head_sha'] == source and run['run_attempt'] == 1 and run['head_branch'] == 'dev/firmware/p51-packaging-20261104'
    passed('bound-ci-archive-and-source')

    metadata = read(DATA / 'prepared/candidate-metadata.json')
    config = json.loads(original('Tools/ota/p51-new-source-inputs.json'))
    manifest = json.loads(original('Tools/ota/p51-candidate-inputs.json'))
    assert (DATA / 'evidence/inputs.json').read_bytes() == original('Tools/ota/p51-new-source-inputs.json')
    owner = dict(commitSha=source, runId=str(run_id), runAttempt='1')
    assert read(DATA / 'evidence/input-binding.json') == dict(manifestSha256=sha(original('Tools/ota/p51-new-source-inputs.json')), owner=owner)
    assert metadata['runner'] == owner
    assert metadata['source']['actualCheckout'] == metadata['source']['workflowCommit'] == source
    assert metadata['source']['reviewedProductBaseline'] == config['reviewedProductBaseline']
    subprocess.run(['git','merge-base','--is-ancestor',config['reviewedProductBaseline'],source],cwd=ROOT,check=True)
    assert not subprocess.check_output(['git','--no-optional-locks','diff','--name-only',
        config['reviewedProductBaseline'],source,'--',*config['productPaths']],cwd=ROOT).strip()
    assert metadata['source']['workflowRef'] == 'Eitan-S-23/E-Track/.github/workflows/firmware-build.yml@refs/heads/dev/firmware/p51-packaging-20261104'
    assert metadata['source']['productUnchangedFromReviewedBaseline']
    assert metadata['sourceCompilations'] == 1 and metadata['derivation'] == 'one-keyed-source-build/three-fw-header-finalizations'
    assert metadata['schema'] == 'p51-artifact-candidate-v2' and metadata['mode'] == 'new-source'
    assert not metadata['isFormalRelease'] and not metadata['productionPublishable'] and not metadata['readyRegistered']
    assert metadata['hardwareAcceptance'] == 'NOT_RUN' and metadata['noCloudMutation'] and metadata['noDeviceOperation']
    passed('new-source-workflow-baseline-and-artifact-only-provenance')

    build = read(DATA / 'keyed-build/gcc-build-inputs.json')
    evidence = read(DATA / 'keyed-build/keyed-build-evidence.json')
    assert build == metadata['build'] and build['commitSha'] == evidence['commitSha'] == source
    assert build['keyBinding'] == evidence['keyBinding']
    assert build['keyBinding']['source'] == 'approved-ci-key-v1'
    assert build['keyBinding']['keySourceSha256'] == sha(original('Libraries/OTA/ota_keys.c'))
    assert metadata['key'] == dict(build['keyBinding'], compiledAndPackagingBindingMatched=True)
    assert evidence['compilerCache'] == 'DISABLED' and evidence['sourceDateEpoch'] == '1786320000'
    assert evidence['buildConfiguration'] == build['buildConfiguration']
    assert build['buildConfiguration']['actualProfile'] == 'p34-v2-candidate'
    for field, name in [('compileCommandsSha256', 'compile_commands.json'), ('compilerCacheConfigSha256', 'CMakeCache.txt'),
                        ('compilerLaunchersSha256', 'compiler-launchers.ninja')]:
        assert evidence[field] == sha((DATA / 'keyed-build' / name).read_bytes())
    assert '-include' in evidence['keyCompileCommand']['command'] and 'private-key.h' in evidence['keyCompileCommand']['command']
    for record in evidence['artifacts']:
        raw = (DATA / 'keyed-build' / record['path']).read_bytes()
        assert len(raw) == record['sizeBytes'] and sha(raw) == record['sha256']
    steps = read(DATA / 'keyed-build/steps.json')
    assert [row['label'] for row in steps] == ['configure', 'build', 'size']
    assert steps == evidence['steps']
    for row in steps:
        assert row['exitCode'] == 0
        for stream in ('stdout', 'stderr'):
            raw = (DATA / 'keyed-build/steps' / (row['label'] + '.' + stream + '.txt')).read_bytes()
            assert sha(raw) == row[stream + 'Sha256']
        text = ''.join((DATA / 'keyed-build/steps' / (row['label'] + '.' + stream + '.txt')).read_text() for stream in ('stdout', 'stderr'))
        assert row['warningLines'] == len([line for line in text.splitlines() if re.search('warning:', line, re.I)])
        assert row['errorLines'] == len([line for line in text.splitlines() if re.search('error:', line, re.I)]) == 0
    passed('actual-keyed-compiler-artifacts-profile-and-diagnostics')

    raw = (DATA / 'keyed-build/app/X-Track-App-GCC.bin').read_bytes()
    assert raw[0x400:0x460] == b'\xff' * 96
    stamp = int(subprocess.check_output(['git', 'show', '-s', '--format=%ct', source], cwd=ROOT))
    assert stamp == metadata['buildTimestamp'] == build['buildTimestamp']
    for file, version in [('app-start-full.bin', '3.3.17'), ('app-start.bin', '3.3.18'), ('app-final.bin', '3.3.19')]:
        image = (DATA / 'prepared' / file).read_bytes()
        assert image == raw[:0x400] + pack.build_fw_header(raw, version, stamp) + raw[0x460:]
        assert recovery.validate_app(image)['version_name'] == version
    target = (DATA / 'prepared/app-final.bin').read_bytes()
    base = (DATA / 'prepared/app-start.bin').read_bytes()
    assert sha(target) == metadata['targetImageSha256'] and sha(base) == metadata['baseImageSha256']
    assert metadata['versionCode'] == 30319 and metadata['baseVersionCode'] == 30318
    recovered, kind = recovery.split_asset((DATA / 'prepared/recovery.bin').read_bytes(), 'recovery')
    assert kind == 'recovery' and recovered == target
    boot = (DATA / 'prepared/X-Track-Boot.bin').read_bytes()
    assert sha(boot) == metadata['boot']['sha256'] == manifest['boot']['sha256'] and len(boot) == manifest['boot']['bytes']
    assert metadata['boot']['kind'] == 'external-approved-group16' and not metadata['boot']['firmwareRebuilt']
    assert metadata['ordinaryBuiltBoot']['candidateBoot'] is False
    assert metadata['ordinaryBuiltBoot']['sha256']==sha((DATA/'keyed-build/boot/X-Track-Boot.bin').read_bytes())
    passed('three-finalized-start-target-identities-recovery-and-external-boot')

    for record in metadata['assets']:
        blob = (DATA / 'prepared' / record['fileName']).read_bytes()
        assert len(blob) == record['sizeBytes'] and sha(blob) == record['sha256']
        if record['kind'] in ('full', 'patch', 'reference'):
            info = unpack.parse_etu_header(blob)
            is_patch = record['kind'] != 'full'
            assert len(blob) == info['payload_len'] + 64 and info['target_vcode'] == 30319
            assert info['base_vcode'] == (30318 if is_patch else 0) and info['flags'] == (7 if is_patch else 11)
            assert info['base_sha8'] == (bytes.fromhex(sha(base))[:8] if is_patch else bytes(8))
    patch = (DATA / 'prepared/patch.etu').read_bytes()
    assert len(patch) == 1048576 and patch == (DATA / 'prepared/reference-1MiB.etu').read_bytes()
    for bad in (patch[:-1], patch[:100] + bytes([patch[100] ^ 1]) + patch[101:]):
        try:
            unpack.parse_etu_header(bad)
        except ValueError:
            continue
        raise AssertionError('Corrupted envelope accepted')
    passed('exact-asset-hashes-envelope-reference-alias-and-negative-controls')

    verification = read(DATA / 'evidence/verification.json')
    assert all(verification[key] is True for key in ('fullByteEqual', 'patchByteEqual', 'recoveryByteEqual', 'referenceAliasesPatch'))
    assert verification['referenceBytes'] == 1048576
    native = verification['native']
    assert len(native['checks']) == 12 and native['warnings'] == native['errors'] == 0
    for row in native['checks']:
        observation = row['observation']
        folder = DATA / 'evidence/native'
        assert observation == read(folder / (row['case'] + '.observation.json'))
        assert observation == json.loads((folder / (row['case'] + '.stdout.txt')).read_bytes())
        assert observation['passed'] and observation['guards_ok'] and observation['workspace_lifecycle_ok']
        if observation['result'] == 'ok':
            assert observation['byte_identical'] and observation['boot_ok'] and observation['prepares'] == 1
        else:
            assert observation['prepares'] == observation['program_calls'] == observation['programmed_bytes'] == 0
    for name, digest in native['sources'].items():
        assert sha(original(name)) == digest
    receipts = list((DATA / 'evidence/native').glob('*.process.json'))
    for path in receipts:
        receipt = read(path)
        assert receipt['exitCode'] == 0 and not receipt['timeout'] and receipt['signal'] is None
        assert receipt['treeCleanupComplete'] and receipt['cleanupErrors'] == [] and receipt['interrupted'] is None
        assert receipt['owner'] == 'POSIX process group'
    assert read(DATA / 'evidence/cleanup.json') == dict(privateAbsent=True)
    passed('native-originals-process-closure-and-private-cleanup')

    report = read(DATA / 'evidence/reference/search-report.json')
    selection = read(DATA / 'evidence/reference/selection.json')
    assert report['strategy'] == selection['strategy'] == 'isolated-frontier-count-salt-seed-v4'
    assert report['outcome'] == 'exact-witness' and report['budget'] == selection['budget'] == 256
    assert report['mainMeasurements'] == len(report['mainSamples']) == selection['mainMeasurements']
    assert report['neighborMeasurements'] == selection['neighborMeasurements'] <= report['neighborLimit'] == 26
    assert selection['foundBy'] in ('main','frontier')
    assert len(report['samples']) == len({(r['count'], r['seed'], r['salt']) for r in report['samples']}) == report['measurements'] == selection['measurements'] <= 256
    assert report['baseSha256'] == sha(base) and report['targetSha256'] == sha(target)
    unique={(r['count'],r['seed'],r['salt']) for r in report['samples']}
    main={(r['count'],r['seed'],r['salt']) for r in report['mainSamples']}
    assert len(main)==report['mainMeasurements'] and main<=unique
    for row in report['samples']:
        measurement=read(DATA/'evidence/reference/logs'/('measure-%d-%d-%d.json'%(row['count'],row['seed'],row['salt'])))
        assert measurement==row and row['base_sha256']==sha(base) and row['target_sha256']==sha(target)
    encoding.pack = pack
    decoded, props, compressed = encoding.encode(base, target, selection['count'], selection['seed'], selection['salt'])
    assert sha(decoded) == selection['raw_sha256'] and sha(compressed) == selection['compressed_sha256']
    assert compressed == (DATA / 'evidence/reference/reference.lzma').read_bytes()
    assert len(compressed) + 104 == 1048576 and encoding.strict_lzma(props, compressed, len(decoded)) == decoded
    assert unpack.bspatch_apply(base, len(target), decoded) == target
    prediction = read(AREA / 'next-inputs/result.json')
    prediction_matched = sha(target) == prediction['targetSha256'] and sha(base) == prediction['baseSha256']
    if prediction_matched:
        assert selection['raw_sha256'] == prediction['row']['raw_sha256'] and selection['measurements'] == prediction['row']['measurements']
    with zipfile.ZipFile(AREA / 'download-01/workflow-logs.stdout') as archive:
        regression = next(name for name in archive.namelist() if 'Run credential-free candidate regression tests' in name)
        text = archive.read(regression).decode('utf8')
        assert re.search(r'Ran 19 tests', text) and re.search(r'\btests 50\b', text) and re.search(r'\bpass 50\b', text)
    passed('adaptive-reference-reencoded-and-linux-regressions')

    h.save(out / 'result.json', dict(outcome='PROTECTED_NEW_SOURCE_ORIGINALS_REVIEW_PASS', checks=checks,
        source=source, runId=run_id, artifactId=download['artifact']['id'], metadata=metadata,
        warnings=sum(row['warningLines'] for row in steps), errors=0, nativeWarnings=0, nativeErrors=0,
        nativeProcessReceipts=len(receipts), sourceBuilds=1, headerFinalizations=3,
        referenceMeasurements=selection['measurements'], predictionMatched=prediction_matched,
        deviceOperations=0, keyExported=False, P5='NOT_RUN'))
except BaseException as error:
    h.save(out / 'failed.json', dict(completedChecks=checks, errorType=type(error).__name__, detail=str(error)))
    raise
