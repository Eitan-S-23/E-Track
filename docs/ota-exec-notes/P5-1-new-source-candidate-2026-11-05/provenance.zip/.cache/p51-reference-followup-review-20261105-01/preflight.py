"""Next actual commit-time prediction, never an admitted ARM candidate."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path.cwd()
AREA = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
spec = importlib.util.spec_from_file_location('next_input_package', ROOT / 'Tools/ota/p51-package.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
source = json.loads((AREA / 'source.json').read_bytes())['source']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == source
stamp = int(subprocess.check_output(['git', 'show', '-s', '--format=%ct', source], cwd=ROOT))
raw = (ROOT / '.cache/p51-new-source-delivery-20261104-01/download-01/extracted/keyed-build/app/X-Track-App-GCC.bin').read_bytes()
assert m.sha(raw) == '78ca849d31976ab5e5037f5aa1f9d02d58f17ed006b1710653207168a0385438'
config = json.loads((ROOT / 'Tools/ota/p51-new-source-inputs.json').read_bytes())
build = dict(versionName='3.3.19', versionCode=30319, buildTimestamp=stamp,
             app=dict(sizeBytes=len(raw), sha256=m.sha(raw)))
base, target = m.source_images(raw, build, '3.3.18', '3.3.19')
full_start, same_target = m.source_images(raw, build, '3.3.17', '3.3.19')
assert same_target == target
out = m.checked(AREA / 'next-inputs')
assert not out.exists()
for name, data in [('base.bin', base), ('target.bin', target), ('full-start.bin', full_start)]:
    m.save(out / name, data)
started = time.monotonic()
try:
    row, compressed = m.source_reference(base, target, config, out / 'reference')
    m.save_json(out / 'result.json', dict(outcome='EXACT_NEXT_INPUT_PREDICTION_PASS', source=source,
        timestamp=stamp, baseSha256=m.sha(base), targetSha256=m.sha(target), fullStartSha256=m.sha(full_start),
        rawImageSha256=m.sha(raw), row=row, elapsedSeconds=time.monotonic()-started,
        limitation='Prior real GCC raw bytes, not a new ARM build; independently verify actual CI raw image.',
        protectedCI=False, protectedKey=False, encryptedPackageGenerated=False, deviceOperations=0))
    print('NEXT_INPUT_PREDICTION_PASS ' + str(row['measurements']), flush=True)
except Exception as error:
    m.save_json(out / 'failed.json', dict(diagnostic=m.failure_diagnostic(error), source=source,
        timestamp=stamp, elapsedSeconds=time.monotonic()-started, protectedCI=False, deviceOperations=0))
    raise
