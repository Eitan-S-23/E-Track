"""Scoped follow-up delivery using the already reviewed GitHub and process adapters."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path.cwd()
AREA=Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
spec=importlib.util.spec_from_file_location('p51_prior_delivery',ROOT/'.cache/p51-new-source-delivery-20261104-01/runner.py')
prior=importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
h,f=prior.h,prior.f
f.AREA=AREA
BASE='db049b6b2b9e0bc0ff0c534d52b686494b7d704c'
BRANCH=prior.BRANCH
FILES=['Tools/ota/p34-acceptance/encoding.py','Tools/ota/p51-package.py','tests/ota/test_p51_package.py',
       'docs/ota-exec-notes/P51-reference-search-implementation-2026-11-04.md',
       'docs/ota-exec-notes/P51-reference-search-remediation-2026-11-04.md',
       'docs/ota-exec-notes/P1-P5-nonpower-sequence-2026-11-04.md']

def main():
    mode,label=sys.argv[1:]
    assert mode in ('prepare','push','dispatch','approve','status','final-state')
    assert h.read_json(AREA/'next-inputs/result.json')['outcome']=='EXACT_NEXT_INPUT_PREDICTION_PASS'
    review=h.read_json(AREA/'result.json')
    assert review['outcome']=='INDEPENDENT_REFERENCE_FOLLOWUP_REVIEW_PASS'
    for name,expected in review['sources'].items():
        assert prior.identity(ROOT/name)['sha256']==expected
    for path in [AREA/label,AREA/'source.json',AREA/'run.json',AREA/'next-inputs']:
        h.checked(path)
    before={name:prior.identity(prior.COMMON/name) for name in ('index','HEAD','config')}
    if mode in ('commit','preflight'):
        out=h.fresh(AREA/label)
        env=h.environment(out)
    else:
        out,env=f.init(label)
    for key in ('ANTHROPIC_API_KEY','WECHAT_WEBHOOK_KEY','GIT_NO_DEBUG_CHECK','GIT_NO_SECRET_CHECK'):
        env.pop(key,None)
    env['NO_PROXY']=env['no_proxy']='api.github.com'
    try:
        h.save(out/'intent.json',dict(mode=mode,branch=BRANCH,root=str(ROOT),
            authority='Existing root-owned P51 v4 repair review and exact-source artifact-only continuation',
            devices=0,production=False))
        if mode=='commit':
            prior.git_preflight()
            assert prior.git('rev-parse','HEAD')==BASE and prior.git('branch','--show-current')==prior.LOCAL
            assert not prior.git('diff','--cached','--name-only')
            dirty=set(prior.git('diff','--name-only').splitlines())|set(prior.git('ls-files','--others','--exclude-standard').splitlines())
            preserved={name:prior.identity(ROOT/name) for name in sorted(dirty-set(FILES))}
            h.save(out/'scope.json',dict(files={name:prior.identity(ROOT/name) for name in FILES},preserved=preserved))
            for key,fmt in [('NAME','%an'),('EMAIL','%ae')]:
                env['GIT_AUTHOR_'+key]=env['GIT_COMMITTER_'+key]=prior.git('show','-s','--format='+fmt,'HEAD')
            h.command(out,'add',prior.GIT+['add','--',*FILES],env,seconds=90)
            assert set(prior.git('diff','--cached','--name-only').splitlines())==set(FILES)
            h.command(out,'check',prior.GIT+['-c','core.whitespace=cr-at-eol','diff','--cached','--check'],env,seconds=60)
            for name in FILES:
                assert subprocess.check_output(['git','show',':'+name],cwd=ROOT,env=env)==(ROOT/name).read_bytes().replace(b'\r\n',b'\n')
            h.command(out,'commit',prior.GIT+['commit','--no-gpg-sign','-m','fix(p51): adapt bounded reference search to real source images'],env,seconds=120)
            source=prior.git('rev-parse','HEAD')
            assert set(prior.git('diff-tree','--no-commit-id','--name-only','-r',source).splitlines())==set(FILES)
            assert all(prior.identity(ROOT/name)==pin for name,pin in preserved.items())
            h.save(AREA/'source.json',dict(source=source,tree=prior.git('rev-parse','HEAD^{tree}'),
                files=FILES,unrelatedPreserved=len(preserved)))
            print('REPAIR_COMMITTED '+source,flush=True)
            return
        source=h.read_json(AREA/'source.json')['source']
        assert prior.git('rev-parse','HEAD')==source
        if mode=='preflight':
            for key in list(env):
                if key.startswith(('OTA_','GH_','GITHUB_','CF_','CLOUDFLARE_','TRACE_','P51_')):
                    del env[key]
            h.command(out,'predict',[sys.executable,'-I','-S','-B','-X','utf8',str(AREA/'preflight.py')],env,seconds=1800)
            print(h.read_json(AREA/'next-inputs/result.json')['outcome'],flush=True)
        elif mode=='prepare':
            state=prior.prior.protected(out,env,'before')
            assert any(row['name']==BRANCH and row['type']=='branch' for row in state['branches']['branch_policies'])
            ref=f.api(out,env,'remote','/git/ref/heads/'+BRANCH)
            assert ref['object']['sha']==BASE
            runs=f.api(out,env,'runs','/actions/workflows/firmware-build.yml/runs?per_page=100')['workflow_runs']
            assert all(row['status']=='completed' for row in runs)
            tags=f.api(out,env,'tags','/git/matching-refs/tags/mcu-e-track-at32f435-v3.3.')
            assert not any(row['ref'].rsplit('v',1)[-1] in ('3.3.17','3.3.18','3.3.19') for row in tags)
            releases=[]
            for page in range(1,6):
                rows=f.api(out,env,'releases-'+str(page),'/releases?per_page=100&page='+str(page))
                releases.extend(rows)
                if len(rows)<100:
                    break
            else:
                raise RuntimeError('Bounded release inventory exceeded')
            assert not any(any(v in row['tag_name'] for v in ('v3.3.17','v3.3.18','v3.3.19')) for row in releases)
            service=prior.service_snapshot(out)
            h.save(out/'result.json',dict(state=state,service=service,remote=BASE,versions=['3.3.17','3.3.18','3.3.19']))
            print('PROTECTED_PREPARATION_PASS',flush=True)
        elif mode=='push':
            prior.git_preflight()
            assert f.api(out,env,'remote-before','/git/ref/heads/'+BRANCH)['object']['sha'] in (BASE,source)
            assert not subprocess.run(['git','merge-base','--is-ancestor',BASE,source],cwd=ROOT,env=env).returncode
            h.command(out,'push',prior.GIT+['-c','credential.helper=','-c','credential.helper=!gh auth git-credential',
                'push','--porcelain','origin',source+':refs/heads/'+BRANCH],env,seconds=300)
            assert f.api(out,env,'remote-after','/git/ref/heads/'+BRANCH)['object']['sha']==source
            print('EXACT_SOURCE_PUSHED',flush=True)
        elif mode=='dispatch':
            assert h.read_json(AREA/'next-inputs/result.json')['outcome']=='EXACT_NEXT_INPUT_PREDICTION_PASS'
            assert prior.prior.protected(out,env,'before')==h.read_json(AREA/'prepare-01/result.json')['state']
            assert f.api(out,env,'remote','/git/ref/heads/'+BRANCH)['object']['sha']==source
            old=f.api(out,env,'runs-before',prior.RUNS)['workflow_runs']
            assert all(row['status']=='completed' and row['head_sha']!=source for row in old)
            assert not (AREA/'run.json').exists()
            inputs=dict(package_candidate='true',candidate_mode='new-source',candidate_reviewed_commit=source,
                candidate_base_version='3.3.18',candidate_full_base_version='3.3.17',version_name='3.3.19',
                firmware_build_profile='p34-v2-candidate',publish='false',rehearsal='false',check_bindings='false')
            f.api(out,env,'dispatch','/actions/workflows/firmware-build.yml/dispatches',dict(ref=BRANCH,inputs=inputs),'POST')
            ids={row['id'] for row in old}
            for i in range(10):
                time.sleep(5)
                rows=f.api(out,env,'runs-after-'+str(i),prior.RUNS)['workflow_runs']
                new=[row for row in rows if row['id'] not in ids]
                if new:
                    assert len(new)==1 and new[0]['head_sha']==source
                    h.save(AREA/'run.json',new[0])
                    print(json.dumps({key:new[0][key] for key in ('id','status','html_url')}),flush=True)
                    break
            else:
                raise RuntimeError('Uncertain dispatch; reconcile without replay')
        elif mode=='final-state':
            state=prior.prior.protected(out,env,'after')
            assert state==h.read_json(AREA/'prepare-01/result.json')['state']
            assert f.api(out,env,'remote','/git/ref/heads/'+BRANCH)['object']['sha']==source
            run=f.api(out,env,'run','/actions/runs/'+str(h.read_json(AREA/'run.json')['id']))
            assert run['status']=='completed' and run['head_sha']==source and run['run_attempt']==1
            service=prior.service_snapshot(out)
            for name in ('channels.json','releases.json'):
                assert h.read_json(out/name)==h.read_json(AREA/'prepare-01'/name)
            h.save(out/'result.json',dict(outcome='POST_CI_STATE_UNCHANGED',state=state,service=service,
                source=source,conclusion=run['conclusion'],production=False,devices=0))
            print('POST_CI_STATE_UNCHANGED',flush=True)
        else:
            run_id=str(h.read_json(AREA/'run.json')['id'])
            run=f.api(out,env,'run','/actions/runs/'+run_id)
            assert run['head_sha']==source and run['run_attempt']==1 and run['head_branch']==BRANCH
            jobs=f.api(out,env,'jobs','/actions/runs/'+run_id+'/jobs?per_page=100')['jobs']
            if mode=='approve':
                assert prior.prior.protected(out,env,'before')==h.read_json(AREA/'prepare-01/result.json')['state']
                pending=f.api(out,env,'pending','/actions/runs/'+run_id+'/pending_deployments')
                assert len(pending)==1 and pending[0]['environment']['name']=='firmware-rehearsal' and pending[0]['current_user_can_approve']
                assert all(row['conclusion']=='skipped' for row in jobs if row['name']!='Protected P5 candidate artifacts (no release or device operation)')
                f.api(out,env,'approve','/actions/runs/'+run_id+'/pending_deployments',dict(environment_ids=[pending[0]['environment']['id']],
                    state='approved',comment='User-delegated root approval for independently reviewed P51 reference-search repair at '+source+'; artifact only; production gates remain closed.'),'POST')
            print(json.dumps(dict(id=run['id'],status=run['status'],conclusion=run['conclusion'],
                steps=[dict(name=s['name'],status=s['status'],conclusion=s['conclusion']) for j in jobs if j['conclusion']!='skipped' for s in j['steps']])),flush=True)
    except BaseException as error:
        h.save(out/'failed.json',dict(type=type(error).__name__,preserve=True,noAutomaticReplay=True))
        raise
    finally:
        env.pop('GH_TOKEN',None)
        assert before=={name:prior.identity(prior.COMMON/name) for name in before}
        h.save(out/'write-audit.json',dict(mainMetadataUnchanged=True,mode=mode,devices=0,production=False))

if __name__=='__main__':
    main()
