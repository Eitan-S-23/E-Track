"""Retrieve the single bound run through the existing GitHub/host adapter."""
import hashlib
import io
import json
from pathlib import Path
import stat
import sys
import zipfile

ROOT = Path.cwd()
AREA = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(AREA))
import remote as d
f, h = d.f, d.h
source = h.read_json(AREA / 'source.json')['source']
run_id = h.read_json(AREA / 'run.json')['id']
out, env = f.init('download-01')
env['NO_PROXY'] = env['no_proxy'] = 'api.github.com,github.com,.githubusercontent.com,.blob.core.windows.net'
try:
    run = f.api(out, env, 'run', '/actions/runs/' + str(run_id))
    assert run['status'] == 'completed' and run['head_sha'] == source and run['run_attempt'] == 1
    result = f.api(out, env, 'artifacts', '/actions/runs/' + str(run_id) + '/artifacts')
    assert result['total_count'] == len(result['artifacts']) == 1
    artifact = result['artifacts'][0]
    assert artifact['name'] == 'p51-candidate-' + str(run_id) + '-1' and not artifact['expired']
    assert artifact['workflow_run']['head_sha'] == source and artifact['workflow_run']['id'] == run_id
    assert 0 < artifact['size_in_bytes'] < 200 * 1024 * 1024
    h.save(out / 'artifact.json', artifact)
    raw = h.command(out, 'archive', ['gh', 'api', 'repos/' + f.REPO + '/actions/artifacts/' + str(artifact['id']) + '/zip'], env, seconds=180)
    assert len(raw) == artifact['size_in_bytes']
    assert artifact['digest'] == 'sha256:' + hashlib.sha256(raw).hexdigest()
    allowed_prepared = {'prepared/' + name for name in (
        'app-final.bin', 'app-start.bin', 'app-start-full.bin', 'X-Track-Boot.bin',
        'full.etu', 'patch.etu', 'reference-1MiB.etu', 'recovery.bin', 'candidate-metadata.json')}
    allowed_build = {'keyed-build/' + name for name in (
        'gcc-build-inputs.json', 'keyed-build-evidence.json', 'CMakeCache.txt',
        'compile_commands.json', 'compiler-launchers.ninja', 'steps.json')}
    allowed_build |= {'keyed-build/' + folder + '/' + name + '.' + ext
        for folder, name in [('app', 'X-Track-App-GCC'), ('boot', 'X-Track-Boot')]
        for ext in ('bin', 'elf', 'hex', 'map')}
    files = []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert sum(item.file_size for item in archive.infolist()) < 400 * 1024 * 1024
        assert archive.testzip() is None
        for item in archive.infolist():
            name = item.filename
            assert name and ':' not in name and '\\' not in name and not name.startswith('/')
            assert all(part not in ('', '.', '..') for part in name.rstrip('/').split('/'))
            assert not stat.S_ISLNK(item.external_attr >> 16)
            assert 'private' not in name.split('/') and not name.endswith(('private-key.h', 'native-active.json', 'key-build-active.json'))
            assert item.is_dir() or name in allowed_prepared | allowed_build or name.startswith(('evidence/', 'keyed-build/steps/'))
            target = h.checked(out / 'extracted' / name)
            if not item.is_dir():
                files.append((target, archive.read(item)))
        if run['conclusion'] == 'success':
            assert allowed_prepared | allowed_build <= set(archive.namelist())
        for target, data in files:
            h.raw(target, data)
    logs = h.command(out, 'workflow-logs', ['gh', 'api', 'repos/' + f.REPO + '/actions/runs/' + str(run_id) + '/logs'], env, seconds=180)
    with zipfile.ZipFile(io.BytesIO(logs)) as archive:
        assert archive.testzip() is None
    h.save(out / 'result.json', dict(outcome='BOUND_CI_ARCHIVE_RETRIEVED', runId=run_id,
        source=source, conclusion=run['conclusion'], artifact=artifact,
        archive=h.record(out / 'archive.stdout'), logs=h.record(out / 'workflow-logs.stdout'),
        files=[h.record(path) for path, _ in files], keyExported=False, deviceOperations=0))
    print(json.dumps(dict(runId=run_id, conclusion=run['conclusion'], artifactId=artifact['id'],
                          bytes=len(raw), files=len(files))), flush=True)
finally:
    env.pop('GH_TOKEN', None)
