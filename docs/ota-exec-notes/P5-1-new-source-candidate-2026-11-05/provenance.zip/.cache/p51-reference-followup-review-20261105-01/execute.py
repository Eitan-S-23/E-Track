"""Root-owned bounded checks; no product changes or repeated native campaign."""
import importlib.util
from pathlib import Path
import sys

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
spec = importlib.util.spec_from_file_location('build_owner', ROOT / 'Tools/ota/p34-acceptance/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
for label, argv, seconds in [
    ('unit', [sys.executable, '-I', '-S', '-B', '-X', 'utf8', 'tests/ota/test_p51_package.py', 'AdaptiveReferenceSearch'], 60),
    ('review', [sys.executable, '-I', '-S', '-B', '-X', 'utf8', OUT / 'review.py'], 300),
]:
    dest = b.checked(OUT / label)
    assert not dest.exists()
    env = b.environment(dest)
    for key in list(env):
        if key.startswith(('OTA_', 'GH_', 'GITHUB_', 'CF_', 'CLOUDFLARE_', 'TRACE_', 'P51_', 'NODE_')):
            del env[key]
    env.update(P51_TEST_AREA=str(b.checked(dest / 'fixtures')), PYTHONIOENCODING='utf8',
               npm_config_cache=str(b.checked(dest / 'npm-cache')))
    b.run(dest, env, 'command', argv, seconds)
