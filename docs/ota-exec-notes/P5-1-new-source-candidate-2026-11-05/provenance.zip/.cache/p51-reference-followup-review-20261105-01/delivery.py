"""Scoped v4 delivery using existing GitHub, output and owned-command adapters."""
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
AREA = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
spec = importlib.util.spec_from_file_location('p51_prior_delivery', ROOT / '.cache/p51-new-source-delivery-20261104-01/runner.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
h, f = prior.h, prior.f
f.AREA = AREA
BASE = 'b1422489a3cb5a56428f5e640513d195ca29e46f'
REMOTE = 'db049b6b2b9e0bc0ff0c534d52b686494b7d704c'
BRANCH = prior.BRANCH
FILES = ['Tools/ota/p34-acceptance/encoding.py', 'tests/ota/test_p51_package.py',
    'docs/ota-exec-notes/P51-reference-search-followup-implementation-2026-11-05.md',
    'docs/ota-exec-notes/P51-reference-search-remediation-2026-11-04.md',
    'docs/ota-exec-notes/P1-P5-nonpower-sequence-2026-11-04.md']

def main():
    mode, label = sys.argv[1:]
    assert mode in ('commit', 'preflight')
    review = h.read_json(AREA / 'result.json')
    assert review['outcome'] == 'INDEPENDENT_REFERENCE_FOLLOWUP_REVIEW_PASS'
    for name, expected in review['sources'].items():
        assert prior.identity(ROOT / name)['sha256'] == expected
    for path in [AREA / label, AREA / 'source.json', AREA / 'next-inputs']:
        h.checked(path)
    before = {name: prior.identity(prior.COMMON / name) for name in ('index', 'HEAD', 'config')}
    out = h.fresh(AREA / label)
    env = h.environment(out)
    for key in list(env):
        if key.startswith(('ANTHROPIC_', 'WECHAT_', 'GH_', 'GITHUB_', 'OTA_', 'CF_', 'CLOUDFLARE_', 'TRACE_', 'P51_', 'NODE_')) or key in ('GIT_NO_DEBUG_CHECK', 'GIT_NO_SECRET_CHECK'):
            del env[key]
    try:
        h.save(out / 'intent.json', dict(mode=mode, files=FILES, authority='Existing root P51 scoped review/delivery', devices=0, production=False))
        if mode == 'commit':
            prior.git_preflight()
            assert prior.git('rev-parse', 'HEAD') == BASE and prior.git('branch', '--show-current') == prior.LOCAL
            assert not prior.git('diff', '--cached', '--name-only')
            dirty = set(prior.git('diff', '--name-only').splitlines()) | set(prior.git('ls-files', '--others', '--exclude-standard').splitlines())
            preserved = {name: prior.identity(ROOT / name) for name in sorted(dirty - set(FILES))}
            h.save(out / 'scope.json', dict(files={name: prior.identity(ROOT / name) for name in FILES}, preserved=preserved))
            for key, fmt in [('NAME', '%an'), ('EMAIL', '%ae')]:
                env['GIT_AUTHOR_' + key] = env['GIT_COMMITTER_' + key] = prior.git('show', '-s', '--format=' + fmt, 'HEAD')
            h.command(out, 'add', prior.GIT + ['add', '--', *FILES], env, seconds=90)
            assert set(prior.git('diff', '--cached', '--name-only').splitlines()) == set(FILES)
            h.command(out, 'check', prior.GIT + ['-c', 'core.whitespace=cr-at-eol', 'diff', '--cached', '--check'], env, seconds=60)
            for name in FILES:
                assert subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT, env=env) == (ROOT / name).read_bytes().replace(b'\r\n', b'\n')
            h.command(out, 'commit', prior.GIT + ['commit', '--no-gpg-sign', '-m', 'fix(p51): isolate bounded frontier from reference search history'], env, seconds=120)
            source = prior.git('rev-parse', 'HEAD')
            assert set(prior.git('diff-tree', '--no-commit-id', '--name-only', '-r', source).splitlines()) == set(FILES)
            assert all(prior.identity(ROOT / name) == pin for name, pin in preserved.items())
            h.save(AREA / 'source.json', dict(source=source, tree=prior.git('rev-parse', 'HEAD^{tree}'),
                timestamp=int(prior.git('show', '-s', '--format=%ct', source)), files=FILES, unrelatedPreserved=len(preserved)))
            print('REPAIR_COMMITTED ' + source, flush=True)
        else:
            source = h.read_json(AREA / 'source.json')['source']
            assert prior.git('rev-parse', 'HEAD') == source
            h.command(out, 'predict', [sys.executable, '-I', '-S', '-B', '-X', 'utf8', str(AREA / 'preflight.py')], env, seconds=1800)
            print(h.read_json(AREA / 'next-inputs/result.json')['outcome'], flush=True)
    except BaseException as error:
        h.save(out / 'failed.json', dict(type=type(error).__name__, preserve=True, noAutomaticReplay=True))
        raise
    finally:
        assert before == {name: prior.identity(prior.COMMON / name) for name in before}
        h.save(out / 'write-audit.json', dict(mainMetadataUnchanged=True, mode=mode, devices=0, production=False))

if __name__ == '__main__':
    main()
