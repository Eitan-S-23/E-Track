"""Audit only this root continuation, preserving every prior observation."""
import json
from pathlib import Path
import sys

ROOT = Path.cwd()
AREA = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(AREA))
import delivery as d
h = d.h
destination = h.checked(AREA / 'closeout.json')
assert not destination.exists()
source = h.read_json(AREA / 'source.json')
assert d.prior.git('rev-parse', 'HEAD') == source['source']
assert not d.prior.git('diff', '--cached', '--name-only')
review = h.read_json(AREA / 'result.json')
for name, expected in review['sources'].items():
    assert d.prior.identity(ROOT / name)['sha256'] == expected
preserved = h.read_json(AREA / 'commit-01/scope.json')['preserved']
assert all(d.prior.identity(ROOT / name) == pin for name, pin in preserved.items())
old = h.read_json(ROOT / '.cache/p51-reference-search-followup-20261105-01/baseline.json')['originals']
assert all(d.prior.identity(ROOT / name)['sha256'] == expected for name, expected in old.items())
closed = []
for path in AREA.rglob('*.started.json'):
    receipt = path.with_name(path.name.replace('.started.json', '.closed.json'))
    value = h.read_json(receipt)
    assert value['cleanup_complete'] and not value['cleanup_errors']
    closed.append(dict(path=receipt.relative_to(ROOT).as_posix(), exit=value['exit_code']))
for label in ('unit', 'review'):
    receipt = h.read_json(AREA / label / 'command.json')
    assert receipt['exit'] == 0 and not receipt['timed_out']
for path in AREA.glob('*/write-audit.json'):
    assert h.read_json(path)['mainMetadataUnchanged']
report = h.read_json(AREA / 'next-inputs/reference/search-report.json')
assert len({(r['count'], r['seed'], r['salt']) for r in report['samples']}) == report['measurements'] <= 256
prediction_path = AREA / 'next-inputs/result.json'
prediction = h.read_json(prediction_path if prediction_path.exists() else AREA / 'next-inputs/failed.json')
assert prediction['source'] == source['source'] and prediction['timestamp'] == source['timestamp']
if not prediction_path.exists():
    assert not (AREA / 'next-inputs/reference/selection.json').exists()
    assert not (AREA / 'next-inputs/reference/reference.lzma').exists()
    assert not (AREA / 'run.json').exists()
files = {}
for path in AREA.rglob('*'):
    h.checked(path)
    if path.is_file():
        files[path.relative_to(ROOT).as_posix()] = d.prior.identity(path)
docs = ['docs/ota-exec-notes/P1-P5-nonpower-sequence-2026-11-04.md',
        'docs/ota-exec-notes/P51-reference-search-remediation-2026-11-04.md']
for name in docs:
    h.checked(ROOT / name)
ci_result = AREA / 'verify-01/result.json'
result = dict(outcome='ROOT_FOLLOWUP_OUTPUT_AUDIT_PASS', source=source['source'],
    localReview=review['outcome'], prediction=prediction, protectedCI=(h.read_json(ci_result) if ci_result.exists() else 'NOT_RUN'),
    controlledFiles=files, closedCommands=closed, unrelatedPreserved=len(preserved), originalFilesPreserved=len(old),
    documents={name: d.prior.identity(ROOT / name) for name in docs},
    boundary=dict(root=str(ROOT), externalScope='Previously authorized task Git objects/ref/reflog/index only',
        unexpectedExternalWritesObserved=False, mainMetadataUnchanged=True),
    deviceOperations=0, subAgentsStarted=0, P5='NOT_RUN')
h.save(destination, result)
print(json.dumps(dict(outcome=result['outcome'], source=source['source'], files=len(files),
    closedCommands=len(closed), unrelatedPreserved=len(preserved), originalFilesPreserved=len(old))))
