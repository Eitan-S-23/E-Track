"""Independent original validation and charged-cache replay of isolated v4."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
E = ROOT / '.cache/p51-reference-search-followup-20261105-01'
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
spec = importlib.util.spec_from_file_location('review_candidate', ROOT / 'Tools/ota/p51-package.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
final = read(E / 'final.json')
assert subprocess.check_output(['git', '--no-optional-locks', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == final['head']
for name, expected in final['sources'].items():
    assert digest(ROOT / name) == expected, name
handoff = ROOT / 'docs/ota-exec-notes/P51-reference-search-followup-implementation-2026-11-05.md'
assert digest(handoff) == final['handoffSha256']
assert digest(E / 'plan.json') == final['planSha256']
baseline = read(E / 'baseline.json')
for name, expected in {**baseline['unrelated'], **baseline['originals']}.items():
    assert digest(ROOT / name) == expected, name

def functions(text):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)}

path = 'Tools/ota/p34-acceptance/encoding.py'
old = functions(subprocess.check_output(['git', '--no-optional-locks', 'show', final['head'] + ':' + path], cwd=ROOT).decode())
new = functions((ROOT / path).read_text())
unchanged = [name for name in old if name != 'search_adaptive']
assert len(unchanged) == 9 and all(old[name] == new[name] for name in unchanged)
closures = list(E.rglob('*.process.json'))
assert len(closures) == final['closedProcessReceipts'] == 269
for path in closures:
    receipt = read(path)
    assert receipt['treeCleanupComplete'] and not receipt['cleanupErrors'], path
assert not list(E.rglob('native-active.json'))
for label, expected_exit in [('python-02', 0), ('unit-04', 0), ('verify-01', 0),
                             ('exhausted-02', 1), ('old-header-01', 1), ('python-01', 1)]:
    command = read(E / label / 'command.json')
    assert command == final['commands'][label]
    assert command['exitCode'] == expected_exit and not command['timeout'] and command['treeCleanupComplete']
log = (E / 'python-02/evidence/native/python-02.stderr.txt').read_text()
assert re.search(r'Ran 19 tests[^\n]*\s+OK', log)
failure = read(E / 'exhausted-02/evidence/native/exhausted-02.stderr.txt')
assert failure['stage'] == 'reference-search' and failure['reason'] == 'REFERENCE_SEARCH_BUDGET_EXHAUSTED'
assert failure['measurements'] == failure['budget'] == 2
rejected = read(E / 'old-header-01/fixtures/old-header/result.json')
assert rejected['outcome'] == 'FAILED' and rejected['report']['measurements'] == 256
assert not rejected['successAssets'] and not rejected['nativeExecuted']

source_results = [p for p in (E / 'python-02/fixtures').rglob('SELFTEST-ONLY.json') if 'row' in read(p)]
assert len(source_results) == 1
cases = [
    ('fixed', E / 'next-cold-01/fixtures/next-fixed/result.json', 62),
    ('timestamp-plus-one', E / 'timestamp-one-02/fixtures/timestamp-plus-one/result.json', 126),
    ('timestamp-plus-hour', E / 'timestamp-hour-02/fixtures/timestamp-plus-hour/result.json', 69),
    ('version-change', E / 'version-02/fixtures/version-change/result.json', 159),
    ('old-fixed', E / 'old-fixed-02/fixtures/old-fixed/result.json', 157),
    ('old-header', E / 'old-header-02/fixtures/old-header/result.json', 197),
    ('old-synthetic', E / 'old-synthetic-02/fixtures/old-synthetic/result.json', 38),
    ('old-source', source_results[0], 249),
]
plan = read(E / 'plan.json')
config = read(ROOT / 'Tools/ota/p51-new-source-inputs.json')
raw = (ROOT / '.cache/p51-new-source-delivery-20261104-01/download-01/extracted/keyed-build/app/X-Track-App-GCC.bin').read_bytes()
assert m.sha(raw) == '78ca849d31976ab5e5037f5aa1f9d02d58f17ed006b1710653207168a0385438'
replays = []
for label, summary_path, count in cases:
    original, summary = summary_path.parent, read(summary_path)
    base = (original / 'inputs/base.bin').read_bytes()
    target = (original / ('prepared/app-final.bin' if label == 'old-source' else 'inputs/target.bin')).read_bytes()
    expected = summary['row']
    assert m.sha(base) == expected['base_sha256'] and m.sha(target) == expected['target_sha256']
    if label in [r['name'] for r in plan['newGeneralizationCases']]:
        item = next(r for r in plan['newGeneralizationCases'] if r['name'] == label)
        build = dict(versionName=item['target'], versionCode=m.pack.parse_version_name(item['target']),
                     buildTimestamp=item['timestamp'], app=dict(sizeBytes=len(raw), sha256=m.sha(raw)))
        assert m.source_images(raw, build, item['base'], item['target']) == (base, target)
    if label == 'fixed':
        assert summary['cold'] and summary['reused'] == 0 and summary['newlyEncoded'] == 62
        assert '--cold' in final['commands']['next-cold-01']['argv']
    dest = m.checked(OUT / 'replay' / label)
    logs = list((original / 'evidence/reference/logs').glob('measure-*.json'))
    for path in logs:
        m.save(dest / 'logs' / path.name, path.read_bytes())
    row, compressed = m.source_reference(base, target, config, dest)
    assert row == expected, label
    assert row['measurements'] == count and row['budget'] == 256
    assert row['strategy'] == 'isolated-frontier-count-salt-seed-v4'
    assert len(list((dest / 'logs').glob('*.json'))) == len(logs), 'Unexpected cold measurement'
    report = read(dest / 'search-report.json')
    assert report == read(original / 'evidence/reference/search-report.json')
    keys = {(r['count'], r['seed'], r['salt']) for r in report['samples']}
    main = {(r['count'], r['seed'], r['salt']) for r in report['mainSamples']}
    assert len(keys) == count and len(main) == report['mainMeasurements'] and main <= keys
    assert 0 <= report['neighborMeasurements'] <= report['neighborLimit'] == 26
    assert count <= report['mainMeasurements'] + report['neighborMeasurements']
    for bad in (compressed[:-1], compressed + b'tail'):
        try:
            m.encoding.strict_lzma(bytes.fromhex(row['props_hex']), bad, row['decoded_bytes'])
        except (AssertionError, ValueError, m.encoding.lzma.LZMAError):
            pass
        else:
            raise AssertionError('Malformed LZMA accepted')
    native = summary['native']
    assert len(native['checks']) == 11 and native['warnings'] == native['errors'] == 0
    for check in native['checks']:
        folder = original / 'evidence/native'
        obs = read(folder / (check['case'] + '.observation.json'))
        assert obs == check['observation'] == read(folder / (check['case'] + '.stdout.txt'))
        assert obs['passed'] and obs['guards_ok'] and obs['workspace_lifecycle_ok']
        if obs['result'] == 'ok':
            assert obs['byte_identical'] and obs['boot_ok']
        else:
            assert obs['prepares'] == obs['program_calls'] == 0
    for name, expected_hash in native['sources'].items():
        assert digest(ROOT / name) == expected_hash
    for path in (original / 'evidence/native').glob('*.process.json'):
        receipt = read(path)
        assert receipt['exitCode'] == 0 and not receipt['timeout'] and receipt['treeCleanupComplete']
    replays.append(dict(case=label, measurements=count, row=row, summarySha256=digest(summary_path),
                        cachedSchedulerReplay=True, selectedWitnessFreshlyEncoded=True, nativeOriginals=11))
    print('INDEPENDENT_REPLAY ' + label + ' ' + str(count), flush=True)

old_root = ROOT / '.cache/p51-reference-search-impl-20261104-01'
prefix_pairs = [
    (cases[0][1].parent, ROOT / '.cache/p51-reference-search-review-20261105-01/next-inputs/reference'),
    (cases[4][1].parent, old_root / 'fixed-02/fixtures/fixed/evidence/reference'),
    (cases[5][1].parent, old_root / 'header-01/fixtures/header/evidence/reference'),
    (cases[6][1].parent, old_root / 'synthetic-01/fixtures/synthetic/evidence/reference'),
    (cases[7][1].parent, old_root / 'python-02/fixtures/new-source-f6vhxnks/evidence/reference'),
]
prefixes = []
fields = ('count', 'seed', 'salt', 'etu_bytes', 'raw_sha256', 'compressed_sha256')
for current, previous in prefix_pairs:
    now = read(current / 'evidence/reference/search-report.json')
    before = read(previous / 'search-report.json')
    main = now['mainSamples']
    assert len(main) <= len(before['samples'])
    assert all(all(a[k] == b[k] for k in fields) for a, b in zip(main, before['samples']))
    prefixes.append(len(main))
assert prefixes == [46, 137, 177, 25, 229]
for name, expected in final['sources'].items():
    assert digest(ROOT / name) == expected
m.save_json(OUT / 'result.json', dict(outcome='INDEPENDENT_REFERENCE_FOLLOWUP_REVIEW_PASS',
    sourceHead=final['head'], sources=final['sources'], handoffSha256=final['handoffSha256'],
    unchangedFunctions=unchanged, preservedOriginals=len(baseline['originals']),
    preservedUnrelated=len(baseline['unrelated']), closedOriginalProcesses=len(closures),
    originalTestsReviewed=19, focusedTestsExecuted=6, replays=replays, v2MainPrefixes=prefixes,
    findings=[], protectedCI=False, exactNextTimestamp='NOT_RUN', deviceOperations=0))
