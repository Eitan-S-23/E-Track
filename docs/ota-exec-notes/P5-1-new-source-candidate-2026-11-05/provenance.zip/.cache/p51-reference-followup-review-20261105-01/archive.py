"""Preserve the independently reviewed original candidate, not a P5 verdict."""
import io
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path.cwd()
AREA = Path(__file__).resolve().parent
DEST = ROOT / 'docs/ota-exec-notes/P5-1-new-source-candidate-2026-11-05'
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
sys.path.insert(0, str(AREA))
import remote as d
h = d.h
review = h.read_json(AREA / 'verify-01/result.json')
assert review['outcome'] == 'PROTECTED_NEW_SOURCE_ORIGINALS_REVIEW_PASS'
after = h.read_json(AREA / 'final-state-01/result.json')
assert after['outcome'] == 'POST_CI_STATE_UNCHANGED' and after['conclusion'] == 'success'
assert after['state'] == h.read_json(AREA / 'prepare-01/result.json')['state']
files = []
for path in AREA.iterdir():
    if path.is_file() and path.suffix in ('.py', '.json'):
        files.append(path)
    elif path.is_dir() and path.name not in ('replay', 'next-inputs'):
        files.extend(p for p in path.iterdir() if p.is_file() and p.name not in ('archive.stdout', 'workflow-logs.stdout'))
files.extend(p for p in (AREA / 'next-inputs').rglob('*.json') if p.is_file())
files = sorted(set(files))
index = {p.relative_to(ROOT).as_posix(): h.record(p) for p in files}
memory = io.BytesIO()
with zipfile.ZipFile(memory, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in files:
        archive.writestr(p.relative_to(ROOT).as_posix(), p.read_bytes())
    archive.writestr('index.json', json.dumps(index, indent=2) + '\n')
packet = memory.getvalue()
with zipfile.ZipFile(io.BytesIO(packet)) as archive:
    assert archive.testzip() is None
    for name, pin in index.items():
        data = archive.read(name)
        assert len(data) == pin['bytes'] and d.prior.hashlib.sha256(data).hexdigest() == pin['sha256']
outputs = {
    'artifact.zip': (AREA / 'download-01/archive.stdout').read_bytes(),
    'workflow-logs.zip': (AREA / 'download-01/workflow-logs.stdout').read_bytes(),
    'provenance.zip': packet,
    'review.json': (AREA / 'verify-01/result.json').read_bytes(),
    'github-artifact.json': (AREA / 'download-01/artifact.json').read_bytes(),
}
for name in [*outputs, 'index.json']:
    assert not h.checked(DEST / name).exists()
for name, data in outputs.items():
    h.raw(DEST / name, data)
h.save(DEST / 'index.json', dict(kind='P51_NEW_SOURCE_CANDIDATE_PREPARATION_NOT_P5_ACCEPTANCE',
    files=[h.record(DEST / name) for name in outputs], source=review['source'], runId=review['runId'],
    attempt=1, artifactId=review['artifactId'], provenanceRecords=len(files),
    remoteMutations=dict(fastForwardPush=1, branchPolicyChanges=0, workflowDispatch=1, delegatedApproval=1),
    gatesAndReviewersUnchanged=True, testServiceUnchanged=True, deviceOperations=0, productionRelease=False,
    keyExported=False, P5='NOT_RUN'))
print(json.dumps(dict(archive=str(DEST), source=review['source'], runId=review['runId'], files=6)))
