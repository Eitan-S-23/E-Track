import path from 'node:path';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { fileURLToPath, pathToFileURL } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const { chromium } = await import(pathToFileURL(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/playwright/index.mjs')));
const executable = 'C:/Users/SU/AppData/Local/ms-playwright/chromium-1217/chrome-win64/chrome.exe';
const profile = path.join(root, '.cache/p43/browser-owner');
assert.ok(fs.existsSync(executable));
const context = await chromium.launchPersistentContext(profile, { executablePath: executable, headless: false,
  args: ['--disable-breakpad','--disable-crash-reporter','--disable-component-update','--no-default-browser-check'],
  acceptDownloads: false, timeout: 30000,
  env: { ...process.env, DEBUG: '', CHROME_LOG_FILE: path.join(root, '.cache/p43/private/browser-chrome.log') } });
try {
  const page = context.pages()[0] || await context.newPage();
  await page.goto('about:blank');
  const result = { purpose: 'Interactive browser qualification only; no login or cloud operation',
    executable, profile, version: context.browser()?.version(), page: page.url(), started: true };
  fs.writeFileSync(path.join(root, '.cache/p43/private/browser-probe.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  process.stdout.write(JSON.stringify(result) + '\n');
} finally { await context.close(); }
