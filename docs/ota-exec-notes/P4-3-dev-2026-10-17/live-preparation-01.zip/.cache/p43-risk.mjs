import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const json = file => JSON.parse(read(file));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const source = '933b790e69e04ee551ad255398e08f12a1b2a107';
const artifact = `.cache/p43/ci/artifacts-39018754889/admin-deployment-input-${source}`;
const metadata = json(`${artifact}/bundle-meta.json`);
const inputs = Object.keys(metadata.inputs);
const bundle = fs.readFileSync(path.join(root, artifact, 'public/_worker.js/index.js'));
assert.equal(sha(bundle), '0ea681f19a8b2eec43c289d5637a0794943d5e44550cd46732b9220795043dc7');
const audit = json('.cache/p43/logs/dependency-audit-admin-01.log');
const flagged = Object.values(audit.vulnerabilities).map(v => ({ name: v.name, severity: v.severity,
  includedInputs: inputs.filter(file => file.includes(`/node_modules/${v.name}/`)) }));
const wrapperInputs = flagged.find(v => v.name === 'wrangler').includedInputs;
assert.ok(wrapperInputs.every(file => file.includes('/_virtual_') || file.endsWith('/templates/pages-template-worker.ts')));
assert.ok(flagged.filter(v => v.name !== 'wrangler').every(v => v.includedInputs.length === 0));
assert.ok(!inputs.some(file => file.includes('/node_modules/hono/')));
const sourceReceipt = json('.cache/p43/live/assets-04-worker-source-summary.json');
const raw = fs.readFileSync(path.join(root, '.cache/p43/private/assets-04-worker-source.bin'));
assert.equal(sha(raw), sourceReceipt.sha256);
const parts = await new Response(raw, { headers: { 'Content-Type': sourceReceipt.contentType } }).formData();
const modules = [];
let liveScript;
for (const [name, value] of parts) {
  const fileName = typeof value === 'string' ? name : value.name;
  const bytes = typeof value === 'string' ? Buffer.from(value) : Buffer.from(await value.arrayBuffer());
  modules.push({ name, fileName, sizeBytes: bytes.length, sha256: sha(bytes) });
  if (fileName.endsWith('.js') || name.endsWith('.js')) liveScript = bytes.toString('utf8');
}
assert.ok(liveScript?.includes('c.req.raw'));
const knownPriorWorkerSha = '9ff814b0fd1731418a2250a3ae941ff1f6ce0db99233f6f1db42a1ba2c161082';
const knownWorkerMatch = modules.some(m => m.sha256 === knownPriorWorkerSha);
assert.ok(knownWorkerMatch, 'Investigate a changed live Worker before the proposed exercise');
const settings = json('.cache/p43/live/inventory-01-worker-settings.json');
const result = { createdAt: new Date().toISOString(), adminSource: source, adminBundleSha256: sha(bundle), flagged,
  honoInAdminBundle: false, adminExternalImports: [...new Set(Object.values(metadata.outputs).flatMap(o => o.imports || []).filter(i => i.external).map(i => i.path))],
  explanation: 'Admin uses Cloudflare runtime fetch/crypto and first-party Pages template/polyfills, not the vulnerable npm image, HTTP-client or test-runtime implementations. Wrangler is an audit meta-vulnerability through those dependencies, not an advisory on the included template/polyfills.',
  deploymentToolLimit: 'CLI tooling advisories remain tracked. Use only the hash-verified local input and TLS-verified Cloudflare endpoints; no untrusted image processing, WebSocket client, retry/cache interceptor or arbitrary source-map input. No package update or risk waiver.',
  liveWorkerModules: modules, matchedExistingWorkerSource: knownWorkerMatch,
  liveWorkerHonoAnalysis: { existingVersion: '4.12.27', authority: 'Prior locked source and exact live module hash',
    usesRawRequestHandlers: liveScript.includes('c.req.raw'),
    containsCorsModule: liveScript.includes('hono/dist/middleware/cors'),
    usesHonoQueryHelperInRoutes: /c\.req\.(query|queries|parseBody)\(/.test(liveScript),
    conclusion: 'Existing route handlers pass raw Request to first-party URL/JSON validators. No CORS/language/proxy/SSR/SSG/parseBody middleware is installed. Known listed Hono advisory paths are not exercised by this isolated Admin deployment or these inspected public routes; dependency uplift remains root-owned.' },
  platformLogRisk: { id: 'P43-OBS-01', observability: settings.observability,
    disposition: 'Block signed-URL use until root resolves the existing Worker invocation-log configuration; no signed URL probe performed.',
    proposedMinimum: 'For this test Worker only, disable invocation_logs while retaining sanitized application/audit logs, or prove effective query redaction. Read back settings and a non-secret URL marker before any signed download. No code upload or other binding change.' } };
fs.writeFileSync(path.join(root, '.cache/p43/live/dependency-reachability-01.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(result, null, 2) + '\n');
