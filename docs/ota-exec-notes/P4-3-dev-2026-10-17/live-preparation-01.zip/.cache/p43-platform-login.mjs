import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const label = process.argv[2];
assert.match(label || '', /^platform-login-[0-9]+$/);
assert.equal(process.argv[3], '--existing-edge', 'Use only the user-selected existing Edge account');
const base = path.join(root, '.cache/p43/private/platform-login');
const profile = path.join(root, '.cache/p43/browser-owner');
const reportPath = path.join(root, '.cache/p43/live', `${label}.json`);
const dirs = Object.fromEntries(['home', 'appdata', 'localappdata', 'xdg-config', 'xdg-cache', 'xdg-data', 'tmp', 'logs']
  .map(name => [name, path.join(base, name)]));
const privateLog = path.join(dirs.logs, `${label}-console.log`);
const wranglerLog = path.join(dirs.logs, `${label}-wrangler.log`);
const chromeLog = path.join(dirs.logs, `${label}-chrome.log`);
const failureLog = path.join(dirs.logs, `${label}-failure.txt`);
const requestPath = path.join(base, `${label}-request.json`);
const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'login-preflight', '.', 'preflight',
  base, profile, reportPath, privateLog, wranglerLog, chromeLog, failureLog, requestPath, ...Object.values(dirs)],
{ cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(guard.status, 0, 'Login output preflight failed');
for (const file of [reportPath, privateLog, wranglerLog, failureLog, requestPath]) {
  assert.ok(!fs.existsSync(file), 'Refusing to overwrite a prior login observation');
}
for (const dir of Object.values(dirs)) fs.mkdirSync(dir, { recursive: true });
const env = { ...process.env, HOME: dirs.home, USERPROFILE: dirs.home,
  APPDATA: dirs.appdata, LOCALAPPDATA: dirs.localappdata,
  XDG_CONFIG_HOME: dirs['xdg-config'], XDG_CACHE_HOME: dirs['xdg-cache'], XDG_DATA_HOME: dirs['xdg-data'],
  TEMP: dirs.tmp, TMP: dirs.tmp, TMPDIR: dirs.tmp, DEBUG: '', CHROME_LOG_FILE: chromeLog,
  WRANGLER_LOG_PATH: wranglerLog, WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false' };
for (const key of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY',
  'CLOUDFLARE_EMAIL', 'CF_EMAIL', 'WRANGLER_AUTH_URL', 'WRANGLER_TOKEN_URL', 'WRANGLER_REVOKE_URL',
  'WRANGLER_AUTH_DOMAIN', 'WRANGLER_CLIENT_ID', 'CLOUDFLARE_API_ENVIRONMENT',
  'WRANGLER_CF_AUTHORIZATION_TOKEN', 'CLOUDFLARE_ACCESS_CLIENT_ID', 'CLOUDFLARE_ACCESS_CLIENT_SECRET']) delete env[key];
const requestedScopes = ['account:read', 'user:read', 'pages:write'];
const allScopes = [...requestedScopes, 'offline_access'].sort();
const admin = path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin');
const report = { label, startedAt: new Date().toISOString(), purpose: 'Legitimate platform OAuth, not an Admin Access session',
  browser: 'User-selected existing Microsoft Edge session; no agent profile write or cookie copy',
  privateConfigRoot: base, requestedScopes, cloudMutations: 0, adminExercise: 'NOT_RUN' };
const log = fs.createWriteStream(privateLog, { flags: 'wx' });
let child, closed, hardDeadline, entryServer, entryResponse, entryDeadline;
const emit = value => process.stdout.write(JSON.stringify(value) + '\n');
const sha256 = value => createHash('sha256').update(value).digest('hex');
function notifyRequester() {
  const session = process.env.CC_SESSION_KEY || '';
  const match = /^(?:feishu|lark):[^:]+:(ou_[a-z0-9]+)$/.exec(session);
  if (!match || !process.env.CC_PROJECT || !process.env.CC_DATA_DIR) {
    return { delivered: false, reason: 'No verified current requester route; no guessed mention' };
  }
  const message = `<at user_id="${match[1]}">requester</at> P4-3: In the ALREADY OPEN Microsoft Edge using the project's original signed-in Cloudflare account, open http://127.0.0.1:8975/ and click Continue. The local link opens official Cloudflare Wrangler OAuth with account:read, user:read, pages:write and offline_access. Approve only these scopes using that same account. No new account or fresh Chromium login is needed. Do not send credentials in chat; no chat reply is needed. The entry waits 10 minutes; the official callback starts only after your click and waits 120 seconds.`;
  const sent = spawnSync('D:/github/my/cc-connect-thread-guard/build/cc-connect.exe',
    ['send', '--project', process.env.CC_PROJECT, '--session', session, '--stdin'],
    { cwd: root, env, windowsHide: true, encoding: 'utf8', input: message, timeout: 20000 });
  const output = `${sent.stdout || ''}${sent.stderr || ''}`;
  return { delivered: sent.status === 0 && output.includes('Message sent successfully.'), exitCode: sent.status,
    receipt: output.split(session).join('[SESSION]').split(match[1]).join('[REQUESTER]'), scope: 'Current requester/current session only' };
}
async function waitForExistingEdge() {
  const pending = new Promise((resolve, reject) => {
    let started = false;
    entryServer = http.createServer((req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('Referrer-Policy', 'no-referrer');
      res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
      if (req.headers.host !== '127.0.0.1:8975' || req.method !== 'GET') {
        res.writeHead(403).end('Forbidden'); return;
      }
      if (req.url === '/') {
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.end('<!doctype html><title>P4-3 Existing Edge Account</title><h1>P4-3 Cloudflare authorization</h1><p>Use the original project account already signed in to this Microsoft Edge. This local helper does not collect passwords or cookies.</p><p><a href="/start">Continue to official Cloudflare Wrangler authorization</a></p><p>Only account:read, user:read, pages:write and offline_access. No cloud deployment happens in this step.</p>');
      } else if (req.url === '/start' && !started && req.headers['sec-fetch-mode'] === 'navigate') {
        started = true; clearTimeout(entryDeadline); entryResponse = res; resolve();
      } else res.writeHead(409).end('No additional login is started.');
    });
    entryServer.once('error', reject);
    entryServer.listen(8975, '127.0.0.1', () => {
      report.localEntry = { url: 'http://127.0.0.1:8975/', waitSeconds: 600, loopbackOnly: true };
      report.reminder = notifyRequester();
      emit({ label, phase: 'EXISTING_EDGE_ENTRY_READY', ...report.localEntry,
        reminderDelivered: report.reminder.delivered, accountRule: 'Use only the original project account already signed in to Edge' });
    });
    entryDeadline = setTimeout(() => reject(new Error('Existing Edge entry was not opened within its bound')), 600000);
  });
  await pending;
}
async function verifyAccount(token) {
  const prior = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8'));
  assert.match(prior.account_id, /^[a-f0-9]{32}$/);
  const observations = [];
  for (const [name, route] of [['account', `accounts/${prior.account_id}`],
    ['pages', `accounts/${prior.account_id}/pages/projects?per_page=100`]]) {
    const result = await fetch(`https://api.cloudflare.com/client/v4/${route}`, {
      headers: { Authorization: `Bearer ${token}` }, redirect: 'error', signal: AbortSignal.timeout(30000) });
    const bytes = Buffer.from(await result.arrayBuffer());
    assert.ok(bytes.length < 4 * 1024 * 1024);
    const json = JSON.parse(bytes.toString('utf8'));
    fs.writeFileSync(path.join(base, `${label}-${name}.json`), bytes, { flag: 'wx' });
    observations.push({ name, method: 'GET', status: result.status, success: json.success === true,
      cfRay: result.headers.get('cf-ray'), bodySha256: sha256(bytes),
      ...(name === 'account' && json.success ? { matchesApprovedAccount: json.result.id === prior.account_id } : {}),
      ...(name === 'pages' && json.success ? { projectNames: json.result.map(p => p.name), resultInfo: json.result_info } : {}),
      errors: json.errors?.map(e => ({ code: e.code })) });
  }
  return observations;
}
try {
  await waitForExistingEdge();
  const args = [path.join(admin, 'node_modules/wrangler/bin/wrangler.js'), 'login', '--browser=false', '--scopes', ...requestedScopes];
  child = spawn(process.execPath, args, { cwd: base, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  report.loginPid = child.pid;
  let output = '', navigation;
  child.stdout.on('data', bytes => { log.write(bytes); output += bytes.toString('utf8'); });
  child.stderr.on('data', bytes => { log.write(bytes); output += bytes.toString('utf8'); });
  closed = new Promise(resolve => {
    child.once('error', error => resolve({ exitCode: null, errorName: error.name, code: error.code }));
    child.once('close', (exitCode, signal) => resolve({ exitCode, signal }));
  });
  hardDeadline = setTimeout(() => child.kill(), 165000);
  for (let i = 0; i < 100 && child.exitCode === null; i++) {
    const match = /Visit this link to authenticate: (https:\/\/[^\s]+)/.exec(output);
    if (match) { navigation = match[1].replace(/\u001b\[[0-9;]*m/g, ''); break; }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert.ok(navigation, 'Official CLI did not provide a login URL');
  const url = new URL(navigation);
  assert.equal(url.origin, 'https://dash.cloudflare.com');
  assert.equal(url.pathname, '/oauth2/auth');
  assert.equal(url.searchParams.get('client_id'), '54d11594-84e4-41aa-b438-e81b8fa78ee7');
  assert.equal(url.searchParams.get('redirect_uri'), 'http://localhost:8976/oauth/callback');
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
  assert.deepEqual(url.searchParams.get('scope').split(' ').sort(), allScopes);
  assert.ok(url.searchParams.get('state') && url.searchParams.get('code_challenge'));
  fs.writeFileSync(requestPath, JSON.stringify({ url: navigation }, null, 2) + '\n', { flag: 'wx' });
  report.oauthRequest = { origin: url.origin, path: url.pathname, scopes: allScopes, pkce: 'S256',
    callback: 'http://localhost:8976/oauth/callback', fullUrlPrivate: true };
  entryResponse.writeHead(302, { Location: navigation }).end();
  report.navigation = { redirectToOfficialOAuth: true, fullUrlPrivate: true, browser: 'Existing Edge, opened by user' };
  emit({ label, phase: 'EXISTING_EDGE_OFFICIAL_OAUTH', trustedOrigin: url.origin, fullUrlOmitted: true,
    scopes: allScopes, officialCallbackDeadlineSeconds: 120 });
  report.cli = await closed;
  report.timedOut = output.includes('Timed out waiting for authorization code');
  report.loginSucceeded = report.cli.exitCode === 0 && output.includes('Successfully logged in.');
  if (report.loginSucceeded) {
    const configPaths = [path.join(dirs['xdg-config'], '.wrangler/config/default.toml'),
      path.join(dirs.home, '.wrangler/config/default.toml'),
      path.join(dirs.appdata, 'xdg.config/.wrangler/config/default.toml')];
    const found = configPaths.filter(p => fs.existsSync(p));
    assert.equal(found.length, 1, 'Expected exactly one contained OAuth configuration');
    const toml = fs.readFileSync(found[0], 'utf8');
    const token = toml.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1];
    assert.ok(token);
    report.oauthConfiguration = { path: found[0], expirationTime: toml.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1] };
    report.accountVerification = await verifyAccount(token);
  } else process.exitCode = 1;
} catch (error) {
  fs.writeFileSync(failureLog, String(error.stack || error), { flag: 'wx' });
  report.failure = { name: error.name, code: error.code || null, detailPrivate: true };
  process.exitCode = 1;
} finally {
  clearTimeout(hardDeadline);
  clearTimeout(entryDeadline);
  if (child && child.exitCode === null && child.signalCode === null) child.kill();
  if (closed && !report.cli) report.cli = await closed;
  if (entryResponse && !entryResponse.writableEnded) entryResponse.writeHead(503).end('Login preparation failed; no credential was collected here.');
  if (entryServer) { entryServer.closeAllConnections(); await new Promise(resolve => entryServer.close(resolve)); }
  report.localEntryClosed = true;
  log.end();
  report.endedAt = new Date().toISOString();
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  emit(report);
}
