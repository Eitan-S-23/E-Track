const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const outside = (base, file) => { const rel = path.relative(base, file); return rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel); };
const stats = { directories: 0, files: 0, bytes: 0, links: [], escaped: [], errors: [] };
function walk(dir, onFile, scope = root) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch (error) { stats.errors.push({ path: dir, code: error.code }); return; }
  for (const entry of entries) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) { stats.links.push(file); continue; }
    if (entry.isDirectory()) {
      const actual = fs.realpathSync(file);
      if (outside(scope, actual)) { stats.escaped.push({ path: file, actual }); continue; }
      stats.directories++;
      walk(file, onFile, scope);
    } else if (entry.isFile()) onFile(file, fs.statSync(file));
  }
}
for (const rel of ['.cache', 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin',
  'app/bluetooth_flutter_Trace/cloudflare/update-service/public', 'app/bluetooth_flutter_Trace/cloudflare/update-service/worker',
  'docs/ota-exec-notes/P4-3-dev-2026-10-17']) {
  const dir = path.join(root, rel);
  if (fs.existsSync(dir)) walk(dir, (_file, stat) => { stats.files++; stats.bytes += stat.size; });
}
process.stdout.write(JSON.stringify({ root, containedOutputs: stats }, null, 2) + '\n');
const chrome = 'C:\\Users\\SU\\AppData\\Local\\Google\\Chrome\\User Data';
const duringLaunch = [];
const start = Date.parse('2026-10-17T04:13:56.530Z');
const end = Date.parse('2026-10-17T04:18:23.290Z');
if (fs.existsSync(chrome)) walk(chrome, (file, stat) => {
  if ((stat.mtimeMs >= start && stat.mtimeMs <= end) || (stat.birthtimeMs >= start && stat.birthtimeMs <= end)) {
    duringLaunch.push({ path: file, modified: stat.mtime.toISOString(), created: stat.birthtime.toISOString() });
  }
}, chrome);
process.stdout.write(JSON.stringify({ readOnlyChromeTimestampAudit: { path: chrome, windowStart: new Date(start).toISOString(),
  windowEnd: new Date(end).toISOString(), matchingFiles: duringLaunch, attribution: 'timestamps only, not proof of process ownership' } }, null, 2) + '\n');
const logs = path.join(root, '.cache', 'p43', 'logs');
const launches = fs.readFileSync(path.join(logs, 'ui-mock-01.log'), 'utf8');
process.stdout.write(JSON.stringify({ installedChromeCleanup: {
  exits: (launches.match(/<process did exit:/g) || []).length,
  cleanupCompletions: (launches.match(/finished temporary directories cleanup/g) || []).length
} }) + '\n');
const tmp = path.join(root, '.cache', 'p43', 'tmp');
process.stdout.write(JSON.stringify({ remainingPlaywrightTemps: fs.readdirSync(tmp).filter(name => name.startsWith('playwright')) }) + '\n');
const status = spawnSync('git', ['status', '--short', '--branch'], { cwd: root, encoding: 'utf8', windowsHide: true });
process.stdout.write(status.stdout);
if (stats.escaped.length || stats.links.length || stats.errors.length) process.exitCode = 1;
