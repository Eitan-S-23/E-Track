const fs = require('node:fs');
const path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const commonGit = 'D:\\github\\my\\E-Track\\.git';
function guard(target, boundary = root) {
  const full = path.resolve(target);
  const relative = path.relative(boundary, full);
  if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) throw new Error('Output outside boundary: ' + full);
  let current = path.parse(full).root;
  for (const part of full.slice(current.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    if (!fs.existsSync(current)) continue;
    if (fs.lstatSync(current).isSymbolicLink()) throw new Error('Linked output path: ' + current);
    const result = spawnSync('fsutil.exe', ['reparsepoint', 'query', current], { cwd: root, windowsHide: true });
    const diagnostic = new TextDecoder('gbk').decode(Buffer.concat([result.stdout || Buffer.alloc(0), result.stderr || Buffer.alloc(0)]));
    if (result.status !== 1 || !/not a reparse point|\u4e0d\u662f\u4e00\u4e2a\u91cd\u5206\u6790\u70b9/.test(diagnostic)) {
      throw new Error('Unverified output path: ' + current + ' ' + JSON.stringify({ status: result.status, diagnostic, error: result.error?.message }));
    }
  }
  return full;
}

const [label, relativeCwd, command, ...args] = process.argv.slice(2);
if (!/^[a-z0-9-]+$/.test(label || '') || !command) throw new Error('Usage: label relative-cwd command args...');
const cwd = guard(path.resolve(root, relativeCwd));
if (command === 'preflight') {
  for (const target of args) process.stdout.write(guard(path.resolve(cwd, target)) + '\n');
  process.exit(0);
}
const dirs = Object.fromEntries(['tmp', 'home', 'appdata', 'localappdata', 'npm', 'gh', 'logs', 'xdg-config', 'xdg-cache', 'xdg-data'].map(name => [name, guard(path.join(root, '.cache', 'p43', name))]));
const logPath = guard(path.join(dirs.logs, `${label}.log`));
const receiptPath = guard(path.join(dirs.logs, `${label}.json`));
const wranglerLog = guard(path.join(dirs.logs, `${label}-wrangler.log`));
const uiOutput = guard(path.join(root, '.cache', 'p43', 'ui', label));
const browsers = guard(path.join(root, '.cache', 'p43', 'browsers'));
for (const dir of Object.values(dirs)) fs.mkdirSync(dir, { recursive: true });
if (fs.existsSync(logPath) || fs.existsSync(receiptPath)) throw new Error('Refusing to overwrite original log');
const env = { ...process.env, TEMP: dirs.tmp, TMP: dirs.tmp, TMPDIR: dirs.tmp,
  HOME: dirs.home, USERPROFILE: dirs.home, APPDATA: dirs.appdata, LOCALAPPDATA: dirs.localappdata,
  XDG_CONFIG_HOME: dirs['xdg-config'], XDG_CACHE_HOME: dirs['xdg-cache'], XDG_DATA_HOME: dirs['xdg-data'],
  npm_config_cache: dirs.npm, npm_config_update_notifier: 'false',
  GH_CONFIG_DIR: dirs.gh, GH_PROMPT_DISABLED: '1', GH_PAGER: 'cat',
  WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false', WRANGLER_LOG_PATH: wranglerLog,
  PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: '1', PLAYWRIGHT_BROWSERS_PATH: browsers, PW_OUTPUT_DIR: uiOutput,
  PYTHONDONTWRITEBYTECODE: '1', PYTHONUTF8: '1', GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: 'never',
  GIT_CONFIG_GLOBAL: 'C:\\Users\\SU\\.gitconfig', WECHAT_WEBHOOK_KEY: '', ANTHROPIC_API_KEY: '' };
let executable = command;
let actualArgs = args;
let binaryOutput;
if (command === 'gh-log-zip') {
  if (!/^\d+$/.test(args[0] || '') || args.length !== 2) throw new Error('Expected run ID and contained archive path');
  binaryOutput = guard(path.resolve(cwd, args[1]));
  if (fs.existsSync(binaryOutput)) throw new Error('Refusing to overwrite original archive');
  fs.mkdirSync(path.dirname(binaryOutput), { recursive: true });
  executable = 'gh';
  actualArgs = ['api', `repos/Eitan-S-23/E-Track/actions/runs/${args[0]}/logs`];
}
if (command === 'npm') {
  for (const name of ['node_modules', 'package-lock.json', '.wrangler']) guard(path.join(cwd, name));
  executable = process.execPath;
  actualArgs = [path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js'), ...args];
}
if (command === 'git' || command === 'github-git') {
  guard(commonGit, commonGit);
  executable = 'git';
  actualArgs = ['-c', 'gc.auto=0', '-c', 'maintenance.auto=false', ...args];
}
if (command === 'gh' || command === 'github-git' || command === 'gh-log-zip') {
  const authEnv = { ...process.env, TEMP: dirs.tmp, TMP: dirs.tmp, TMPDIR: dirs.tmp, GH_PROMPT_DISABLED: '1' };
  delete authEnv.GH_TOKEN;
  delete authEnv.GITHUB_TOKEN;
  const auth = spawnSync('gh', ['auth', 'token', '--hostname', 'github.com', '--user', 'Eitan-S-23'], { cwd, env: authEnv, encoding: 'utf8', windowsHide: true, timeout: 30000 });
  if (auth.status !== 0 || !auth.stdout.trim()) throw new Error('Approved GitHub credential unavailable');
  const token = auth.stdout.trim();
  env.GH_TOKEN = token;
  delete env.GITHUB_TOKEN;
  const identity = spawnSync('gh', ['api', 'user', '--jq', '.login'], { cwd, env, encoding: 'utf8', windowsHide: true, timeout: 30000 });
  if (identity.status !== 0 || identity.stdout.trim() !== 'Eitan-S-23') throw new Error('GitHub identity verification failed');
  if (command === 'github-git') {
    env.GIT_CONFIG_COUNT = '2';
    env.GIT_CONFIG_KEY_0 = 'credential.helper';
    env.GIT_CONFIG_VALUE_0 = '';
    env.GIT_CONFIG_KEY_1 = 'http.https://github.com/.extraheader';
    env.GIT_CONFIG_VALUE_1 = 'AUTHORIZATION: basic ' + Buffer.from('Eitan-S-23:' + token).toString('base64');
  }
}
const started = new Date().toISOString();
const log = fs.createWriteStream(logPath, { flags: 'wx' });
const binary = binaryOutput ? fs.createWriteStream(binaryOutput, { flags: 'wx' }) : null;
const child = spawn(executable, actualArgs, { cwd, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
child.stdout.on('data', data => { if (binary) binary.write(data); else { log.write(data); process.stdout.write(data); } });
child.stderr.on('data', data => { log.write(data); process.stdout.write(data); });
child.on('error', error => { log.write(String(error)); process.stderr.write(String(error)); });
child.on('close', (code, signal) => {
  log.end();
  if (binary) binary.end();
  fs.writeFileSync(receiptPath, JSON.stringify({ label, cwd, command, args, started, ended: new Date().toISOString(), exitCode: code, signal, node: process.version, logPath, binaryOutput }, null, 2) + '\n', { flag: 'wx' });
  process.exitCode = code === 0 ? 0 : (code || 1);
});
