# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: firmware-ui.spec.ts >> unknown channel result is read back but never automatically repeated
- Location: test\firmware-ui.spec.ts:213:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.firmware-channel-card[data-channel="beta"] [data-firmware-action="stop-latest"]')
    - locator resolved to <button disabled type="button" class="pill-button" data-channel="beta" data-firmware-action="stop-latest">Stop latest</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not stable
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not stable
    - retrying click action
      - waiting 100ms
    - waiting for element to be visible, enabled and stable
    - element is not stable
  43 × retrying click action
       - waiting 500ms
       - waiting for element to be visible, enabled and stable
       - element is not enabled
  - retrying click action
    - waiting 500ms
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic: MOCK UI / NO REAL ACCESS OR D1
  - generic [ref=e2]:
    - complementary "Admin navigation" [ref=e3]:
      - generic [ref=e4]:
        - generic [ref=e5]: CF
        - generic [ref=e6]:
          - strong [ref=e7]: Cloudflare
          - text: Device Update Admin
      - navigation [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]: Device targets
          - button "Phone" [ref=e11] [cursor=pointer]
          - button "MCU Firmware" [active] [ref=e16] [cursor=pointer]
      - generic [ref=e21]:
        - generic [ref=e22]:
          - generic [ref=e23]: O
          - generic [ref=e24]:
            - strong [ref=e25]: owner@example.test
            - text: owner
        - button "Collapse" [ref=e26] [cursor=pointer]
    - main [ref=e31]:
      - generic [ref=e32]:
        - text: Open navigation
        - searchbox [ref=e36]
        - button "Switch language" [ref=e37] [cursor=pointer]:
          - generic [ref=e40]: 中文
        - button "Refresh" [ref=e41] [cursor=pointer]
        - link "Session JSON" [ref=e45] [cursor=pointer]:
          - /url: /api/admin/session
        - generic [ref=e49]:
          - generic [ref=e50]: O
          - generic [ref=e51]:
            - strong [ref=e52]: owner@example.test
            - text: owner
      - text: How release controls work All releases Candidate releases Published releases Disabled releases Releases needing notes Fallback releases All channels Stable channel Beta channel Unpublished releases Sort releases Selected Previous version Next version
      - generic [ref=e53]:
        - generic [ref=e58]:
          - paragraph [ref=e59]:
            - text: Trace /
            - strong [ref=e60]: MCU Firmware
          - heading "MCU Firmware Management" [level=1] [ref=e61]
          - paragraph [ref=e62]: Publish ready MCU releases, retract channel pointers and control distribution independently.
          - generic [ref=e63]:
            - generic [ref=e64]:
              - strong [ref=e65]: "3"
              - generic [ref=e66]: R2-ready firmware versions
            - generic [ref=e67]: The app downloads only published firmware through Cloudflare.
        - region "MCU firmware releases" [ref=e68]:
          - generic [ref=e69]:
            - generic [ref=e71]:
              - paragraph [ref=e72]: Firmware source
              - heading "R2 Firmware Versions" [level=2] [ref=e73]
            - generic [ref=e74]:
              - article [ref=e75]:
                - generic [ref=e76]:
                  - button [ref=e77] [cursor=pointer]:
                    - heading "mcu-e-track-at32f435-v2.8.3" [level=3] [ref=e78]
                    - paragraph [ref=e79]: e-track-at32f435
                  - generic [ref=e80]: Ready
                - generic [ref=e81]: Unpublished
                - generic [ref=e83]:
                  - generic [ref=e84]:
                    - generic [ref=e85]: Version
                    - strong [ref=e86]: 2.8.3
                  - generic [ref=e87]:
                    - generic [ref=e88]: Version code
                    - strong [ref=e89]: "20803"
                  - generic [ref=e90]:
                    - generic [ref=e91]: Size
                    - strong [ref=e92]: 3 KiB
                  - generic [ref=e93]:
                    - generic [ref=e94]: Target raw image SHA-256
                    - strong [ref=e95]: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
                - group [ref=e96]:
                  - generic "Assets (3)" [ref=e97]
                - generic [ref=e98]:
                  - button "Publish beta" [disabled] [ref=e99]
                  - button "Publish stable" [disabled] [ref=e100]
                  - button "Disable" [disabled] [ref=e101]
                  - button "Recovery download" [disabled] [ref=e102]
              - article [ref=e103]:
                - generic [ref=e104]:
                  - button [ref=e105] [cursor=pointer]:
                    - heading "mcu-e-track-at32f435-v2.8.2" [level=3] [ref=e106]
                    - paragraph [ref=e107]: e-track-at32f435
                  - generic [ref=e108]: Ready
                - generic [ref=e109]:
                  - generic [ref=e110]: Stable
                  - generic [ref=e111]: Beta
                - generic [ref=e112]:
                  - generic [ref=e113]:
                    - generic [ref=e114]: Version
                    - strong [ref=e115]: 2.8.2
                  - generic [ref=e116]:
                    - generic [ref=e117]: Version code
                    - strong [ref=e118]: "20802"
                  - generic [ref=e119]:
                    - generic [ref=e120]: Size
                    - strong [ref=e121]: 3 KiB
                  - generic [ref=e122]:
                    - generic [ref=e123]: Target raw image SHA-256
                    - strong [ref=e124]: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
                - group [ref=e125]:
                  - generic "Assets (3)" [ref=e126]
                - generic [ref=e127]:
                  - button "Publish beta" [disabled] [ref=e128]
                  - button "Publish stable" [disabled] [ref=e129]
                  - button "Disable" [disabled] [ref=e130]
                  - button "Recovery download" [disabled] [ref=e131]
              - article [ref=e132]:
                - generic [ref=e133]:
                  - button [ref=e134] [cursor=pointer]:
                    - heading "mcu-e-track-at32f435-v2.8.1" [level=3] [ref=e135]
                    - paragraph [ref=e136]: e-track-at32f435
                  - generic [ref=e137]: Ready
                - generic [ref=e138]: Unpublished
                - generic [ref=e140]:
                  - generic [ref=e141]:
                    - generic [ref=e142]: Version
                    - strong [ref=e143]: 2.8.1
                  - generic [ref=e144]:
                    - generic [ref=e145]: Version code
                    - strong [ref=e146]: "20801"
                  - generic [ref=e147]:
                    - generic [ref=e148]: Size
                    - strong [ref=e149]: 3 KiB
                  - generic [ref=e150]:
                    - generic [ref=e151]: Target raw image SHA-256
                    - strong [ref=e152]: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
                - group [ref=e153]:
                  - generic "Assets (3)" [ref=e154]
                - generic [ref=e155]:
                  - button "Publish beta" [disabled] [ref=e156]
                  - button "Publish stable" [disabled] [ref=e157]
                  - button "Disable" [disabled] [ref=e158]
                  - button "Recovery download" [disabled] [ref=e159]
          - generic [ref=e160]:
            - generic [ref=e162]:
              - paragraph [ref=e163]: App visibility
              - heading "Firmware Channels" [level=2] [ref=e164]
            - generic [ref=e165]:
              - article [ref=e166]:
                - generic [ref=e167]:
                  - generic [ref=e168]:
                    - heading "Stable" [level=3] [ref=e169]
                    - paragraph [ref=e170]: e-track-at32f435
                  - generic [ref=e171]: Revision 7
                - generic [ref=e172]:
                  - generic [ref=e173]:
                    - generic [ref=e174]: Current
                    - strong [ref=e175]: mcu-e-track-at32f435-v2.8.2
                  - generic [ref=e176]:
                    - generic [ref=e177]: Version code
                    - strong [ref=e178]: "20802"
                  - generic [ref=e179]:
                    - generic [ref=e180]: New update checks
                    - strong [ref=e181]: Enabled
                  - generic [ref=e182]:
                    - generic [ref=e183]: Asset downloads
                    - strong [ref=e184]: Enabled
                  - generic [ref=e185]:
                    - generic [ref=e186]: Selected retraction target
                    - strong [ref=e187]: mcu-e-track-at32f435-v2.8.3
                - generic [ref=e188]:
                  - button "Retract stable" [disabled] [ref=e189]
                  - button "Stop latest" [disabled] [ref=e190]
                  - button "Stop downloads" [disabled] [ref=e191]
              - article [ref=e192]:
                - generic [ref=e193]:
                  - generic [ref=e194]:
                    - heading "Beta" [level=3] [ref=e195]
                    - paragraph [ref=e196]: e-track-at32f435
                  - generic [ref=e197]: Revision 8
                - generic [ref=e198]:
                  - generic [ref=e199]:
                    - generic [ref=e200]: Current
                    - strong [ref=e201]: mcu-e-track-at32f435-v2.8.2
                  - generic [ref=e202]:
                    - generic [ref=e203]: Version code
                    - strong [ref=e204]: "20802"
                  - generic [ref=e205]:
                    - generic [ref=e206]: New update checks
                    - strong [ref=e207]: Enabled
                  - generic [ref=e208]:
                    - generic [ref=e209]: Asset downloads
                    - strong [ref=e210]: Enabled
                  - generic [ref=e211]:
                    - generic [ref=e212]: Selected retraction target
                    - strong [ref=e213]: mcu-e-track-at32f435-v2.8.3
                - generic [ref=e214]:
                  - button "Retract beta" [disabled] [ref=e215]
                  - button "Stop latest" [disabled] [ref=e216]
                  - button "Stop downloads" [disabled] [ref=e217]
            - generic [ref=e218]:
              - strong [ref=e219]: Current flow
              - paragraph [ref=e220]: Publish/retract changes channel visibility, not release identity. Latest and download switches are independent. Stopping a channel blocks downloads of a release shared with another channel too.
              - paragraph [ref=e221]: Retraction only affects devices that have not upgraded. Upgraded devices will not downgrade; publish a fix with a higher versionCode.
  - region "R2 and D1 resources" [ref=e222]:
    - button "Open R2 and D1 resources" [ref=e223]:
      - generic [ref=e226]:
        - strong [ref=e227]: "--"
        - generic [ref=e228]: R2 / D1
```

# Test source

```ts
  115 |   await expect(page.locator("#firmwareReleaseList .firmware-release-card")).toHaveCount(3);
  116 |   if ((page.viewportSize()?.width ?? 1440) < 700) await page.locator("#mobileMenu").click();
  117 |   await page.locator('[data-view-target="firmware"]').click();
  118 |   return data;
  119 | }
  120 | 
  121 | const channelButton = (page: Page, channel: string, action: string) => page.locator(
  122 |   `.firmware-channel-card[data-channel="${channel}"] [data-firmware-action="${action}"]`);
  123 | const releaseButton = (page: Page, id: string, action: string) => page.locator(
  124 |   `.firmware-release-card[data-release-id="${id}"] [data-firmware-action="${action}"]`);
  125 | async function fillConfirmation(page: Page, reason = " browser operator reason ") {
  126 |   if (await page.locator("#confirmInput").isVisible()) await page.locator("#confirmInput").fill("stable");
  127 |   if (await page.locator("#confirmReason").isVisible()) await page.locator("#confirmReason").fill(reason);
  128 |   await expect(page.locator("#confirmAccept")).toBeEnabled();
  129 |   await page.locator("#confirmAccept").click();
  130 | }
  131 | async function closeResult(page: Page) {
  132 |   await page.locator("#confirmAccept").click();
  133 |   await expect(page.locator("#confirmDialog")).toBeHidden();
  134 |   await expect(page.locator("#refreshButton")).toBeEnabled();
  135 | }
  136 | 
  137 | for (const language of ["en", "zh"]) {
  138 |   test(`${language}: retract boundary, reason, cancel and fresh confirmation`, async ({ page }, info) => {
  139 |     const data = await mockAdmin(page, language);
  140 |     await expect(page.locator("#firmwareView")).not.toContainText("undefined");
  141 |     await releaseButton(page, "fw-old", "select").click();
  142 |     await page.screenshot({ path: info.outputPath(`${language}-mock-overview.png`), fullPage: true });
  143 |     await channelButton(page, "stable", "retract").click();
  144 |     await expect(page.locator("#confirmDetail")).toContainText(language === "zh" ? "已升级设备不会降级" : "Upgraded devices will not downgrade");
  145 |     await expect(page.locator("#confirmDetail")).toContainText("versionCode");
  146 |     await page.locator("#confirmInput").fill("stable");
  147 |     await expect(page.locator("#confirmAccept")).toBeDisabled();
  148 |     await page.locator("#confirmReason").fill("   ");
  149 |     await expect(page.locator("#confirmAccept")).toBeDisabled();
  150 |     await page.locator("#confirmReason").fill("operator cancellation fixture");
  151 |     await page.screenshot({ path: info.outputPath(`${language}-mock-confirm.png`), fullPage: true });
  152 |     await page.locator("#confirmCancel").click();
  153 |     await expect(page.locator("#confirmDialog")).toBeHidden();
  154 |     expect(data.writes).toHaveLength(0); expect(data.mutations).toBe(0);
  155 |     await page.screenshot({ path: info.outputPath(`${language}-mock-cancel.png`), fullPage: true });
  156 |     await channelButton(page, "stable", "retract").click();
  157 |     await fillConfirmation(page);
  158 |     await expect(page.locator("#confirmTitle")).toHaveText(language === "zh" ? "固件操作已确认" : "Firmware operation confirmed");
  159 |     expect(data.writes).toHaveLength(1);
  160 |     expect(data.writes[0].body).toEqual({ ...scope, releaseId: "fw-old", expectedRevision: 7, reason: " browser operator reason " });
  161 |     await page.screenshot({ path: info.outputPath(`${language}-mock-success.png`), fullPage: true });
  162 |     await closeResult(page);
  163 |     expect(data.channels[0].currentReleaseId).toBe("fw-old");
  164 |     expect(data.releases.find(r => r.releaseId === "fw-old")!.state).toBe("ready");
  165 |   });
  166 |   test(`${language}: CAS refresh never replays an old intent`, async ({ page }, info) => {
  167 |     const data = await mockAdmin(page, language); data.mode = "conflict";
  168 |     await releaseButton(page, "fw-old", "select").click();
  169 |     await channelButton(page, "stable", "retract").click(); await fillConfirmation(page);
  170 |     await expect(page.locator("#confirmMessage")).toContainText(language === "zh" ? "再次确认" : "confirm again");
  171 |     await page.screenshot({ path: info.outputPath(`${language}-mock-conflict.png`), fullPage: true });
  172 |     expect(data.writes).toHaveLength(1); expect(data.mutations).toBe(0);
  173 |     await closeResult(page);
  174 |     await channelButton(page, "stable", "retract").click();
  175 |     await expect(page.locator("#confirmMessage")).toContainText("8");
  176 |     await expect(page.locator("#confirmReason")).toHaveValue("");
  177 |     expect(data.writes).toHaveLength(1);
  178 |     await fillConfirmation(page, "new confirmed intent");
  179 |     await expect(page.locator("#confirmTitle")).toHaveText(language === "zh" ? "固件操作已确认" : "Firmware operation confirmed");
  180 |     expect(data.writes[1].body.expectedRevision).toBe(8); expect(data.mutations).toBe(1);
  181 |   });
  182 | }
  183 | 
  184 | test("beta publisher controls are independent and stable/release actions stay owner-only", async ({ page }) => {
  185 |   const data = await mockAdmin(page, "en", "publisher");
  186 |   await expect(channelButton(page, "stable", "stop-latest")).toBeDisabled();
  187 |   await expect(releaseButton(page, "fw-new", "disable")).toBeDisabled();
  188 |   await expect(releaseButton(page, "fw-new", "recovery-download")).toBeDisabled();
  189 |   await channelButton(page, "beta", "stop-downloads").click();
  190 |   await expect(page.locator("#confirmInput")).toBeHidden();
  191 |   await page.locator("#confirmMaintenance").fill("download incident"); await fillConfirmation(page);
  192 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed"); await closeResult(page);
  193 |   expect(data.channels[1]).toMatchObject({ disableLatest: false, disableDownloads: true });
  194 |   await channelButton(page, "beta", "resume-downloads").click();
  195 |   await expect(page.locator("#confirmMaintenance")).toBeHidden(); await fillConfirmation(page);
  196 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  197 |   expect(data.writes[1].body).not.toHaveProperty("maintenanceMessage");
  198 | });
  199 | 
  200 | test("viewer and unavailable/reference-protected releases cannot write", async ({ page }) => {
  201 |   const data = await mockAdmin(page, "en", "viewer");
  202 |   await expect(channelButton(page, "beta", "stop-downloads")).toBeDisabled();
  203 |   await expect(releaseButton(page, "fw-new", "publish").first()).toBeDisabled();
  204 |   expect(data.writes).toHaveLength(0);
  205 |   data.role = "owner"; data.actor = "owner@example.test";
  206 |   data.releases[0].state = "draft"; data.releases[2].archived = true;
  207 |   await page.locator("#refreshButton").click();
  208 |   await expect(releaseButton(page, "fw-new", "publish").first()).toBeDisabled();
  209 |   await expect(releaseButton(page, "fw-old", "disable")).toBeDisabled();
  210 |   await expect(releaseButton(page, "fw-current", "disable")).toBeDisabled();
  211 | });
  212 | 
  213 | test("unknown channel result is read back but never automatically repeated", async ({ page }) => {
  214 |   const data = await mockAdmin(page); data.mode = "unknown-channel";
> 215 |   await channelButton(page, "beta", "stop-latest").click(); await fillConfirmation(page);
      |                                                    ^ Error: locator.click: Test timeout of 30000ms exceeded.
  216 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown");
  217 |   expect(data.writes).toHaveLength(1); expect(data.mutations).toBe(1);
  218 |   expect(data.events.at(-1)).toMatch(/^GET /);
  219 |   await closeResult(page);
  220 |   await expect(channelButton(page, "beta", "resume-latest")).toBeEnabled();
  221 |   expect(data.writes).toHaveLength(1);
  222 | });
  223 | 
  224 | test("unknown release result uses an explicit same-key/same-body reconciliation after reads", async ({ page }) => {
  225 |   const data = await mockAdmin(page); data.mode = "unknown-release";
  226 |   await releaseButton(page, "fw-new", "recovery-download").click(); await fillConfirmation(page, "original recovery reason");
  227 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  228 |   expect(data.writes).toHaveLength(1);
  229 |   await expect(releaseButton(page, "fw-new", "disable")).toBeDisabled();
  230 |   const eventCount = data.events.length;
  231 |   await page.locator('[data-firmware-action="retry-release"]').click();
  232 |   await expect(page.locator("#confirmDetail")).toContainText("original recovery reason");
  233 |   expect(data.events.slice(eventCount).every(event => event.startsWith("GET "))).toBe(true);
  234 |   expect(data.writes).toHaveLength(1);
  235 |   await fillConfirmation(page);
  236 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  237 |   expect(data.writes).toHaveLength(2);
  238 |   expect(data.writes[1]).toEqual(data.writes[0]); expect(data.mutations).toBe(1);
  239 |   await expect(page.locator("#confirmDownload")).toBeVisible();
  240 |   await expect(page.locator("#confirmDownload")).toHaveAttribute("href", /purpose=admin-recovery/);
  241 |   await closeResult(page);
  242 |   await expect(page.locator("#confirmDownload")).not.toHaveAttribute("href");
  243 | });
  244 | 
  245 | test("an expired original key requires a newly confirmed operation, not an automatic new key", async ({ page }) => {
  246 |   const data = await mockAdmin(page); data.mode = "unknown-release";
  247 |   await releaseButton(page, "fw-new", "recovery-download").click(); await fillConfirmation(page);
  248 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  249 |   data.expireReplay = true;
  250 |   await page.locator('[data-firmware-action="retry-release"]').click(); await fillConfirmation(page);
  251 |   await expect(page.locator("#confirmDetail")).toContainText("IDEMPOTENCY_RESULT_EXPIRED");
  252 |   expect(data.writes).toHaveLength(2); expect(data.writes[1].key).toBe(data.writes[0].key);
  253 |   await closeResult(page); data.expireReplay = false;
  254 |   await releaseButton(page, "fw-new", "recovery-download").click();
  255 |   expect(data.writes).toHaveLength(2); await fillConfirmation(page);
  256 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  257 |   expect(data.writes[2].key).not.toBe(data.writes[0].key);
  258 | });
  259 | 
  260 | test("owner identity changes cannot replay a pending request in another actor scope", async ({ page }) => {
  261 |   const data = await mockAdmin(page); data.mode = "unknown-release";
  262 |   await releaseButton(page, "fw-new", "disable").click(); await fillConfirmation(page);
  263 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  264 |   data.actor = "different-owner@example.test";
  265 |   await page.locator('[data-firmware-action="retry-release"]').click();
  266 |   await expect(page.locator("#firmwareNotice")).toBeVisible();
  267 |   await expect(page.locator("#confirmDialog")).toBeHidden();
  268 |   expect(data.writes).toHaveLength(1); expect(data.mutations).toBe(1);
  269 | });
  270 | 
  271 | test("failed state refresh keeps writes locked until a successful manual read", async ({ page }) => {
  272 |   const data = await mockAdmin(page); data.mode = "refresh-failure";
  273 |   await channelButton(page, "beta", "stop-latest").click(); await fillConfirmation(page);
  274 |   await expect(page.locator("#confirmMessage")).toContainText("state refresh failed"); await closeResult(page);
  275 |   await expect(channelButton(page, "beta", "stop-latest")).toBeDisabled();
  276 |   expect(data.writes).toHaveLength(1);
  277 |   data.failReads = false;
  278 |   await page.locator('[data-firmware-action="refresh"]').click();
  279 |   await expect(channelButton(page, "beta", "resume-latest")).toBeEnabled();
  280 |   expect(data.writes).toHaveLength(1);
  281 | });
  282 | 
  283 | test("mobile firmware controls and confirmation fit the viewport", async ({ page }, info) => {
  284 |   await page.setViewportSize({ width: 390, height: 844 });
  285 |   await mockAdmin(page, "zh");
  286 |   await releaseButton(page, "fw-old", "select").click();
  287 |   await channelButton(page, "stable", "retract").click();
  288 |   await expect(page.locator("#confirmReason")).toBeVisible();
  289 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  290 |   await page.screenshot({ path: info.outputPath("zh-mobile-mock-confirm.png"), fullPage: true });
  291 | });
  292 | 
```