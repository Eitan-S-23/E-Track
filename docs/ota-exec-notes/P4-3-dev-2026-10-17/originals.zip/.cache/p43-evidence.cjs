const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const baseline = 'a96aa03da14a912aaf783d875d6a379846c21289';
const tested = 'cd352c5a7e9e7d1619ec31678c20a017f95a9adc';
const relative = file => path.relative(root, file).replaceAll('\\', '/');
function run(command, args) {
  const result = spawnSync(command, args, { cwd: root, windowsHide: true, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  if (result.status !== 0) throw new Error(`${command}: ${result.stderr}`);
  return result.stdout;
}
function guard(file) {
  const full = path.resolve(root, file);
  const rel = path.relative(root, full);
  if (rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) throw new Error('Outside worktree');
  run(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'preflight', '.', 'preflight', full]);
  return full;
}
const read = file => fs.readFileSync(path.resolve(root, file), 'utf8');
const logs = '.cache/p43/logs';
function diagnostics(name) {
  const content = read(`${logs}/${name}.log`);
  const count = regex => (content.match(regex) || []).length;
  return { sqliteExperimental: count(/ExperimentalWarning:/g), colorWarning: count(/Warning: The 'NO_COLOR'/g),
    npmInstallScriptWarningLines: count(/npm warn install-scripts/g), deprecationWarnings: count(/DeprecationWarning:/g),
    githubWarningAnnotations: count(/##\[warning\]/g), errorLevelEvents: count(/"level":"error"/g),
    nativeUncaughtExceptionLines: count(/uncaught exception;/g), npmAuditSummaries: content.split('\n').filter(line => /\d+ (high severity )?vulnerabilities/.test(line)) };
}
const dependencyScope = {};
for (const component of ['admin', 'worker']) {
  const audit = JSON.parse(read(`${logs}/dependency-audit-${component}-01.log`));
  const lockPath = `app/bluetooth_flutter_Trace/cloudflare/update-service/${component}/package-lock.json`;
  const current = JSON.parse(read(lockPath));
  const old = JSON.parse(run('git', ['show', `${baseline}:${lockPath}`]));
  dependencyScope[component] = { totals: audit.metadata.vulnerabilities,
    packages: Object.values(audit.vulnerabilities).map(value => ({ name: value.name, severity: value.severity,
      nodes: value.nodes.map(node => ({ path: node, version: current.packages[node].version,
        dev: current.packages[node].dev === true,
        unchangedFromBaseline: JSON.stringify(current.packages[node]) === JSON.stringify(old.packages[node]) })) })) };
}
const oldLog = run('tar', ['-xOf', 'docs/ota-exec-notes/P4-2-ci-2026-10-14/run-38591559979.zip',
  'Worker Typecheck and Invariants/7_Run invariant tests.txt']);
const summary = { baseline, testedCommit: tested,
  diagnostics: Object.fromEntries(['worker-host-03', 'ui-mock-03', 'ci-cloudflare-log-01', 'ci-governance-log-01'].map(name => [name, diagnostics(name)])),
  historicalNativeDiagnostics: { archive: 'P4-2-ci-2026-10-14/run-38591559979.zip',
    uncaughtExceptionLines: (oldLog.match(/uncaught exception;/g) || []).length,
    foreignKeyConstraintLines: (oldLog.match(/FOREIGN KEY constraint failed/g) || []).length }, dependencyScope };
process.stdout.write(JSON.stringify(summary, null, 2) + '\n');
if (process.argv[2] !== 'archive') process.exit(0);
const target = guard('docs/ota-exec-notes/P4-3-dev-2026-10-17');
const archivePath = guard(path.join(target, 'originals.zip'));
const inventoryPath = guard(path.join(target, 'inventory.json'));
const listPath = guard('.cache/p43/evidence-files.txt');
if (fs.existsSync(archivePath) || fs.existsSync(inventoryPath) || fs.existsSync(listPath)) throw new Error('Original evidence already exists');
const files = [];
function collect(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) throw new Error('Linked input: ' + file);
    const actual = fs.realpathSync(file);
    if (relative(actual).startsWith('../') || path.isAbsolute(relative(actual))) throw new Error('Escaped input');
    if (entry.isDirectory()) collect(file);
    else if (entry.isFile()) files.push(file);
  }
}
for (const name of fs.readdirSync(path.join(root, logs)).filter(name => name.endsWith('.json'))) {
  const receipt = JSON.parse(read(`${logs}/${name}`));
  if (receipt.exitCode === undefined) continue;
  files.push(path.join(root, logs, name));
  files.push(path.join(root, logs, name.replace(/\.json$/, '.log')));
}
collect(path.join(root, '.cache/p43/ui'));
collect(path.join(root, '.cache/p43/ci'));
for (const name of ['p43-run.cjs', 'p43-audit.cjs', 'p43-evidence.cjs']) files.push(path.join(root, '.cache', name));
files.sort();
const digest = buffer => createHash('sha256').update(buffer).digest('hex');
const entries = files.map(file => { const bytes = fs.readFileSync(file); return { path: relative(file), sizeBytes: bytes.length, sha256: digest(bytes) }; });
fs.mkdirSync(target, { recursive: true });
fs.writeFileSync(listPath, entries.map(entry => entry.path).join('\n') + '\n', { flag: 'wx' });
run('tar', ['-a', '-cf', archivePath, '-T', listPath]);
const listing = run('tar', ['-tf', archivePath]).trim().split(/\r?\n/).sort();
if (JSON.stringify(listing) !== JSON.stringify(entries.map(entry => entry.path).sort())) throw new Error('Archive entry mismatch');
for (const entry of entries) {
  const result = spawnSync('tar', ['-xOf', archivePath, entry.path], { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  if (result.status !== 0 || digest(result.stdout) !== entry.sha256) throw new Error('Archive byte mismatch: ' + entry.path);
}
const archive = fs.readFileSync(archivePath);
fs.writeFileSync(inventoryPath, JSON.stringify({ ...summary, createdAt: new Date().toISOString(),
  nature: 'Implementation development evidence; mock UI, native emulator and host results are not real Access or independent acceptance',
  archive: { path: 'originals.zip', sizeBytes: archive.length, sha256: digest(archive), entries: entries.length }, entries }, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ archive: relative(archivePath), sizeBytes: archive.length, entries: entries.length, sha256: digest(archive), verified: true }) + '\n');
