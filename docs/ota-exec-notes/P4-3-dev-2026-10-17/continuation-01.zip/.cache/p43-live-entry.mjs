import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, '.cache/p43/live-entry-01.json');
const check = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'preflight', '.', 'preflight', output],
  { cwd: root, encoding: 'utf8', windowsHide: true });
if (check.status !== 0) throw new Error('Output preflight failed');
if (fs.existsSync(output)) throw new Error('Refusing to replace an observation');

const targets = [
  ['existing-admin-home', 'https://trace-update-admin-staging.pages.dev/'],
  ['existing-admin-session', 'https://trace-update-admin-staging.pages.dev/api/admin/session'],
  ['existing-admin-firmware', 'https://trace-update-admin-staging.pages.dev/api/admin/firmware/channels?appId=trace&deviceModel=e-track-at32f435'],
  ['existing-isolated-worker-health', 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev/healthz']
];
const observations = [];
for (const [name, url] of targets) {
  const started = new Date().toISOString();
  try {
    const response = await fetch(url, { method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(30000),
      headers: { Accept: name.endsWith('home') ? 'text/html' : 'application/json' } });
    const chunks = []; let size = 0;
    if (response.body) {
      const reader = response.body.getReader();
      while (true) {
        const item = await reader.read();
        if (item.done) break;
        size += item.value.length;
        if (size > 1024 * 1024) { await reader.cancel(); throw new Error('Response exceeds observation bound'); }
        chunks.push(item.value);
      }
    }
    const bytes = Buffer.concat(chunks); const body = bytes.toString('utf8');
    const location = response.headers.get('location');
    const redirect = location ? new URL(location, url) : null;
    let parsed;
    try { parsed = JSON.parse(body); } catch {}
    const safe = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? Object.fromEntries(['ok', 'errorCode', 'requestId', 'service', 'environment', 'role']
        .filter(key => ['string', 'boolean'].includes(typeof parsed[key])).map(key => [key, parsed[key]])) : null;
    observations.push({ name, method: 'GET', url, started, ended: new Date().toISOString(), status: response.status,
      contentType: response.headers.get('content-type'), requestId: response.headers.get('x-request-id'), ray: response.headers.get('cf-ray'),
      redirect: redirect ? { origin: redirect.origin, pathname: redirect.pathname, queryOmitted: !!redirect.search } : null,
      bodySize: bytes.length, bodySha256: createHash('sha256').update(bytes).digest('hex'), safeBody: safe,
      p43MarkerPresent: name.endsWith('home') ? body.includes('runFirmwareChannelAction') : null,
      cookieNames: response.headers.getSetCookie().map(cookie => cookie.slice(0, cookie.indexOf('='))),
      authentication: 'none supplied; not an authenticated exercise' });
  } catch (error) {
    observations.push({ name, method: 'GET', url, started, ended: new Date().toISOString(),
      status: null, errorName: error.name, causeCode: error.cause?.code ?? null,
      authentication: 'none supplied; not an authenticated exercise' });
  }
}
const inputPresence = Object.fromEntries(['CLOUDFLARE_API_TOKEN', 'CLOUDFLARE_ACCOUNT_ID', 'ACCESS_JWT_ISSUER',
  'ACCESS_JWT_AUD', 'ADMIN_OWNER_EMAILS', 'P43_ACCESS_STORAGE_STATE', 'P43_ADMIN_ORIGIN']
  .map(name => [name, !!process.env[name]]));
const report = { capturedAt: new Date().toISOString(), kind: 'READ_ONLY_UNAUTHENTICATED_ENTRY_OBSERVATION',
  inputs: { inheritedEnvironmentPresenceOnly: inputPresence, credentialsRead: false }, observations,
  limits: ['No redirect followed', 'No credential supplied or read', 'No cookie/token/signature persisted',
    'GET only; no deployment/configuration/D1/R2/channel mutation', 'Does not establish approved P4-3 target or live owner session'] };
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
if (observations.some(item => item.status === null)) process.exitCode = 1;
