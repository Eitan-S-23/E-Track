const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const baseline = 'a96aa03da14a912aaf783d875d6a379846c21289';
const mode = process.argv[2];
const continuation = mode === 'inspect-continuation' || mode === 'archive-continuation';
const tested = continuation ? '933b790e69e04ee551ad255398e08f12a1b2a107' : 'cd352c5a7e9e7d1619ec31678c20a017f95a9adc';
const relative = file => path.relative(root, file).replaceAll('\\', '/');
function run(command, args) {
  const result = spawnSync(command, args, { cwd: root, windowsHide: true, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  if (result.status !== 0) throw new Error(`${command}: ${result.stderr}`);
  return result.stdout;
}
function guard(file) {
  const full = path.resolve(root, file);
  const rel = path.relative(root, full);
  if (rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) throw new Error('Outside worktree');
  run(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'preflight', '.', 'preflight', full]);
  return full;
}
const read = file => fs.readFileSync(path.resolve(root, file), 'utf8');
const logs = '.cache/p43/logs';
function diagnostics(name) {
  const content = read(`${logs}/${name}.log`);
  const count = regex => (content.match(regex) || []).length;
  return { sqliteExperimental: count(/ExperimentalWarning:/g), colorWarning: count(/Warning: The 'NO_COLOR'/g),
    npmInstallScriptWarningLines: count(/npm warn install-scripts/g), deprecationWarnings: count(/DeprecationWarning:/g),
    githubWarningAnnotations: count(/##\[warning\]/g), errorLevelEvents: count(/"level":"error"/g),
    nativeUncaughtExceptionLines: count(/uncaught exception;/g), npmAuditSummaries: content.split('\n').filter(line => /\d+ (high severity )?vulnerabilities/.test(line)) };
}
const dependencyScope = {};
for (const component of ['admin', 'worker']) {
  const audit = JSON.parse(read(`${logs}/dependency-audit-${component}-01.log`));
  const lockPath = `app/bluetooth_flutter_Trace/cloudflare/update-service/${component}/package-lock.json`;
  const current = JSON.parse(read(lockPath));
  const old = JSON.parse(run('git', ['show', `${baseline}:${lockPath}`]));
  dependencyScope[component] = { totals: audit.metadata.vulnerabilities,
    packages: Object.values(audit.vulnerabilities).map(value => ({ name: value.name, severity: value.severity,
      nodes: value.nodes.map(node => ({ path: node, version: current.packages[node].version,
        dev: current.packages[node].dev === true,
        unchangedFromBaseline: JSON.stringify(current.packages[node]) === JSON.stringify(old.packages[node]) })) })) };
}
const oldLog = run('tar', ['-xOf', 'docs/ota-exec-notes/P4-2-ci-2026-10-14/run-38591559979.zip',
  'Worker Typecheck and Invariants/7_Run invariant tests.txt']);
let summary = { baseline, testedCommit: tested,
  diagnostics: Object.fromEntries(['worker-host-03', 'ui-mock-03', 'ci-cloudflare-log-01', 'ci-governance-log-01'].map(name => [name, diagnostics(name)])),
  historicalNativeDiagnostics: { archive: 'P4-2-ci-2026-10-14/run-38591559979.zip',
    uncaughtExceptionLines: (oldLog.match(/uncaught exception;/g) || []).length,
    foreignKeyConstraintLines: (oldLog.match(/FOREIGN KEY constraint failed/g) || []).length }, dependencyScope };
let previous;
if (continuation) {
  const priorPath = 'docs/ota-exec-notes/P4-3-dev-2026-10-17/inventory.json';
  previous = JSON.parse(read(priorPath));
  const sha = bytes => createHash('sha256').update(bytes).digest('hex');
  assert.equal(sha(fs.readFileSync(path.join(root, path.dirname(priorPath), previous.archive.path))), previous.archive.sha256);
  const runId = '39018754889';
  const metadata = JSON.parse(read(`${logs}/bundle-fixed-state-02.log`));
  assert.equal(metadata.conclusion, 'success');
  assert.equal(metadata.status, 'completed');
  assert.equal(metadata.event, 'workflow_dispatch');
  assert.equal(metadata.headSha, tested);
  assert.equal(metadata.headBranch, 'dev/p4-3/admin-controls-20261017');
  assert.equal(metadata.jobs.length, 4);
  assert.ok(metadata.jobs.every(job => job.conclusion === 'success'));
  const input = `.cache/p43/ci/artifacts-${runId}/admin-deployment-input-${tested}`;
  assert.equal(read(`${input}/source-commit.txt`).trim(), tested);
  assert.equal(read(`${input}/source-run.txt`).trim(), `${runId}/1`);
  assert.match(read(`${input}/purpose.txt`), /BUILD ONLY\. Not deployed/);
  assert.deepEqual(fs.readdirSync(path.join(root, input)).sort(),
    ['SHA256SUMS', 'bundle-meta.json', 'public', 'purpose.txt', 'source-commit.txt', 'source-run.txt'].sort());
  const fileDigests = read(`${input}/SHA256SUMS`).trim().split(/\r?\n/).map(line => {
    const match = /^([a-f0-9]{64})  (public\/[A-Za-z0-9_./-]+)$/.exec(line);
    assert.ok(match, 'Invalid SHA256SUMS entry');
    const full = path.resolve(root, input, match[2]);
    const rel = path.relative(path.resolve(root, input), full);
    assert.ok(rel !== '..' && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
    const bytes = fs.readFileSync(guard(full));
    assert.equal(sha(bytes), match[1]);
    return { path: match[2], sizeBytes: bytes.length, sha256: match[1] };
  });
  function listPublic(dir) {
    return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
      assert.ok(!entry.isSymbolicLink());
      const full = path.join(dir, entry.name);
      return entry.isDirectory() ? listPublic(full) : [path.relative(path.join(root, input), full).replaceAll('\\', '/')];
    });
  }
  assert.deepEqual(listPublic(path.join(root, input, 'public')).sort(), fileDigests.map(item => item.path).sort());
  assert.deepEqual(fileDigests.map(item => item.path).sort(), ['public/_routes.json', 'public/_worker.js/index.js', 'public/index.html']);
  const sourceHtml = run('git', ['show', `${tested}:app/bluetooth_flutter_Trace/cloudflare/update-service/admin/public/index.html`]);
  assert.equal(read(`${input}/public/index.html`), sourceHtml);
  const routes = JSON.parse(read(`${input}/public/_routes.json`));
  assert.deepEqual(routes.include, ['/api/admin/*']);
  assert.deepEqual(routes.exclude, []);
  const smoke = read(`.cache/p43/ci/artifacts-${runId}/admin-bundle-diagnostics-${runId}-1/native-smoke.log`);
  const smokeCounts = Object.fromEntries(['tests', 'pass', 'fail', 'skipped', 'cancelled'].map(name =>
    [name, Number(smoke.match(new RegExp(`\\b${name} (\\d+)`))?.[1])]));
  assert.deepEqual(smokeCounts, { tests: 3, pass: 3, fail: 0, skipped: 0, cancelled: 0 });
  const withoutColor = text => text.replace(/(?:\u001b|\^\[)\[[0-9;]*m/g, '');
  for (const sample of ['\u001b[2mTests\u001b[22m 259 passed (259)', '^[[2mTests^[[22m 259 passed (259)']) {
    assert.equal(withoutColor(sample), 'Tests 259 passed (259)');
  }
  const ciLog = withoutColor(read(`${logs}/bundle-fixed-log-01.log`));
  const countLines = ciLog.split('\n').filter(line => line.includes('\tRun invariant tests\t') && /\bTests\s/.test(line));
  assert.equal(countLines.length, 1);
  assert.match(countLines[0], /Tests\s+259 passed\s+\(259\)/);
  assert.ok(/12 passed \(/.test(ciLog), 'Missing mock UI test count');
  summary = { baseline, testedCommit: tested, previousInventory: priorPath,
    previousArchiveSha256: previous.archive.sha256, workflowRun: runId, workflowConclusion: metadata.conclusion,
    nativeWorker: { passed: 259, failed: 0, skipped: 0 }, mockUi: { passed: 12, failed: 0, skipped: 0 },
    compiledRouterSmoke: smokeCounts, diagnostics: diagnostics('bundle-fixed-log-01'),
    deploymentInput: { path: input, sourceAndFileDigestsVerified: true, files: fileDigests },
    priorSmokeFailure: { run: '39018015096', passed: 0, failed: 4, skipped: 0, classification: 'HARNESS_CONFIGURATION',
      cause: 'Default Miniflare modulesRoot made the external artifact module name start with ..',
      repair: 'Explicit checked artifact entry directory as modulesRoot' },
    realAdminExercise: 'NOT_RUN: target, approved fixture/mutation scope and live Access owner session unresolved' };
}
process.stdout.write(JSON.stringify(summary, null, 2) + '\n');
if (mode !== 'archive' && mode !== 'archive-continuation') process.exit(0);
const target = guard('docs/ota-exec-notes/P4-3-dev-2026-10-17');
const archiveName = continuation ? 'continuation-01.zip' : 'originals.zip';
const archivePath = guard(path.join(target, archiveName));
const inventoryPath = guard(path.join(target, continuation ? 'continuation-01.inventory.json' : 'inventory.json'));
const listPath = guard(continuation ? '.cache/p43/evidence-continuation-01-files.txt' : '.cache/p43/evidence-files.txt');
if (fs.existsSync(archivePath) || fs.existsSync(inventoryPath) || fs.existsSync(listPath)) throw new Error('Original evidence already exists');
const files = [];
function collect(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) throw new Error('Linked input: ' + file);
    const actual = fs.realpathSync(file);
    if (relative(actual).startsWith('../') || path.isAbsolute(relative(actual))) throw new Error('Escaped input');
    if (entry.isDirectory()) collect(file);
    else if (entry.isFile()) files.push(file);
  }
}
for (const name of fs.readdirSync(path.join(root, logs)).filter(name => name.endsWith('.json'))) {
  const receipt = JSON.parse(read(`${logs}/${name}`));
  if (receipt.exitCode === undefined) continue;
  files.push(path.join(root, logs, name));
  files.push(path.join(root, logs, name.replace(/\.json$/, '.log')));
}
collect(path.join(root, '.cache/p43/ui'));
collect(path.join(root, '.cache/p43/ci'));
for (const name of ['p43-run.cjs', 'p43-audit.cjs', 'p43-evidence.cjs']) files.push(path.join(root, '.cache', name));
if (continuation) {
  files.push(path.join(root, '.cache/p43-live-entry.mjs'), path.join(root, '.cache/p43/live-entry-01.json'));
}
files.sort();
const digest = buffer => createHash('sha256').update(buffer).digest('hex');
const priorDigests = new Map((previous?.entries || []).map(entry => [entry.path, entry.sha256]));
const entries = [...new Set(files)].map(file => { const bytes = fs.readFileSync(file); return { path: relative(file), sizeBytes: bytes.length, sha256: digest(bytes) }; })
  .filter(entry => priorDigests.get(entry.path) !== entry.sha256);
fs.mkdirSync(target, { recursive: true });
fs.writeFileSync(listPath, entries.map(entry => entry.path).join('\n') + '\n', { flag: 'wx' });
run('tar', ['-a', '-cf', archivePath, '-T', listPath]);
const listing = run('tar', ['-tf', archivePath]).trim().split(/\r?\n/).sort();
if (JSON.stringify(listing) !== JSON.stringify(entries.map(entry => entry.path).sort())) throw new Error('Archive entry mismatch');
for (const entry of entries) {
  const result = spawnSync('tar', ['-xOf', archivePath, entry.path], { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  if (result.status !== 0 || digest(result.stdout) !== entry.sha256) throw new Error('Archive byte mismatch: ' + entry.path);
}
const archive = fs.readFileSync(archivePath);
fs.writeFileSync(inventoryPath, JSON.stringify({ ...summary, createdAt: new Date().toISOString(),
  nature: 'Implementation development evidence; mock UI, native emulator and host results are not real Access or independent acceptance',
  archive: { path: archiveName, sizeBytes: archive.length, sha256: digest(archive), entries: entries.length }, entries }, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ archive: relative(archivePath), sizeBytes: archive.length, entries: entries.length, sha256: digest(archive), verified: true }) + '\n');
