---
title: Run a query
---

[Skip to content](#_top)

[API Reference](https://developers.cloudflare.com/api)

[Workers](https://developers.cloudflare.com/api/resources/workers)

[Observability](https://developers.cloudflare.com/api/resources/workers/subresources/observability)

[Telemetry](https://developers.cloudflare.com/api/resources/workers/subresources/observability/subresources/telemetry)

Copy Markdown

Open in **Claude**Open in **ChatGPT**Open in **Cursor**

---

**Copy Markdown****View as Markdown**

# Run a query

POST/accounts/{account\_id}/workers/observability/telemetry/query

Run a temporary or saved query.

##### Security

<details>

<summary>API Email + API Key</summary>



The previous authorization scheme for interacting with the Cloudflare API, used in conjunction with a Global API key.

**Example:**<code>X-Auth-Email: user@example.com</code>

The previous authorization scheme for interacting with the Cloudflare API. When possible, use API tokens instead of Global API keys.

**Example:**<code>X-Auth-Key: 144c9defac04969c7bfad8efaa8ea194</code>

</details>

<details>

<summary>API Token</summary>



The preferred authorization scheme for interacting with the Cloudflare API. <a href="https://developers.cloudflare.com/fundamentals/api/get-started/create-token/">Create a token</a>.

**Example:**<code>Authorization: Bearer Sn3lZJTBX6kkg7OdcBUAxOO963GEIyGQqnFTOFYY</code>

</details>

<details>

<summary>User Service Key</summary>



Used when interacting with the Origin CA certificates API. <a href="https://developers.cloudflare.com/fundamentals/api/get-started/ca-keys/#viewchange-your-origin-ca-keys">View/change your key</a>.

**Example:**<code>X-Auth-User-Service-Key: v1.0-144c9defac04969c7bfad8ef-631a41d003a32d25fe878081ef365c49503f7fada600da935e2851a1c7326084b85cbf6429c4b859de8475731dc92a9c329631e6d59e6c73da7b198497172b4cefe071d90d0f5d2719</code>

</details>

##### Accepted Permissions (at least one required)

`Workers Observability Write`

##### P ath ParametersExpand Collapse

account\_id: string

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%20default%20%3E%20(param)%20account_id%20%3E%20(schema)>)

##### Body ParametersJSONExpand Collapse

queryId: string

Identifier for the query. When parameters are omitted, this ID is used to load a previously saved query’s parameters. When providing parameters inline, pass any identifier (e.g. an ad-hoc ID).

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20queryId%20%3E%20(schema)>)

<details>

<summary>

timeframe: object {from, to }

Timeframe for the query using Unix timestamps in milliseconds. ‘from’ must be earlier than ‘to’. Narrower timeframes produce faster responses and more specific results.

</summary>

from: number

Start timestamp for the query timeframe. Unix timestamp in milliseconds

maximum253402300799999

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20timeframe%20%3E%20(schema)%20%3E%20(property)%20from">Link to this property</a>

to: number

End timestamp for the query timeframe. Unix timestamp in milliseconds

maximum253402300799999

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20timeframe%20%3E%20(schema)%20%3E%20(property)%20to">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20timeframe%20%3E%20(schema)>)

chart: optional boolean

When true, includes time-series data in the response.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20chart%20%3E%20(schema)>)

<details>

<summary>

chartType: optional "timeseries\_and\_aggregate"or "timeseries"or "aggregate"or "distribution"

Controls the SQL shape and response payload for the ‘calculations’ view. Omitted or ‘timeseries\_and\_aggregate’: current behaviour — both the time-series and aggregate queries. ‘timeseries’: time-series only. ‘aggregate’: aggregate only. ‘distribution’: a bucketed 2D histogram (time × value buckets) returned in ‘distribution’ instead of ‘calculations’. ‘distribution’ is not compatible with ‘compare’ — combining them returns a 400.

</summary>

One of the following:

"timeseries\_and\_aggregate"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20chartType%20%3E%20(schema)%20%3E%20(member)%200">Link to this property</a>

"timeseries"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20chartType%20%3E%20(schema)%20%3E%20(member)%201">Link to this property</a>

"aggregate"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20chartType%20%3E%20(schema)%20%3E%20(member)%202">Link to this property</a>

"distribution"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20chartType%20%3E%20(schema)%20%3E%20(member)%203">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20chartType%20%3E%20(schema)>)

compare: optional boolean

When true, includes a comparison dataset from the previous time period of equal length.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20compare%20%3E%20(schema)>)

<details>

<summary>

distributionScale: optional "log"or "linear"

Value-axis bucketing for chartType ‘distribution’. Omitted or ‘log’: geometric buckets, best for heavy-tailed latency. ‘linear’: fixed-width buckets, clearer for narrow or additive ranges. Ignored for other chartTypes. The response echoes the scheme used in distribution.bucketMode.

</summary>

One of the following:

"log"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20distributionScale%20%3E%20(schema)%20%3E%20(member)%200">Link to this property</a>

"linear"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20distributionScale%20%3E%20(schema)%20%3E%20(member)%201">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20distributionScale%20%3E%20(schema)>)

dry: optional boolean

When true, executes the query without persisting the results. Useful for validation or previewing.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20dry%20%3E%20(schema)>)

granularity: optional number

Number of time-series buckets. Only used when view is ‘calculations’. Omit to let the system auto-detect an appropriate granularity.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20granularity%20%3E%20(schema)>)

ignoreSeries: optional boolean

When true, omits time-series data from the response and returns only aggregated values. Reduces response size when series are not needed.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20ignoreSeries%20%3E%20(schema)>)

limit: optional number

Maximum number of events to return when view is ‘events’. Also controls the number of group-by rows when view is ‘calculations’.

maximum2000

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20limit%20%3E%20(schema)>)

offset: optional string

Cursor for pagination in event, trace, invocation, and agent views. Pass the $metadata.id of the last event, the trace cursor, or AgentRun.id to fetch the next page.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20offset%20%3E%20(schema)>)

offsetBy: optional number

Numeric offset for paginating grouped/pattern results (top-N lists). Use together with limit. Not used by cursor-based pagination.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20offsetBy%20%3E%20(schema)>)

offsetDirection: optional string

Pagination direction: ‘next’ for forward, ‘prev’ for backward.

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20offsetDirection%20%3E%20(schema)>)

<details>

<summary>

parameters: optional object {calculations, datasets, filterCombination, 6 more }

Query parameters defining what data to retrieve — filters, calculations, group-bys, and ordering. In practice this should always be provided for ad-hoc queries. Only omit when executing a previously saved query by queryId. Use the keys and values endpoints to discover available fields before building filters.

</summary>

<details>

<summary>

calculations: optional array of object {operator, alias, key, keyType } or object {key, operator, alias, keyType }

Aggregation calculations to compute (e.g. count, avg, p99). Each calculation produces aggregate values and optional time-series data.

</summary>

One of the following:

<details>

<summary>

object {operator, alias, key, keyType }

</summary>

<details>

<summary>

operator: "count"or "COUNT"

Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance.

</summary>

One of the following:

"count"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20operator%20%3E%20(member)%200">Link to this property</a>

"COUNT"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20operator%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20operator">Link to this property</a>

alias: optional string

Custom label for this calculation in the results. Useful for distinguishing multiple calculations.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20alias">Link to this property</a>

key: optional string

Field name to calculate over. Must exist in the data. Verify with the keys endpoint. Required for every operator except <code>count</code>, which aggregates whole rows and may omit it.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

keyType: optional "string"or "number"or "boolean"

Data type of the key. Required when key is provided to ensure correct aggregation.

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

object {key, operator, alias, keyType }

</summary>

key: string

Field name to calculate over. Must exist in the data. Verify with the keys endpoint. Required for every operator except <code>count</code>, which aggregates whole rows and may omit it.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operator: "uniq"or "max"or "min"or 33 more

Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance.

</summary>

One of the following:

"uniq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%200">Link to this property</a>

"max"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%201">Link to this property</a>

"min"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%202">Link to this property</a>

"sum"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%203">Link to this property</a>

"avg"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%204">Link to this property</a>

"median"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%205">Link to this property</a>

"p001"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%206">Link to this property</a>

"p01"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%207">Link to this property</a>

"p05"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%208">Link to this property</a>

"p10"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%209">Link to this property</a>

"p25"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2010">Link to this property</a>

"p75"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2011">Link to this property</a>

"p90"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2012">Link to this property</a>

"p95"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2013">Link to this property</a>

"p99"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2014">Link to this property</a>

"p999"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2015">Link to this property</a>

"stddev"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2016">Link to this property</a>

"variance"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2017">Link to this property</a>

"COUNT\_DISTINCT"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2018">Link to this property</a>

"MAX"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2019">Link to this property</a>

"MIN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2020">Link to this property</a>

"SUM"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2021">Link to this property</a>

"AVG"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2022">Link to this property</a>

"MEDIAN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2023">Link to this property</a>

"P001"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2024">Link to this property</a>

"P01"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2025">Link to this property</a>

"P05"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2026">Link to this property</a>

"P10"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2027">Link to this property</a>

"P25"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2028">Link to this property</a>

"P75"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2029">Link to this property</a>

"P90"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2030">Link to this property</a>

"P95"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2031">Link to this property</a>

"P99"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2032">Link to this property</a>

"P999"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2033">Link to this property</a>

"STDDEV"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2034">Link to this property</a>

"VARIANCE"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2035">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator">Link to this property</a>

alias: optional string

Custom label for this calculation in the results. Useful for distinguishing multiple calculations.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20alias">Link to this property</a>

<details>

<summary>

keyType: optional "string"or "number"or "boolean"

Data type of the key. Required when key is provided to ensure correct aggregation.

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20calculations">Link to this property</a>

datasets: optional array of string

Datasets to query. Leave empty to query all available datasets.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20datasets">Link to this property</a>

<details>

<summary>

filterCombination: optional "and"or "or"or "AND"or "OR"

Logical operator for combining top-level filters: ‘and’ (all must match) or ‘or’ (any must match). Defaults to ‘and’.

</summary>

One of the following:

"and"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filterCombination%20%3E%20(member)%200">Link to this property</a>

"or"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filterCombination%20%3E%20(member)%201">Link to this property</a>

"AND"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filterCombination%20%3E%20(member)%202">Link to this property</a>

"OR"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filterCombination%20%3E%20(member)%203">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filterCombination">Link to this property</a>

<details>

<summary>

filters: optional array of object {filterCombination, filters, kind } or object {key, operation, type, 2 more }

Filters to narrow query results. Use the keys and values endpoints to discover available fields before building filters. Supports nested groups via kind: ‘group’. Maximum nesting depth is 4.

</summary>

One of the following:

<details>

<summary>

object {filterCombination, filters, kind }

</summary>

<details>

<summary>

filterCombination: "and"or "or"or "AND"or "OR"

</summary>

One of the following:

"and"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%200">Link to this property</a>

"or"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%201">Link to this property</a>

"AND"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%202">Link to this property</a>

"OR"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%203">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination">Link to this property</a>

<details>

<summary>

filters: array of object {filterCombination, filters, kind } or object {key, operation, type, 2 more }

</summary>

One of the following:

<details>

<summary>

object {filterCombination, filters, kind }

</summary>

<details>

<summary>

filterCombination: "and"or "or"or "AND"or "OR"

</summary>

One of the following:

"and"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%200">Link to this property</a>

"or"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%201">Link to this property</a>

"AND"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%202">Link to this property</a>

"OR"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%203">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination">Link to this property</a>

filters: array of unknown

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters">Link to this property</a>

kind: "group"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20kind">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

WorkersObservabilityFilterLeaf object {key, operation, type, 2 more }

A filter condition applied to query results. Use the keys and values endpoints to discover available fields and their values before constructing filters.

</summary>

key: string

Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operation: "includes"or "not\_includes"or "starts\_with"or 27 more

Comparison operator. String operators: includes, not\_includes, starts\_with, ends\_with, regex. Existence: exists, is\_null. Set membership: in, not\_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte.

</summary>

One of the following:

"includes"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%200">Link to this property</a>

"not\_includes"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%201">Link to this property</a>

"starts\_with"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%202">Link to this property</a>

"ends\_with"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%203">Link to this property</a>

"regex"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%204">Link to this property</a>

"exists"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%205">Link to this property</a>

"is\_null"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%206">Link to this property</a>

"in"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%207">Link to this property</a>

"not\_in"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%208">Link to this property</a>

"eq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%209">Link to this property</a>

"neq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2010">Link to this property</a>

"gt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2011">Link to this property</a>

"gte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2012">Link to this property</a>

"lt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2013">Link to this property</a>

"lte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2014">Link to this property</a>

"="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2015">Link to this property</a>

"!="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2016">Link to this property</a>

"&gt;"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2017">Link to this property</a>

"&gt;="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2018">Link to this property</a>

"&lt;"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2019">Link to this property</a>

"&lt;="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2020">Link to this property</a>

"INCLUDES"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2021">Link to this property</a>

"DOES\_NOT\_INCLUDE"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2022">Link to this property</a>

"MATCH\_REGEX"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2023">Link to this property</a>

"EXISTS"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2024">Link to this property</a>

"DOES\_NOT\_EXIST"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2025">Link to this property</a>

"IN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2026">Link to this property</a>

"NOT\_IN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2027">Link to this property</a>

"STARTS\_WITH"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2028">Link to this property</a>

"ENDS\_WITH"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2029">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation">Link to this property</a>

<details>

<summary>

type: "string"or "number"or "boolean"

Data type of the filter field. Must match the actual type of the key being filtered.

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type">Link to this property</a>

kind: optional "filter"

Discriminator for leaf filter nodes. Always ‘filter’ when present; may be omitted.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20kind">Link to this property</a>

<details>

<summary>

value: optional stringor numberor boolean

Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds).

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters">Link to this property</a>

kind: "group"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20kind">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

WorkersObservabilityFilterLeaf object {key, operation, type, 2 more }

A filter condition applied to query results. Use the keys and values endpoints to discover available fields and their values before constructing filters.

</summary>

key: string

Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operation: "includes"or "not\_includes"or "starts\_with"or 27 more

Comparison operator. String operators: includes, not\_includes, starts\_with, ends\_with, regex. Existence: exists, is\_null. Set membership: in, not\_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte.

</summary>

One of the following:

"includes"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%200">Link to this property</a>

"not\_includes"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%201">Link to this property</a>

"starts\_with"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%202">Link to this property</a>

"ends\_with"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%203">Link to this property</a>

"regex"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%204">Link to this property</a>

"exists"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%205">Link to this property</a>

"is\_null"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%206">Link to this property</a>

"in"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%207">Link to this property</a>

"not\_in"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%208">Link to this property</a>

"eq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%209">Link to this property</a>

"neq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2010">Link to this property</a>

"gt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2011">Link to this property</a>

"gte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2012">Link to this property</a>

"lt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2013">Link to this property</a>

"lte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2014">Link to this property</a>

"="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2015">Link to this property</a>

"!="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2016">Link to this property</a>

"&gt;"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2017">Link to this property</a>

"&gt;="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2018">Link to this property</a>

"&lt;"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2019">Link to this property</a>

"&lt;="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2020">Link to this property</a>

"INCLUDES"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2021">Link to this property</a>

"DOES\_NOT\_INCLUDE"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2022">Link to this property</a>

"MATCH\_REGEX"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2023">Link to this property</a>

"EXISTS"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2024">Link to this property</a>

"DOES\_NOT\_EXIST"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2025">Link to this property</a>

"IN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2026">Link to this property</a>

"NOT\_IN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2027">Link to this property</a>

"STARTS\_WITH"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2028">Link to this property</a>

"ENDS\_WITH"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2029">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation">Link to this property</a>

<details>

<summary>

type: "string"or "number"or "boolean"

Data type of the filter field. Must match the actual type of the key being filtered.

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type">Link to this property</a>

kind: optional "filter"

Discriminator for leaf filter nodes. Always ‘filter’ when present; may be omitted.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20kind">Link to this property</a>

<details>

<summary>

value: optional stringor numberor boolean

Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds).

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20filters">Link to this property</a>

<details>

<summary>

groupBys: optional array of object {type, value }

Fields to group calculation results by. Only applicable when the query view is ‘calculations’. Produces per-group aggregate values.

</summary>

<details>

<summary>

type: "string"or "number"or "boolean"

Data type of the group-by field.

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type">Link to this property</a>

value: string

Field name to group results by (e.g. $metadata.service, $metadata.statusCode).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20groupBys">Link to this property</a>

<details>

<summary>

havings: optional array of object {key, operation, value }

Post-aggregation filters applied to calculation results. Use to filter groups after aggregation (e.g. only groups where count &gt; 100).

</summary>

key: string

Calculation alias or operator to filter on after aggregation.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operation: "eq"or "neq"or "gt"or 3 more

Numeric comparison operator: eq, neq, gt, gte, lt, lte.

</summary>

One of the following:

"eq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%200">Link to this property</a>

"neq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%201">Link to this property</a>

"gt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%202">Link to this property</a>

"gte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%203">Link to this property</a>

"lt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%204">Link to this property</a>

"lte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%205">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation">Link to this property</a>

value: number

Threshold value to compare the calculation result against.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20havings">Link to this property</a>

limit: optional number

Maximum number of group-by rows to return in calculation results. A value of 10 is a sensible default for most use cases.

maximum2000

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20limit">Link to this property</a>

<details>

<summary>

needle: optional object {value, isRegex, matchCase }

Full-text search expression applied across all event fields. Matches events containing the specified text.

</summary>

<details>

<summary>

value: stringor numberor boolean

The text or pattern to search for.

maxLength1000

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle%20%3E%20(property)%20value">Link to this property</a>

isRegex: optional boolean

When true, treats the value as a regular expression (RE2 syntax).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle%20%3E%20(property)%20isRegex">Link to this property</a>

matchCase: optional boolean

When true, performs a case-sensitive search. Defaults to case-insensitive.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle%20%3E%20(property)%20matchCase">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20needle">Link to this property</a>

<details>

<summary>

orderBy: optional object {value, order }

Ordering for grouped calculation results. Only effective when a group-by is present.

</summary>

value: string

Alias of the calculation to order results by. Must match the alias (or operator) of a calculation in the query.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20orderBy%20%3E%20(property)%20value">Link to this property</a>

<details>

<summary>

order: optional "asc"or "desc"

Sort direction: ‘asc’ for ascending, ‘desc’ for descending.

</summary>

One of the following:

"asc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20orderBy%20%3E%20(property)%20order%20%3E%20(member)%200">Link to this property</a>

"desc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20orderBy%20%3E%20(property)%20order%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20orderBy%20%3E%20(property)%20order">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)%20%3E%20(property)%20orderBy">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20parameters%20%3E%20(schema)>)

<details>

<summary>

view: optional "traces"or "events"or "calculations"or 3 more

Controls the shape of the response. ‘events’: individual log lines matching the query. ‘calculations’: aggregated metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series. ‘invocations’: events grouped by request ID. ‘traces’: distributed trace summaries. ‘agents’: agent-specific trace summaries.

</summary>

One of the following:

"traces"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)%20%3E%20(member)%200">Link to this property</a>

"events"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)%20%3E%20(member)%201">Link to this property</a>

"calculations"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)%20%3E%20(member)%202">Link to this property</a>

"invocations"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)%20%3E%20(member)%203">Link to this property</a>

"requests"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)%20%3E%20(member)%204">Link to this property</a>

"agents"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)%20%3E%20(member)%205">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(params)%200%20%3E%20(param)%20view%20%3E%20(schema)>)

##### ReturnsExpand Collapse

<details>

<summary>

errors: array of object {message }

</summary>

message: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20errors%20%3E%20(items)%20%3E%20(property)%20message">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20errors>)

<details>

<summary>

messages: array of object {message }

</summary>

message: "Successful request"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20messages%20%3E%20(items)%20%3E%20(property)%20message">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20messages>)

<details>

<summary>

result: object {run, statistics, agents, 6 more }

Complete results of a query run. The populated fields depend on the requested view type (events, calculations, invocations, traces, or agents).

</summary>

<details>

<summary>

run: object {id, accountId, dry, 8 more }

Represents a single execution of a query against Workers Observability data, including the query definition, execution status, and performance statistics.

</summary>

id: string

Unique identifier for this query run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20id">Link to this property</a>

accountId: string

Cloudflare account ID that owns this query run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20accountId">Link to this property</a>

dry: boolean

Whether this was a dry run (results not persisted).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20dry">Link to this property</a>

granularity: number

Number of time-series buckets used for the query. Higher values produce more detailed series data.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20granularity">Link to this property</a>

<details>

<summary>

query: object {id, adhoc, created, 6 more }

A saved query definition with its parameters, metadata, and ownership information.

</summary>

id: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20id">Link to this property</a>

adhoc: boolean

If the query wasn’t explcitly saved

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20adhoc">Link to this property</a>

<details>

<summary>

created: stringor string

formatdate-time

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20created%20%3E%20(variant)%200">Link to this property</a>

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20created%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20created">Link to this property</a>

createdBy: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20createdBy">Link to this property</a>

description: string

maxLength1000

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20description">Link to this property</a>

name: string

Query name

maxLength250

minLength1

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20name">Link to this property</a>

<details>

<summary>

parameters: object {calculations, datasets, filterCombination, 6 more }

</summary>

<details>

<summary>

calculations: optional array of object {operator, alias, key, keyType } or object {key, operator, alias, keyType }

Create Calculations to compute as part of the query.

</summary>

One of the following:

<details>

<summary>

object {operator, alias, key, keyType }

</summary>

<details>

<summary>

operator: "count"or "COUNT"

</summary>

One of the following:

"count"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20operator%20%3E%20(member)%200">Link to this property</a>

"COUNT"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20operator%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20operator">Link to this property</a>

alias: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20alias">Link to this property</a>

key: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

keyType: optional "string"or "number"or "boolean"

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20keyType">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

object {key, operator, alias, keyType }

</summary>

key: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operator: "uniq"or "max"or "min"or 33 more

</summary>

One of the following:

"uniq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%200">Link to this property</a>

"max"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%201">Link to this property</a>

"min"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%202">Link to this property</a>

"sum"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%203">Link to this property</a>

"avg"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%204">Link to this property</a>

"median"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%205">Link to this property</a>

"p001"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%206">Link to this property</a>

"p01"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%207">Link to this property</a>

"p05"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%208">Link to this property</a>

"p10"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%209">Link to this property</a>

"p25"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2010">Link to this property</a>

"p75"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2011">Link to this property</a>

"p90"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2012">Link to this property</a>

"p95"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2013">Link to this property</a>

"p99"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2014">Link to this property</a>

"p999"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2015">Link to this property</a>

"stddev"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2016">Link to this property</a>

"variance"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2017">Link to this property</a>

"COUNT\_DISTINCT"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2018">Link to this property</a>

"MAX"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2019">Link to this property</a>

"MIN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2020">Link to this property</a>

"SUM"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2021">Link to this property</a>

"AVG"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2022">Link to this property</a>

"MEDIAN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2023">Link to this property</a>

"P001"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2024">Link to this property</a>

"P01"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2025">Link to this property</a>

"P05"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2026">Link to this property</a>

"P10"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2027">Link to this property</a>

"P25"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2028">Link to this property</a>

"P75"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2029">Link to this property</a>

"P90"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2030">Link to this property</a>

"P95"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2031">Link to this property</a>

"P99"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2032">Link to this property</a>

"P999"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2033">Link to this property</a>

"STDDEV"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2034">Link to this property</a>

"VARIANCE"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator%20%3E%20(member)%2035">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operator">Link to this property</a>

alias: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20alias">Link to this property</a>

<details>

<summary>

keyType: optional "string"or "number"or "boolean"

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20keyType">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20calculations">Link to this property</a>

datasets: optional array of string

Set the Datasets to query. Leave it empty to query all the datasets.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20datasets">Link to this property</a>

<details>

<summary>

filterCombination: optional "and"or "or"or "AND"or "OR"

Set a Flag to describe how to combine the filters on the query.

</summary>

One of the following:

"and"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filterCombination%20%3E%20(member)%200">Link to this property</a>

"or"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filterCombination%20%3E%20(member)%201">Link to this property</a>

"AND"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filterCombination%20%3E%20(member)%202">Link to this property</a>

"OR"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filterCombination%20%3E%20(member)%203">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filterCombination">Link to this property</a>

<details>

<summary>

filters: optional array of object {filterCombination, filters, kind } or object {key, operation, type, 2 more }

Configure the Filters to apply to the query. Supports nested groups via kind: ‘group’.

</summary>

One of the following:

<details>

<summary>

object {filterCombination, filters, kind }

</summary>

<details>

<summary>

filterCombination: "and"or "or"or "AND"or "OR"

</summary>

One of the following:

"and"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%200">Link to this property</a>

"or"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%201">Link to this property</a>

"AND"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%202">Link to this property</a>

"OR"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination%20%3E%20(member)%203">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filterCombination">Link to this property</a>

filters: array of unknown

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20filters">Link to this property</a>

kind: "group"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200%20%3E%20(property)%20kind">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

WorkersObservabilityFilterLeaf object {key, operation, type, 2 more }

A filter condition applied to query results. Use the keys and values endpoints to discover available fields and their values before constructing filters.

</summary>

key: string

Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operation: "includes"or "not\_includes"or "starts\_with"or 27 more

Comparison operator. String operators: includes, not\_includes, starts\_with, ends\_with, regex. Existence: exists, is\_null. Set membership: in, not\_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte.

</summary>

One of the following:

"includes"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%200">Link to this property</a>

"not\_includes"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%201">Link to this property</a>

"starts\_with"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%202">Link to this property</a>

"ends\_with"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%203">Link to this property</a>

"regex"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%204">Link to this property</a>

"exists"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%205">Link to this property</a>

"is\_null"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%206">Link to this property</a>

"in"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%207">Link to this property</a>

"not\_in"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%208">Link to this property</a>

"eq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%209">Link to this property</a>

"neq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2010">Link to this property</a>

"gt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2011">Link to this property</a>

"gte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2012">Link to this property</a>

"lt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2013">Link to this property</a>

"lte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2014">Link to this property</a>

"="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2015">Link to this property</a>

"!="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2016">Link to this property</a>

"&gt;"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2017">Link to this property</a>

"&gt;="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2018">Link to this property</a>

"&lt;"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2019">Link to this property</a>

"&lt;="

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2020">Link to this property</a>

"INCLUDES"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2021">Link to this property</a>

"DOES\_NOT\_INCLUDE"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2022">Link to this property</a>

"MATCH\_REGEX"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2023">Link to this property</a>

"EXISTS"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2024">Link to this property</a>

"DOES\_NOT\_EXIST"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2025">Link to this property</a>

"IN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2026">Link to this property</a>

"NOT\_IN"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2027">Link to this property</a>

"STARTS\_WITH"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2028">Link to this property</a>

"ENDS\_WITH"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation%20%3E%20(member)%2029">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20operation">Link to this property</a>

<details>

<summary>

type: "string"or "number"or "boolean"

Data type of the filter field. Must match the actual type of the key being filtered.

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20type">Link to this property</a>

kind: optional "filter"

Discriminator for leaf filter nodes. Always ‘filter’ when present; may be omitted.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20kind">Link to this property</a>

<details>

<summary>

value: optional stringor numberor boolean

Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds).

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters%20%3E%20(items)%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20filters">Link to this property</a>

<details>

<summary>

groupBys: optional array of object {type, value }

Define how to group the results of the query.

</summary>

<details>

<summary>

type: "string"or "number"or "boolean"

</summary>

One of the following:

"string"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type%20%3E%20(member)%200">Link to this property</a>

"number"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type%20%3E%20(member)%201">Link to this property</a>

"boolean"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type%20%3E%20(member)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20type">Link to this property</a>

value: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20groupBys%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20groupBys">Link to this property</a>

<details>

<summary>

havings: optional array of object {key, operation, value }

Configure the Having clauses that filter on calculations in the query result.

</summary>

key: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

operation: "eq"or "neq"or "gt"or 3 more

</summary>

One of the following:

"eq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%200">Link to this property</a>

"neq"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%201">Link to this property</a>

"gt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%202">Link to this property</a>

"gte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%203">Link to this property</a>

"lt"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%204">Link to this property</a>

"lte"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation%20%3E%20(member)%205">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20operation">Link to this property</a>

value: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20havings">Link to this property</a>

limit: optional number

Set a limit on the number of results / records returned by the query

maximum100

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20limit">Link to this property</a>

<details>

<summary>

needle: optional object {value, isRegex, matchCase }

Define an expression to search using full-text search.

</summary>

value:

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20needle%20%3E%20(property)%20value">Link to this property</a>

isRegex: optional boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20needle%20%3E%20(property)%20isRegex">Link to this property</a>

matchCase: optional boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20needle%20%3E%20(property)%20matchCase">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20needle">Link to this property</a>

<details>

<summary>

orderBy: optional object {value, order }

Configure the order of the results returned by the query.

</summary>

value: string

Configure which Calculation to order the results by.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20orderBy%20%3E%20(property)%20value">Link to this property</a>

<details>

<summary>

order: optional "asc"or "desc"

Set the order of the results

</summary>

One of the following:

"asc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20orderBy%20%3E%20(property)%20order%20%3E%20(member)%200">Link to this property</a>

"desc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20orderBy%20%3E%20(property)%20order%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20orderBy%20%3E%20(property)%20order">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters%20%3E%20(property)%20orderBy">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20parameters">Link to this property</a>

<details>

<summary>

updated: stringor string

formatdate-time

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20updated%20%3E%20(variant)%200">Link to this property</a>

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20updated%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20updated">Link to this property</a>

updatedBy: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query%20%3E%20(property)%20updatedBy">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20query">Link to this property</a>

<details>

<summary>

status: "STARTED"or "COMPLETED"

Current execution status of the query run.

</summary>

One of the following:

"STARTED"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20status%20%3E%20(member)%200">Link to this property</a>

"COMPLETED"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20status%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20status">Link to this property</a>

<details>

<summary>

timeframe: object {from, to }

Time range for the query execution. ‘from’ must be earlier than ‘to’. No fractional milliseconds.

</summary>

from: number

Start timestamp for the query timeframe. Unix timestamp in milliseconds

maximum253402300799999

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20timeframe%20%3E%20(property)%20from">Link to this property</a>

to: number

End timestamp for the query timeframe. Unix timestamp in milliseconds

maximum253402300799999

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20timeframe%20%3E%20(property)%20to">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20timeframe">Link to this property</a>

userId: string

ID of the user who initiated the query run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20userId">Link to this property</a>

created: optional string

ISO-8601 timestamp when the query run was created.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20created">Link to this property</a>

<details>

<summary>

statistics: optional object {bytes\_read, elapsed, rows\_read, abr\_level }

Query performance statistics from the database (does not include network latency).

</summary>

bytes\_read: number

Number of uncompressed bytes read from the table.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20statistics%20%3E%20(property)%20bytes_read">Link to this property</a>

elapsed: number

Time in seconds for the query to run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20statistics%20%3E%20(property)%20elapsed">Link to this property</a>

rows\_read: number

Number of rows scanned from the table.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20statistics%20%3E%20(property)%20rows_read">Link to this property</a>

abr\_level: optional number

The level of Adaptive Bit Rate (ABR) sampling used for the query. If empty the ABR level is 1

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20statistics%20%3E%20(property)%20abr_level">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20statistics">Link to this property</a>

updated: optional string

ISO-8601 timestamp when the query run was last updated.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run%20%3E%20(property)%20updated">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20run">Link to this property</a>

<details>

<summary>

statistics: object {bytes\_read, elapsed, rows\_read, abr\_level }

Query performance statistics from the database. Includes execution time, rows scanned, and bytes read. Does not include network latency.

</summary>

bytes\_read: number

Number of uncompressed bytes read from the table.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20statistics%20%3E%20(property)%20bytes_read">Link to this property</a>

elapsed: number

Time in seconds for the query to run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20statistics%20%3E%20(property)%20elapsed">Link to this property</a>

rows\_read: number

Number of rows scanned from the table.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20statistics%20%3E%20(property)%20rows_read">Link to this property</a>

abr\_level: optional number

The level of Adaptive Bit Rate (ABR) sampling used for the query. If empty the ABR level is 1

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20statistics%20%3E%20(property)%20abr_level">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20statistics">Link to this property</a>

<details>

<summary>

agents: optional array of object {id, errors, models, 13 more }

Agent run summaries. Present when the query view is ‘agents’. Each entry represents one trace containing at least one agent invocation.

</summary>

id: string

Stable pagination cursor for this agent run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20id">Link to this property</a>

errors: array of string

Distinct errors reported by spans in the run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20errors">Link to this property</a>

models: array of string

Distinct models reported by chat spans across the run’s trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20models">Link to this property</a>

providers: array of string

Distinct GenAI providers reported by chat spans in the run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20providers">Link to this property</a>

services: array of string

Worker services represented in the run’s trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20services">Link to this property</a>

spans: number

Number of spans in the run’s trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20spans">Link to this property</a>

<details>

<summary>

status: "completed"or "error"

Observed run status.

</summary>

One of the following:

"completed"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20status%20%3E%20(member)%200">Link to this property</a>

"error"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20status%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20status">Link to this property</a>

traceDurationMs: number

Total trace duration in milliseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20traceDurationMs">Link to this property</a>

traceEndMs: number

End of the run’s trace as a Unix epoch in milliseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20traceEndMs">Link to this property</a>

traceId: string

Trace identifier for this agent run.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20traceId">Link to this property</a>

traceStartMs: number

Start of the run’s trace as a Unix epoch in milliseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20traceStartMs">Link to this property</a>

agentId: optional string

ID from the earliest agent invocation that provides one.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20agentId">Link to this property</a>

agentName: optional string

Name from the earliest agent invocation that provides one.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20agentName">Link to this property</a>

conversationId: optional string

Conversation ID from the earliest invocation that provides one.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20conversationId">Link to this property</a>

inputTokens: optional number

Input tokens summed across chat spans in the run’s trace; informational, not billing data.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20inputTokens">Link to this property</a>

outputTokens: optional number

Output tokens summed across chat spans in the run’s trace; informational, not billing data.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents%20%3E%20(items)%20%3E%20(property)%20outputTokens">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20agents">Link to this property</a>

<details>

<summary>

calculations: optional array of object {aggregates, calculation, series, alias }

Aggregated calculation results. Present when the query view is ‘calculations’. Contains computed metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series data.

</summary>

<details>

<summary>

aggregates: array of object {count, interval, sampleInterval, 2 more }

</summary>

count: number

Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20count">Link to this property</a>

Deprecatedinterval: number

Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20interval">Link to this property</a>

sampleInterval: number

Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker’s head\_sampling\_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr\_level.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20sampleInterval">Link to this property</a>

value: number

Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event’s sample interval

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

<details>

<summary>

groups: optional array of object {key, value }

</summary>

key: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

value: stringor numberor boolean

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20aggregates">Link to this property</a>

calculation: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20calculation">Link to this property</a>

<details>

<summary>

series: array of object {data, time }

</summary>

<details>

<summary>

data: array of object {count, interval, sampleInterval, 4 more }

</summary>

count: number

Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20count">Link to this property</a>

Deprecatedinterval: number

Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20interval">Link to this property</a>

sampleInterval: number

Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker’s head\_sampling\_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr\_level.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20sampleInterval">Link to this property</a>

value: number

Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event’s sample interval

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

firstSeen: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20firstSeen">Link to this property</a>

<details>

<summary>

groups: optional array of object {key, value }

</summary>

key: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

value: stringor numberor boolean

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups">Link to this property</a>

lastSeen: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20lastSeen">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data">Link to this property</a>

time: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20time">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20series">Link to this property</a>

alias: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations%20%3E%20(items)%20%3E%20(property)%20alias">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20calculations">Link to this property</a>

<details>

<summary>

compare: optional array of object {aggregates, calculation, series, alias }

Comparison calculation results from the previous time period. Present when the compare option is enabled. Same structure as calculations.

</summary>

<details>

<summary>

aggregates: array of object {count, interval, sampleInterval, 2 more }

</summary>

count: number

Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20count">Link to this property</a>

Deprecatedinterval: number

Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20interval">Link to this property</a>

sampleInterval: number

Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker’s head\_sampling\_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr\_level.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20sampleInterval">Link to this property</a>

value: number

Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event’s sample interval

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

<details>

<summary>

groups: optional array of object {key, value }

</summary>

key: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

value: stringor numberor boolean

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(items)%20%3E%20(property)%20groups">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20aggregates">Link to this property</a>

calculation: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20calculation">Link to this property</a>

<details>

<summary>

series: array of object {data, time }

</summary>

<details>

<summary>

data: array of object {count, interval, sampleInterval, 4 more }

</summary>

count: number

Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20count">Link to this property</a>

Deprecatedinterval: number

Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20interval">Link to this property</a>

sampleInterval: number

Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker’s head\_sampling\_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr\_level.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20sampleInterval">Link to this property</a>

value: number

Result of the calculation. count, sum, avg, median, and percentiles are weighted by each event’s sample interval

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

firstSeen: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20firstSeen">Link to this property</a>

<details>

<summary>

groups: optional array of object {key, value }

</summary>

key: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

<details>

<summary>

value: stringor numberor boolean

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(property)%20value">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups">Link to this property</a>

lastSeen: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20lastSeen">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data">Link to this property</a>

time: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20time">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20series">Link to this property</a>

alias: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare%20%3E%20(items)%20%3E%20(property)%20alias">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20compare">Link to this property</a>

<details>

<summary>

distribution: optional object {bins, bucketBoundaries, bucketMode, 2 more }

Bucketed 2D histogram of a numeric field over time. Present when chartType is ‘distribution’.

</summary>

bins: array of string

Time-bucket labels (ISO-8601 strings), one per matrix column.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20bins">Link to this property</a>

bucketBoundaries: array of number

Raw bucket edges in the value’s native unit, length buckets.length + 1. Used for the colour scale and percentile mapping.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20bucketBoundaries">Link to this property</a>

<details>

<summary>

bucketMode: "log"or "linear"

Bucketing scheme used to derive the boundaries. ‘log’ produces geometric edges; ‘linear’ produces fixed-width edges.

</summary>

One of the following:

"log"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20bucketMode%20%3E%20(member)%200">Link to this property</a>

"linear"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20bucketMode%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20bucketMode">Link to this property</a>

buckets: array of string

Value-range labels, one per matrix row (e.g. ‘50–100ms’).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20buckets">Link to this property</a>

matrix: array of array of number

Sampling-corrected counts. matrix\[bucketIdx]\[binIdx] is the estimated number of events in value-bucket ‘bucketIdx’ during time-bin ‘binIdx’.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution%20%3E%20(property)%20matrix">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20distribution">Link to this property</a>

<details>

<summary>

events: optional object {count, events, fields, series }

Individual event results. Present when the query view is ‘events’. Contains the matching log lines and their metadata.

</summary>

count: optional number

Total number of events matching the query (may exceed the number returned due to limits).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20count">Link to this property</a>

<details>

<summary>

events: optional array of object {"$metadata", dataset, source, 3 more }

List of individual telemetry events matching the query.

</summary>

<details>

<summary>

"$metadata": object {id, account, cloudService, 33 more }

Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation.

</summary>

id: string

Unique event ID. Use as the cursor value for offset-based pagination.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20id">Link to this property</a>

account: optional string

Cloudflare account identifier.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20account">Link to this property</a>

cloudService: optional string

Cloudflare product that generated this event (e.g. workers, pages).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20cloudService">Link to this property</a>

coldStart: optional number

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20coldStart">Link to this property</a>

cost: optional number

Estimated cost units for this invocation.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20cost">Link to this property</a>

duration: optional number

Span duration in milliseconds.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20duration">Link to this property</a>

endTime: optional number

Span end time as a Unix epoch in milliseconds.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20endTime">Link to this property</a>

endTimeNs: optional string

Span end time as a Unix epoch in nanoseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20endTimeNs">Link to this property</a>

error: optional string

Error message, present when the log represents an error.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20error">Link to this property</a>

errorTemplate: optional string

Templatized version of the error message used for grouping similar errors.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20errorTemplate">Link to this property</a>

eventSize: optional number

Size of the stored telemetry event in bytes.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20eventSize">Link to this property</a>

fingerprint: optional string

Content-based fingerprint used to group similar events.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20fingerprint">Link to this property</a>

level: optional string

Log level (e.g. log, debug, info, warn, error).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20level">Link to this property</a>

message: optional string

Log message text.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20message">Link to this property</a>

messageTemplate: optional string

Templatized version of the log message used for grouping similar messages.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20messageTemplate">Link to this property</a>

metricName: optional string

Metric name when the event represents a metric data point.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20metricName">Link to this property</a>

origin: optional string

Origin of the event (e.g. fetch, scheduled, queue).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20origin">Link to this property</a>

parentSpanId: optional string

Span ID of the parent span in the trace hierarchy.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20parentSpanId">Link to this property</a>

provider: optional string

Infrastructure provider identifier.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20provider">Link to this property</a>

rayId: optional string

Cloudflare Ray ID from the <code>cf-ray</code> header of the request that triggered the invocation.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20rayId">Link to this property</a>

region: optional string

Cloudflare data center / region that handled the request.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20region">Link to this property</a>

requestId: optional string

Cloudflare request ID that ties all logs from a single invocation together.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20requestId">Link to this property</a>

service: optional string

Worker script name that produced this event.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20service">Link to this property</a>

spanId: optional string

Span ID for this individual unit of work within a trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20spanId">Link to this property</a>

spanName: optional string

Human-readable name for this span.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20spanName">Link to this property</a>

stackId: optional string

Stack / deployment identifier.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20stackId">Link to this property</a>

startTime: optional number

Span start time as a Unix epoch in milliseconds.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20startTime">Link to this property</a>

startTimeNs: optional string

Span start time as a Unix epoch in nanoseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20startTimeNs">Link to this property</a>

statusCode: optional number

HTTP response status code returned by the Worker.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20statusCode">Link to this property</a>

timestampNs: optional string

Event time as a Unix epoch in nanoseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20timestampNs">Link to this property</a>

traceDuration: optional number

Total duration of the entire trace in milliseconds.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20traceDuration">Link to this property</a>

traceId: optional string

Distributed trace ID linking spans across services.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20traceId">Link to this property</a>

transactionName: optional string

Logical transaction name for this request.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20transactionName">Link to this property</a>

trigger: optional string

What triggered the invocation (e.g. GET /users, POST /orders, queue message).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20trigger">Link to this property</a>

type: optional string

Event type classifier (e.g. cf-worker-event, cf-worker-log).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20type">Link to this property</a>

url: optional string

Request URL that triggered the Worker invocation.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20url">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24metadata">Link to this property</a>

dataset: string

The dataset this event belongs to (e.g. cloudflare-workers).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20dataset">Link to this property</a>

<details>

<summary>

source: stringor map\[unknown]

Raw log payload. May be a string or a structured object depending on how the log was emitted.

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20source%20%3E%20(variant)%200">Link to this property</a>

map\[unknown]

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20source%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20source">Link to this property</a>

timestamp: number

Event timestamp as a Unix epoch in milliseconds.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20timestamp">Link to this property</a>

"$containers": optional map\[unknown]

Cloudflare Containers event information that enriches your logs for identifying and debugging issues.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24containers">Link to this property</a>

<details>

<summary>

"$workers": optional object {eventType, scriptName, durableObjectId, 10 more } or object {cpuTimeMs, eventType, outcome, 14 more }

Cloudflare Workers event information that enriches your logs for identifying and debugging issues.

</summary>

One of the following:

<details>

<summary>

object {eventType, scriptName, durableObjectId, 10 more }

</summary>

<details>

<summary>

eventType: "fetch"or "scheduled"or "alarm"or 9 more

</summary>

One of the following:

"fetch"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%200">Link to this property</a>

"scheduled"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%201">Link to this property</a>

"alarm"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%202">Link to this property</a>

"cron"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%203">Link to this property</a>

"queue"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%204">Link to this property</a>

"email"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%205">Link to this property</a>

"tail"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%206">Link to this property</a>

"rpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%207">Link to this property</a>

"jsrpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%208">Link to this property</a>

"websocket"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%209">Link to this property</a>

"workflow"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%2010">Link to this property</a>

"unknown"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%2011">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType">Link to this property</a>

scriptName: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptName">Link to this property</a>

durableObjectId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20durableObjectId">Link to this property</a>

entrypoint: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20entrypoint">Link to this property</a>

event: optional map\[unknown]

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20event">Link to this property</a>

<details>

<summary>

executionModel: optional "durableObject"or "stateless"

</summary>

One of the following:

"durableObject"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20executionModel%20%3E%20(member)%200">Link to this property</a>

"stateless"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20executionModel%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20executionModel">Link to this property</a>

outcome: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20outcome">Link to this property</a>

<details>

<summary>

preview: optional object {id, name, slug }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview%20%3E%20(property)%20id">Link to this property</a>

name: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview%20%3E%20(property)%20name">Link to this property</a>

slug: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview%20%3E%20(property)%20slug">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview">Link to this property</a>

requestId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20requestId">Link to this property</a>

<details>

<summary>

scriptVersion: optional object {id, message, tag }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20id">Link to this property</a>

message: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20message">Link to this property</a>

tag: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20tag">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion">Link to this property</a>

spanId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20spanId">Link to this property</a>

traceId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20traceId">Link to this property</a>

truncated: optional boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20truncated">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

object {cpuTimeMs, eventType, outcome, 14 more }

</summary>

cpuTimeMs: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20cpuTimeMs">Link to this property</a>

<details>

<summary>

eventType: "fetch"or "scheduled"or "alarm"or 9 more

</summary>

One of the following:

"fetch"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%200">Link to this property</a>

"scheduled"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%201">Link to this property</a>

"alarm"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%202">Link to this property</a>

"cron"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%203">Link to this property</a>

"queue"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%204">Link to this property</a>

"email"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%205">Link to this property</a>

"tail"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%206">Link to this property</a>

"rpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%207">Link to this property</a>

"jsrpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%208">Link to this property</a>

"websocket"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%209">Link to this property</a>

"workflow"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%2010">Link to this property</a>

"unknown"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%2011">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType">Link to this property</a>

outcome: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20outcome">Link to this property</a>

scriptName: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptName">Link to this property</a>

wallTimeMs: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20wallTimeMs">Link to this property</a>

<details>

<summary>

diagnosticsChannelEvents: optional array of object {channel, message, timestamp }

</summary>

channel: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents%20%3E%20(items)%20%3E%20(property)%20channel">Link to this property</a>

message: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents%20%3E%20(items)%20%3E%20(property)%20message">Link to this property</a>

timestamp: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents%20%3E%20(items)%20%3E%20(property)%20timestamp">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents">Link to this property</a>

dispatchNamespace: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20dispatchNamespace">Link to this property</a>

durableObjectId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20durableObjectId">Link to this property</a>

entrypoint: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20entrypoint">Link to this property</a>

event: optional map\[unknown]

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20event">Link to this property</a>

<details>

<summary>

executionModel: optional "durableObject"or "stateless"

</summary>

One of the following:

"durableObject"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20executionModel%20%3E%20(member)%200">Link to this property</a>

"stateless"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20executionModel%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20executionModel">Link to this property</a>

<details>

<summary>

preview: optional object {id, name, slug }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview%20%3E%20(property)%20id">Link to this property</a>

name: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview%20%3E%20(property)%20name">Link to this property</a>

slug: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview%20%3E%20(property)%20slug">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview">Link to this property</a>

requestId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20requestId">Link to this property</a>

<details>

<summary>

scriptVersion: optional object {id, message, tag }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20id">Link to this property</a>

message: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20message">Link to this property</a>

tag: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20tag">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion">Link to this property</a>

spanId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20spanId">Link to this property</a>

traceId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20traceId">Link to this property</a>

truncated: optional boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20truncated">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events%20%3E%20(items)%20%3E%20(property)%20%24workers">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20events">Link to this property</a>

<details>

<summary>

fields: optional array of object {key, type }

List of fields discovered in the matched events. Useful for building dynamic UIs.

</summary>

key: string

Field name present in the matched events.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20fields%20%3E%20(items)%20%3E%20(property)%20key">Link to this property</a>

type: string

Data type of the field (string, number, or boolean).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20fields%20%3E%20(items)%20%3E%20(property)%20type">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20fields">Link to this property</a>

<details>

<summary>

series: optional array of object {data, time }

Time-series data for the matched events, bucketed by the query granularity.

</summary>

<details>

<summary>

data: array of object {aggregates, count, interval, 3 more }

</summary>

<details>

<summary>

aggregates: object {\_count, \_interval, \_firstSeen, 2 more }

</summary>

Deprecated\_count: number

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(property)%20_count">Link to this property</a>

Deprecated\_interval: number

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(property)%20_interval">Link to this property</a>

Deprecated\_firstSeen: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(property)%20_firstSeen">Link to this property</a>

Deprecated\_lastSeen: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(property)%20_lastSeen">Link to this property</a>

Deprecatedbin: optional unknown

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20aggregates%20%3E%20(property)%20bin">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20aggregates">Link to this property</a>

count: number

Estimated number of matching events: the sum of the sample intervals of the stored events. It equals the number of stored events when sampleInterval is 1.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20count">Link to this property</a>

Deprecatedinterval: number

Deprecated alias of sampleInterval. Always has the same value; use sampleInterval instead.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20interval">Link to this property</a>

sampleInterval: number

Average sample interval of the matched events. Each stored event has a sample interval of 1 / (the sampling rate applied when it was ingested): the Worker’s head\_sampling\_rate multiplied by any platform sampling applied to the account or script. A value of 1 means none of the matched events were sampled. A value above 1 means count and value are estimated from sampled data, not exact. This is independent of statistics.abr\_level.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20sampleInterval">Link to this property</a>

errors: optional number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20errors">Link to this property</a>

<details>

<summary>

groups: optional map\[stringor numberor boolean]

Groups in the query results.

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(variant)%200">Link to this property</a>

number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(variant)%201">Link to this property</a>

boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups%20%3E%20(items)%20%3E%20(variant)%202">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data%20%3E%20(items)%20%3E%20(property)%20groups">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20data">Link to this property</a>

time: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series%20%3E%20(items)%20%3E%20(property)%20time">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events%20%3E%20(property)%20series">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20events">Link to this property</a>

<details>

<summary>

invocations: optional map\[array of object {"$metadata", dataset, source, 3 more } ]

Events grouped by invocation (request ID). Present when the query view is ‘invocations’. Each key is a request ID mapping to all events from that invocation.

</summary>

<details>

<summary>

"$metadata": object {id, account, cloudService, 33 more }

Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation.

</summary>

id: string

Unique event ID. Use as the cursor value for offset-based pagination.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20id">Link to this property</a>

account: optional string

Cloudflare account identifier.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20account">Link to this property</a>

cloudService: optional string

Cloudflare product that generated this event (e.g. workers, pages).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20cloudService">Link to this property</a>

coldStart: optional number

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20coldStart">Link to this property</a>

cost: optional number

Estimated cost units for this invocation.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20cost">Link to this property</a>

duration: optional number

Span duration in milliseconds.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20duration">Link to this property</a>

endTime: optional number

Span end time as a Unix epoch in milliseconds.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20endTime">Link to this property</a>

endTimeNs: optional string

Span end time as a Unix epoch in nanoseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20endTimeNs">Link to this property</a>

error: optional string

Error message, present when the log represents an error.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20error">Link to this property</a>

errorTemplate: optional string

Templatized version of the error message used for grouping similar errors.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20errorTemplate">Link to this property</a>

eventSize: optional number

Size of the stored telemetry event in bytes.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20eventSize">Link to this property</a>

fingerprint: optional string

Content-based fingerprint used to group similar events.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20fingerprint">Link to this property</a>

level: optional string

Log level (e.g. log, debug, info, warn, error).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20level">Link to this property</a>

message: optional string

Log message text.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20message">Link to this property</a>

messageTemplate: optional string

Templatized version of the log message used for grouping similar messages.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20messageTemplate">Link to this property</a>

metricName: optional string

Metric name when the event represents a metric data point.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20metricName">Link to this property</a>

origin: optional string

Origin of the event (e.g. fetch, scheduled, queue).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20origin">Link to this property</a>

parentSpanId: optional string

Span ID of the parent span in the trace hierarchy.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20parentSpanId">Link to this property</a>

provider: optional string

Infrastructure provider identifier.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20provider">Link to this property</a>

rayId: optional string

Cloudflare Ray ID from the <code>cf-ray</code> header of the request that triggered the invocation.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20rayId">Link to this property</a>

region: optional string

Cloudflare data center / region that handled the request.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20region">Link to this property</a>

requestId: optional string

Cloudflare request ID that ties all logs from a single invocation together.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20requestId">Link to this property</a>

service: optional string

Worker script name that produced this event.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20service">Link to this property</a>

spanId: optional string

Span ID for this individual unit of work within a trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20spanId">Link to this property</a>

spanName: optional string

Human-readable name for this span.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20spanName">Link to this property</a>

stackId: optional string

Stack / deployment identifier.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20stackId">Link to this property</a>

startTime: optional number

Span start time as a Unix epoch in milliseconds.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20startTime">Link to this property</a>

startTimeNs: optional string

Span start time as a Unix epoch in nanoseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20startTimeNs">Link to this property</a>

statusCode: optional number

HTTP response status code returned by the Worker.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20statusCode">Link to this property</a>

timestampNs: optional string

Event time as a Unix epoch in nanoseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20timestampNs">Link to this property</a>

traceDuration: optional number

Total duration of the entire trace in milliseconds.

exclusiveMinimum

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20traceDuration">Link to this property</a>

traceId: optional string

Distributed trace ID linking spans across services.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20traceId">Link to this property</a>

transactionName: optional string

Logical transaction name for this request.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20transactionName">Link to this property</a>

trigger: optional string

What triggered the invocation (e.g. GET /users, POST /orders, queue message).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20trigger">Link to this property</a>

type: optional string

Event type classifier (e.g. cf-worker-event, cf-worker-log).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20type">Link to this property</a>

url: optional string

Request URL that triggered the Worker invocation.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata%20%3E%20(property)%20url">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24metadata">Link to this property</a>

dataset: string

The dataset this event belongs to (e.g. cloudflare-workers).

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20dataset">Link to this property</a>

<details>

<summary>

source: stringor map\[unknown]

Raw log payload. May be a string or a structured object depending on how the log was emitted.

</summary>

One of the following:

string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20source%20%3E%20(variant)%200">Link to this property</a>

map\[unknown]

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20source%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20source">Link to this property</a>

timestamp: number

Event timestamp as a Unix epoch in milliseconds.

minimum0

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20timestamp">Link to this property</a>

"$containers": optional map\[unknown]

Cloudflare Containers event information that enriches your logs for identifying and debugging issues.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24containers">Link to this property</a>

<details>

<summary>

"$workers": optional object {eventType, scriptName, durableObjectId, 10 more } or object {cpuTimeMs, eventType, outcome, 14 more }

Cloudflare Workers event information that enriches your logs for identifying and debugging issues.

</summary>

One of the following:

<details>

<summary>

object {eventType, scriptName, durableObjectId, 10 more }

</summary>

<details>

<summary>

eventType: "fetch"or "scheduled"or "alarm"or 9 more

</summary>

One of the following:

"fetch"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%200">Link to this property</a>

"scheduled"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%201">Link to this property</a>

"alarm"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%202">Link to this property</a>

"cron"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%203">Link to this property</a>

"queue"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%204">Link to this property</a>

"email"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%205">Link to this property</a>

"tail"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%206">Link to this property</a>

"rpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%207">Link to this property</a>

"jsrpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%208">Link to this property</a>

"websocket"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%209">Link to this property</a>

"workflow"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%2010">Link to this property</a>

"unknown"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType%20%3E%20(member)%2011">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20eventType">Link to this property</a>

scriptName: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptName">Link to this property</a>

durableObjectId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20durableObjectId">Link to this property</a>

entrypoint: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20entrypoint">Link to this property</a>

event: optional map\[unknown]

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20event">Link to this property</a>

<details>

<summary>

executionModel: optional "durableObject"or "stateless"

</summary>

One of the following:

"durableObject"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20executionModel%20%3E%20(member)%200">Link to this property</a>

"stateless"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20executionModel%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20executionModel">Link to this property</a>

outcome: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20outcome">Link to this property</a>

<details>

<summary>

preview: optional object {id, name, slug }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview%20%3E%20(property)%20id">Link to this property</a>

name: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview%20%3E%20(property)%20name">Link to this property</a>

slug: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview%20%3E%20(property)%20slug">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20preview">Link to this property</a>

requestId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20requestId">Link to this property</a>

<details>

<summary>

scriptVersion: optional object {id, message, tag }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20id">Link to this property</a>

message: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20message">Link to this property</a>

tag: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20tag">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20scriptVersion">Link to this property</a>

spanId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20spanId">Link to this property</a>

traceId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20traceId">Link to this property</a>

truncated: optional boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200%20%3E%20(property)%20truncated">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%200">Link to this property</a>

<details>

<summary>

object {cpuTimeMs, eventType, outcome, 14 more }

</summary>

cpuTimeMs: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20cpuTimeMs">Link to this property</a>

<details>

<summary>

eventType: "fetch"or "scheduled"or "alarm"or 9 more

</summary>

One of the following:

"fetch"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%200">Link to this property</a>

"scheduled"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%201">Link to this property</a>

"alarm"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%202">Link to this property</a>

"cron"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%203">Link to this property</a>

"queue"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%204">Link to this property</a>

"email"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%205">Link to this property</a>

"tail"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%206">Link to this property</a>

"rpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%207">Link to this property</a>

"jsrpc"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%208">Link to this property</a>

"websocket"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%209">Link to this property</a>

"workflow"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%2010">Link to this property</a>

"unknown"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType%20%3E%20(member)%2011">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20eventType">Link to this property</a>

outcome: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20outcome">Link to this property</a>

scriptName: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptName">Link to this property</a>

wallTimeMs: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20wallTimeMs">Link to this property</a>

<details>

<summary>

diagnosticsChannelEvents: optional array of object {channel, message, timestamp }

</summary>

channel: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents%20%3E%20(items)%20%3E%20(property)%20channel">Link to this property</a>

message: string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents%20%3E%20(items)%20%3E%20(property)%20message">Link to this property</a>

timestamp: number

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents%20%3E%20(items)%20%3E%20(property)%20timestamp">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20diagnosticsChannelEvents">Link to this property</a>

dispatchNamespace: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20dispatchNamespace">Link to this property</a>

durableObjectId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20durableObjectId">Link to this property</a>

entrypoint: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20entrypoint">Link to this property</a>

event: optional map\[unknown]

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20event">Link to this property</a>

<details>

<summary>

executionModel: optional "durableObject"or "stateless"

</summary>

One of the following:

"durableObject"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20executionModel%20%3E%20(member)%200">Link to this property</a>

"stateless"

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20executionModel%20%3E%20(member)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20executionModel">Link to this property</a>

<details>

<summary>

preview: optional object {id, name, slug }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview%20%3E%20(property)%20id">Link to this property</a>

name: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview%20%3E%20(property)%20name">Link to this property</a>

slug: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview%20%3E%20(property)%20slug">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20preview">Link to this property</a>

requestId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20requestId">Link to this property</a>

<details>

<summary>

scriptVersion: optional object {id, message, tag }

</summary>

id: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20id">Link to this property</a>

message: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20message">Link to this property</a>

tag: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion%20%3E%20(property)%20tag">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20scriptVersion">Link to this property</a>

spanId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20spanId">Link to this property</a>

traceId: optional string

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20traceId">Link to this property</a>

truncated: optional boolean

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201%20%3E%20(property)%20truncated">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers%20%3E%20(variant)%201">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations%20%3E%20(items)%20%3E%20(items)%20%3E%20(property)%20%24workers">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20invocations">Link to this property</a>

<details>

<summary>

traces: optional array of object {rootSpanName, rootTransactionName, service, 6 more }

Trace summaries matching the query. Present when the query view is ‘traces’. Each entry represents a distributed trace with its spans, duration, and services involved.

</summary>

rootSpanName: string

Name of the root span that initiated the trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20rootSpanName">Link to this property</a>

rootTransactionName: string

Logical transaction name for the root span.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20rootTransactionName">Link to this property</a>

service: array of string

List of Worker services involved in the trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20service">Link to this property</a>

spans: number

Total number of spans in the trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20spans">Link to this property</a>

traceDurationMs: number

Total duration of the trace in milliseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20traceDurationMs">Link to this property</a>

traceEndMs: number

Trace end time as a Unix epoch in milliseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20traceEndMs">Link to this property</a>

traceId: string

Unique identifier for the distributed trace.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20traceId">Link to this property</a>

traceStartMs: number

Trace start time as a Unix epoch in milliseconds.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20traceStartMs">Link to this property</a>

errors: optional array of string

Error messages encountered during the trace, if any.

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces%20%3E%20(items)%20%3E%20(property)%20errors">Link to this property</a>

</details>

<a href="#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result%20%2B%20(resource)%20workers.observability.telemetry%20%3E%20(model)%20telemetry_query_response%20%3E%20(schema)%20%3E%20(property)%20traces">Link to this property</a>

</details>

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20result>)

success: true

[Link to this property](<#(resource)%20workers.observability.telemetry%20%3E%20(method)%20query%20%3E%20(network%20schema)%20%3E%20(property)%20success>)

### Run a query

HTTP

HTTPTypeScriptPythonGoTerraform

```
curl https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/workers/observability/telemetry/query \
    -H 'Content-Type: application/json' \
    -H "X-Auth-Email: $CLOUDFLARE_EMAIL" \
    -H "X-Auth-Key: $CLOUDFLARE_API_KEY" \
    -d '{
          "queryId": "queryId",
          "timeframe": {
            "from": 0,
            "to": 0
          }
        }'
```

200 example

```
{
  "errors": [
    {
      "message": "message"
    }
  ],
  "messages": [
    {
      "message": "Successful request"
    }
  ],
  "result": {
    "run": {
      "id": "id",
      "accountId": "accountId",
      "dry": true,
      "granularity": 0,
      "query": {
        "id": "id",
        "adhoc": true,
        "created": "string",
        "createdBy": "createdBy",
        "description": "Query description",
        "name": "x",
        "parameters": {
          "calculations": [
            {
              "operator": "count",
              "alias": "alias",
              "key": "key",
              "keyType": "string"
            }
          ],
          "datasets": [
            "string"
          ],
          "filterCombination": "and",
          "filters": [
            {
              "filterCombination": "and",
              "filters": [
                {}
              ],
              "kind": "group"
            }
          ],
          "groupBys": [
            {
              "type": "string",
              "value": "value"
            }
          ],
          "havings": [
            {
              "key": "key",
              "operation": "eq",
              "value": 0
            }
          ],
          "limit": 0,
          "needle": {
            "value": {
              "0": "s",
              "1": "t",
              "2": "r",
              "3": "i",
              "4": "n",
              "5": "g"
            },
            "isRegex": true,
            "matchCase": true
          },
          "orderBy": {
            "value": "value",
            "order": "asc"
          }
        },
        "updated": "string",
        "updatedBy": "updatedBy"
      },
      "status": "STARTED",
      "timeframe": {
        "from": 0,
        "to": 0
      },
      "userId": "userId",
      "created": "created",
      "statistics": {
        "bytes_read": 0,
        "elapsed": 0,
        "rows_read": 0,
        "abr_level": 0
      },
      "updated": "updated"
    },
    "statistics": {
      "bytes_read": 0,
      "elapsed": 0,
      "rows_read": 0,
      "abr_level": 0
    },
    "agents": [
      {
        "id": "id",
        "errors": [
          "string"
        ],
        "models": [
          "string"
        ],
        "providers": [
          "string"
        ],
        "services": [
          "string"
        ],
        "spans": 0,
        "status": "completed",
        "traceDurationMs": 0,
        "traceEndMs": 0,
        "traceId": "traceId",
        "traceStartMs": 0,
        "agentId": "agentId",
        "agentName": "agentName",
        "conversationId": "conversationId",
        "inputTokens": 0,
        "outputTokens": 0
      }
    ],
    "calculations": [
      {
        "aggregates": [
          {
            "count": 0,
            "interval": 0,
            "sampleInterval": 0,
            "value": 0,
            "groups": [
              {
                "key": "key",
                "value": "string"
              }
            ]
          }
        ],
        "calculation": "calculation",
        "series": [
          {
            "data": [
              {
                "count": 0,
                "interval": 0,
                "sampleInterval": 0,
                "value": 0,
                "firstSeen": "firstSeen",
                "groups": [
                  {
                    "key": "key",
                    "value": "string"
                  }
                ],
                "lastSeen": "lastSeen"
              }
            ],
            "time": "time"
          }
        ],
        "alias": "alias"
      }
    ],
    "compare": [
      {
        "aggregates": [
          {
            "count": 0,
            "interval": 0,
            "sampleInterval": 0,
            "value": 0,
            "groups": [
              {
                "key": "key",
                "value": "string"
              }
            ]
          }
        ],
        "calculation": "calculation",
        "series": [
          {
            "data": [
              {
                "count": 0,
                "interval": 0,
                "sampleInterval": 0,
                "value": 0,
                "firstSeen": "firstSeen",
                "groups": [
                  {
                    "key": "key",
                    "value": "string"
                  }
                ],
                "lastSeen": "lastSeen"
              }
            ],
            "time": "time"
          }
        ],
        "alias": "alias"
      }
    ],
    "distribution": {
      "bins": [
        "string"
      ],
      "bucketBoundaries": [
        0
      ],
      "bucketMode": "log",
      "buckets": [
        "string"
      ],
      "matrix": [
        [
          0
        ]
      ]
    },
    "events": {
      "count": 0,
      "events": [
        {
          "$metadata": {
            "id": "id",
            "account": "account",
            "cloudService": "cloudService",
            "coldStart": 1,
            "cost": 1,
            "duration": 1,
            "endTime": 0,
            "endTimeNs": "endTimeNs",
            "error": "error",
            "errorTemplate": "errorTemplate",
            "eventSize": 0,
            "fingerprint": "fingerprint",
            "level": "level",
            "message": "message",
            "messageTemplate": "messageTemplate",
            "metricName": "metricName",
            "origin": "origin",
            "parentSpanId": "parentSpanId",
            "provider": "provider",
            "rayId": "rayId",
            "region": "region",
            "requestId": "requestId",
            "service": "service",
            "spanId": "spanId",
            "spanName": "spanName",
            "stackId": "stackId",
            "startTime": 0,
            "startTimeNs": "startTimeNs",
            "statusCode": 1,
            "timestampNs": "timestampNs",
            "traceDuration": 1,
            "traceId": "traceId",
            "transactionName": "transactionName",
            "trigger": "trigger",
            "type": "type",
            "url": "url"
          },
          "dataset": "dataset",
          "source": "string",
          "timestamp": 0,
          "$containers": {
            "foo": "bar"
          },
          "$workers": {
            "eventType": "fetch",
            "scriptName": "scriptName",
            "durableObjectId": "durableObjectId",
            "entrypoint": "entrypoint",
            "event": {
              "foo": "bar"
            },
            "executionModel": "durableObject",
            "outcome": "outcome",
            "preview": {
              "id": "id",
              "name": "name",
              "slug": "slug"
            },
            "requestId": "requestId",
            "scriptVersion": {
              "id": "id",
              "message": "message",
              "tag": "tag"
            },
            "spanId": "spanId",
            "traceId": "traceId",
            "truncated": true
          }
        }
      ],
      "fields": [
        {
          "key": "key",
          "type": "type"
        }
      ],
      "series": [
        {
          "data": [
            {
              "aggregates": {
                "_count": 1,
                "_interval": 1,
                "_firstSeen": "_firstSeen",
                "_lastSeen": "_lastSeen",
                "bin": {}
              },
              "count": 0,
              "interval": 0,
              "sampleInterval": 0,
              "errors": 0,
              "groups": {
                "foo": "string"
              }
            }
          ],
          "time": "time"
        }
      ]
    },
    "invocations": {
      "foo": [
        {
          "$metadata": {
            "id": "id",
            "account": "account",
            "cloudService": "cloudService",
            "coldStart": 1,
            "cost": 1,
            "duration": 1,
            "endTime": 0,
            "endTimeNs": "endTimeNs",
            "error": "error",
            "errorTemplate": "errorTemplate",
            "eventSize": 0,
            "fingerprint": "fingerprint",
            "level": "level",
            "message": "message",
            "messageTemplate": "messageTemplate",
            "metricName": "metricName",
            "origin": "origin",
            "parentSpanId": "parentSpanId",
            "provider": "provider",
            "rayId": "rayId",
            "region": "region",
            "requestId": "requestId",
            "service": "service",
            "spanId": "spanId",
            "spanName": "spanName",
            "stackId": "stackId",
            "startTime": 0,
            "startTimeNs": "startTimeNs",
            "statusCode": 1,
            "timestampNs": "timestampNs",
            "traceDuration": 1,
            "traceId": "traceId",
            "transactionName": "transactionName",
            "trigger": "trigger",
            "type": "type",
            "url": "url"
          },
          "dataset": "dataset",
          "source": "string",
          "timestamp": 0,
          "$containers": {
            "foo": "bar"
          },
          "$workers": {
            "eventType": "fetch",
            "scriptName": "scriptName",
            "durableObjectId": "durableObjectId",
            "entrypoint": "entrypoint",
            "event": {
              "foo": "bar"
            },
            "executionModel": "durableObject",
            "outcome": "outcome",
            "preview": {
              "id": "id",
              "name": "name",
              "slug": "slug"
            },
            "requestId": "requestId",
            "scriptVersion": {
              "id": "id",
              "message": "message",
              "tag": "tag"
            },
            "spanId": "spanId",
            "traceId": "traceId",
            "truncated": true
          }
        }
      ]
    },
    "traces": [
      {
        "rootSpanName": "rootSpanName",
        "rootTransactionName": "rootTransactionName",
        "service": [
          "string"
        ],
        "spans": 0,
        "traceDurationMs": 0,
        "traceEndMs": 0,
        "traceId": "traceId",
        "traceStartMs": 0,
        "errors": [
          "string"
        ]
      }
    ]
  },
  "success": true
}
```

##### Returns Examples

200 example

```
{
  "errors": [
    {
      "message": "message"
    }
  ],
  "messages": [
    {
      "message": "Successful request"
    }
  ],
  "result": {
    "run": {
      "id": "id",
      "accountId": "accountId",
      "dry": true,
      "granularity": 0,
      "query": {
        "id": "id",
        "adhoc": true,
        "created": "string",
        "createdBy": "createdBy",
        "description": "Query description",
        "name": "x",
        "parameters": {
          "calculations": [
            {
              "operator": "count",
              "alias": "alias",
              "key": "key",
              "keyType": "string"
            }
          ],
          "datasets": [
            "string"
          ],
          "filterCombination": "and",
          "filters": [
            {
              "filterCombination": "and",
              "filters": [
                {}
              ],
              "kind": "group"
            }
          ],
          "groupBys": [
            {
              "type": "string",
              "value": "value"
            }
          ],
          "havings": [
            {
              "key": "key",
              "operation": "eq",
              "value": 0
            }
          ],
          "limit": 0,
          "needle": {
            "value": {
              "0": "s",
              "1": "t",
              "2": "r",
              "3": "i",
              "4": "n",
              "5": "g"
            },
            "isRegex": true,
            "matchCase": true
          },
          "orderBy": {
            "value": "value",
            "order": "asc"
          }
        },
        "updated": "string",
        "updatedBy": "updatedBy"
      },
      "status": "STARTED",
      "timeframe": {
        "from": 0,
        "to": 0
      },
      "userId": "userId",
      "created": "created",
      "statistics": {
        "bytes_read": 0,
        "elapsed": 0,
        "rows_read": 0,
        "abr_level": 0
      },
      "updated": "updated"
    },
    "statistics": {
      "bytes_read": 0,
      "elapsed": 0,
      "rows_read": 0,
      "abr_level": 0
    },
    "agents": [
      {
        "id": "id",
        "errors": [
          "string"
        ],
        "models": [
          "string"
        ],
        "providers": [
          "string"
        ],
        "services": [
          "string"
        ],
        "spans": 0,
        "status": "completed",
        "traceDurationMs": 0,
        "traceEndMs": 0,
        "traceId": "traceId",
        "traceStartMs": 0,
        "agentId": "agentId",
        "agentName": "agentName",
        "conversationId": "conversationId",
        "inputTokens": 0,
        "outputTokens": 0
      }
    ],
    "calculations": [
      {
        "aggregates": [
          {
            "count": 0,
            "interval": 0,
            "sampleInterval": 0,
            "value": 0,
            "groups": [
              {
                "key": "key",
                "value": "string"
              }
            ]
          }
        ],
        "calculation": "calculation",
        "series": [
          {
            "data": [
              {
                "count": 0,
                "interval": 0,
                "sampleInterval": 0,
                "value": 0,
                "firstSeen": "firstSeen",
                "groups": [
                  {
                    "key": "key",
                    "value": "string"
                  }
                ],
                "lastSeen": "lastSeen"
              }
            ],
            "time": "time"
          }
        ],
        "alias": "alias"
      }
    ],
    "compare": [
      {
        "aggregates": [
          {
            "count": 0,
            "interval": 0,
            "sampleInterval": 0,
            "value": 0,
            "groups": [
              {
                "key": "key",
                "value": "string"
              }
            ]
          }
        ],
        "calculation": "calculation",
        "series": [
          {
            "data": [
              {
                "count": 0,
                "interval": 0,
                "sampleInterval": 0,
                "value": 0,
                "firstSeen": "firstSeen",
                "groups": [
                  {
                    "key": "key",
                    "value": "string"
                  }
                ],
                "lastSeen": "lastSeen"
              }
            ],
            "time": "time"
          }
        ],
        "alias": "alias"
      }
    ],
    "distribution": {
      "bins": [
        "string"
      ],
      "bucketBoundaries": [
        0
      ],
      "bucketMode": "log",
      "buckets": [
        "string"
      ],
      "matrix": [
        [
          0
        ]
      ]
    },
    "events": {
      "count": 0,
      "events": [
        {
          "$metadata": {
            "id": "id",
            "account": "account",
            "cloudService": "cloudService",
            "coldStart": 1,
            "cost": 1,
            "duration": 1,
            "endTime": 0,
            "endTimeNs": "endTimeNs",
            "error": "error",
            "errorTemplate": "errorTemplate",
            "eventSize": 0,
            "fingerprint": "fingerprint",
            "level": "level",
            "message": "message",
            "messageTemplate": "messageTemplate",
            "metricName": "metricName",
            "origin": "origin",
            "parentSpanId": "parentSpanId",
            "provider": "provider",
            "rayId": "rayId",
            "region": "region",
            "requestId": "requestId",
            "service": "service",
            "spanId": "spanId",
            "spanName": "spanName",
            "stackId": "stackId",
            "startTime": 0,
            "startTimeNs": "startTimeNs",
            "statusCode": 1,
            "timestampNs": "timestampNs",
            "traceDuration": 1,
            "traceId": "traceId",
            "transactionName": "transactionName",
            "trigger": "trigger",
            "type": "type",
            "url": "url"
          },
          "dataset": "dataset",
          "source": "string",
          "timestamp": 0,
          "$containers": {
            "foo": "bar"
          },
          "$workers": {
            "eventType": "fetch",
            "scriptName": "scriptName",
            "durableObjectId": "durableObjectId",
            "entrypoint": "entrypoint",
            "event": {
              "foo": "bar"
            },
            "executionModel": "durableObject",
            "outcome": "outcome",
            "preview": {
              "id": "id",
              "name": "name",
              "slug": "slug"
            },
            "requestId": "requestId",
            "scriptVersion": {
              "id": "id",
              "message": "message",
              "tag": "tag"
            },
            "spanId": "spanId",
            "traceId": "traceId",
            "truncated": true
          }
        }
      ],
      "fields": [
        {
          "key": "key",
          "type": "type"
        }
      ],
      "series": [
        {
          "data": [
            {
              "aggregates": {
                "_count": 1,
                "_interval": 1,
                "_firstSeen": "_firstSeen",
                "_lastSeen": "_lastSeen",
                "bin": {}
              },
              "count": 0,
              "interval": 0,
              "sampleInterval": 0,
              "errors": 0,
              "groups": {
                "foo": "string"
              }
            }
          ],
          "time": "time"
        }
      ]
    },
    "invocations": {
      "foo": [
        {
          "$metadata": {
            "id": "id",
            "account": "account",
            "cloudService": "cloudService",
            "coldStart": 1,
            "cost": 1,
            "duration": 1,
            "endTime": 0,
            "endTimeNs": "endTimeNs",
            "error": "error",
            "errorTemplate": "errorTemplate",
            "eventSize": 0,
            "fingerprint": "fingerprint",
            "level": "level",
            "message": "message",
            "messageTemplate": "messageTemplate",
            "metricName": "metricName",
            "origin": "origin",
            "parentSpanId": "parentSpanId",
            "provider": "provider",
            "rayId": "rayId",
            "region": "region",
            "requestId": "requestId",
            "service": "service",
            "spanId": "spanId",
            "spanName": "spanName",
            "stackId": "stackId",
            "startTime": 0,
            "startTimeNs": "startTimeNs",
            "statusCode": 1,
            "timestampNs": "timestampNs",
            "traceDuration": 1,
            "traceId": "traceId",
            "transactionName": "transactionName",
            "trigger": "trigger",
            "type": "type",
            "url": "url"
          },
          "dataset": "dataset",
          "source": "string",
          "timestamp": 0,
          "$containers": {
            "foo": "bar"
          },
          "$workers": {
            "eventType": "fetch",
            "scriptName": "scriptName",
            "durableObjectId": "durableObjectId",
            "entrypoint": "entrypoint",
            "event": {
              "foo": "bar"
            },
            "executionModel": "durableObject",
            "outcome": "outcome",
            "preview": {
              "id": "id",
              "name": "name",
              "slug": "slug"
            },
            "requestId": "requestId",
            "scriptVersion": {
              "id": "id",
              "message": "message",
              "tag": "tag"
            },
            "spanId": "spanId",
            "traceId": "traceId",
            "truncated": true
          }
        }
      ]
    },
    "traces": [
      {
        "rootSpanName": "rootSpanName",
        "rootTransactionName": "rootTransactionName",
        "service": [
          "string"
        ],
        "spans": 0,
        "traceDurationMs": 0,
        "traceEndMs": 0,
        "traceId": "traceId",
        "traceStartMs": 0,
        "errors": [
          "string"
        ]
      }
    ]
  },
  "success": true
}
```