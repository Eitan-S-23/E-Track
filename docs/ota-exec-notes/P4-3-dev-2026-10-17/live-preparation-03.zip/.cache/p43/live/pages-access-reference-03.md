---
description: Current bugs and limitations for Cloudflare Pages builds, deployments, and configuration.
title: Known issues
image: https://developers.cloudflare.com/pages/platform/known-issues/og.png?v=5a712c74821f807c
---

[Skip to content](#main-content)

> Documentation Index  
> Fetch the complete documentation index at: https://developers.cloudflare.com/pages/llms.txt  
> Use this file to discover all available pages before exploring further.

# Known issues

Last updated Oct 15, 2026|Copy as Markdown| [View as Markdown](https://developers.cloudflare.com/pages/platform/known-issues/index.md)| [Agent setup](https://developers.cloudflare.com/agent-setup/)

Here are some known bugs and issues with Cloudflare Pages:

## Builds and deployment

- GitHub and GitLab are currently the only supported platforms for automatic CI/CD builds. [Direct Upload](https://developers.cloudflare.com/pages/get-started/direct-upload/) allows you to integrate your own build platform or upload from your local computer.
- Incremental builds are currently not supported in Cloudflare Pages.
- Uploading a `/functions` directory through the dashboard's Direct Upload option does not work (refer to [Using Functions in Direct Upload](https://developers.cloudflare.com/pages/get-started/direct-upload/#functions)).
- Commits/PRs from forked repositories will not create a preview. Support for this will come in the future.

## Git configuration

- If you deploy using the Git integration, you cannot switch to Direct Upload later. However, if you already use a Git-integrated project and do not want to trigger deployments every time you push a commit, you can [disable/pause automatic deployments](https://developers.cloudflare.com/pages/configuration/git-integration/#disable-automatic-deployments). Alternatively, you can delete your Pages project and create a new one pointing at a different repository if you need to update it.

## Build configuration

- `*.pages.dev` subdomains currently cannot be changed. If you need to change your `*.pages.dev` subdomain, delete your project and create a new one.
- Hugo builds automatically run an old version. To run the latest version of Hugo (for example, `0.101.0`), you will need to set an environment variable. Set `HUGO_VERSION` to `0.101.0` or the Hugo version of your choice.
- By default, Cloudflare uses Node `12.18.0` in the Pages build environment. If you need to use a newer Node version, refer to the [Build configuration page](https://developers.cloudflare.com/pages/configuration/build-configuration/) for configuration options.
- For users migrating from Netlify, Cloudflare does not support Netlify's Forms feature. [Pages Functions](https://developers.cloudflare.com/pages/functions/) are available as an equivalent to Netlify's Serverless Functions.

## Custom Domains

- It is currently not possible to add a custom domain with
  - a wildcard, for example, `*.domain.com`.
  - a Worker already routed on that domain.
- It is currently not possible to add a custom domain with a Cloudflare Access policy already enabled on that domain.
- Cloudflare's Load Balancer does not work with `*.pages.dev` projects; an `Error 1000: DNS points to prohibited IP` will appear.
- When adding a custom domain, the domain will not verify if Cloudflare cannot validate a request for an SSL certificate on that hostname. In order for the SSL to validate, ensure Cloudflare Access or a Cloudflare Worker is allowing requests to the validation path: `http://{domain_name}/.well-known/acme-challenge/*`.
- [Advanced Certificates](https://developers.cloudflare.com/ssl/edge-certificates/advanced-certificate-manager/) cannot be used with Cloudflare Pages due to Cloudflare for SaaS's [certificate prioritization](https://developers.cloudflare.com/ssl/reference/certificate-and-hostname-priority/).

## Pages Functions

- [Functions](https://developers.cloudflare.com/pages/functions/) does not currently support adding/removing polyfills, so your bundler (for example, webpack) may not run.
- `passThroughOnException()` is not currently available for Advanced Mode Pages Functions (Pages Functions which use an `_worker.js` file).
- `passThroughOnException()` is not currently as resilient as it is in Workers. We currently wrap Pages Functions code in a [try...catch ↗︎](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/try...catch) block and fallback to calling `env.ASSETS.fetch()`. This means that any critical failures (such as exceeding CPU time or exceeding memory) may still throw an error.

## Enable Access on your `*.pages.dev` domain

If you would like to enable [Cloudflare Access ↗︎](https://www.cloudflare.com/teams-access/)] for your preview deployments and your `*.pages.dev` domain, you must:

1. In the Cloudflare dashboard, go to the **Workers & Pages** page. [Go to **Workers & Pages** ↗](https://dash.cloudflare.com/?to=/:account/workers-and-pages)
2. Select your Pages project.
3. Go to **Settings** > **Enable access policy**.
4. Select **Manage** on the Access policy created for your preview deployments.
5. Under **Access** > **Applications**, select your project.
6. Select **Configure**.
7. Under **Public hostname**, in the **Subdomain** field, delete the wildcard ( `*`) and select **Save**. You may need to change the **Application name** at this step to avoid an error.

At this step, your `*.pages.dev` domain has been secured behind Access. To resecure your preview deployments:

8. Go back to your Pages project > **Settings** > **General** > and reselect **Enable access policy**.
9. Review that two Access policies, one for your `*.pages.dev` domain and one for your preview deployments ( `*.<YOUR_SITE>.pages.dev`), have been created.

If you have a custom domain and protected your `*.pages.dev` domain behind Access, you must:

10. In the [Cloudflare dashboard ↗︎](https://dash.cloudflare.com/), go to **Zero Trust** > **Access controls** > **Applications**. Select **Create new application** > **Self-hosted and private**.
11. Select **Add public hostname** and select your custom domain from the *Domain* dropdown menu.
12. Configure your access rules to define who can reach the Access authentication page.
13. Select **Create**.

Caution

If you do not configure an Access policy for your custom domain, an Access authentication will render but not work for your custom domain visitors. If your Pages project has a custom domain, make sure to add an Access policy as described above in steps 10 through 13 to avoid any authentication issues.

If you have an issue that you do not see listed, let the team know in the Cloudflare Workers Discord. Get your invite at [discord.cloudflare.com ↗︎](https://discord.cloudflare.com), and share your bug report in the #pages-general channel.

## Delete a project with a high number of deployments

You may not be able to delete your Pages project if it has a high number (over 100) of deployments. The Cloudflare team is tracking this issue.

As a workaround, you can use [`wrangler pages deployment delete`](https://developers.cloudflare.com/workers/wrangler/commands/pages/#pages-deployment-delete) to delete deployments individually. After you delete your deployments, you will be able to delete your Pages project.

```sh
npx wrangler pages deployment delete <DEPLOYMENT_ID> --project-name <PROJECT_NAME>
```

Use the `--force` flag to skip the confirmation prompt and to force deletion of aliased deployments.

To delete *all* of your preview deployments for a particular project, save and run one of the following scripts, passing your project name as the first argument. Each script finds your production deployment, keeps it, and deletes the remaining preview deployments in parallel. You can optionally pass a second argument to control how many deletions run at once (the default is `5`):

```bash
#!/usr/bin/env bash
set -euo pipefail

project="${1:?usage: $0 <project-name> [parallelism]}"
parallel="${2:-5}"

deployments=$(npx --no-install wrangler pages deployment list \
    --project-name "$project" --json)

prod_id=$(jq -r '[.[] | select(.Environment == "Production")][0].Id // empty' <<<"$deployments")
if [ -z "$prod_id" ]; then
    echo "No production deployment found for '$project' - aborting." >&2
    echo "This script keeps your production deployment, so it needs one to run." >&2
    echo "Create a production deployment by deploying to your production branch (for example: npx wrangler pages deploy <output-dir> --project-name $project), then re-run this script." >&2
    exit 1
fi

to_delete=$(jq -r '.[] | select(.Environment != "Production") | .Id' <<<"$deployments")
count=$(printf '%s\n' "$to_delete" | grep -c . || true)

if [ "$count" -eq 0 ]; then
    echo "Nothing to delete. Production: $prod_id"
    exit 0
fi

echo "Production: $prod_id. Deleting $count preview deployments..."

failed=$(printf '%s\n' "$to_delete" | xargs -n1 -P "$parallel" -I{} \
    sh -c 'npx --no-install wrangler pages deployment delete "$1" --project-name "$2" --force >/dev/null 2>&1 \
           || echo "$1"' _ {} "$project")

if [ -n "$failed" ]; then
    echo "The following deployments failed to delete:" >&2
    printf '%s\n' "$failed" >&2
    exit 1
fi

echo "Done."
```

```powershell
param(
    [Parameter(Mandatory=$true)][string]$ProjectName,
    [int]$Throttle = 5
)

$ErrorActionPreference = "Stop"
$env:CLOUDFLARE_ACCOUNT_ID = $env:CLOUDFLARE_ACCOUNT_ID  # ensure inherited into runspaces

$deployments = npx --no-install wrangler pages deployment list `
    --project-name $ProjectName --json | ConvertFrom-Json

$prod = $deployments | Where-Object { $_.Environment -eq "Production" } | Select-Object -First 1
if (-not $prod) {
    throw "No production deployment found for '$ProjectName' - aborting to avoid data loss. This script keeps your production deployment, so it needs one to run. Create a production deployment by deploying to your production branch (for example: npx wrangler pages deploy <output-dir> --project-name $ProjectName), then re-run this script."
}

$toDelete = $deployments | Where-Object { $_.Environment -ne "Production" }

if ($toDelete.Count -eq 0) {
    Write-Output "Nothing to delete. Production: $($prod.Id)"
    return
}

Write-Output "Production: $($prod.Id). Deleting $($toDelete.Count) preview deployments..."

$results = $toDelete | ForEach-Object -Parallel {
    $id = $_.Id
    npx --no-install wrangler pages deployment delete $id `
        --project-name $using:ProjectName --force *> $null
    [pscustomobject]@{ Id = $id; ExitCode = $LASTEXITCODE }
} -ThrottleLimit $Throttle

$failed = $results | Where-Object { $_.ExitCode -ne 0 }
if ($failed) {
    Write-Warning "$($failed.Count) deletions failed:"
    $failed | Format-Table -AutoSize
    exit 1
}

Write-Output "Done."
```

These scripts will not delete the active production deployment if one exists.

## Use Pages as Origin in Cloudflare Load Balancer

[Cloudflare Load Balancing](https://developers.cloudflare.com/load-balancing/) will not work without the host header set. To use a Pages project as target, make sure to select **Add host header** when [creating a pool](https://developers.cloudflare.com/load-balancing/pools/create-pool/#create-a-pool), and set both the host header value and the endpoint address to your `pages.dev` domain.

Refer to [Use Cloudflare Pages as origin](https://developers.cloudflare.com/load-balancing/pools/cloudflare-pages-origin/) for a complete tutorial.

Was this helpful?

YesNo

## On this page

[![](https://developers.cloudflare.com/_astro/logo.te5VL_aD.svg)Docs](https://developers.cloudflare.com/)

```json
{"@context":"https://schema.org","@type":"TechArticle","@id":"https://developers.cloudflare.com/pages/platform/known-issues/#page","headline":"Known issues","description":"Current bugs and limitations for Cloudflare Pages builds, deployments, and configuration.","url":"https://developers.cloudflare.com/pages/platform/known-issues/","inLanguage":"en","image":"https://developers.cloudflare.com/pages/platform/known-issues/og.png?v=5a712c74821f807c","dateModified":"2026-10-15","publisher":{"@type":"Organization","name":"Cloudflare","description":"One platform for your apps, agents, and workforce. Build, secure, and scale without managing infrastructure","url":"https://www.cloudflare.com/","sameAs":["https://github.com/cloudflare","https://www.linkedin.com/company/cloudflare","https://x.com/cloudflare"],"logo":{"@type":"ImageObject","url":"https://developers.cloudflare.com/logo.svg"},"address":{"@type":"PostalAddress","streetAddress":"101 Townsend St","addressLocality":"San Francisco","addressRegion":"CA","postalCode":"94107","addressCountry":"US"},"contactPoint":[{"@type":"ContactPoint","contactType":"Customer Support","url":"https://support.cloudflare.com/","availableLanguage":["English"]},{"@type":"ContactPoint","contactType":"Sales","url":"https://www.cloudflare.com/contact/","availableLanguage":["English"]}]},"isPartOf":{"@type":"WebSite","@id":"https://developers.cloudflare.com/#website","name":"Cloudflare Docs","url":"https://developers.cloudflare.com/"}}
```
