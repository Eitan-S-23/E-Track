import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const [mode, label] = process.argv.slice(2);
assert.ok(['inventory', 'assets', 'credential-status', 'original-capabilities', 'original-remaining', 'channel-state', 'token-policy', 'original-token-policy', 'access-inputs', 'log-probe', 'original-log-probe'].includes(mode));
assert.match(label || '', /^[a-z0-9-]+$/);
const priorRoot = 'D:/github/my/E-Track/.cache/p41-dev-20261015';
const privateInput = path.join(priorRoot, '.cache/cf-auth-input');
const config = JSON.parse(fs.readFileSync(path.join(priorRoot, '.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json'), 'utf8'));
const originalConfigPath = 'D:/github/my/E-Track/app/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json';
const originalConfig = mode.startsWith('original-') ? JSON.parse(fs.readFileSync(originalConfigPath, 'utf8')) : null;
if (originalConfig) assert.equal(originalConfig.secrets.CLOUDFLARE_ACCOUNT_ID, config.account_id);
const token = originalConfig ? originalConfig.secrets.CLOUDFLARE_API_TOKEN.trim() : fs.readFileSync(path.join(privateInput, 'token.txt'), 'utf8').trim();
const secrets = JSON.parse(fs.readFileSync(path.join(privateInput, 'firmware-test-secrets.json'), 'utf8'));
assert.ok(token.length > 20);
assert.match(config.account_id, /^[a-f0-9]{32}$/);
const account = config.account_id;
const database = '2617e1e1-956f-42ce-a465-da56d84abf06';
const bucket = 'e-track-firmware-p41-test-releases';
const worker = 'e-track-firmware-p41-test';
assert.equal(config.name, worker);
assert.equal(config.d1_databases[0].database_id, database);
assert.equal(config.r2_buckets[0].bucket_name, bucket);
const sensitive = [token, ...Object.values(secrets)].filter(v => typeof v === 'string' && v.length > 10);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const scrub = text => sensitive.reduce((s, value) => s.split(value).join('[REDACTED]'), String(text));
function target(name, isPrivate = false) {
  assert.match(name, /^[a-z0-9_-]+\.(json|txt|bin)$/);
  const full = path.join(root, '.cache/p43', isPrivate ? 'private' : 'live', `${label}-${name}`);
  const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'live-preflight', '.', 'preflight', full],
    { cwd: root, windowsHide: true, encoding: 'utf8' });
  assert.equal(guard.status, 0, guard.stderr);
  assert.ok(!fs.existsSync(full), 'Refusing to replace a prior observation');
  fs.mkdirSync(path.dirname(full), { recursive: true });
  return full;
}
function save(name, value, isPrivate = false) {
  const text = JSON.stringify(value, null, 2) + '\n';
  fs.writeFileSync(target(name, isPrivate), isPrivate ? text : scrub(text), { flag: 'wx' });
}
async function boundedBody(response, max = 4 * 1024 * 1024) {
  const chunks = []; let total = 0;
  for await (const chunk of response.body || []) {
    total += chunk.length; assert.ok(total <= max, 'Response exceeds bounded observation size'); chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}
const receipts = [];
async function api(name, route, sql, params = [], telemetryQuery) {
  assert.ok(route === 'user/tokens/verify' || route.startsWith(`accounts/${account}/`)
    || (mode.endsWith('token-policy') && /^user\/tokens\/[a-f0-9]{32}$/.test(route)));
  if (sql) {
    assert.equal(route, `accounts/${account}/d1/database/${database}/query`);
    assert.match(sql, /^SELECT\b/i); assert.ok(!sql.includes(';'));
  }
  if (telemetryQuery) {
    assert.ok(mode.endsWith('log-probe'));
    assert.equal(route, `accounts/${account}/workers/observability/telemetry/query`);
    assert.equal(telemetryQuery.dry, true);
    assert.equal(telemetryQuery.view, 'events');
    assert.equal(telemetryQuery.limit, 10);
    assert.equal(telemetryQuery.parameters.filterCombination, 'and');
    assert.deepEqual(telemetryQuery.parameters.filters[0], { key: '$metadata.service', type: 'string', operation: 'eq', value: worker });
    assert.equal(telemetryQuery.parameters.filters.length, 2);
    assert.ok(telemetryQuery.timeframe.to - telemetryQuery.timeframe.from <= 120000);
  }
  let response;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      response = await fetch(`https://api.cloudflare.com/client/v4/${route}`, {
        method: sql || telemetryQuery ? 'POST' : 'GET', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: sql ? JSON.stringify({ sql, params }) : telemetryQuery ? JSON.stringify(telemetryQuery) : undefined, redirect: 'error', signal: AbortSignal.timeout(30000)
      });
      break;
    } catch (error) {
      save(`${name}-transport-${attempt}.json`, { name, attempt, operation: sql ? 'SELECT_ONLY' : telemetryQuery ? 'TELEMETRY_DRY_QUERY' : 'GET',
        error: { name: error.name, code: error.code, causeCode: error.cause?.code }, timestamp: new Date().toISOString() });
      if (attempt === 2) throw error;
    }
  }
  const bytes = await boundedBody(response);
  let body;
  try { body = JSON.parse(bytes.toString('utf8')); } catch { body = null; }
  const receipt = { name, method: sql ? 'POST_SELECT_ONLY' : telemetryQuery ? 'POST_TELEMETRY_DRY_QUERY' : 'GET', route: route.replace(account, '<account>'),
    timestamp: new Date().toISOString(), status: response.status, cfRay: response.headers.get('cf-ray'),
    bodySha256: digest(bytes), bodyBytes: bytes.length, success: body ? body.success === true : response.ok,
    errors: body?.errors?.map(e => ({ code: e.code, message: scrub(e.message) })) };
  if (sql) {
    receipt.sql = sql; receipt.params = params;
    if (body?.success) assert.ok(body.result.every(r => r.success && r.meta.rows_written === 0 && !r.meta.changed_db));
  }
  if (telemetryQuery) receipt.query = telemetryQuery;
  receipts.push(receipt);
  save(`${name}-receipt.json`, receipt);
  return { receipt, body, bytes, headers: response.headers };
}
function safeProject(p) {
  return { name: p.name, subdomain: p.subdomain, productionBranch: p.production_branch,
    deployments: { latest: p.latest_deployment?.id, canonical: p.canonical_deployment?.id },
    configs: Object.fromEntries(Object.entries(p.deployment_configs || {}).map(([k,v]) => [k, {
      compatibility_date: v.compatibility_date, compatibility_flags: v.compatibility_flags,
      d1_databases: v.d1_databases, r2_buckets: v.r2_buckets,
      variables: Object.fromEntries(Object.entries(v.env_vars || {}).map(([n, x]) => [n, {
        type: x.type, present: typeof x.value === 'string' && x.value.length > 0,
        ...(x.type === 'plain_text' && ['ENVIRONMENT','APP_ID','FIRMWARE_DOWNLOAD_ORIGIN','FIRMWARE_V2_CUTOVER_EPOCH','DOWNLOAD_TOKEN_KEY_VERSION'].includes(n) ? { value: x.value } : {})
      }])) }])) };
}
try {
  save('private-input-shape.json', { source: originalConfig ? originalConfigPath : privateInput, configSource: '.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json',
    accountMatchesPriorBindings: true, tokenPresent: true, secretNames: Object.keys(secrets),
    tokenModifiedAt: fs.statSync(originalConfig ? originalConfigPath : path.join(privateInput, 'token.txt')).mtime.toISOString() });
  if (mode === 'access-inputs') {
    const names = ['ACCESS_JWT_ISSUER', 'ACCESS_JWT_AUD', 'ADMIN_OWNER_EMAILS', 'ADMIN_PUBLISHER_EMAILS', 'ADMIN_VIEWER_EMAILS', 'ADMIN_ALLOWED_ORIGINS'];
    const inputs = [originalConfigPath,
      'D:/github/my/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json',
      'D:/github/my/bluetooth_flutter_Trace/cloudflare/update-service/.bootstrap/staging-summary.json'];
    const observations = inputs.map(file => {
      const data = JSON.parse(fs.readFileSync(file, 'utf8'));
      const fields = [];
      const walk = (object, fieldPath = '') => {
        if (!object || typeof object !== 'object') return;
        for (const [key, value] of Object.entries(object)) {
          const itemPath = fieldPath ? `${fieldPath}.${key}` : key;
          if (names.includes(key)) fields.push({ name: key, fieldPath: itemPath, nonemptyString: typeof value === 'string' && value.trim().length > 0 });
          if (value && typeof value === 'object') walk(value, itemPath);
        }
      };
      walk(data);
      return { source: file, modifiedAt: fs.statSync(file).mtime.toISOString(), fields };
    });
    save('existing-access-inputs.json', { observations, environment: names.map(name => ({ name, present: !!process.env[name]?.trim() })),
      valuesLoggedOrCopied: false, limitation: 'Bounded search of the known original project deployment inputs; not a claim that no private input exists anywhere else' });
  } else if (mode.endsWith('log-probe')) {
    const marker = `p43-safe-query-${label}`;
    const route = `accounts/${account}/workers/observability/telemetry/query`;
    const probeStart = Date.now();
    const parameters = { datasets: ['cloudflare-workers'], filterCombination: 'and', filters: [
      { key: '$metadata.service', type: 'string', operation: 'eq', value: worker },
      { key: '$metadata.message', type: 'string', operation: 'includes', value: marker }
    ] };
    const makeQuery = () => ({ queryId: marker, dry: true, view: 'events', limit: 10,
      timeframe: { from: probeStart - 1000, to: Date.now() + 1000 }, parameters });
    const capability = await api('telemetry-capability', route, null, [], makeQuery());
    save('telemetry-capability.json', capability.body, true);
    if (!capability.body?.success) {
      save('log-probe-result.json', { status: 'NOT_OBSERVED', queryHttpStatus: capability.receipt.status,
        healthProbeSent: false, signedUrlIssuedOrUsed: false, platformConfigurationChanged: false,
        reason: 'Existing credential cannot execute the narrowly filtered, non-persisted telemetry query; no unobservable probe was sent' });
    } else {
      assert.equal(capability.body.result.run.dry, true);
      const before = await api('log-settings-before', `accounts/${account}/workers/scripts/${worker}/settings`);
      assert.ok(before.body?.success);
      const url = new URL('https://e-track-firmware-p41-test.tangjichentudou.workers.dev/healthz');
      url.searchParams.set('p43_query_probe', marker);
      const response = await fetch(url, { redirect: 'error', signal: AbortSignal.timeout(30000) });
      const bytes = await boundedBody(response, 16384);
      const ray = response.headers.get('cf-ray');
      const requestId = ray?.split('-')[0];
      save('health-marker.json', { url: url.href, marker, markerIsSecret: false, status: response.status,
        cfRay: ray, applicationRequestId: response.headers.get('x-request-id'), bodySha256: digest(bytes),
        body: JSON.parse(bytes.toString('utf8')), sentAt: new Date().toISOString() });
      assert.equal(response.status, 200);
      assert.match(requestId || '', /^[a-f0-9]+$/);
      parameters.filters[1] = { key: '$metadata.requestId', type: 'string', operation: 'eq', value: requestId };
      let events = [];
      for (let poll = 1; poll <= 3; poll++) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        const logs = await api(`telemetry-marker-${poll}`, route, null, [], makeQuery());
        save(`telemetry-marker-${poll}.json`, logs.body, true);
        assert.ok(logs.body?.success);
        assert.equal(logs.body.result.run.dry, true);
        events = logs.body.result.events?.events || [];
        assert.ok(Array.isArray(events));
        for (const event of events) {
          assert.equal(event.$metadata.service, worker);
          assert.equal(event.$metadata.requestId, requestId);
        }
        if (events.length) break;
      }
      const after = await api('log-settings-after', `accounts/${account}/workers/scripts/${worker}/settings`);
      assert.ok(after.body?.success);
      assert.deepEqual(after.body.result, before.body.result);
      save('log-probe-result.json', { status: events.length ? 'OBSERVED' : 'NOT_OBSERVED',
        marker, markerIsSecret: false, observedEvents: events.map(event => ({
          service: event.$metadata.service, requestId: event.$metadata.requestId,
          eventId: event.$metadata.id, timestamp: event.timestamp,
          metadataUrlContainsQueryMarker: String(event.$metadata.url || '').includes(marker),
          metadataMessageContainsQueryMarker: String(event.$metadata.message || '').includes(marker),
          rawEventContainsQueryMarker: JSON.stringify(event).includes(marker) })),
        queryResultsPersisted: false, signedUrlIssuedOrUsed: false, platformConfigurationChanged: false,
        settingsUnchanged: true, observability: after.body.result.observability,
        limitation: 'A harmless query marker is not a recovery URL; absence without a matching invocation is not proof of query redaction' });
    }
  } else if (mode.endsWith('token-policy')) {
    const verify = await api('own-token-verify', 'user/tokens/verify');
    assert.ok(verify.body?.success && verify.body.result.status === 'active', 'Existing credential must verify before querying its own policy');
    const id = verify.body.result.id;
    assert.match(id, /^[a-f0-9]{32}$/);
    save('own-token-verification.json', verify.body, true);
    const details = await api('own-token-details', `user/tokens/${id}`);
    save('own-token-details.json', details.body, true);
    const result = details.body?.success ? details.body.result : null;
    save('own-token-policy-summary.json', { credentialSource: originalConfig ? 'Original project API token' : 'Existing P41 same-account API token',
      tokenStatus: verify.body.result.status, tokenIdSha256: digest(id), policyReadable: !!result,
      policyReadStatus: details.receipt.status,
      policies: result?.policies?.map(p => ({ effect: p.effect,
        permissions: p.permission_groups?.map(g => ({ id: g.id, name: g.name })),
        approvedAccountResource: Object.hasOwn(p.resources || {}, `com.cloudflare.api.account.${account}`),
        allAccountsResource: Object.hasOwn(p.resources || {}, 'com.cloudflare.api.account.*'),
        otherResourceCount: Object.keys(p.resources || {}).filter(k => k !== `com.cloudflare.api.account.${account}` && k !== 'com.cloudflare.api.account.*').length,
        conditionsPresent: !!p.condition && Object.keys(p.condition).length > 0 })),
      authorityUnchanged: true, credentialsCreatedOrModified: false, accessWriteRetried: false,
      limitation: result ? 'Token metadata is not an Admin Access user session or proof of successful application configuration'
        : 'The API did not disclose this token policy; do not infer exact permission groups from a refused read' });
    const oauthPath = path.join(root, '.cache/p43/private/platform-login/xdg-config/.wrangler/config/default.toml');
    const oauth = fs.readFileSync(oauthPath, 'utf8');
    const scopeLine = oauth.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1];
    const expiration = oauth.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
    save('current-oauth-scope-summary.json', { source: path.relative(root, oauthPath),
      expiration, refreshPresent: /^refresh_token\s*=\s*"[^"]+"/m.test(oauth),
      scopes: scopeLine ? [...scopeLine.matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]) : null,
      credentialValuesPersisted: false, refreshedOrReauthenticated: false });
  } else if (mode === 'channel-state') {
    const route = `accounts/${account}/d1/database/${database}/query`;
    for (const [name, sql] of [
      ['channels-final', 'SELECT id,app_id,device_model,name,current_release_id,revision,disable_latest,disable_downloads,updated_at FROM firmware_channels ORDER BY id'],
      ['releases-final', 'SELECT id,app_id,device_model,version_code,state,archived,target_image_sha256 FROM firmware_releases ORDER BY id'],
      ['idempotency-final', 'SELECT action,release_id,state,request_id,created_epoch_seconds,retained_until,original_expires_at FROM firmware_admin_idempotency']
    ]) {
      const result = await api(name, route, sql);
      assert.ok(result.body?.success);
      save(`${name}.json`, result.body.result);
    }
  } else if (mode === 'original-capabilities' || mode === 'original-remaining') {
    if (mode === 'original-capabilities') {
    const verify = await api('credential', 'user/tokens/verify');
    save('credential-state.json', { status: verify.body?.result?.status, expires_on: verify.body?.result?.expires_on });
    const pages = await api('pages', `accounts/${account}/pages/projects?per_page=100`);
    if (pages.body?.success) {
      save('pages.json', { projects: pages.body.result.map(safeProject), result_info: pages.body.result_info });
      for (const p of pages.body.result.filter(p => p.name.includes('p43') || p.name.includes('p4-3') || p.name === 'trace-update-admin-staging')) {
        save(`project-${p.name}.json`, p, true);
      }
    }
    const access = await api('access-apps', `accounts/${account}/access/apps?per_page=100`);
    if (access.body?.success) {
      save('access-apps.json', { applications: access.body.result.map(a => ({ id: a.id, name: a.name, domain: a.domain,
        type: a.type, allowed_idps: a.allowed_idps, session_duration: a.session_duration, audHash: a.aud ? digest(a.aud) : null })), result_info: access.body.result_info });
      save('access-apps.json', access.body.result, true);
    }
    }
    const idps = await api('access-idps', `accounts/${account}/access/identity_providers`);
    if (idps.body?.success) {
      save('access-idps.json', idps.body.result.map(p => ({ id: p.id, name: p.name, type: p.type })));
      save('access-idps.json', idps.body.result, true);
    }
    const org = await api('access-organization', `accounts/${account}/access/organizations`);
    if (org.body?.success) save('access-organization.json', { auth_domain: org.body.result.auth_domain, name: org.body.result.name });
  } else if (mode === 'credential-status') {
    const oauthPath = 'C:/Users/SU/AppData/Roaming/xdg.config/.wrangler/config/default.toml';
    if (fs.existsSync(oauthPath)) {
      const toml = fs.readFileSync(oauthPath, 'utf8');
      const expiry = toml.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
      const scopeLine = toml.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1];
      save('oauth-input-status.json', { path: oauthPath, modifiedAt: fs.statSync(oauthPath).mtime.toISOString(),
        expirationTime: expiry || null, expired: !expiry || Date.parse(expiry) <= Date.now(),
        refreshPresent: /^refresh_token\s*=\s*"[^"]+"/m.test(toml),
        scopes: scopeLine ? [...scopeLine.matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]) : null, credentialValuesPersisted: false });
    }
  } else if (mode === 'assets') {
    const { r2KeyFor } = await import(pathToFileURL(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/scripts/firmware-schema.mjs')));
    const currentAssets = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/inventory-01-d1-assets.json'), 'utf8'))[0].results;
    const currentReleases = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/inventory-01-d1-releases.json'), 'utf8'))[0].results;
    const approved = new Set(['fw_e1abd9e066161562fb72322b81ee7c06bf4719df7d6f89e769811a7460373648', 'fw_12367eee317a0774a7271cf982ee7f933c6b089336645f9e607501105e72bf0c']);
    assert.equal(currentAssets.length, 6);
    const verified = [];
    for (const asset of currentAssets) {
      assert.ok(approved.has(asset.release_id));
      assert.equal(asset.r2_state, 'available');
      const release = currentReleases.find(r => r.id === asset.release_id);
      assert.equal(release.app_id, 'trace'); assert.equal(release.device_model, 'e-track-at32f435');
      assert.match(asset.file_name, /^[A-Za-z0-9._-]+$/);
      assert.equal(asset.r2_key, r2KeyFor({ appId: release.app_id, deviceModel: release.device_model,
        versionCode: release.version_code, releaseTag: release.release_tag }, { fileName: asset.file_name }));
      const priorObservation = path.join(root, '.cache/p43/live', `assets-03-r2-${asset.id}.json`);
      if (label !== 'assets-03' && fs.existsSync(priorObservation)) {
        const observed = JSON.parse(fs.readFileSync(priorObservation, 'utf8'));
        assert.equal(observed.status, 200);
        assert.equal(observed.observedSize, asset.size_bytes);
        assert.equal(observed.observedSha256, asset.sha256);
        verified.push({ ...observed, reusedCurrentP43Observation: path.relative(root, priorObservation),
          evidenceSha256: digest(fs.readFileSync(priorObservation)) });
        continue;
      }
      const route = `accounts/${account}/r2/buckets/${bucket}/objects/${asset.r2_key.split('/').map(encodeURIComponent).join('/')}`;
      const result = await api(`r2-${asset.id}`, route);
      const observed = { assetId: asset.id, releaseId: asset.release_id, kind: asset.kind,
        status: result.receipt.status, cfRay: result.receipt.cfRay, expectedSize: asset.size_bytes,
        observedSize: result.bytes.length, expectedSha256: asset.sha256, observedSha256: digest(result.bytes),
        etag: result.headers.get('etag'), contentType: result.headers.get('content-type') };
      verified.push(observed);
      save(`r2-${asset.id}.json`, observed);
      if (result.receipt.status !== 200) break;
    }
    const allVerified = verified.length === 6 && verified.every(v => v.status === 200 && v.expectedSize === v.observedSize && v.expectedSha256 === v.observedSha256);
    save('r2-integrity.json', { allVerified, observations: verified });
    if (!allVerified) process.exitCode = 1;
    const source = await api('worker-source', `accounts/${account}/workers/scripts/${worker}`);
    assert.equal(source.receipt.status, 200);
    fs.writeFileSync(target('worker-source.bin', true), source.bytes, { flag: 'wx' });
    const sourceText = source.bytes.toString('utf8');
    save('worker-source-summary.json', { bytes: source.bytes.length, sha256: digest(source.bytes), contentType: source.headers.get('content-type'),
      hasHono: sourceText.includes('hono'), hasCorsImport: /hono\/cors/.test(sourceText),
      hasRawRequestHandlers: sourceText.includes('c.req.raw'), privateSourceOnly: true });
    const oauthPath = 'C:/Users/SU/AppData/Roaming/xdg.config/.wrangler/config/default.toml';
    if (fs.existsSync(oauthPath)) {
      const toml = fs.readFileSync(oauthPath, 'utf8');
      const expiry = toml.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
      const scopeLine = toml.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1];
      save('oauth-input-status.json', { path: oauthPath, modifiedAt: fs.statSync(oauthPath).mtime.toISOString(),
        expirationTime: expiry || null, expired: !expiry || Date.parse(expiry) <= Date.now(),
        refreshPresent: /^refresh_token\s*=\s*"[^"]+"/m.test(toml),
        scopes: scopeLine ? [...scopeLine.matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]) : null, credentialValuesPersisted: false });
    }
    const queryRoute = `accounts/${account}/d1/database/${database}/query`;
    const refs = await api('d1-all-channel-references', queryRoute,
      'SELECT id,app_id,device_model,name,current_release_id,revision,disable_latest,disable_downloads,updated_at FROM firmware_channels ORDER BY id');
    if (refs.body?.success) save('d1-all-channel-references.json', refs.body.result);
    const patch = await api('d1-patch-dependencies', queryRoute,
      'SELECT a.id,a.release_id,a.base_image_sha256,a.base_vcode,r.state,r.archived FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id WHERE a.kind=?', ['patch']);
    if (patch.body?.success) save('d1-patch-dependencies.json', patch.body.result);
  } else {
  const verify = await api('credential', 'user/tokens/verify');
  save('credential-state.json', { status: verify.body?.result?.status, expires_on: verify.body?.result?.expires_on,
    not_before: verify.body?.result?.not_before });
  const settings = await api('worker-settings', `accounts/${account}/workers/scripts/${worker}/settings`);
  if (settings.body?.success) {
    const value = settings.body.result;
    save('worker-settings.json', { ...value, bindings: value.bindings.map(b => b.type === 'secret_text' ? { name: b.name, type: b.type } : b) });
    assert.equal(value.bindings.find(b => b.name === 'DB').id, database);
    assert.equal(value.bindings.find(b => b.name === 'RELEASES_BUCKET').bucket_name, bucket);
  }
  const deployments = await api('worker-deployments', `accounts/${account}/workers/scripts/${worker}/deployments`);
  if (deployments.body?.success) save('worker-deployments.json', deployments.body.result);
  const pages = await api('pages', `accounts/${account}/pages/projects?per_page=100`);
  if (pages.body?.success) {
    save('pages.json', { projects: pages.body.result.map(safeProject), result_info: pages.body.result_info });
    for (const p of pages.body.result.filter(p => p.name.includes('p43') || p.name.includes('p4-3') || p.name === 'trace-update-admin-staging')) {
      save(`project-${p.name}.json`, p, true);
    }
  }
  const access = await api('access-apps', `accounts/${account}/access/apps?per_page=100`);
  if (access.body?.success) {
    save('access-apps.json', { applications: access.body.result.map(a => ({ id: a.id, name: a.name, domain: a.domain, type: a.type,
      allowed_idps: a.allowed_idps, session_duration: a.session_duration, audHash: a.aud ? digest(a.aud) : null })), result_info: access.body.result_info });
    save('access-apps.json', access.body.result, true);
  }
  const idps = await api('access-idps', `accounts/${account}/access/identity_providers`);
  if (idps.body?.success) {
    save('access-idps.json', idps.body.result.map(p => ({ id: p.id, name: p.name, type: p.type })));
    save('access-idps.json', idps.body.result, true);
  }
  const org = await api('access-organization', `accounts/${account}/access/organizations`);
  if (org.body?.success) save('access-organization.json', { auth_domain: org.body.result.auth_domain, name: org.body.result.name });
  const queryRoute = `accounts/${account}/d1/database/${database}/query`;
  const scope = ['trace','e-track-at32f435'];
  for (const [name, sql, params] of [
    ['channels', 'SELECT * FROM firmware_channels WHERE app_id=? AND device_model=? ORDER BY name', scope],
    ['releases', 'SELECT * FROM firmware_releases WHERE app_id=? AND device_model=? ORDER BY version_code', scope],
    ['assets', 'SELECT a.* FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id WHERE r.app_id=? AND r.device_model=? ORDER BY r.version_code,a.kind', scope],
    ['audit', 'SELECT id,app_id,actor,actor_type,action,target_type,target_id,request_id,reason,before_json,after_json,created_at FROM audit_logs WHERE app_id=? ORDER BY created_at,id', ['trace']],
    ['app-config', 'SELECT * FROM app_config WHERE app_id=?', ['trace']],
    ['idempotency-state', 'SELECT action,release_id,state,request_id,created_epoch_seconds,retained_until,original_expires_at FROM firmware_admin_idempotency', []],
    ['schema-tables', "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name", []]
  ]) {
    const result = await api(`d1-${name}`, queryRoute, sql, params);
    if (result.body?.success) save(`d1-${name}.json`, result.body.result);
  }
  }
} catch (error) {
  save('failure.json', { name: error.name, message: scrub(error.message), code: error.code });
  process.exitCode = 1;
} finally {
  save('summary.json', { mode, label, businessMutations: 0, source: 'Current authenticated Cloudflare API observations; not an Access browser exercise', receipts });
  process.stdout.write(JSON.stringify({ label, observations: receipts.map(r => ({ name: r.name, status: r.status, success: r.success, errors: r.errors })), businessMutations: 0 }) + '\n');
}
