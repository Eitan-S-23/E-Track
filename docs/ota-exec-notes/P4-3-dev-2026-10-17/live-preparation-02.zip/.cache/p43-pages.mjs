import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const [mode, label, credential = 'oauth'] = process.argv.slice(2);
assert.ok(['inventory', 'create', 'configure', 'protect', 'readback'].includes(mode));
assert.ok(['oauth', 'original', 'p41'].includes(credential));
assert.ok(credential === 'oauth' || mode === 'protect');
assert.match(label || '', /^[a-z0-9-]+$/);
const privateDir = path.join(root, '.cache/p43/private/pages');
const publicDir = path.join(root, '.cache/p43/live');
const guard = (...files) => {
  const result = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'pages-preflight', '.', 'preflight', ...files],
    { cwd: root, windowsHide: true, encoding: 'utf8' });
  assert.equal(result.status, 0, 'Pages output preflight failed');
};
guard(privateDir, publicDir);
fs.mkdirSync(privateDir, { recursive: true });
const oauth = fs.readFileSync(path.join(root, '.cache/p43/private/platform-login/xdg-config/.wrangler/config/default.toml'), 'utf8');
let token = oauth.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1];
const expiry = oauth.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
assert.ok(token && Date.parse(expiry) > Date.now(), 'Reuse current legitimate login; do not start another OAuth attempt');
const approved = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8'));
const account = approved.account_id;
assert.match(account, /^[a-f0-9]{32}$/);
if (credential === 'original') {
  const existing = JSON.parse(fs.readFileSync('D:/github/my/E-Track/app/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json', 'utf8'));
  assert.equal(existing.secrets.CLOUDFLARE_ACCOUNT_ID, account);
  token = existing.secrets.CLOUDFLARE_API_TOKEN.trim();
} else if (credential === 'p41') {
  token = fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/token.txt', 'utf8').trim();
}
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const publicVars = ['ENVIRONMENT', 'APP_ID', 'FIRMWARE_DOWNLOAD_ORIGIN', 'DOWNLOAD_TOKEN_KEY_VERSION', 'FIRMWARE_V2_CUTOVER_EPOCH'];
const projectName = 'e-track-firmware-p43-admin-test';
const projectRoute = `pages/projects/${projectName}`;
const report = { label, startedAt: new Date().toISOString(), accountSourceMatchesApprovedBindings: true,
  authentication: credential === 'oauth' ? 'Successful existing-Edge official OAuth; platform only, not Admin Access' : `Existing ${credential} API credential for the same approved account; not Admin Access`,
  receipts: [], businessMutations: 0, cloudWritesAttempted: 0 };
function save(name, value, isPrivate = false) {
  assert.match(name, /^[a-z0-9-]+\.json$/);
  const target = path.join(isPrivate ? privateDir : publicDir, `${label}-${name}`);
  guard(target);
  fs.writeFileSync(target, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
}
async function api(name, suffix, method = 'GET', body) {
  if (method !== 'GET') {
    assert.ok((mode === 'configure' && method === 'PATCH' && suffix === projectRoute)
      || (mode === 'protect' && method === 'POST' && suffix === 'access/apps'));
    report.cloudWritesAttempted++;
  }
  const url = `https://api.cloudflare.com/client/v4/accounts/${account}/${suffix}`;
  const result = await fetch(url, { method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
    redirect: 'error', signal: AbortSignal.timeout(30000) });
  const chunks = []; let size = 0;
  for await (const chunk of result.body || []) { size += chunk.length; assert.ok(size <= 4 * 1024 * 1024); chunks.push(chunk); }
  const bytes = Buffer.concat(chunks);
  const json = JSON.parse(bytes.toString('utf8'));
  const receipt = { name, method, suffix, time: new Date().toISOString(), status: result.status,
    cfRay: result.headers.get('cf-ray'), success: json.success === true, bodySha256: sha(bytes), bodyBytes: bytes.length,
    errors: json.errors?.map(e => ({ code: e.code, message: String(e.message ?? e.error).split(token).join('[REDACTED]') })) };
  report.receipts.push(receipt);
  save(`${name}-receipt.json`, receipt);
  save(`${name}.json`, json, true);
  return json;
}
function project(p) {
  return { name: p.name, subdomain: p.subdomain, productionBranch: p.production_branch,
    latestDeployment: p.latest_deployment?.id, canonicalDeployment: p.canonical_deployment?.id,
    source: p.source ? { type: p.source.type, owner: p.source.config?.owner, repoName: p.source.config?.repo_name } : null,
    configs: Object.fromEntries(Object.entries(p.deployment_configs || {}).map(([environment, c]) => [environment, {
      compatibilityDate: c.compatibility_date, compatibilityFlags: c.compatibility_flags,
      d1: c.d1_databases, r2: c.r2_buckets,
      vars: Object.fromEntries(Object.entries(c.env_vars || {}).map(([name, v]) => [name, { type: v.type,
        configured: true, valueVisible: typeof v.value === 'string' && v.value.length > 0,
        ...(publicVars.includes(name) && v.type === 'plain_text' ? { value: v.value } : {}) }]))
    }])) };
}
try {
  if (mode === 'readback') {
    const current = await api('project-final', projectRoute);
    assert.ok(current.success);
    const configured = JSON.parse(fs.readFileSync(path.join(privateDir, 'pages-configure-01-project-after-configure.json'), 'utf8'));
    assert.deepEqual(current.result.deployment_configs, configured.result.deployment_configs);
    assert.ok(!current.result.latest_deployment && !current.result.canonical_deployment);
    const original = await api('original-project-final', 'pages/projects/trace-update-admin-staging');
    const originalBefore = JSON.parse(fs.readFileSync(path.join(privateDir, 'pages-inventory-01-project-trace-update-admin-staging.json'), 'utf8'));
    assert.ok(original.success);
    assert.deepEqual(original.result.deployment_configs, originalBefore.result.deployment_configs);
    assert.equal(original.result.canonical_deployment?.id, originalBefore.result.canonical_deployment?.id);
    const origin = `https://${projectName}.pages.dev`;
    const response = await fetch(origin, { redirect: 'manual', signal: AbortSignal.timeout(30000) });
    const location = response.headers.get('location');
    const next = location ? new URL(location, origin) : null;
    await response.body?.cancel();
    report.isolatedProject = project(current.result);
    report.originalTraceConfigAndDeploymentUnchanged = true;
    report.originProbe = { url: origin, status: response.status, cfRay: response.headers.get('cf-ray'),
      redirect: next ? { origin: next.origin, path: next.pathname, queryOmitted: true } : null,
      ownerLoginEntryReady: false, note: 'No Admin code deployment or Access protection yet' };
  } else if (mode === 'configure') {
    const before = await api('project-before-configure', projectRoute);
    assert.ok(before.success);
    assert.equal(before.result.name, projectName);
    assert.ok(!before.result.latest_deployment, 'Unexpected deployment; reconcile before configuring');
    const testSecrets = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/firmware-test-secrets.json', 'utf8'));
    assert.ok(testSecrets.DOWNLOAD_HMAC_KEY_CURRENT);
    const variables = {
      ENVIRONMENT: { type: 'plain_text', value: 'staging' }, APP_ID: { type: 'plain_text', value: 'trace' },
      DOWNLOAD_TOKEN_KEY_VERSION: { type: 'plain_text', value: 'p41-test-1' },
      FIRMWARE_V2_CUTOVER_EPOCH: { type: 'plain_text', value: '1792039926' },
      FIRMWARE_DOWNLOAD_ORIGIN: { type: 'plain_text', value: 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev' },
      DOWNLOAD_HMAC_KEY_CURRENT: { type: 'secret_text', value: testSecrets.DOWNLOAD_HMAC_KEY_CURRENT }
    };
    assert.deepEqual(Object.keys(before.result.deployment_configs.production.env_vars || {}), []);
    const payload = { deployment_configs: { production: {
      compatibility_date: '2026-06-28', compatibility_flags: ['nodejs_compat'],
      d1_databases: { DB: { id: '2617e1e1-956f-42ce-a465-da56d84abf06' } },
      r2_buckets: { RELEASES_BUCKET: { name: 'e-track-firmware-p41-test-releases' } }, env_vars: variables
    } } };
    const response = await api('project-configure', projectRoute, 'PATCH', payload);
    const after = await api('project-after-configure', projectRoute);
    assert.ok(response.success && after.success, 'Configuration result requires reconciliation, not an automatic replay');
    const actual = after.result.deployment_configs.production;
    assert.deepEqual(actual.d1_databases, payload.deployment_configs.production.d1_databases);
    assert.deepEqual(actual.r2_buckets, payload.deployment_configs.production.r2_buckets);
    for (const key of publicVars) assert.equal(actual.env_vars[key].value, variables[key].value);
    assert.equal(actual.env_vars.DOWNLOAD_HMAC_KEY_CURRENT.type, 'secret_text');
    assert.deepEqual(after.result.deployment_configs.preview, before.result.deployment_configs.preview);
    report.configuredProject = project(after.result);
    report.secretReuse = { name: 'DOWNLOAD_HMAC_KEY_CURRENT', source: 'Existing approved test-secret input; no Worker credential rotation',
      configuredNameReadBack: true, valueNotReadableThroughPagesApi: true, realSignedDownloadNotYetRun: true };
    report.deployed = false;
  } else if (mode === 'protect') {
    const existing = await api('apps-before-protect', 'access/apps?per_page=100');
    assert.ok(existing.success);
    assert.ok(!existing.result.some(app => app.domain === `${projectName}.pages.dev`), 'Existing matching app must be inspected instead of recreated');
    const payload = { name: 'E-Track P4-3 Admin Test', domain: `${projectName}.pages.dev`, type: 'self_hosted',
      session_duration: '1h', app_launcher_visible: false, auto_redirect_to_identity: false, policies: [] };
    const created = await api('app-protect', 'access/apps', 'POST', payload);
    const after = await api('apps-after-protect', 'access/apps?per_page=100');
    assert.ok(after.success, 'Access write must be reconciled before any retry');
    report.matchingApps = after.result.filter(app => app.domain === payload.domain)
      .map(app => ({ id: app.id, name: app.name, domain: app.domain, type: app.type,
        policyCount: app.policies?.length ?? null, audiencePresent: !!app.aud }));
    if (!created.success) process.exitCode = 1;
    else {
      assert.equal(report.matchingApps.length, 1);
      assert.equal(created.result.domain, payload.domain);
      assert.ok(!created.result.policies?.length, 'Unexpected allow policy; do not deploy');
      report.accessApplicationCreated = true;
      report.ownerPolicyConfigured = false;
    }
  } else if (mode === 'create') {
    const inventory = JSON.parse(fs.readFileSync(path.join(publicDir, 'pages-inventory-01-summary.json'), 'utf8'));
    assert.deepEqual(inventory.p43Candidates, []);
    assert.ok(inventory.receipts.find(r => r.name === 'pages-1' && r.status === 200 && r.success));
    const name = 'e-track-firmware-p43-admin-test';
    const base = path.join(root, '.cache/p43/private/platform-login');
    const wranglerLog = path.join(privateDir, `${label}-wrangler.log`);
    guard(wranglerLog, path.join(privateDir, '.wrangler'));
    const env = { ...process.env, HOME: path.join(base, 'home'), USERPROFILE: path.join(base, 'home'),
      APPDATA: path.join(base, 'appdata'), LOCALAPPDATA: path.join(base, 'localappdata'),
      XDG_CONFIG_HOME: path.join(base, 'xdg-config'), XDG_CACHE_HOME: path.join(base, 'xdg-cache'),
      XDG_DATA_HOME: path.join(base, 'xdg-data'), CLOUDFLARE_ACCOUNT_ID: account,
      WRANGLER_LOG_PATH: wranglerLog, WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false' };
    for (const key of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY', 'CLOUDFLARE_EMAIL', 'CF_EMAIL']) delete env[key];
    const args = [path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/wrangler/bin/wrangler.js'),
      'pages', 'project', 'create', name, '--production-branch', 'main', '--compatibility-date', '2026-06-28', '--compatibility-flags', 'nodejs_compat'];
    report.cloudWritesAttempted = 1;
    const cli = spawnSync(process.execPath, args, { cwd: privateDir, env, windowsHide: true, encoding: 'utf8', timeout: 120000,
      stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 4 * 1024 * 1024 });
    save('cli.json', { args, exitCode: cli.status, signal: cli.signal, stdout: cli.stdout, stderr: cli.stderr }, true);
    report.cli = { operation: 'Create only the authorized isolated Pages project', exitCode: cli.status, signal: cli.signal };
    const actual = await api('project-after-create', `pages/projects/${name}`);
    assert.ok(actual.success, 'Creation result unresolved; no automatic create replay');
    assert.equal(actual.result.name, name);
    assert.equal(actual.result.subdomain, `${name}.pages.dev`);
    assert.equal(actual.result.production_branch, 'main');
    report.createdProject = project(actual.result);
    report.deployed = false;
    report.accessConfigured = false;
  } else {
  const projects = [];
  for (let page = 1; page <= 20; page++) {
    const json = await api(`pages-${page}`, `pages/projects?page=${page}&per_page=10`);
    assert.ok(json.success, 'Pages list failed; do not infer absence');
    projects.push(...json.result);
    if (json.result.length < 10) break;
    assert.ok(page < 20, 'Project inventory exceeds finite bound');
  }
  report.projects = projects.map(project);
  report.p43Candidates = projects.filter(p => p.name.includes('p43') || p.name.includes('p4-3')).map(p => p.name);
  for (const p of projects.filter(p => p.name === 'trace-update-admin-staging' || report.p43Candidates.includes(p.name))) {
    await api(`project-${p.name}`, `pages/projects/${p.name}`);
  }
  for (const [name, suffix] of [['access-apps', 'access/apps?per_page=100'], ['access-idps', 'access/identity_providers'],
    ['access-org', 'access/organizations']]) {
    const json = await api(name, suffix);
    if (!json.success) continue;
    if (name === 'access-apps') report.accessApps = json.result.map(a => ({ id: a.id, name: a.name, domain: a.domain, type: a.type }));
    if (name === 'access-idps') report.idps = json.result.map(p => ({ id: p.id, name: p.name, type: p.type }));
    if (name === 'access-org') report.accessOrg = { authDomain: json.result.auth_domain, name: json.result.name };
  }
  }
} catch (error) {
  report.failure = { name: error.name, code: error.code, message: String(error.message).split(token).join('[REDACTED]') };
  process.exitCode = 1;
} finally {
  report.endedAt = new Date().toISOString();
  save('summary.json', report);
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
}
