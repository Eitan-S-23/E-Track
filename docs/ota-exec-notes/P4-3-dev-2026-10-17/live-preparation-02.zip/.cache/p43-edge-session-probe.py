import collections
import datetime
import json
import os
import pathlib
import sqlite3
import sys

root = pathlib.Path(__file__).resolve().parent.parent
assert pathlib.Path.cwd().resolve() == root
source = pathlib.Path('C:/Users/SU/AppData/Local/Microsoft/Edge/User Data/Default/Network/Cookies')
public_output = root / '.cache/p43/live/edge-session-probe-01.json'
private_output = root / '.cache/p43/private/edge-session-probe-01.json'
assert not public_output.exists() and not private_output.exists()
domains = ['.cloudflare.com', 'cloudflare.com', '.dash.cloudflare.com', 'dash.cloudflare.com',
           '.sulovehuang.cloudflareaccess.com', 'sulovehuang.cloudflareaccess.com']
result = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'purpose': 'Read-only storage capability check for the user-selected existing Edge Cloudflare session',
          'source': str(source), 'sourceExists': source.exists(), 'python': sys.version.split()[0],
          'sqlite': sqlite3.sqlite_version, 'sourceModified': False,
          'credentialValuesReadOrDecrypted': False, 'fullProfileCopied': False}
connection = None
try:
    connection = sqlite3.connect(source.resolve().as_uri() + '?mode=ro&immutable=1', uri=True, timeout=2)
    connection.execute('PRAGMA query_only=ON')
    connection.execute('PRAGMA temp_store=MEMORY')
    query = '''SELECT host_key, name, expires_utc, length(encrypted_value),
                      hex(substr(encrypted_value,1,3)), length(value)
               FROM cookies WHERE host_key IN (?,?,?,?,?,?)'''
    rows = connection.execute(query, domains).fetchall()
    with private_output.open('x', encoding='utf-8') as file:
        json.dump({'columns': ['host', 'name', 'expires', 'encryptedBytes', 'prefixHex', 'plainBytes'],
                   'rows': rows, 'query': query, 'domains': domains,
                   'limitation': 'Immutable read omits any uncheckpointed WAL changes; metadata is not a live-session validity claim.'}, file, indent=2)
        file.write('\n')
    result.update({'openedReadOnlyImmutable': True, 'matchingRows': len(rows),
                   'encryptionPrefixCounts': dict(collections.Counter(row[4] for row in rows)),
                   'domainCounts': dict(collections.Counter(row[0] for row in rows)),
                   'plainValueCount': sum(row[5] > 0 for row in rows),
                   'limitation': 'Metadata only, no WAL freshness or authentication claim'})
except (OSError, sqlite3.Error) as error:
    result.update({'openedReadOnlyImmutable': False, 'errorType': type(error).__name__,
                   'sqliteErrorName': getattr(error, 'sqlite_errorname', None),
                   'error': str(error), 'next': 'Do not copy a locked profile or bypass browser protection'})
    sys.exitcode = 1
finally:
    if connection is not None:
        connection.close()
    with public_output.open('x', encoding='utf-8') as file:
        json.dump(result, file, indent=2)
        file.write('\n')
    print(json.dumps(result))
sys.exit(getattr(sys, 'exitcode', 0))
