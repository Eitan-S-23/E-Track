import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const [mode, label] = process.argv.slice(2);
assert.ok(['inventory', 'assets', 'credential-status', 'original-capabilities', 'original-remaining', 'channel-state'].includes(mode));
assert.match(label || '', /^[a-z0-9-]+$/);
const priorRoot = 'D:/github/my/E-Track/.cache/p41-dev-20261015';
const privateInput = path.join(priorRoot, '.cache/cf-auth-input');
const config = JSON.parse(fs.readFileSync(path.join(priorRoot, '.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json'), 'utf8'));
const originalConfigPath = 'D:/github/my/E-Track/app/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json';
const originalConfig = mode.startsWith('original-') ? JSON.parse(fs.readFileSync(originalConfigPath, 'utf8')) : null;
if (originalConfig) assert.equal(originalConfig.secrets.CLOUDFLARE_ACCOUNT_ID, config.account_id);
const token = originalConfig ? originalConfig.secrets.CLOUDFLARE_API_TOKEN.trim() : fs.readFileSync(path.join(privateInput, 'token.txt'), 'utf8').trim();
const secrets = JSON.parse(fs.readFileSync(path.join(privateInput, 'firmware-test-secrets.json'), 'utf8'));
assert.ok(token.length > 20);
assert.match(config.account_id, /^[a-f0-9]{32}$/);
const account = config.account_id;
const database = '2617e1e1-956f-42ce-a465-da56d84abf06';
const bucket = 'e-track-firmware-p41-test-releases';
const worker = 'e-track-firmware-p41-test';
assert.equal(config.name, worker);
assert.equal(config.d1_databases[0].database_id, database);
assert.equal(config.r2_buckets[0].bucket_name, bucket);
const sensitive = [token, ...Object.values(secrets)].filter(v => typeof v === 'string' && v.length > 10);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const scrub = text => sensitive.reduce((s, value) => s.split(value).join('[REDACTED]'), String(text));
function target(name, isPrivate = false) {
  assert.match(name, /^[a-z0-9_-]+\.(json|txt|bin)$/);
  const full = path.join(root, '.cache/p43', isPrivate ? 'private' : 'live', `${label}-${name}`);
  const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'live-preflight', '.', 'preflight', full],
    { cwd: root, windowsHide: true, encoding: 'utf8' });
  assert.equal(guard.status, 0, guard.stderr);
  assert.ok(!fs.existsSync(full), 'Refusing to replace a prior observation');
  fs.mkdirSync(path.dirname(full), { recursive: true });
  return full;
}
function save(name, value, isPrivate = false) {
  const text = JSON.stringify(value, null, 2) + '\n';
  fs.writeFileSync(target(name, isPrivate), isPrivate ? text : scrub(text), { flag: 'wx' });
}
async function boundedBody(response, max = 4 * 1024 * 1024) {
  const chunks = []; let total = 0;
  for await (const chunk of response.body || []) {
    total += chunk.length; assert.ok(total <= max, 'Response exceeds bounded observation size'); chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}
const receipts = [];
async function api(name, route, sql, params = []) {
  assert.ok(route === 'user/tokens/verify' || route.startsWith(`accounts/${account}/`));
  if (sql) {
    assert.equal(route, `accounts/${account}/d1/database/${database}/query`);
    assert.match(sql, /^SELECT\b/i); assert.ok(!sql.includes(';'));
  }
  let response;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      response = await fetch(`https://api.cloudflare.com/client/v4/${route}`, {
        method: sql ? 'POST' : 'GET', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: sql ? JSON.stringify({ sql, params }) : undefined, redirect: 'error', signal: AbortSignal.timeout(30000)
      });
      break;
    } catch (error) {
      save(`${name}-transport-${attempt}.json`, { name, attempt, operation: sql ? 'SELECT_ONLY' : 'GET',
        error: { name: error.name, code: error.code, causeCode: error.cause?.code }, timestamp: new Date().toISOString() });
      if (attempt === 2) throw error;
    }
  }
  const bytes = await boundedBody(response);
  let body;
  try { body = JSON.parse(bytes.toString('utf8')); } catch { body = null; }
  const receipt = { name, method: sql ? 'POST_SELECT_ONLY' : 'GET', route: route.replace(account, '<account>'),
    timestamp: new Date().toISOString(), status: response.status, cfRay: response.headers.get('cf-ray'),
    bodySha256: digest(bytes), bodyBytes: bytes.length, success: body ? body.success === true : response.ok,
    errors: body?.errors?.map(e => ({ code: e.code, message: scrub(e.message) })) };
  if (sql) {
    receipt.sql = sql; receipt.params = params;
    if (body?.success) assert.ok(body.result.every(r => r.success && r.meta.rows_written === 0 && !r.meta.changed_db));
  }
  receipts.push(receipt);
  save(`${name}-receipt.json`, receipt);
  return { receipt, body, bytes, headers: response.headers };
}
function safeProject(p) {
  return { name: p.name, subdomain: p.subdomain, productionBranch: p.production_branch,
    deployments: { latest: p.latest_deployment?.id, canonical: p.canonical_deployment?.id },
    configs: Object.fromEntries(Object.entries(p.deployment_configs || {}).map(([k,v]) => [k, {
      compatibility_date: v.compatibility_date, compatibility_flags: v.compatibility_flags,
      d1_databases: v.d1_databases, r2_buckets: v.r2_buckets,
      variables: Object.fromEntries(Object.entries(v.env_vars || {}).map(([n, x]) => [n, {
        type: x.type, present: typeof x.value === 'string' && x.value.length > 0,
        ...(x.type === 'plain_text' && ['ENVIRONMENT','APP_ID','FIRMWARE_DOWNLOAD_ORIGIN','FIRMWARE_V2_CUTOVER_EPOCH','DOWNLOAD_TOKEN_KEY_VERSION'].includes(n) ? { value: x.value } : {})
      }])) }])) };
}
try {
  save('private-input-shape.json', { source: originalConfig ? originalConfigPath : privateInput, configSource: '.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json',
    accountMatchesPriorBindings: true, tokenPresent: true, secretNames: Object.keys(secrets),
    tokenModifiedAt: fs.statSync(originalConfig ? originalConfigPath : path.join(privateInput, 'token.txt')).mtime.toISOString() });
  if (mode === 'channel-state') {
    const route = `accounts/${account}/d1/database/${database}/query`;
    for (const [name, sql] of [
      ['channels-final', 'SELECT id,app_id,device_model,name,current_release_id,revision,disable_latest,disable_downloads,updated_at FROM firmware_channels ORDER BY id'],
      ['releases-final', 'SELECT id,app_id,device_model,version_code,state,archived,target_image_sha256 FROM firmware_releases ORDER BY id'],
      ['idempotency-final', 'SELECT action,release_id,state,request_id,created_epoch_seconds,retained_until,original_expires_at FROM firmware_admin_idempotency']
    ]) {
      const result = await api(name, route, sql);
      assert.ok(result.body?.success);
      save(`${name}.json`, result.body.result);
    }
  } else if (mode === 'original-capabilities' || mode === 'original-remaining') {
    if (mode === 'original-capabilities') {
    const verify = await api('credential', 'user/tokens/verify');
    save('credential-state.json', { status: verify.body?.result?.status, expires_on: verify.body?.result?.expires_on });
    const pages = await api('pages', `accounts/${account}/pages/projects?per_page=100`);
    if (pages.body?.success) {
      save('pages.json', { projects: pages.body.result.map(safeProject), result_info: pages.body.result_info });
      for (const p of pages.body.result.filter(p => p.name.includes('p43') || p.name.includes('p4-3') || p.name === 'trace-update-admin-staging')) {
        save(`project-${p.name}.json`, p, true);
      }
    }
    const access = await api('access-apps', `accounts/${account}/access/apps?per_page=100`);
    if (access.body?.success) {
      save('access-apps.json', { applications: access.body.result.map(a => ({ id: a.id, name: a.name, domain: a.domain,
        type: a.type, allowed_idps: a.allowed_idps, session_duration: a.session_duration, audHash: a.aud ? digest(a.aud) : null })), result_info: access.body.result_info });
      save('access-apps.json', access.body.result, true);
    }
    }
    const idps = await api('access-idps', `accounts/${account}/access/identity_providers`);
    if (idps.body?.success) {
      save('access-idps.json', idps.body.result.map(p => ({ id: p.id, name: p.name, type: p.type })));
      save('access-idps.json', idps.body.result, true);
    }
    const org = await api('access-organization', `accounts/${account}/access/organizations`);
    if (org.body?.success) save('access-organization.json', { auth_domain: org.body.result.auth_domain, name: org.body.result.name });
  } else if (mode === 'credential-status') {
    const oauthPath = 'C:/Users/SU/AppData/Roaming/xdg.config/.wrangler/config/default.toml';
    if (fs.existsSync(oauthPath)) {
      const toml = fs.readFileSync(oauthPath, 'utf8');
      const expiry = toml.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
      const scopeLine = toml.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1];
      save('oauth-input-status.json', { path: oauthPath, modifiedAt: fs.statSync(oauthPath).mtime.toISOString(),
        expirationTime: expiry || null, expired: !expiry || Date.parse(expiry) <= Date.now(),
        refreshPresent: /^refresh_token\s*=\s*"[^"]+"/m.test(toml),
        scopes: scopeLine ? [...scopeLine.matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]) : null, credentialValuesPersisted: false });
    }
  } else if (mode === 'assets') {
    const { r2KeyFor } = await import(pathToFileURL(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/scripts/firmware-schema.mjs')));
    const currentAssets = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/inventory-01-d1-assets.json'), 'utf8'))[0].results;
    const currentReleases = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/inventory-01-d1-releases.json'), 'utf8'))[0].results;
    const approved = new Set(['fw_e1abd9e066161562fb72322b81ee7c06bf4719df7d6f89e769811a7460373648', 'fw_12367eee317a0774a7271cf982ee7f933c6b089336645f9e607501105e72bf0c']);
    assert.equal(currentAssets.length, 6);
    const verified = [];
    for (const asset of currentAssets) {
      assert.ok(approved.has(asset.release_id));
      assert.equal(asset.r2_state, 'available');
      const release = currentReleases.find(r => r.id === asset.release_id);
      assert.equal(release.app_id, 'trace'); assert.equal(release.device_model, 'e-track-at32f435');
      assert.match(asset.file_name, /^[A-Za-z0-9._-]+$/);
      assert.equal(asset.r2_key, r2KeyFor({ appId: release.app_id, deviceModel: release.device_model,
        versionCode: release.version_code, releaseTag: release.release_tag }, { fileName: asset.file_name }));
      const priorObservation = path.join(root, '.cache/p43/live', `assets-03-r2-${asset.id}.json`);
      if (label !== 'assets-03' && fs.existsSync(priorObservation)) {
        const observed = JSON.parse(fs.readFileSync(priorObservation, 'utf8'));
        assert.equal(observed.status, 200);
        assert.equal(observed.observedSize, asset.size_bytes);
        assert.equal(observed.observedSha256, asset.sha256);
        verified.push({ ...observed, reusedCurrentP43Observation: path.relative(root, priorObservation),
          evidenceSha256: digest(fs.readFileSync(priorObservation)) });
        continue;
      }
      const route = `accounts/${account}/r2/buckets/${bucket}/objects/${asset.r2_key.split('/').map(encodeURIComponent).join('/')}`;
      const result = await api(`r2-${asset.id}`, route);
      const observed = { assetId: asset.id, releaseId: asset.release_id, kind: asset.kind,
        status: result.receipt.status, cfRay: result.receipt.cfRay, expectedSize: asset.size_bytes,
        observedSize: result.bytes.length, expectedSha256: asset.sha256, observedSha256: digest(result.bytes),
        etag: result.headers.get('etag'), contentType: result.headers.get('content-type') };
      verified.push(observed);
      save(`r2-${asset.id}.json`, observed);
      if (result.receipt.status !== 200) break;
    }
    const allVerified = verified.length === 6 && verified.every(v => v.status === 200 && v.expectedSize === v.observedSize && v.expectedSha256 === v.observedSha256);
    save('r2-integrity.json', { allVerified, observations: verified });
    if (!allVerified) process.exitCode = 1;
    const source = await api('worker-source', `accounts/${account}/workers/scripts/${worker}`);
    assert.equal(source.receipt.status, 200);
    fs.writeFileSync(target('worker-source.bin', true), source.bytes, { flag: 'wx' });
    const sourceText = source.bytes.toString('utf8');
    save('worker-source-summary.json', { bytes: source.bytes.length, sha256: digest(source.bytes), contentType: source.headers.get('content-type'),
      hasHono: sourceText.includes('hono'), hasCorsImport: /hono\/cors/.test(sourceText),
      hasRawRequestHandlers: sourceText.includes('c.req.raw'), privateSourceOnly: true });
    const oauthPath = 'C:/Users/SU/AppData/Roaming/xdg.config/.wrangler/config/default.toml';
    if (fs.existsSync(oauthPath)) {
      const toml = fs.readFileSync(oauthPath, 'utf8');
      const expiry = toml.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
      const scopeLine = toml.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1];
      save('oauth-input-status.json', { path: oauthPath, modifiedAt: fs.statSync(oauthPath).mtime.toISOString(),
        expirationTime: expiry || null, expired: !expiry || Date.parse(expiry) <= Date.now(),
        refreshPresent: /^refresh_token\s*=\s*"[^"]+"/m.test(toml),
        scopes: scopeLine ? [...scopeLine.matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]) : null, credentialValuesPersisted: false });
    }
    const queryRoute = `accounts/${account}/d1/database/${database}/query`;
    const refs = await api('d1-all-channel-references', queryRoute,
      'SELECT id,app_id,device_model,name,current_release_id,revision,disable_latest,disable_downloads,updated_at FROM firmware_channels ORDER BY id');
    if (refs.body?.success) save('d1-all-channel-references.json', refs.body.result);
    const patch = await api('d1-patch-dependencies', queryRoute,
      'SELECT a.id,a.release_id,a.base_image_sha256,a.base_vcode,r.state,r.archived FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id WHERE a.kind=?', ['patch']);
    if (patch.body?.success) save('d1-patch-dependencies.json', patch.body.result);
  } else {
  const verify = await api('credential', 'user/tokens/verify');
  save('credential-state.json', { status: verify.body?.result?.status, expires_on: verify.body?.result?.expires_on,
    not_before: verify.body?.result?.not_before });
  const settings = await api('worker-settings', `accounts/${account}/workers/scripts/${worker}/settings`);
  if (settings.body?.success) {
    const value = settings.body.result;
    save('worker-settings.json', { ...value, bindings: value.bindings.map(b => b.type === 'secret_text' ? { name: b.name, type: b.type } : b) });
    assert.equal(value.bindings.find(b => b.name === 'DB').id, database);
    assert.equal(value.bindings.find(b => b.name === 'RELEASES_BUCKET').bucket_name, bucket);
  }
  const deployments = await api('worker-deployments', `accounts/${account}/workers/scripts/${worker}/deployments`);
  if (deployments.body?.success) save('worker-deployments.json', deployments.body.result);
  const pages = await api('pages', `accounts/${account}/pages/projects?per_page=100`);
  if (pages.body?.success) {
    save('pages.json', { projects: pages.body.result.map(safeProject), result_info: pages.body.result_info });
    for (const p of pages.body.result.filter(p => p.name.includes('p43') || p.name.includes('p4-3') || p.name === 'trace-update-admin-staging')) {
      save(`project-${p.name}.json`, p, true);
    }
  }
  const access = await api('access-apps', `accounts/${account}/access/apps?per_page=100`);
  if (access.body?.success) {
    save('access-apps.json', { applications: access.body.result.map(a => ({ id: a.id, name: a.name, domain: a.domain, type: a.type,
      allowed_idps: a.allowed_idps, session_duration: a.session_duration, audHash: a.aud ? digest(a.aud) : null })), result_info: access.body.result_info });
    save('access-apps.json', access.body.result, true);
  }
  const idps = await api('access-idps', `accounts/${account}/access/identity_providers`);
  if (idps.body?.success) {
    save('access-idps.json', idps.body.result.map(p => ({ id: p.id, name: p.name, type: p.type })));
    save('access-idps.json', idps.body.result, true);
  }
  const org = await api('access-organization', `accounts/${account}/access/organizations`);
  if (org.body?.success) save('access-organization.json', { auth_domain: org.body.result.auth_domain, name: org.body.result.name });
  const queryRoute = `accounts/${account}/d1/database/${database}/query`;
  const scope = ['trace','e-track-at32f435'];
  for (const [name, sql, params] of [
    ['channels', 'SELECT * FROM firmware_channels WHERE app_id=? AND device_model=? ORDER BY name', scope],
    ['releases', 'SELECT * FROM firmware_releases WHERE app_id=? AND device_model=? ORDER BY version_code', scope],
    ['assets', 'SELECT a.* FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id WHERE r.app_id=? AND r.device_model=? ORDER BY r.version_code,a.kind', scope],
    ['audit', 'SELECT id,app_id,actor,actor_type,action,target_type,target_id,request_id,reason,before_json,after_json,created_at FROM audit_logs WHERE app_id=? ORDER BY created_at,id', ['trace']],
    ['app-config', 'SELECT * FROM app_config WHERE app_id=?', ['trace']],
    ['idempotency-state', 'SELECT action,release_id,state,request_id,created_epoch_seconds,retained_until,original_expires_at FROM firmware_admin_idempotency', []],
    ['schema-tables', "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name", []]
  ]) {
    const result = await api(`d1-${name}`, queryRoute, sql, params);
    if (result.body?.success) save(`d1-${name}.json`, result.body.result);
  }
  }
} catch (error) {
  save('failure.json', { name: error.name, message: scrub(error.message), code: error.code });
  process.exitCode = 1;
} finally {
  save('summary.json', { mode, label, businessMutations: 0, source: 'Current authenticated Cloudflare API observations; not an Access browser exercise', receipts });
  process.stdout.write(JSON.stringify({ label, observations: receipts.map(r => ({ name: r.name, status: r.status, success: r.success, errors: r.errors })), businessMutations: 0 }) + '\n');
}
