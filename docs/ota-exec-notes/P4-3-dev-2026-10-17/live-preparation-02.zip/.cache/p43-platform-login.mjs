import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const label = process.argv[2];
assert.match(label || '', /^platform-login-[0-9]+$/);
assert.equal(process.argv[3], '--existing-edge', 'Use only the user-selected existing Edge account');
const base = path.join(root, '.cache/p43/private/platform-login');
const profile = path.join(root, '.cache/p43/browser-owner');
const reportPath = path.join(root, '.cache/p43/live', `${label}.json`);
const dirs = Object.fromEntries(['home', 'appdata', 'localappdata', 'xdg-config', 'xdg-cache', 'xdg-data', 'tmp', 'logs']
  .map(name => [name, path.join(base, name)]));
const privateLog = path.join(dirs.logs, `${label}-console.log`);
const wranglerLog = path.join(dirs.logs, `${label}-wrangler.log`);
const chromeLog = path.join(dirs.logs, `${label}-chrome.log`);
const failureLog = path.join(dirs.logs, `${label}-failure.txt`);
const requestPath = path.join(base, `${label}-request.json`);
const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'login-preflight', '.', 'preflight',
  base, profile, reportPath, privateLog, wranglerLog, chromeLog, failureLog, requestPath, ...Object.values(dirs)],
{ cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(guard.status, 0, 'Login output preflight failed');
for (const file of [reportPath, privateLog, wranglerLog, failureLog, requestPath]) {
  assert.ok(!fs.existsSync(file), 'Refusing to overwrite a prior login observation');
}
for (const dir of Object.values(dirs)) fs.mkdirSync(dir, { recursive: true });
const env = { ...process.env, HOME: dirs.home, USERPROFILE: dirs.home,
  APPDATA: dirs.appdata, LOCALAPPDATA: dirs.localappdata,
  XDG_CONFIG_HOME: dirs['xdg-config'], XDG_CACHE_HOME: dirs['xdg-cache'], XDG_DATA_HOME: dirs['xdg-data'],
  TEMP: dirs.tmp, TMP: dirs.tmp, TMPDIR: dirs.tmp, DEBUG: '', CHROME_LOG_FILE: chromeLog,
  WRANGLER_LOG_PATH: wranglerLog, WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false' };
for (const key of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY',
  'CLOUDFLARE_EMAIL', 'CF_EMAIL', 'WRANGLER_AUTH_URL', 'WRANGLER_TOKEN_URL', 'WRANGLER_REVOKE_URL',
  'WRANGLER_AUTH_DOMAIN', 'WRANGLER_CLIENT_ID', 'CLOUDFLARE_API_ENVIRONMENT',
  'WRANGLER_CF_AUTHORIZATION_TOKEN', 'CLOUDFLARE_ACCESS_CLIENT_ID', 'CLOUDFLARE_ACCESS_CLIENT_SECRET']) delete env[key];
const requestedScopes = ['account:read', 'user:read', 'pages:write'];
const allScopes = [...requestedScopes, 'offline_access'].sort();
const admin = path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin');
const report = { label, startedAt: new Date().toISOString(), purpose: 'Legitimate platform OAuth, not an Admin Access session',
  browser: 'User-selected existing Microsoft Edge session; no agent profile write or cookie copy',
  privateConfigRoot: base, requestedScopes, cloudMutations: 0, adminExercise: 'NOT_RUN' };
const log = fs.createWriteStream(privateLog, { flags: 'wx' });
let child, closed, hardDeadline, entryServer, entryResponse, entryDeadline;
const emit = value => process.stdout.write(JSON.stringify(value) + '\n');
const sha256 = value => createHash('sha256').update(value).digest('hex');
function notifyRequester() {
  const session = process.env.CC_SESSION_KEY || '';
  const match = /^(?:feishu|lark):[^:]+:(ou_[a-z0-9]+)$/.exec(session);
  if (!match || !process.env.CC_PROJECT || !process.env.CC_DATA_DIR) {
    return { delivered: false, reason: 'No verified current requester route; no guessed mention' };
  }
  const message = `<at user_id="${match[1]}">requester</at> P4-3 \u9700\u8981\u4f60\u5728\u73b0\u6709 Edge \u5185\u5b8c\u6210\u4e00\u6b21\u4f1a\u8bdd\u63a5\u5165\uff0c\u4e0d\u662f\u91cd\u65b0\u6279\u51c6\u4efb\u52a1\u3002\u8bf7\u628a http://127.0.0.1:8975/ \u590d\u5236\u5230\u5f53\u524d\u5df2\u7ecf\u767b\u5f55\u539f Cloudflare \u8d26\u53f7\u7684 Microsoft Edge \u5730\u5740\u680f\uff0c\u52ff\u76f4\u63a5\u70b9\u804a\u5929\u94fe\u63a5\uff08\u53ef\u80fd\u6253\u5f00\u9ed8\u8ba4 Chrome\uff09\u3002\u5165\u53e3\u53ea\u63a5\u53d7 Edge\uff1b\u70b9\u51fb\u7ee7\u7eed\u540e\uff0c\u5728\u5b98\u65b9 Cloudflare \u9875\u9762\u786e\u8ba4 Wrangler \u8fde\u63a5\uff0c\u8303\u56f4\u4ec5 account:read\u3001user:read\u3001pages:write\u3001offline_access\u3002\u65e0\u9700\u6362\u8d26\u53f7\u3001\u521b\u5efa\u8d26\u53f7\u6216\u53d1\u9001\u51ed\u636e\uff1b\u9875\u9762\u5b8c\u6210\u540e\u65e0\u9700\u804a\u5929\u56de\u590d\uff0c\u6211\u4f1a\u89c2\u5bdf\u56de\u8c03\u7ee7\u7eed\u3002\u5165\u53e3\u7b49\u5f85 10 \u5206\u949f\uff0c\u5b98\u65b9 120 \u79d2\u56de\u8c03\u4ece\u4f60\u70b9\u51fb\u7ee7\u7eed\u65f6\u624d\u5f00\u59cb\u3002`;
  const sent = spawnSync('D:/github/my/cc-connect-thread-guard/build/cc-connect.exe',
    ['send', '--project', process.env.CC_PROJECT, '--session', session, '--stdin'],
    { cwd: root, env, windowsHide: true, encoding: 'utf8', input: message, timeout: 20000 });
  const output = `${sent.stdout || ''}${sent.stderr || ''}`;
  return { delivered: sent.status === 0 && output.includes('Message sent successfully.'), exitCode: sent.status,
    receipt: output.split(session).join('[SESSION]').split(match[1]).join('[REQUESTER]'), scope: 'Current requester/current session only' };
}
async function waitForExistingEdge() {
  const pending = new Promise((resolve, reject) => {
    let started = false;
    entryServer = http.createServer((req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('Referrer-Policy', 'no-referrer');
      res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
      if (req.headers.host !== '127.0.0.1:8975' || req.method !== 'GET') {
        res.writeHead(403).end('Forbidden'); return;
      }
      const edge = / Edg\/([0-9.]+)/.exec(String(req.headers['user-agent'] || ''))?.[1];
      if (!edge) {
        report.rejectedNonEdgeVisits = (report.rejectedNonEdgeVisits || 0) + 1;
        res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8' }).end('<!doctype html><meta charset="utf-8"><title>\u8bf7\u4f7f\u7528\u73b0\u6709 Microsoft Edge</title><h1>\u5f53\u524d\u4e0d\u662f Microsoft Edge\uff0c\u672a\u542f\u52a8\u767b\u5f55</h1><p>\u8bf7\u5c06 http://127.0.0.1:8975/ \u590d\u5236\u5230\u5df2\u7ecf\u767b\u5f55\u539f Cloudflare \u8d26\u53f7\u7684 Microsoft Edge \u5730\u5740\u680f\u3002\u4e0d\u8981\u91cd\u65b0\u8f93\u5165\u8d26\u53f7\u6216\u6362\u7528\u5176\u4ed6\u6d4f\u89c8\u5668\u3002</p>');
        return;
      }
      if (req.url === '/') {
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.end('<!doctype html><meta charset="utf-8"><title>P4-3 Edge \u4f1a\u8bdd\u63a5\u5165</title><h1>P4-3\uff1a\u4f7f\u7528\u5f53\u524d\u5df2\u767b\u5f55\u7684\u539f Cloudflare \u8d26\u53f7</h1><p>\u6b64\u672c\u673a\u5165\u53e3\u4e0d\u6536\u96c6\u5bc6\u7801\u6216 cookie\uff0c\u4e0d\u6267\u884c\u90e8\u7f72\u3002</p><p>\u70b9\u51fb\u540e\u4ec5\u786e\u8ba4\u5b98\u65b9 Wrangler \u4e0e\u73b0\u6709\u8d26\u53f7\u7684\u8fde\u63a5\uff0c\u4e0d\u662f\u91cd\u65b0\u6279\u51c6 P4-3\u3002</p><p><a href="/start">\u7ee7\u7eed\u5230\u5b98\u65b9 Cloudflare \u9875\u9762</a></p><p>\u8bf7\u6c42\u8303\u56f4\uff1aaccount:read\u3001user:read\u3001pages:write\u3001offline_access\u3002\u5b98\u65b9\u56de\u8c03\u7b49\u5f85 120 \u79d2\u3002</p>');
      } else if (req.url === '/start' && !started && req.headers['sec-fetch-mode'] === 'navigate') {
        report.entryBrowser = { family: 'Microsoft Edge', version: edge, source: 'Actual navigation User-Agent, not an authentication identity' };
        started = true; clearTimeout(entryDeadline); entryResponse = res; resolve();
      } else res.writeHead(409).end('No additional login is started.');
    });
    entryServer.once('error', reject);
    entryServer.listen(8975, '127.0.0.1', () => {
      report.localEntry = { url: 'http://127.0.0.1:8975/', waitSeconds: 600, loopbackOnly: true };
      report.reminder = notifyRequester();
      emit({ label, phase: 'EXISTING_EDGE_ENTRY_READY', ...report.localEntry,
        reminderDelivered: report.reminder.delivered, accountRule: 'Use only the original project account already signed in to Edge' });
    });
    entryDeadline = setTimeout(() => reject(new Error('Existing Edge entry was not opened within its bound')), 600000);
  });
  await pending;
}
async function verifyAccount(token) {
  const prior = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8'));
  assert.match(prior.account_id, /^[a-f0-9]{32}$/);
  const observations = [];
  for (const [name, route] of [['account', `accounts/${prior.account_id}`],
    ['pages', `accounts/${prior.account_id}/pages/projects?per_page=100`]]) {
    const result = await fetch(`https://api.cloudflare.com/client/v4/${route}`, {
      headers: { Authorization: `Bearer ${token}` }, redirect: 'error', signal: AbortSignal.timeout(30000) });
    const bytes = Buffer.from(await result.arrayBuffer());
    assert.ok(bytes.length < 4 * 1024 * 1024);
    const json = JSON.parse(bytes.toString('utf8'));
    fs.writeFileSync(path.join(base, `${label}-${name}.json`), bytes, { flag: 'wx' });
    observations.push({ name, method: 'GET', status: result.status, success: json.success === true,
      cfRay: result.headers.get('cf-ray'), bodySha256: sha256(bytes),
      ...(name === 'account' && json.success ? { matchesApprovedAccount: json.result.id === prior.account_id } : {}),
      ...(name === 'pages' && json.success ? { projectNames: json.result.map(p => p.name), resultInfo: json.result_info } : {}),
      errors: json.errors?.map(e => ({ code: e.code })) });
  }
  return observations;
}
try {
  await waitForExistingEdge();
  const args = [path.join(admin, 'node_modules/wrangler/bin/wrangler.js'), 'login', '--browser=false', '--scopes', ...requestedScopes];
  child = spawn(process.execPath, args, { cwd: base, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  report.loginPid = child.pid;
  let output = '', navigation;
  child.stdout.on('data', bytes => { log.write(bytes); output += bytes.toString('utf8'); });
  child.stderr.on('data', bytes => { log.write(bytes); output += bytes.toString('utf8'); });
  closed = new Promise(resolve => {
    child.once('error', error => resolve({ exitCode: null, errorName: error.name, code: error.code }));
    child.once('close', (exitCode, signal) => resolve({ exitCode, signal }));
  });
  hardDeadline = setTimeout(() => child.kill(), 165000);
  for (let i = 0; i < 100 && child.exitCode === null; i++) {
    const match = /Visit this link to authenticate: (https:\/\/[^\s]+)/.exec(output);
    if (match) { navigation = match[1].replace(/\u001b\[[0-9;]*m/g, ''); break; }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert.ok(navigation, 'Official CLI did not provide a login URL');
  const url = new URL(navigation);
  assert.equal(url.origin, 'https://dash.cloudflare.com');
  assert.equal(url.pathname, '/oauth2/auth');
  assert.equal(url.searchParams.get('client_id'), '54d11594-84e4-41aa-b438-e81b8fa78ee7');
  assert.equal(url.searchParams.get('redirect_uri'), 'http://localhost:8976/oauth/callback');
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
  assert.deepEqual(url.searchParams.get('scope').split(' ').sort(), allScopes);
  assert.ok(url.searchParams.get('state') && url.searchParams.get('code_challenge'));
  fs.writeFileSync(requestPath, JSON.stringify({ url: navigation }, null, 2) + '\n', { flag: 'wx' });
  report.oauthRequest = { origin: url.origin, path: url.pathname, scopes: allScopes, pkce: 'S256',
    callback: 'http://localhost:8976/oauth/callback', fullUrlPrivate: true };
  entryResponse.writeHead(302, { Location: navigation }).end();
  report.navigation = { redirectToOfficialOAuth: true, fullUrlPrivate: true, browser: 'Existing Edge, opened by user' };
  emit({ label, phase: 'EXISTING_EDGE_OFFICIAL_OAUTH', trustedOrigin: url.origin, fullUrlOmitted: true,
    scopes: allScopes, officialCallbackDeadlineSeconds: 120 });
  report.cli = await closed;
  report.timedOut = output.includes('Timed out waiting for authorization code');
  report.loginSucceeded = report.cli.exitCode === 0 && output.includes('Successfully logged in.');
  if (report.loginSucceeded) {
    const configPaths = [path.join(dirs['xdg-config'], '.wrangler/config/default.toml'),
      path.join(dirs.home, '.wrangler/config/default.toml'),
      path.join(dirs.appdata, 'xdg.config/.wrangler/config/default.toml')];
    const found = configPaths.filter(p => fs.existsSync(p));
    assert.equal(found.length, 1, 'Expected exactly one contained OAuth configuration');
    const toml = fs.readFileSync(found[0], 'utf8');
    const token = toml.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1];
    assert.ok(token);
    report.oauthConfiguration = { path: found[0], expirationTime: toml.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1] };
    report.accountVerification = await verifyAccount(token);
  } else process.exitCode = 1;
} catch (error) {
  fs.writeFileSync(failureLog, String(error.stack || error), { flag: 'wx' });
  report.failure = { name: error.name, code: error.code || null, detailPrivate: true };
  process.exitCode = 1;
} finally {
  clearTimeout(hardDeadline);
  clearTimeout(entryDeadline);
  if (child && child.exitCode === null && child.signalCode === null) child.kill();
  if (closed && !report.cli) report.cli = await closed;
  if (entryResponse && !entryResponse.writableEnded) entryResponse.writeHead(503).end('Login preparation failed; no credential was collected here.');
  if (entryServer) { entryServer.closeAllConnections(); await new Promise(resolve => entryServer.close(resolve)); }
  report.localEntryClosed = true;
  log.end();
  report.endedAt = new Date().toISOString();
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  emit(report);
}
