/**
  **************************************************************************
  * @file     at32f435_437_clock.c
  * @brief    system clock config program
  **************************************************************************
  *                       Copyright notice & Disclaimer
  *
  * The software Board Support Package (BSP) that is made available to 
  * download from Artery official website is the copyrighted work of Artery. 
  * Artery authorizes customers to use, copy, and distribute the BSP 
  * software and its related documentation for the purpose of design and 
  * development in conjunction with Artery microcontrollers. Use of the 
  * software is governed by this copyright notice and the following disclaimer.
  *
  * THIS SOFTWARE IS PROVIDED ON "AS IS" BASIS WITHOUT WARRANTIES,
  * GUARANTEES OR REPRESENTATIONS OF ANY KIND. ARTERY EXPRESSLY DISCLAIMS,
  * TO THE FULLEST EXTENT PERMITTED BY LAW, ALL EXPRESS, IMPLIED OR
  * STATUTORY OR OTHER WARRANTIES, GUARANTEES OR REPRESENTATIONS,
  * INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
  *
  **************************************************************************
  */

/* includes ------------------------------------------------------------------*/
#include "at32f435_437_clock.h"

/**
  * @brief  system clock config program
  * @note   the system clock is configured as follow:
  *         - system clock        = (hick / 6 * pll_ns)/(pll_ms * pll_fr)
  *         - system clock source = pll (hick)
  *         - sclk                = 288000000
  *         - ahbdiv              = 1
  *         - ahbclk              = 288000000
  *         - apb1div             = 2
  *         - apb1clk             = 144000000
  *         - apb2div             = 2
  *         - apb2clk             = 144000000
  *         - pll_ns              = 72
  *         - pll_ms              = 1
  *         - pll_fr              = 2
  * @param  none
  * @retval none
  */
void system_clock_config(void)
{
  /* enable pwc periph clock */
  crm_periph_clock_enable(CRM_PWC_PERIPH_CLOCK, TRUE);

  /* config ldo voltage */
  pwc_ldo_output_voltage_set(PWC_LDO_OUTPUT_1V3);
 
  /* set the flash clock divider */
  flash_clock_divider_set(FLASH_CLOCK_DIV_3);

  /* reset crm */
  crm_reset();

  /* enable hick */
  crm_clock_source_enable(CRM_CLOCK_SOURCE_HICK, TRUE);

   /* wait till hick is ready */
  while(crm_flag_get(CRM_HICK_STABLE_FLAG) != SET)
  {
  }


  /* config pll clock resource */
  crm_pll_config(CRM_PLL_SOURCE_HICK, 72, 1, CRM_PLL_FR_2);

  /* enable pll */
  crm_clock_source_enable(CRM_CLOCK_SOURCE_PLL, TRUE);

  /* wait till pll is ready */
  while(crm_flag_get(CRM_PLL_STABLE_FLAG) != SET)
  {
  }


  /* config ahbclk */
  crm_ahb_div_set(CRM_AHB_DIV_1);

  /* config apb2clk */
  crm_apb2_div_set(CRM_APB2_DIV_2);

  /* config apb1clk */
  crm_apb1_div_set(CRM_APB1_DIV_2);

  /* enable auto step mode */
  crm_auto_step_mode_enable(TRUE);


  /* select pll as system clock source */
  crm_sysclk_switch(CRM_SCLK_PLL);

  /* wait till pll is used as system clock source */
  while(crm_sysclk_switch_status_get() != CRM_SCLK_PLL)
  {
  }


  /* disable auto step mode */
  crm_auto_step_mode_enable(FALSE);


  /* update system_core_clock global variable */
  system_core_clock_update();
}


/**
  * @brief  确保片上 SRAM 配置为 512KB（EOPB0）。
  *         由 startup 的 Reset_Handler 在 SystemInit 之前调用：此时 RW/ZI
  *         尚未初始化，本函数只允许使用局部变量与外设寄存器。
  *         若 EOPB0 已是 512K 直接返回；否则按官方流程 擦除用户系统数据
  *         （SDK 函数内部保留 FAP）→ 编程 EOPB0 → 系统复位，复位后新
  *         SRAM 容量生效（代价：flash 零等待区 256K→128K）。
  *         注意：EOPB0 存储含反码字节，改小值也可能出现 0→1 位翻转，
  *         必须先擦除，不能只编程。
  */
void extend_sram_512k(void)
{
  if((USD->eopb0 & 0xFF) == FLASH_EOPB0_SRAM_512K)
  {
    return;
  }

  flash_unlock();
  flash_user_system_data_erase();
  flash_eopb0_config(FLASH_EOPB0_SRAM_512K);
  flash_lock();

  /* 编程后读回校验：失败则不复位，维持 384K 继续运行，
     避免陷入复位循环（后续使用扩展区的模块自行探测容量） */
  if((USD->eopb0 & 0xFF) == FLASH_EOPB0_SRAM_512K)
  {
    nvic_system_reset();
  }
}
