# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: firmware-ui.spec.ts >> recovery-download: interrupted reconciliation preserves intent after 403/IDEMPOTENCY_RESULT_EXPIRED/valid
- Location: test\firmware-ui.spec.ts:282:3

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#confirmTitle')
Expected: "Firmware operation unconfirmed"
Received: "Firmware operation not confirmed"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('#confirmTitle') with timeout 5000ms
  - waiting for locator('#confirmTitle')
    - locator resolved to <h2 id="confirmTitle" class="confirm-title">Reconcile original request</h2>
    - unexpected value "Reconcile original request"
    13 × locator resolved to <h2 id="confirmTitle" class="confirm-title">Firmware operation not confirmed</h2>
       - unexpected value "Firmware operation not confirmed"

```

```yaml
- heading "Firmware operation not confirmed" [level=2]
```

# Test source

```ts
  196 |   await expect(releaseButton(page, "fw-new", "disable")).toBeDisabled();
  197 |   await expect(releaseButton(page, "fw-new", "recovery-download")).toBeDisabled();
  198 |   await channelButton(page, "beta", "stop-downloads").click();
  199 |   await expect(page.locator("#confirmInput")).toBeHidden();
  200 |   await page.locator("#confirmMaintenance").fill("download incident"); await fillConfirmation(page);
  201 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed"); await closeResult(page);
  202 |   expect(data.channels[1]).toMatchObject({ disableLatest: false, disableDownloads: true });
  203 |   await channelButton(page, "beta", "resume-downloads").click();
  204 |   await expect(page.locator("#confirmMaintenance")).toBeHidden(); await fillConfirmation(page);
  205 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  206 |   expect(data.writes[1].body).not.toHaveProperty("maintenanceMessage");
  207 | });
  208 | 
  209 | test("viewer and unavailable/reference-protected releases cannot write", async ({ page }) => {
  210 |   const data = await mockAdmin(page, "en", "viewer");
  211 |   await expect(channelButton(page, "beta", "stop-downloads")).toBeDisabled();
  212 |   await expect(releaseButton(page, "fw-new", "publish").first()).toBeDisabled();
  213 |   expect(data.writes).toHaveLength(0);
  214 |   data.role = "owner"; data.actor = "owner@example.test";
  215 |   data.releases[0].state = "draft"; data.releases[2].archived = true;
  216 |   await page.locator("#refreshButton").click();
  217 |   await expect(releaseButton(page, "fw-new", "publish").first()).toBeDisabled();
  218 |   await expect(releaseButton(page, "fw-old", "disable")).toBeDisabled();
  219 |   await expect(releaseButton(page, "fw-current", "disable")).toBeDisabled();
  220 | });
  221 | 
  222 | test("unknown channel result is read back but never automatically repeated", async ({ page }) => {
  223 |   const data = await mockAdmin(page); data.mode = "unknown-channel";
  224 |   await channelButton(page, "beta", "stop-latest").click(); await fillConfirmation(page);
  225 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown");
  226 |   expect(data.writes).toHaveLength(1); expect(data.mutations).toBe(1);
  227 |   expect(data.events.at(-1)).toMatch(/^GET /);
  228 |   await closeResult(page);
  229 |   await expect(channelButton(page, "beta", "resume-latest")).toBeEnabled();
  230 |   expect(data.writes).toHaveLength(1);
  231 | });
  232 | 
  233 | test("unknown release result uses an explicit same-key/same-body reconciliation after reads", async ({ page }) => {
  234 |   const data = await mockAdmin(page); data.mode = "unknown-release";
  235 |   await releaseButton(page, "fw-new", "recovery-download").click(); await fillConfirmation(page, "original recovery reason");
  236 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  237 |   expect(data.writes).toHaveLength(1);
  238 |   await expect(releaseButton(page, "fw-new", "disable")).toBeDisabled();
  239 |   const eventCount = data.events.length;
  240 |   await page.locator('[data-firmware-action="retry-release"]').click();
  241 |   await expect(page.locator("#confirmDetail")).toContainText("original recovery reason");
  242 |   expect(data.events.slice(eventCount).every(event => event.startsWith("GET "))).toBe(true);
  243 |   expect(data.writes).toHaveLength(1);
  244 |   await fillConfirmation(page);
  245 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  246 |   expect(data.writes).toHaveLength(2);
  247 |   expect(data.writes[1]).toEqual(data.writes[0]); expect(data.mutations).toBe(1);
  248 |   await expect(page.locator("#confirmDownload")).toBeVisible();
  249 |   await expect(page.locator("#confirmDownload")).toHaveAttribute("href", /purpose=admin-recovery/);
  250 |   await closeResult(page);
  251 |   await expect(page.locator("#confirmDownload")).not.toHaveAttribute("href");
  252 | });
  253 | 
  254 | test("an expired original key requires a newly confirmed operation, not an automatic new key", async ({ page }) => {
  255 |   const data = await mockAdmin(page); data.mode = "unknown-release";
  256 |   await releaseButton(page, "fw-new", "recovery-download").click(); await fillConfirmation(page);
  257 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  258 |   data.expireReplay = true;
  259 |   await page.locator('[data-firmware-action="retry-release"]').click(); await fillConfirmation(page);
  260 |   await expect(page.locator("#confirmDetail")).toContainText("IDEMPOTENCY_RESULT_EXPIRED");
  261 |   expect(data.writes).toHaveLength(2); expect(data.writes[1].key).toBe(data.writes[0].key);
  262 |   await closeResult(page); data.expireReplay = false;
  263 |   await releaseButton(page, "fw-new", "recovery-download").click();
  264 |   expect(data.writes).toHaveLength(2); await fillConfirmation(page);
  265 |   await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  266 |   expect(data.writes[2].key).not.toBe(data.writes[0].key);
  267 | });
  268 | 
  269 | const interruptedReplayFailures: ReleaseFailure[] = [
  270 |   { status: 401, code: "TOKEN_EXPIRED" },
  271 |   { status: 403, code: "CSRF_INVALID" },
  272 |   { status: 403, code: "ROLE_FORBIDDEN" },
  273 |   { status: 429, code: "RATE_LIMITED" },
  274 |   { status: 503, code: "BACKEND_UNAVAILABLE" },
  275 |   { status: 409, code: "IDEMPOTENCY_CONFLICT" },
  276 |   { status: 410, code: "RELEASE_DISABLED" },
  277 |   { status: 409, code: "IDEMPOTENCY_RESULT_EXPIRED", correlation: "missing" },
  278 |   { status: 409, code: "IDEMPOTENCY_RESULT_EXPIRED", correlation: "mismatch" },
  279 |   { status: 403, code: "IDEMPOTENCY_RESULT_EXPIRED" }
  280 | ];
  281 | for (const action of ["recovery-download", "disable"]) for (const failure of interruptedReplayFailures) {
  282 |   test(`${action}: interrupted reconciliation preserves intent after ${failure.status}/${failure.code}/${failure.correlation ?? "valid"}`, async ({ page }) => {
  283 |     const data = await mockAdmin(page); data.mode = "unknown-release";
  284 |     await releaseButton(page, "fw-new", action).click(); await fillConfirmation(page, "original unresolved intent");
  285 |     await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  286 |     const original = data.writes[0]; const result = data.results.get(original.key!)!.result;
  287 |     expect(data.mutations).toBe(1);
  288 |     data.releaseFailure = failure;
  289 |     for (let attempt = 0; attempt < 2; attempt++) {
  290 |       const events = data.events.length; const writes = data.writes.length;
  291 |       await page.locator('[data-firmware-action="retry-release"]').click();
  292 |       await expect(page.locator("#confirmDetail")).toContainText("original unresolved intent");
  293 |       expect(data.events.slice(events).every(event => event.startsWith("GET "))).toBe(true);
  294 |       expect(data.writes).toHaveLength(writes);
  295 |       await fillConfirmation(page);
> 296 |       await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation unconfirmed");
      |                                                   ^ Error: expect(locator).toHaveText(expected) failed
  297 |       await expect(page.locator("#confirmDownload")).toBeHidden(); await closeResult(page);
  298 |       expect(data.writes.at(-1)).toEqual(original); expect(data.mutations).toBe(1);
  299 |       await expect(page.locator('[data-firmware-action="retry-release"]')).toBeVisible();
  300 |       await expect(channelButton(page, "beta", "stop-latest")).toBeDisabled();
  301 |       await expect(releaseButton(page, "fw-old", "recovery-download")).toBeDisabled();
  302 |       await expect(releaseButton(page, "fw-old", "disable")).toBeDisabled();
  303 |       await page.locator("#refreshButton").click(); await expect(page.locator("#refreshButton")).toBeEnabled();
  304 |       await expect(page.locator('[data-firmware-action="retry-release"]')).toBeVisible();
  305 |       await expect(releaseButton(page, "fw-old", "recovery-download")).toBeDisabled();
  306 |       expect(data.writes).toHaveLength(writes + 1); expect(data.results.size).toBe(1);
  307 |     }
  308 |     data.releaseFailure = null;
  309 |     await page.locator('[data-firmware-action="retry-release"]').click();
  310 |     expect(data.writes).toHaveLength(3); await fillConfirmation(page);
  311 |     await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  312 |     await expect(page.locator("#confirmDetail")).toContainText(String(result.requestId));
  313 |     if (action === "recovery-download") await expect(page.locator("#confirmDownload")).toHaveAttribute("href", String(result.downloadUrl));
  314 |     expect(data.writes).toHaveLength(4); expect(data.writes[3]).toEqual(original);
  315 |     expect(data.mutations).toBe(1); expect(data.results.size).toBe(1);
  316 |     await closeResult(page);
  317 |     await expect(page.locator('[data-firmware-action="retry-release"]')).toBeHidden();
  318 |     await expect(channelButton(page, "beta", "stop-latest")).toBeEnabled();
  319 |   });
  320 | }
  321 | 
  322 | for (const failure of interruptedReplayFailures.slice(0, 4)) {
  323 |   test(`a first definitive ${failure.status}/${failure.code} rejection permits a separately confirmed intent`, async ({ page }) => {
  324 |     const data = await mockAdmin(page); data.releaseFailure = failure;
  325 |     await releaseButton(page, "fw-new", "recovery-download").click(); await fillConfirmation(page, "rejected first intent");
  326 |     await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation unconfirmed"); await closeResult(page);
  327 |     expect(data.writes).toHaveLength(1); expect(data.mutations).toBe(0); expect(data.results.size).toBe(0);
  328 |     await expect(page.locator('[data-firmware-action="retry-release"]')).toBeHidden();
  329 |     await expect(releaseButton(page, "fw-new", "recovery-download")).toBeEnabled();
  330 |     data.releaseFailure = null;
  331 |     await releaseButton(page, "fw-new", "recovery-download").click();
  332 |     expect(data.writes).toHaveLength(1); await fillConfirmation(page, "new confirmed intent after restoring access");
  333 |     await expect(page.locator("#confirmTitle")).toHaveText("Firmware operation confirmed");
  334 |     expect(data.writes).toHaveLength(2); expect(data.writes[1].key).not.toBe(data.writes[0].key);
  335 |     expect(data.mutations).toBe(1);
  336 |   });
  337 | }
  338 | 
  339 | test("owner identity changes cannot replay a pending request in another actor scope", async ({ page }) => {
  340 |   const data = await mockAdmin(page); data.mode = "unknown-release";
  341 |   await releaseButton(page, "fw-new", "disable").click(); await fillConfirmation(page);
  342 |   await expect(page.locator("#confirmMessage")).toContainText("network result is unknown"); await closeResult(page);
  343 |   data.actor = "different-owner@example.test";
  344 |   await page.locator('[data-firmware-action="retry-release"]').click();
  345 |   await expect(page.locator("#firmwareNotice")).toBeVisible();
  346 |   await expect(page.locator("#confirmDialog")).toBeHidden();
  347 |   expect(data.writes).toHaveLength(1); expect(data.mutations).toBe(1);
  348 | });
  349 | 
  350 | test("failed state refresh keeps writes locked until a successful manual read", async ({ page }) => {
  351 |   const data = await mockAdmin(page); data.mode = "refresh-failure";
  352 |   await channelButton(page, "beta", "stop-latest").click(); await fillConfirmation(page);
  353 |   await expect(page.locator("#confirmMessage")).toContainText("state refresh failed"); await closeResult(page);
  354 |   await expect(channelButton(page, "beta", "stop-latest")).toBeDisabled();
  355 |   expect(data.writes).toHaveLength(1);
  356 |   data.failReads = false;
  357 |   await page.locator('[data-firmware-action="refresh"]').click();
  358 |   await expect(channelButton(page, "beta", "resume-latest")).toBeEnabled();
  359 |   expect(data.writes).toHaveLength(1);
  360 | });
  361 | 
  362 | test("mobile firmware controls and confirmation fit the viewport", async ({ page }, info) => {
  363 |   await page.setViewportSize({ width: 390, height: 844 });
  364 |   await mockAdmin(page, "zh");
  365 |   await releaseButton(page, "fw-old", "select").click();
  366 |   await channelButton(page, "stable", "retract").click();
  367 |   await expect(page.locator("#confirmReason")).toBeVisible();
  368 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  369 |   await page.screenshot({ path: info.outputPath("zh-mobile-mock-confirm.png"), fullPage: true });
  370 | });
  371 | 
```