const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const live = process.argv[2] === 'live';
const remediation = process.argv[2] === 'accept02';
const outside = (base, file) => { const rel = path.relative(base, file); return rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel); };
const stats = { directories: 0, files: 0, bytes: 0, links: [], escaped: [], errors: [] };
function walk(dir, onFile, scope = root) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch (error) { stats.errors.push({ path: dir, code: error.code }); return; }
  for (const entry of entries) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) { stats.links.push(file); continue; }
    if (entry.isDirectory()) {
      const actual = fs.realpathSync(file);
      if (outside(scope, actual)) { stats.escaped.push({ path: file, actual }); continue; }
      stats.directories++;
      walk(file, onFile, scope);
    } else if (entry.isFile()) onFile(file, fs.statSync(file));
  }
}
for (const rel of ['.cache', 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin',
  'app/bluetooth_flutter_Trace/cloudflare/update-service/public', 'app/bluetooth_flutter_Trace/cloudflare/update-service/worker',
  'docs/ota-exec-notes/P4-3-dev-2026-10-17']) {
  const dir = path.join(root, rel);
  if (fs.existsSync(dir)) walk(dir, (_file, stat) => { stats.files++; stats.bytes += stat.size; });
}
process.stdout.write(JSON.stringify({ root, containedOutputs: stats }, null, 2) + '\n');
const chrome = 'C:\\Users\\SU\\AppData\\Local\\Google\\Chrome\\User Data';
const duringLaunch = [];
const start = remediation ? Date.parse(process.argv[3]) : live ? Date.parse('2026-10-17T09:40:00.000Z') : Date.parse('2026-10-17T04:13:56.530Z');
const end = live || remediation ? Date.now() : Date.parse('2026-10-17T04:18:23.290Z');
if (!Number.isFinite(start) || start > end) throw new Error('Invalid audit window');
if (fs.existsSync(chrome)) walk(chrome, (file, stat) => {
  if ((stat.mtimeMs >= start && stat.mtimeMs <= end) || (stat.birthtimeMs >= start && stat.birthtimeMs <= end)) {
    duringLaunch.push({ path: file, modified: stat.mtime.toISOString(), created: stat.birthtime.toISOString() });
  }
}, chrome);
process.stdout.write(JSON.stringify({ readOnlyChromeTimestampAudit: { path: chrome, windowStart: new Date(start).toISOString(),
  windowEnd: new Date(end).toISOString(), matchingFiles: duringLaunch, attribution: 'timestamps only, not proof of process ownership' } }, null, 2) + '\n');
if (live || remediation) {
  const external = [];
  for (const base of ['C:/Users/SU/.npm', 'C:/Users/SU/AppData/Local/npm-cache',
    'C:/Users/SU/AppData/Local/Microsoft/PowerShell', 'C:/Users/SU/AppData/Local/Microsoft/Windows/PowerShell',
    'C:/Users/SU/AppData/Roaming/xdg.config/.wrangler', 'C:/Users/SU/AppData/Local/ms-playwright']) {
    const changes = [];
    if (fs.existsSync(base)) walk(base, (file, stat) => {
      if ((stat.mtimeMs >= start && stat.mtimeMs <= end) || (stat.birthtimeMs >= start && stat.birthtimeMs <= end)) {
        changes.push({ path: file, modified: stat.mtime.toISOString(), created: stat.birthtime.toISOString() });
      }
    }, base);
    external.push({ path: base, matchingFiles: changes });
  }
  process.stdout.write(JSON.stringify({ externalDefaultLocationTimestampAudit: external,
    originalEdge: remediation ? 'No installed user browser or Access session was used in P43-ACCEPT-02 remediation.'
      : 'User-owned Edge was not launched, restarted, CDP-attached, reconfigured or copied. Read-only native accessibility probes did not capture a page body. User navigation completed official Access transfer into worktree-contained state.',
    attribution: 'Read-only timestamp observations. Concurrent user/other-process activity is not attributed to this task.' }, null, 2) + '\n');
  const processes = spawnSync('wmic.exe', ['process', 'get', 'CommandLine,ProcessId,ParentProcessId', '/format:csv'],
    { cwd: root, windowsHide: true, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  const remaining = processes.stdout.split(/\r?\n/).filter(line => remediation
    ? /accept02-ui-\d+|p4-3-implementation-20261017.*(?:headless_shell|playwright)/i.test(line)
    : /p43-(platform-login|live|browser-probe|owner-login|access-connect|live-drill|edge-observe|edge-page)\.(mjs|cjs|py|exe)/.test(line));
  process.stdout.write(JSON.stringify({ ownedLiveCollectors: { queryExitCode: processes.status,
    remainingCount: remaining.length, commandLinesOmitted: true } }) + '\n');
  if (processes.status !== 0 || remaining.length) process.exitCode = 1;
}
const logs = path.join(root, '.cache', 'p43', 'logs');
const launches = fs.readFileSync(path.join(logs, 'ui-mock-01.log'), 'utf8');
process.stdout.write(JSON.stringify({ installedChromeCleanup: {
  exits: (launches.match(/<process did exit:/g) || []).length,
  cleanupCompletions: (launches.match(/finished temporary directories cleanup/g) || []).length
} }) + '\n');
const tmp = path.join(root, '.cache', 'p43', 'tmp');
process.stdout.write(JSON.stringify({ remainingPlaywrightTemps: fs.readdirSync(tmp).filter(name => name.startsWith('playwright')) }) + '\n');
if (remediation) {
  const base = 'C:/Users/SU/AppData/LocalLow/Microsoft/CryptnetUrlCache';
  const files = ['Content/ABD721CDC3648033BA8C827AF15A4543', 'MetaData/ABD721CDC3648033BA8C827AF15A4543',
    'Content/B6E4D06BF128A1673A8DAFB4E25B990D', 'MetaData/B6E4D06BF128A1673A8DAFB4E25B990D'];
  const observations = files.map(file => { const full = path.join(base, file); const stat = fs.statSync(full);
    return { path: full, sizeBytes: stat.size, modified: stat.mtime.toISOString() }; });
  process.stdout.write(JSON.stringify({ historicalCryptnetException: observations, cleanupPerformed: false }) + '\n');
}
const status = spawnSync('git', ['--no-optional-locks', 'status', '--short', '--branch'], { cwd: root, encoding: 'utf8', windowsHide: true });
process.stdout.write(status.stdout);
if (stats.escaped.length || stats.links.length || stats.errors.length) process.exitCode = 1;
