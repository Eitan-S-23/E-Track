import csv
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import importlib.util
import io
import json
import pathlib
import re
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent.parent
assert pathlib.Path.cwd().resolve() == root
label = sys.argv[1]
assert re.fullmatch(r'edge-observe-[0-9]+', label)
output = root / '.cache/p43/live' / (label + '.json')
private_output = root / '.cache/p43/private' / (label + '-task-page.json')
preflight = subprocess.run(['node', str(root / '.cache/p43-run.cjs'), 'edge-preflight', '.', 'preflight', str(output), str(private_output)],
                           cwd=root, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
assert preflight.returncode == 0
assert not output.exists()
assert not private_output.exists()
result = {'label': label, 'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'purpose': 'Read-only observation of the user-selected already-open Edge after user-reported OTP action',
          'browserLaunchedOrRestarted': False, 'profileCopied': False,
          'cookieValuesReadOrDecrypted': False, 'outsideWrites': False}
processes = subprocess.run(['wmic.exe', 'process', 'get', 'CommandLine,ProcessId,ExecutablePath', '/format:csv'],
                           cwd=root, capture_output=True, text=True, encoding='utf-8', errors='replace',
                           creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
result['processQueryExitCode'] = processes.returncode
edge_pids = set()
result['edgeProcesses'] = []
for row in csv.DictReader(io.StringIO(processes.stdout.strip())):
    if pathlib.PureWindowsPath(row.get('ExecutablePath', '')).name.lower() != 'msedge.exe':
        continue
    command = row.get('CommandLine', '')
    pid = int(row['ProcessId'])
    edge_pids.add(pid)
    match = re.search(r'--remote-debugging-port[= ](\d+)', command)
    result['edgeProcesses'].append({'pid': pid, 'subprocess': '--type=' in command,
                                    'remoteDebuggingFlag': '--remote-debugging' in command,
                                    'debuggingPort': int(match[1]) if match else None})

user32 = ctypes.WinDLL('user32', use_last_error=True)
callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.IsWindowVisible.argtypes = [wintypes.HWND]
result['edgeWindows'] = []

@callback_type
def observe_window(hwnd, _):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if pid.value not in edge_pids or not user32.IsWindowVisible(hwnd):
        return True
    buffer = ctypes.create_unicode_buffer(user32.GetWindowTextLengthW(hwnd) + 1)
    user32.GetWindowTextW(hwnd, buffer, len(buffer))
    title = buffer.value
    # Retain only task-related title classification, never arbitrary user tab titles.
    result['edgeWindows'].append({'pid': pid.value, 'hwnd': int(hwnd),
                                  'taskRelatedTitle': bool(re.search(r'cloudflare|trace-update-admin|P4-3|e-track-firmware-p43', title, re.I)),
                                  'accessTitle': bool(re.search(r'cloudflare access', title, re.I)),
                                  'sessionEndpointTitle': '/api/admin/session' in title,
                                  'titleOmitted': True})
    return True

user32.EnumWindows(observe_window, 0)
result['availableAutomationModules'] = {name: importlib.util.find_spec(name) is not None
                                        for name in ['comtypes', 'pywinauto', 'uiautomation', 'win32com', 'psutil']}
devtools = pathlib.Path('C:/Users/SU/AppData/Local/Microsoft/Edge/User Data/DevToolsActivePort')
result['existingDevToolsEndpointFilePresent'] = devtools.is_file()
if devtools.is_file():
    lines = devtools.read_text(encoding='utf-8').splitlines()
    result['existingDevToolsPort'] = int(lines[0]) if lines and lines[0].isdigit() else None
if len(sys.argv) > 2:
    assert sys.argv[2] == '--read-task-page'
    # Use installed native accessibility, with no browser restart, navigation, input or COM code generation.
    import pythoncom
    target = 'https://trace-update-admin-staging.pages.dev/api/admin/session'
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                         wintypes.LPARAM, wintypes.UINT, wintypes.UINT,
                                         ctypes.POINTER(ctypes.c_size_t)]
    user32.SendMessageTimeoutW.restype = wintypes.LPARAM
    client_windows = []
    @callback_type
    def client_window(hwnd, _):
        name = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, name, 256)
        if name.value == 'Chrome_RenderWidgetHostHWND' and user32.IsWindowVisible(hwnd):
            client_windows.append(int(hwnd))
        return True
    for window in result['edgeWindows']:
        if window['sessionEndpointTitle']:
            user32.EnumChildWindows(wintypes.HWND(window['hwnd']), client_window, 0)
            if not client_windows:
                client_windows.append(window['hwnd'])
    result['accessibility'] = {'visibleRenderWindows': len(client_windows), 'documents': [], 'errors': []}
    deadline = time.monotonic() + 20
    visited = 0
    captured = []
    def get(obj, name, *args):
        try:
            return obj.Invoke(obj.GetIDsOfNames(name), 0, pythoncom.DISPATCH_PROPERTYGET, True, *args)
        except pythoncom.com_error:
            return None
    def visit(obj, depth=0, in_target=False):
        global visited
        if visited >= 500 or depth > 35 or time.monotonic() >= deadline:
            return
        visited += 1
        role = get(obj, 'accRole', 0)
        if role == 15:
            url = get(obj, 'accValue', 0)
            matches = isinstance(url, str) and url.split('?', 1)[0].rstrip('/') == target
            result['accessibility']['documents'].append({'matchesTaskSessionEndpoint': matches, 'role': role})
            if not matches:
                return
            in_target = True
        if in_target:
            for field in ['accName', 'accValue']:
                value = get(obj, field, 0)
                if isinstance(value, str) and value and value not in captured:
                    captured.append(value)
        count = get(obj, 'accChildCount')
        for i in range(1, min(count if isinstance(count, int) else 0, 150) + 1):
            child = get(obj, 'accChild', i)
            if child is not None and hasattr(child, 'Invoke'):
                visit(child, depth + 1, in_target)
            elif in_target:
                for field in ['accName', 'accValue']:
                    value = get(obj, field, i)
                    if isinstance(value, str) and value and value not in captured:
                        captured.append(value)
    for hwnd in client_windows:
        try:
            lresult = ctypes.c_size_t()
            succeeded = user32.SendMessageTimeoutW(wintypes.HWND(hwnd), 0x003D, 0, -4, 2, 2000, ctypes.byref(lresult))
            if succeeded and lresult.value:
                accessible = pythoncom.ObjectFromLresult(lresult.value, pythoncom.IID_IDispatch, 0)
                visit(accessible)
        except Exception as error:
            result['accessibility']['errors'].append({'type': type(error).__name__, 'hresult': getattr(error, 'hresult', None)})
    result['accessibility']['visitedNodes'] = visited
    result['accessibility']['capturedTextCount'] = len(captured)
    with private_output.open('x', encoding='utf-8') as file:
        json.dump({'target': target, 'text': captured, 'nature': 'Read-only MSAA text from the user-opened Edge task page'}, file, indent=2)
        file.write('\n')
    for value in captured:
        try:
            body = json.loads(value)
        except (ValueError, TypeError):
            continue
        if isinstance(body, dict) and ('ok' in body or 'errorCode' in body):
            result['accessibility']['sessionPage'] = {'ok': body.get('ok'), 'role': body.get('role'),
                'errorCode': body.get('errorCode'), 'fields': sorted(body),
                'actorSha256': hashlib.sha256(body['actor'].strip().lower().encode()).hexdigest() if isinstance(body.get('actor'), str) else None,
                'credentialValuesOmitted': True, 'httpStatusNotObserved': True}
with output.open('x', encoding='utf-8') as file:
    json.dump(result, file, indent=2)
    file.write('\n')
print(json.dumps(result))
