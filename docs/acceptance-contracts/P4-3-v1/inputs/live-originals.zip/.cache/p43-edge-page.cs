using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Automation;

internal static class P43EdgePage
{
    private const string Root = @"D:\github\my\E-Track\.cache\p4-3-implementation-20261017";
    private const string Target = "trace-update-admin-staging.pages.dev/api/admin/session";
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 262144 };

    private static void Save(string file, object value)
    {
        using (var stream = new FileStream(file, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.WriteLine(Json.Serialize(value));
    }

    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Length != 2 || Directory.GetCurrentDirectory() != Root || !System.Text.RegularExpressions.Regex.IsMatch(args[1], "^edge-page-[0-9]+$")) return 2;
        var privateFile = Path.Combine(Root, @".cache\p43\private", args[1] + ".json");
        var publicFile = Path.Combine(Root, @".cache\p43\live", args[1] + ".json");
        var guard = new ProcessStartInfo("node", ".cache\\p43-run.cjs edge-page-guard . preflight " + privateFile + " " + publicFile)
            { WorkingDirectory = Root, UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
        using (var process = Process.Start(guard)) { process.StandardOutput.ReadToEnd(); process.StandardError.ReadToEnd(); process.WaitForExit(); if (process.ExitCode != 0) return 3; }
        var report = new Dictionary<string, object> { { "label", args[1] }, { "observedAt", DateTime.UtcNow.ToString("o") },
            { "nature", "Read-only Windows UI Automation of the user-opened Edge Admin session page" },
            { "navigationOrInput", false }, { "cookiesReadOrDecrypted", false }, { "browserLaunchedOrRestarted", false } };
        var raw = new List<object>();
        var texts = new List<string>();
        try
        {
            var window = AutomationElement.FromHandle(new IntPtr(long.Parse(args[0])));
            if (Process.GetProcessById(window.Current.ProcessId).ProcessName != "msedge" || !window.Current.Name.Contains(Target)) throw new InvalidOperationException("Task window identity changed");
            report["window"] = new { className = window.Current.ClassName, framework = window.Current.FrameworkId,
                offscreen = window.Current.IsOffscreen, enabled = window.Current.IsEnabled,
                width = window.Current.BoundingRectangle.Width, height = window.Current.BoundingRectangle.Height,
                childCount = window.FindAll(TreeScope.Children, Condition.TrueCondition).Count };
            var documents = window.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Document));
            report["documentCount"] = documents.Count;
            var descriptions = new List<object>();
            foreach (AutomationElement document in documents)
            {
                bool matches = document.Current.Name.Contains(Target);
                descriptions.Add(new { matchesTask = matches, offscreen = document.Current.IsOffscreen,
                    patterns = document.GetSupportedPatterns().Select(p => p.ProgrammaticName).ToArray() });
                if (!matches || document.Current.IsOffscreen) continue;
                object pattern;
                if (document.TryGetCurrentPattern(TextPattern.Pattern, out pattern)) texts.Add(((TextPattern)pattern).DocumentRange.GetText(131072));
                var children = document.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Text));
                foreach (AutomationElement child in children) if (!String.IsNullOrEmpty(child.Current.Name)) texts.Add(child.Current.Name);
            }
            report["documents"] = descriptions;
            report["capturedTexts"] = texts.Count;
            foreach (string text in texts.Distinct())
            {
                raw.Add(new { text = text });
                Dictionary<string, object> body;
                try { body = Json.DeserializeObject(text.Trim()) as Dictionary<string, object>; } catch (ArgumentException) { continue; }
                if (body == null || (!body.ContainsKey("ok") && !body.ContainsKey("errorCode"))) continue;
                var safe = new Dictionary<string, object> { { "fields", body.Keys.OrderBy(x => x).ToArray() }, { "httpStatusNotObserved", true } };
                foreach (var name in new[] { "ok", "role", "errorCode", "requestId" }) if (body.ContainsKey(name)) safe[name] = body[name];
                if (body.ContainsKey("actor") && body["actor"] is string)
                    using (var hash = SHA256.Create()) safe["actorSha256"] = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(((string)body["actor"]).Trim().ToLowerInvariant()))).Replace("-", "").ToLowerInvariant();
                report["sessionPage"] = safe;
            }
        }
        catch (Exception error) { report["error"] = new { type = error.GetType().Name, hresult = error.HResult }; }
        Save(privateFile, new { endpoint = "https://" + Target, observation = raw });
        Save(publicFile, report);
        Console.WriteLine(Json.Serialize(report));
        return report.ContainsKey("error") ? 1 : 0;
    }
}
