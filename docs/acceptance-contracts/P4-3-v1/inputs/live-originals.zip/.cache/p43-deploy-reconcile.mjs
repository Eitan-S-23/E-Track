import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const privateDir = path.join(root, '.cache/p43/private/pages');
const target = path.join(root, '.cache/p43/live/pages-csrf-02-summary.json');
const rawTarget = path.join(privateDir, 'pages-csrf-02-readback.json');
const preflight = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'reconcile-preflight', '.', 'preflight', target, rawTarget],
  { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(preflight.status, 0);
assert.ok(!fs.existsSync(target) && !fs.existsSync(rawTarget));
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
const verified = read(path.join(root, '.cache/p43/logs/csrf-ci-verify-01.log'));
assert.equal(verified.verified, true); assert.equal(verified.conclusion, 'success');
const before = read(path.join(privateDir, 'pages-csrf-01-project-before-deploy.json')).result;
const observed = read(path.join(privateDir, 'pages-csrf-01-project-after-deploy.json')).result;
const cli = read(path.join(privateDir, 'pages-csrf-01-deployment-cli.json'));
assert.equal(cli.exitCode, null); assert.equal(cli.signal, 'SIGTERM');
const config = read('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json');
const oauth = fs.readFileSync(path.join(root, '.cache/p43/private/platform-login/xdg-config/.wrangler/config/default.toml'), 'utf8');
const token = oauth.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1];
assert.ok(token && Date.parse(oauth.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1]) > Date.now());
const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${config.account_id}/pages/projects/e-track-firmware-p43-admin-test`, {
  headers: { Authorization: `Bearer ${token}` }, redirect: 'error', signal: AbortSignal.timeout(30000)
});
const raw = Buffer.from(await response.arrayBuffer()); assert.ok(raw.length < 100000);
fs.writeFileSync(rawTarget, raw, { flag: 'wx' });
assert.equal(response.status, 200);
const result = JSON.parse(raw.toString('utf8')); assert.equal(result.success, true);
assert.deepEqual(observed.deployment_configs, before.deployment_configs);
assert.deepEqual(result.result.deployment_configs, before.deployment_configs);
const deployment = result.result.canonical_deployment;
assert.equal(deployment.id, observed.canonical_deployment.id);
assert.equal(deployment.deployment_trigger.metadata.commit_hash, verified.source);
assert.equal(deployment.latest_stage.status, 'success');
assert.equal(result.result.deployment_configs.production.d1_databases.DB.id, '2617e1e1-956f-42ce-a465-da56d84abf06');
assert.equal(result.result.deployment_configs.production.r2_buckets.RELEASES_BUCKET.name, 'e-track-firmware-p41-test-releases');
const report = { label: 'pages-csrf-02', observedAt: new Date().toISOString(), operation: 'GET_ONLY',
  status: response.status, cfRay: response.headers.get('cf-ray'), originalSha256: sha(raw), cloudWritesAttempted: 0,
  originalAttempt: { label: 'pages-csrf-01', cliExitCode: cli.exitCode, signal: cli.signal, timeoutPreserved: true },
  deployment: { id: deployment.id, sourceCommit: verified.source, sourceRun: `${verified.runId}/1`,
    origin: 'https://e-track-firmware-p43-admin-test.pages.dev', actualStage: deployment.latest_stage,
    servingFiles: verified.files, settingsUnchanged: true, bundledLocally: false, reconciledWithoutRedeploy: true } };
fs.writeFileSync(target, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(report) + '\n');
