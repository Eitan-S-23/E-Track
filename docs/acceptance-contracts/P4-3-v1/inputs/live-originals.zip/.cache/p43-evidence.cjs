const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const baseline = 'a96aa03da14a912aaf783d875d6a379846c21289';
const mode = process.argv[2];
const continuation = mode === 'inspect-continuation' || mode === 'archive-continuation';
const tested = continuation ? '933b790e69e04ee551ad255398e08f12a1b2a107' : 'cd352c5a7e9e7d1619ec31678c20a017f95a9adc';
const relative = file => path.relative(root, file).replaceAll('\\', '/');
function run(command, args) {
  const result = spawnSync(command, args, { cwd: root, windowsHide: true, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  if (result.status !== 0) throw new Error(`${command}: ${result.stderr}`);
  return result.stdout;
}
function guard(file) {
  const full = path.resolve(root, file);
  const rel = path.relative(root, full);
  if (rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) throw new Error('Outside worktree');
  run(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'preflight', '.', 'preflight', full]);
  return full;
}
const read = file => fs.readFileSync(path.resolve(root, file), 'utf8');
const logs = '.cache/p43/logs';
if (mode === 'inspect-csrf') {
  const source = '972e74c43cd36b7a308e457296aaf7bb06120e78';
  const runId = '39084376785';
  const metadata = JSON.parse(read(`${logs}/csrf-ci-inspect-01.log`));
  assert.equal(metadata.status, 'completed'); assert.equal(metadata.conclusion, 'success');
  assert.equal(metadata.headSha, source); assert.equal(metadata.event, 'workflow_dispatch');
  assert.equal(metadata.jobs.length, 4); assert.ok(metadata.jobs.every(job => job.conclusion === 'success'));
  const input = `.cache/p43/ci/artifacts-${runId}/admin-deployment-input-${source}`;
  assert.equal(read(`${input}/source-commit.txt`).trim(), source);
  assert.equal(read(`${input}/source-run.txt`).trim(), `${runId}/1`);
  const sha = value => createHash('sha256').update(value).digest('hex');
  const files = read(`${input}/SHA256SUMS`).trim().split(/\r?\n/).map(line => {
    const match = /^([a-f0-9]{64})  (public\/(?:_routes\.json|_worker\.js\/index\.js|index\.html))$/.exec(line);
    assert.ok(match, 'Unexpected serving entry');
    const full = path.resolve(root, input, match[2]);
    assert.equal(fs.realpathSync(full).toLowerCase(), full.toLowerCase());
    const bytes = fs.readFileSync(full); assert.equal(sha(bytes), match[1]);
    return { path: match[2], sizeBytes: bytes.length, sha256: match[1] };
  });
  assert.deepEqual(files.map(file => file.path).sort(), ['public/_routes.json', 'public/_worker.js/index.js', 'public/index.html']);
  assert.equal(read(`${input}/public/index.html`), run('git', ['show', `${source}:app/bluetooth_flutter_Trace/cloudflare/update-service/admin/public/index.html`]));
  assert.match(read(`${input}/public/_worker.js/index.js`), /existingCsrf/);
  const archive = `.cache/p43/ci/logs-${runId}.zip`;
  const clean = value => value.replace(/\u001b\[[0-9;]*m/g, '');
  const worker = clean(run('tar', ['-xOf', archive, 'Worker Typecheck and Invariants/7_Run invariant tests.txt']));
  const native = worker.match(/\bTests\s+(\d+) passed\s+\((\d+)\)/);
  assert.ok(native); assert.equal(Number(native[1]), 270); assert.equal(native[1], native[2]);
  const ui = read(`.cache/p43/ci/artifacts-${runId}/admin-mock-ui-${runId}-1/playwright.log`);
  assert.match(ui, /12 passed \(/);
  const smoke = read(`.cache/p43/ci/artifacts-${runId}/admin-bundle-diagnostics-${runId}-1/native-smoke.log`);
  const smokeCounts = Object.fromEntries(['tests', 'pass', 'fail', 'skipped', 'cancelled'].map(name =>
    [name, Number(smoke.match(new RegExp(`\\b${name} (\\d+)`))?.[1])]));
  assert.deepEqual(smokeCounts, { tests: 3, pass: 3, fail: 0, skipped: 0, cancelled: 0 });
  const jobLogs = run('tar', ['-tf', archive]).trim().split(/\r?\n/).filter(name => /^[0-9]_/.test(name))
    .map(name => ({ name, text: clean(run('tar', ['-xOf', archive, name])) }));
  const diagnostics = jobLogs.map(({ name, text }) => ({ name,
    githubWarningAnnotations: (text.match(/##\[warning\]/g) || []).length,
    nativeExpectedExceptionLines: (text.match(/uncaught exception;/g) || []).length,
    npmWarnings: (text.match(/npm warn/g) || []).length,
    auditSummaries: text.split('\n').filter(line => /\b\d+ (?:high severity )?vulnerabilities\b/.test(line)) }));
  process.stdout.write(JSON.stringify({ source, runId, conclusion: metadata.conclusion, files,
    nativeWorker: { passed: Number(native[1]), failed: 0, skipped: 0 }, mockUi: { passed: 12 },
    compiledRouterSmoke: smokeCounts, diagnostics, verified: true, deployed: false }, null, 2) + '\n');
  process.exit(0);
}
if (mode === 'archive-live') {
  const increment = process.argv[3] || '01';
  assert.ok(['01', '02', '03', '04'].includes(increment));
  const digest = bytes => createHash('sha256').update(bytes).digest('hex');
  const evidence = 'docs/ota-exec-notes/P4-3-dev-2026-10-17';
  const priorInventories = ['inventory.json', 'continuation-01.inventory.json'];
  if (Number(increment) >= 2) priorInventories.push('live-preparation-01.inventory.json');
  if (Number(increment) >= 3) priorInventories.push('live-preparation-02.inventory.json');
  if (Number(increment) >= 4) priorInventories.push('live-preparation-03.inventory.json');
  const previous = priorInventories.map(name => {
    const inventory = JSON.parse(read(`${evidence}/${name}`));
    assert.equal(digest(fs.readFileSync(path.join(root, evidence, inventory.archive.path))), inventory.archive.sha256);
    return inventory;
  });
  const prior = new Map(previous.flatMap(item => item.entries).map(item => [item.path, item.sha256]));
  const files = [];
  for (const name of fs.readdirSync(path.join(root, '.cache/p43/live'))) {
    assert.match(name, /^[a-z0-9_-]+\.(json|md)$/);
    files.push(`.cache/p43/live/${name}`);
  }
  for (const name of fs.readdirSync(path.join(root, logs))) {
    const currentDiagnostic = increment === '03'
      && /^(?:original-token-policy-01|p41-token-policy-01|token-policy-syntax-01|read-probes-syntax-01|existing-access-inputs-01|original-log-probe-01|p41-log-probe-01|telemetry-reference-03|access-create-reference-03)\.(json|log)$/.test(name);
    const currentLive = increment === '04' && /^(?:access-|owner-|pages-|edge-|cloudflared-|final-|csrf-|takeover-|relay-|public-node-)[a-z0-9-]+\.(json|log)$/.test(name);
    if ((!/^live-[a-z0-9-]+\.(json|log)$/.test(name) && !currentDiagnostic && !currentLive) || name.endsWith('-wrangler.log')) continue;
    if (name.endsWith('.log') && !fs.existsSync(path.join(root, logs, name.replace(/\.log$/, '.json')))
      && name !== 'live-original-capabilities-01.log') continue;
    files.push(`${logs}/${name}`);
  }
  for (const name of ['p43-run.cjs', 'p43-audit.cjs', 'p43-evidence.cjs', 'p43-live.mjs',
    'p43-risk.mjs', 'p43-browser-probe.mjs', 'p43-platform-login.mjs', 'p43-pages.mjs', 'p43-edge-session-probe.py', 'p43-owner-login.mjs',
    'p43-edge-observe.py', 'p43-edge-page.cs', 'p43-access-connect.mjs', 'p43-live-drill.mjs', 'p43-public-http.mjs', 'p43-deploy-reconcile.mjs']) {
    if (fs.existsSync(path.join(root, '.cache', name))) files.push(`.cache/${name}`);
  }
  for (const name of ['access-connect-01.source.mjs', 'pages-deploy-01.source.mjs']) {
    if (fs.existsSync(path.join(root, '.cache/p43', name))) files.push(`.cache/p43/${name}`);
  }
  function addPublicDrill(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      assert.ok(!entry.isSymbolicLink());
      if (entry.isDirectory()) addPublicDrill(full);
      else { assert.match(entry.name, /^[a-z0-9._-]+\.(?:json|mjs|png)$/); files.push(relative(full)); }
    }
  }
  if (fs.existsSync(path.join(root, '.cache/p43/live-drill'))) addPublicDrill(path.join(root, '.cache/p43/live-drill'));
  if (increment === '04') {
    files.push('.cache/p43/ci/logs-39084376785.zip');
    const artifactRoot = path.join(root, '.cache/p43/ci/artifacts-39084376785');
    function addCheckedCi(dir) {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        assert.ok(!entry.isSymbolicLink());
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) addCheckedCi(full); else files.push(relative(full));
      }
    }
    addCheckedCi(artifactRoot);
  }
  const oauthFile = path.join(root, '.cache/p43/private/platform-login/xdg-config/.wrangler/config/default.toml');
  const oauthValues = fs.existsSync(oauthFile) ? [...read(oauthFile).matchAll(/^(?:oauth_token|refresh_token)\s*=\s*"([^"]+)"/mg)].map(match => match[1]) : [];
  const sensitive = [
    fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/token.txt', 'utf8').trim(),
    fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/p41-ci-token.txt', 'utf8').trim(),
    JSON.parse(fs.readFileSync('D:/github/my/E-Track/app/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json', 'utf8')).secrets.CLOUDFLARE_API_TOKEN,
    ...Object.values(JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/firmware-test-secrets.json', 'utf8'))),
    ...oauthValues
  ].filter(value => typeof value === 'string' && value.length > 12);
  const accessTokens = path.join(root, '.cache/p43/private/access-connect/home/.cloudflared');
  if (fs.existsSync(accessTokens)) for (const name of fs.readdirSync(accessTokens).filter(name => name.endsWith('-token'))) {
    const value = fs.readFileSync(path.join(accessTokens, name), 'utf8').trim(); if (value.length > 12) sensitive.push(value);
  }
  const owners = path.join(root, '.cache/p43/private/owner-login');
  if (fs.existsSync(owners)) for (const name of fs.readdirSync(owners).filter(name => name.endsWith('-storage-state.json'))) {
    const state = JSON.parse(fs.readFileSync(path.join(owners, name), 'utf8'));
    sensitive.push(...state.cookies.map(cookie => cookie.value).filter(value => value.length > 12));
  }
  const drills = path.join(root, '.cache/p43/private/live-drill');
  if (fs.existsSync(drills)) for (const dir of fs.readdirSync(drills)) {
    for (const name of fs.readdirSync(path.join(drills, dir))) {
      if (name === 'storage-state.json') {
        const state = JSON.parse(fs.readFileSync(path.join(drills, dir, name), 'utf8'));
        sensitive.push(...state.cookies.map(cookie => cookie.value).filter(value => value.length > 12));
      } else if (name.endsWith('-request.json')) {
        const request = JSON.parse(fs.readFileSync(path.join(drills, dir, name), 'utf8'));
        if (request.idempotencyKey) sensitive.push(request.idempotencyKey);
      }
    }
  }
  const entries = [...new Set(files)].sort().map(file => {
    const full = path.join(root, file);
    assert.ok(!fs.lstatSync(full).isSymbolicLink());
    assert.equal(fs.realpathSync(full).toLowerCase(), full.toLowerCase());
    const bytes = fs.readFileSync(full);
    const text = bytes.toString('utf8');
    assert.ok(!sensitive.some(value => text.includes(value)), `Secret in evidence candidate: ${file}`);
    assert.ok(!/https?:\/\/[^\s"<>]+[?&](?:signature|code_challenge|state|token)=/i.test(text), `Authorized URL in evidence candidate: ${file}`);
    assert.ok(!/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/.test(text), `JWT in evidence candidate: ${file}`);
    return { path: file, sizeBytes: bytes.length, sha256: digest(bytes) };
  }).filter(entry => prior.get(entry.path) !== entry.sha256);
  const archiveName = `live-preparation-${increment}.zip`;
  const archivePath = guard(`${evidence}/${archiveName}`);
  const inventoryPath = guard(`${evidence}/live-preparation-${increment}.inventory.json`);
  const listPath = guard(`.cache/p43/evidence-live-preparation-${increment}-files.txt`);
  for (const file of [archivePath, inventoryPath, listPath]) assert.ok(!fs.existsSync(file), 'Preserve previous evidence');
  fs.writeFileSync(listPath, entries.map(entry => entry.path).join('\n') + '\n', { flag: 'wx' });
  run('tar', ['-a', '-cf', archivePath, '-T', listPath]);
  assert.deepEqual(run('tar', ['-tf', archivePath]).trim().split(/\r?\n/).sort(), entries.map(entry => entry.path).sort());
  for (const entry of entries) {
    const actual = spawnSync('tar', ['-xOf', archivePath, entry.path], { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
    assert.equal(actual.status, 0);
    assert.equal(digest(actual.stdout), entry.sha256, `Archive byte mismatch: ${entry.path}`);
  }
  const archive = fs.readFileSync(archivePath);
  const receipts = entries.filter(entry => entry.path.startsWith(`${logs}/`) && entry.path.endsWith('.json'))
    .map(entry => JSON.parse(read(entry.path))).filter(item => item.exitCode !== undefined);
  const http = entries.filter(entry => entry.path.startsWith('.cache/p43/live/') && entry.path.endsWith('-receipt.json'))
    .map(entry => JSON.parse(read(entry.path)));
  const group = (items, field) => items.reduce((counts, item) => {
    const key = String(item[field]); counts[key] = (counts[key] || 0) + 1; return counts;
  }, {});
  const inventory = { createdAt: new Date().toISOString(), baseline, recordedHead: run('git', ['rev-parse', 'HEAD']).trim(),
    testedAdminSource: '933b790e69e04ee551ad255398e08f12a1b2a107',
    nature: 'Live preparation/read-only observations and preserved tooling failures. NOT a completed real Admin exercise or independent acceptance.',
    precedingArchives: previous.map(item => item.archive),
    archive: { path: archiveName, sizeBytes: archive.length, sha256: digest(archive), entries: entries.length },
    checks: { entryListingAndEveryExtractedByteVerified: true, knownSecretsScan: 'PASS', authorizedUrlScan: 'PASS' },
    observations: { closedToolReceipts: receipts.length, collectorExitCodes: group(receipts, 'exitCode'),
      httpReceipts: http.length, httpStatusCounts: group(http, 'status'), interruptedCollectorWithoutExit: 'original-capabilities-01' },
    exclusions: ['Private inputs/configuration/OAuth URLs/browser state', 'Worker private multipart source', 'Browser binaries/partial downloads/caches', 'Earlier unchanged evidence'],
    requiredLiveAdminExercise: 'NOT_RUN', newProductTests: 0, cloudBusinessMutations: 0,
    ...(increment === '02' ? { cloudConfigurationChanges: ['Created the isolated P4-3 Pages project', 'Configured only its production test bindings and matching signing settings'],
      accessCreation: 'Rejected with HTTP 403/auth.forbidden for all three existing credentials; no application created',
      login: 'Original Edge official OAuth succeeded; matched the approved account; not Admin Access' } : {}), entries };
  if (increment === '03') {
    inventory.cloudConfigurationChanges = [];
    inventory.accessCreation = 'Not retried; the three prior HTTP 403 rejections and no-application readbacks remain';
    inventory.credentialDiagnostics = 'Both existing API tokens active; own-policy reads 403/9109; existing OAuth has Pages-only write scope';
    inventory.logProbe = 'Both existing API tokens rejected the dry telemetry query with 403/10000; no health marker or signed URL sent';
    inventory.login = 'Official noninteractive refresh succeeded with unchanged scopes; no browser login, new credential or permission expansion';
  }
  if (increment === '04') {
    inventory.cloudConfigurationChanges = [
      'Created Access app ca168030-0227-49a5-bd0c-bf030c9c86ea for the isolated P4-3 origin',
      'Created its separate explicit-email policy; old Trace policy unchanged',
      'Set only e-track-firmware-p41-test observability.redact_query_string=true; deployments and bindings unchanged'
    ];
    inventory.credentialDiagnostics = 'Used the existing dedicated p41-ci-token.txt, user-confirmed e-track-ci/e-track-p41-ci; previous inventory omitted it';
    inventory.accessProtection = 'Actual new-origin 302, separate explicit-identity policy and real new-origin owner session; exact-input deployment 89805318-12e8-4ea1-9838-b794ae03580d of 933b790';
    const repaired = JSON.parse(read('.cache/p43/live/pages-csrf-02-summary.json'));
    assert.equal(repaired.deployment.sourceCommit, '972e74c43cd36b7a308e457296aaf7bb06120e78');
    inventory.testedAdminSources = ['933b790e69e04ee551ad255398e08f12a1b2a107', repaired.deployment.sourceCommit];
    inventory.testedAdminSource = repaired.deployment.sourceCommit;
    inventory.repairedDeployment = repaired;
    inventory.repairCi = JSON.parse(read('.cache/p43/logs/csrf-ci-verify-01.log'));
    inventory.newProductTests = { nativeWorker: 270, mockUi: 12, compiledRouter: 3, source: inventory.repairCi.source, runId: inventory.repairCi.runId };
    inventory.logProbe = 'One successful non-secret curl health request correlated with its real stored invocation; query marker absent throughout the event';
    inventory.ownerSession = 'Existing Edge official Access transfer; old owner and new-isolated-origin owner verified through real session endpoints; no mock identity or cookie-database export';
    inventory.cloudConfigurationChanges.push('Added only the isolated Pages Access/origin/verified-owner secrets', 'Deployed only the checked 933b790 Admin input without rebundling');
    const results = fs.existsSync(path.join(root, '.cache/p43/live-drill'))
      ? fs.readdirSync(path.join(root, '.cache/p43/live-drill')).flatMap(name => {
        const file = path.join(root, '.cache/p43/live-drill', name, 'result.json');
        if (!fs.existsSync(file)) return [];
        const value = JSON.parse(fs.readFileSync(file, 'utf8'));
        return [{ label: value.label, result: value.result, counts: value.counts, restored: value.restored,
          businessMutations: value.businessMutations, sourceSha256: value.collectorSha256, path: relative(file), sha256: digest(fs.readFileSync(file)) }];
      }) : [];
    inventory.liveResults = results;
    inventory.requiredLiveAdminExercise = 'Evaluate the complete coverage ledger across original batches; a continuation PASS alone is not whole-card PASS. Real publisher/viewer sessions remain unavailable.';
    inventory.cloudBusinessMutations = 'See source-bound HTTP/D1 originals and each continued drill result; not zero';
    inventory.nature = 'P4-3 real isolated preparation, deployment, session and development exercise originals. Not independent acceptance; original failures preserved.';
  }
  fs.writeFileSync(inventoryPath, JSON.stringify(inventory, null, 2) + '\n', { flag: 'wx' });
  process.stdout.write(JSON.stringify({ archive: inventory.archive, checks: inventory.checks, observations: inventory.observations }) + '\n');
  process.exit(0);
}
function diagnostics(name) {
  const content = read(`${logs}/${name}.log`);
  const count = regex => (content.match(regex) || []).length;
  return { sqliteExperimental: count(/ExperimentalWarning:/g), colorWarning: count(/Warning: The 'NO_COLOR'/g),
    npmInstallScriptWarningLines: count(/npm warn install-scripts/g), deprecationWarnings: count(/DeprecationWarning:/g),
    githubWarningAnnotations: count(/##\[warning\]/g), errorLevelEvents: count(/"level":"error"/g),
    nativeUncaughtExceptionLines: count(/uncaught exception;/g), npmAuditSummaries: content.split('\n').filter(line => /\d+ (high severity )?vulnerabilities/.test(line)) };
}
const dependencyScope = {};
for (const component of ['admin', 'worker']) {
  const audit = JSON.parse(read(`${logs}/dependency-audit-${component}-01.log`));
  const lockPath = `app/bluetooth_flutter_Trace/cloudflare/update-service/${component}/package-lock.json`;
  const current = JSON.parse(read(lockPath));
  const old = JSON.parse(run('git', ['show', `${baseline}:${lockPath}`]));
  dependencyScope[component] = { totals: audit.metadata.vulnerabilities,
    packages: Object.values(audit.vulnerabilities).map(value => ({ name: value.name, severity: value.severity,
      nodes: value.nodes.map(node => ({ path: node, version: current.packages[node].version,
        dev: current.packages[node].dev === true,
        unchangedFromBaseline: JSON.stringify(current.packages[node]) === JSON.stringify(old.packages[node]) })) })) };
}
const oldLog = run('tar', ['-xOf', 'docs/ota-exec-notes/P4-2-ci-2026-10-14/run-38591559979.zip',
  'Worker Typecheck and Invariants/7_Run invariant tests.txt']);
let summary = { baseline, testedCommit: tested,
  diagnostics: Object.fromEntries(['worker-host-03', 'ui-mock-03', 'ci-cloudflare-log-01', 'ci-governance-log-01'].map(name => [name, diagnostics(name)])),
  historicalNativeDiagnostics: { archive: 'P4-2-ci-2026-10-14/run-38591559979.zip',
    uncaughtExceptionLines: (oldLog.match(/uncaught exception;/g) || []).length,
    foreignKeyConstraintLines: (oldLog.match(/FOREIGN KEY constraint failed/g) || []).length }, dependencyScope };
let previous;
if (continuation) {
  const priorPath = 'docs/ota-exec-notes/P4-3-dev-2026-10-17/inventory.json';
  previous = JSON.parse(read(priorPath));
  const sha = bytes => createHash('sha256').update(bytes).digest('hex');
  assert.equal(sha(fs.readFileSync(path.join(root, path.dirname(priorPath), previous.archive.path))), previous.archive.sha256);
  const runId = '39018754889';
  const metadata = JSON.parse(read(`${logs}/bundle-fixed-state-02.log`));
  assert.equal(metadata.conclusion, 'success');
  assert.equal(metadata.status, 'completed');
  assert.equal(metadata.event, 'workflow_dispatch');
  assert.equal(metadata.headSha, tested);
  assert.equal(metadata.headBranch, 'dev/p4-3/admin-controls-20261017');
  assert.equal(metadata.jobs.length, 4);
  assert.ok(metadata.jobs.every(job => job.conclusion === 'success'));
  const input = `.cache/p43/ci/artifacts-${runId}/admin-deployment-input-${tested}`;
  assert.equal(read(`${input}/source-commit.txt`).trim(), tested);
  assert.equal(read(`${input}/source-run.txt`).trim(), `${runId}/1`);
  assert.match(read(`${input}/purpose.txt`), /BUILD ONLY\. Not deployed/);
  assert.deepEqual(fs.readdirSync(path.join(root, input)).sort(),
    ['SHA256SUMS', 'bundle-meta.json', 'public', 'purpose.txt', 'source-commit.txt', 'source-run.txt'].sort());
  const fileDigests = read(`${input}/SHA256SUMS`).trim().split(/\r?\n/).map(line => {
    const match = /^([a-f0-9]{64})  (public\/[A-Za-z0-9_./-]+)$/.exec(line);
    assert.ok(match, 'Invalid SHA256SUMS entry');
    const full = path.resolve(root, input, match[2]);
    const rel = path.relative(path.resolve(root, input), full);
    assert.ok(rel !== '..' && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
    const bytes = fs.readFileSync(guard(full));
    assert.equal(sha(bytes), match[1]);
    return { path: match[2], sizeBytes: bytes.length, sha256: match[1] };
  });
  function listPublic(dir) {
    return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
      assert.ok(!entry.isSymbolicLink());
      const full = path.join(dir, entry.name);
      return entry.isDirectory() ? listPublic(full) : [path.relative(path.join(root, input), full).replaceAll('\\', '/')];
    });
  }
  assert.deepEqual(listPublic(path.join(root, input, 'public')).sort(), fileDigests.map(item => item.path).sort());
  assert.deepEqual(fileDigests.map(item => item.path).sort(), ['public/_routes.json', 'public/_worker.js/index.js', 'public/index.html']);
  const sourceHtml = run('git', ['show', `${tested}:app/bluetooth_flutter_Trace/cloudflare/update-service/admin/public/index.html`]);
  assert.equal(read(`${input}/public/index.html`), sourceHtml);
  const routes = JSON.parse(read(`${input}/public/_routes.json`));
  assert.deepEqual(routes.include, ['/api/admin/*']);
  assert.deepEqual(routes.exclude, []);
  const smoke = read(`.cache/p43/ci/artifacts-${runId}/admin-bundle-diagnostics-${runId}-1/native-smoke.log`);
  const smokeCounts = Object.fromEntries(['tests', 'pass', 'fail', 'skipped', 'cancelled'].map(name =>
    [name, Number(smoke.match(new RegExp(`\\b${name} (\\d+)`))?.[1])]));
  assert.deepEqual(smokeCounts, { tests: 3, pass: 3, fail: 0, skipped: 0, cancelled: 0 });
  const withoutColor = text => text.replace(/(?:\u001b|\^\[)\[[0-9;]*m/g, '');
  for (const sample of ['\u001b[2mTests\u001b[22m 259 passed (259)', '^[[2mTests^[[22m 259 passed (259)']) {
    assert.equal(withoutColor(sample), 'Tests 259 passed (259)');
  }
  const ciLog = withoutColor(read(`${logs}/bundle-fixed-log-01.log`));
  const countLines = ciLog.split('\n').filter(line => line.includes('\tRun invariant tests\t') && /\bTests\s/.test(line));
  assert.equal(countLines.length, 1);
  assert.match(countLines[0], /Tests\s+259 passed\s+\(259\)/);
  assert.ok(/12 passed \(/.test(ciLog), 'Missing mock UI test count');
  summary = { baseline, testedCommit: tested, previousInventory: priorPath,
    previousArchiveSha256: previous.archive.sha256, workflowRun: runId, workflowConclusion: metadata.conclusion,
    nativeWorker: { passed: 259, failed: 0, skipped: 0 }, mockUi: { passed: 12, failed: 0, skipped: 0 },
    compiledRouterSmoke: smokeCounts, diagnostics: diagnostics('bundle-fixed-log-01'),
    deploymentInput: { path: input, sourceAndFileDigestsVerified: true, files: fileDigests },
    priorSmokeFailure: { run: '39018015096', passed: 0, failed: 4, skipped: 0, classification: 'HARNESS_CONFIGURATION',
      cause: 'Default Miniflare modulesRoot made the external artifact module name start with ..',
      repair: 'Explicit checked artifact entry directory as modulesRoot' },
    realAdminExercise: 'NOT_RUN: target, approved fixture/mutation scope and live Access owner session unresolved' };
}
process.stdout.write(JSON.stringify(summary, null, 2) + '\n');
if (mode !== 'archive' && mode !== 'archive-continuation') process.exit(0);
const target = guard('docs/ota-exec-notes/P4-3-dev-2026-10-17');
const archiveName = continuation ? 'continuation-01.zip' : 'originals.zip';
const archivePath = guard(path.join(target, archiveName));
const inventoryPath = guard(path.join(target, continuation ? 'continuation-01.inventory.json' : 'inventory.json'));
const listPath = guard(continuation ? '.cache/p43/evidence-continuation-01-files.txt' : '.cache/p43/evidence-files.txt');
if (fs.existsSync(archivePath) || fs.existsSync(inventoryPath) || fs.existsSync(listPath)) throw new Error('Original evidence already exists');
const files = [];
function collect(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) throw new Error('Linked input: ' + file);
    const actual = fs.realpathSync(file);
    if (relative(actual).startsWith('../') || path.isAbsolute(relative(actual))) throw new Error('Escaped input');
    if (entry.isDirectory()) collect(file);
    else if (entry.isFile()) files.push(file);
  }
}
for (const name of fs.readdirSync(path.join(root, logs)).filter(name => name.endsWith('.json'))) {
  const receipt = JSON.parse(read(`${logs}/${name}`));
  if (receipt.exitCode === undefined) continue;
  files.push(path.join(root, logs, name));
  files.push(path.join(root, logs, name.replace(/\.json$/, '.log')));
}
collect(path.join(root, '.cache/p43/ui'));
collect(path.join(root, '.cache/p43/ci'));
for (const name of ['p43-run.cjs', 'p43-audit.cjs', 'p43-evidence.cjs']) files.push(path.join(root, '.cache', name));
if (continuation) {
  files.push(path.join(root, '.cache/p43-live-entry.mjs'), path.join(root, '.cache/p43/live-entry-01.json'));
}
files.sort();
const digest = buffer => createHash('sha256').update(buffer).digest('hex');
const priorDigests = new Map((previous?.entries || []).map(entry => [entry.path, entry.sha256]));
const entries = [...new Set(files)].map(file => { const bytes = fs.readFileSync(file); return { path: relative(file), sizeBytes: bytes.length, sha256: digest(bytes) }; })
  .filter(entry => priorDigests.get(entry.path) !== entry.sha256);
fs.mkdirSync(target, { recursive: true });
fs.writeFileSync(listPath, entries.map(entry => entry.path).join('\n') + '\n', { flag: 'wx' });
run('tar', ['-a', '-cf', archivePath, '-T', listPath]);
const listing = run('tar', ['-tf', archivePath]).trim().split(/\r?\n/).sort();
if (JSON.stringify(listing) !== JSON.stringify(entries.map(entry => entry.path).sort())) throw new Error('Archive entry mismatch');
for (const entry of entries) {
  const result = spawnSync('tar', ['-xOf', archivePath, entry.path], { cwd: root, windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  if (result.status !== 0 || digest(result.stdout) !== entry.sha256) throw new Error('Archive byte mismatch: ' + entry.path);
}
const archive = fs.readFileSync(archivePath);
fs.writeFileSync(inventoryPath, JSON.stringify({ ...summary, createdAt: new Date().toISOString(),
  nature: 'Implementation development evidence; mock UI, native emulator and host results are not real Access or independent acceptance',
  archive: { path: archiveName, sizeBytes: archive.length, sha256: digest(archive), entries: entries.length }, entries }, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ archive: relative(archivePath), sizeBytes: archive.length, entries: entries.length, sha256: digest(archive), verified: true }) + '\n');
