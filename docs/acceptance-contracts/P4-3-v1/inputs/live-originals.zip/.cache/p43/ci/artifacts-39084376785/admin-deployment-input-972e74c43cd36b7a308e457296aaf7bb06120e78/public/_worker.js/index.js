var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// ../node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
if (!("__unenv__" in performance)) {
  const proto = Performance.prototype;
  for (const key of Object.getOwnPropertyNames(proto)) {
    if (key !== "constructor" && !(key in performance)) {
      const desc = Object.getOwnPropertyDescriptor(proto, key);
      if (desc) {
        Object.defineProperty(performance, key, desc);
      }
    }
  }
}
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// ../node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// ../node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// ../node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// ../node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// ../node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// ../node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// ../node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// ../node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir3, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env2) {
    return 1;
  }
  hasColors(count3, env2) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// ../node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// ../node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd2) {
    this.#cwd = cwd2;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var unenvProcess = new Process({
  env: globalProcess.env,
  hrtime,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var {
  _channel,
  _debugEnd,
  _debugProcess,
  _disconnect,
  _events,
  _eventsCount,
  _exiting,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _handleQueue,
  _kill,
  _linkedBinding,
  _maxListeners,
  _pendingMessage,
  _preload_modules,
  _rawDebug,
  _send,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  arch,
  argv,
  argv0,
  assert: assert2,
  availableMemory,
  binding,
  channel,
  chdir,
  config,
  connected,
  constrainedMemory,
  cpuUsage,
  cwd,
  debugPort,
  disconnect,
  dlopen,
  domain,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exitCode,
  finalization,
  getActiveResourcesInfo,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getMaxListeners,
  getuid,
  hasUncaughtExceptionCaptureCallback,
  hrtime: hrtime3,
  initgroups,
  kill,
  listenerCount,
  listeners,
  loadEnvFile,
  mainModule,
  memoryUsage,
  moduleLoadList,
  nextTick,
  off,
  on,
  once,
  openStdin,
  permission,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  reallyExit,
  ref,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  send,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setMaxListeners,
  setSourceMapsEnabled,
  setuid,
  setUncaughtExceptionCaptureCallback,
  sourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  throwDeprecation,
  title,
  traceDeprecation,
  umask,
  unref,
  uptime,
  version,
  versions
} = unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// ../node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// ../../worker/src/errors.ts
var ApiError = class extends Error {
  constructor(code, message, status, details) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
    this.name = "ApiError";
  }
  code;
  status;
  details;
  static {
    __name(this, "ApiError");
  }
};
function backendUnavailable(message = "Update backend unavailable") {
  return new ApiError("BACKEND_UNAVAILABLE", message, 503);
}
__name(backendUnavailable, "backendUnavailable");
function invalidParameter(message) {
  return new ApiError("INVALID_PARAMETER", message, 400);
}
__name(invalidParameter, "invalidParameter");

// ../../scripts/firmware-schema.mjs
var FIRMWARE_MODEL = "e-track-at32f435";
var FirmwareSchemaError = class extends Error {
  static {
    __name(this, "FirmwareSchemaError");
  }
  constructor(message, code = "INVALID_PARAMETER") {
    super(message);
    this.name = "FirmwareSchemaError";
    this.code = code;
  }
};
function exactObject(value, keys, label = "body") {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new FirmwareSchemaError(`${label} must be an object`);
  }
  for (const key of Object.keys(value)) {
    if (!keys.includes(key)) throw new FirmwareSchemaError(`Unknown ${label} field: ${key}`);
  }
  return value;
}
__name(exactObject, "exactObject");
function text(value, label, allowEmpty = false) {
  if (typeof value !== "string" || !allowEmpty && !value.trim() || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) {
    throw new FirmwareSchemaError(`${label} must be a valid string`);
  }
  if (/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(value)) {
    throw new FirmwareSchemaError(`${label} contains invalid Unicode`);
  }
  return value;
}
__name(text, "text");
function integer(value, label, max = Number.MAX_SAFE_INTEGER, min = 0) {
  if (!Number.isSafeInteger(value) || value < min || value > max) {
    throw new FirmwareSchemaError(`${label} must be an integer in ${min}..${max}`);
  }
  return value;
}
__name(integer, "integer");
function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
__name(canonicalJson, "canonicalJson");

// ../../worker/src/crypto.ts
var encoder = new TextEncoder();
async function sha256Hex(input) {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(input));
  return hex(new Uint8Array(digest));
}
__name(sha256Hex, "sha256Hex");
async function signHmacSha256(message, key) {
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    encoder.encode(key),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", cryptoKey, encoder.encode(message));
  return base64Url(new Uint8Array(signature));
}
__name(signHmacSha256, "signHmacSha256");
function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
__name(base64Url, "base64Url");
function hex(bytes) {
  return Array.from(bytes).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
__name(hex, "hex");

// ../../worker/src/logger.ts
var runtimeLogSink = globalThis["console"];

// ../../worker/src/http.ts
function json(data, status = 200, headers) {
  return Response.json(data, {
    status,
    headers: {
      "Cache-Control": "no-store",
      ...headers
    }
  });
}
__name(json, "json");

// ../../worker/src/rate_limiter.ts
import { DurableObject } from "cloudflare:workers";

// ../../worker/src/firmware_download.ts
function keyFor(env2, version2) {
  if (version2 === env2.DOWNLOAD_TOKEN_KEY_VERSION) {
    if (env2.DOWNLOAD_HMAC_KEY_CURRENT) return env2.DOWNLOAD_HMAC_KEY_CURRENT;
    throw backendUnavailable("Firmware signing key is not configured");
  }
  if (version2 === env2.DOWNLOAD_TOKEN_PREVIOUS_KEY_VERSION && env2.DOWNLOAD_HMAC_KEY_PREVIOUS) {
    return env2.DOWNLOAD_HMAC_KEY_PREVIOUS;
  }
  throw new ApiError("TOKEN_INVALID", "Unknown signing key version", 401);
}
__name(keyFor, "keyFor");
function cutover(env2) {
  const value = env2.FIRMWARE_V2_CUTOVER_EPOCH;
  if (!value || !/^(0|[1-9][0-9]*)$/.test(value) || !Number.isSafeInteger(Number(value))) {
    throw backendUnavailable("Auditable firmware v2 cutover epoch is not configured");
  }
  return Number(value);
}
__name(cutover, "cutover");
function firmwareTokenMessage(asset, purpose, expiresAt, keyVersion) {
  return ["2", "GET", asset.id, asset.release_id, asset.kind, purpose, String(expiresAt), keyVersion].join("\n");
}
__name(firmwareTokenMessage, "firmwareTokenMessage");
async function signFirmwareDownload(env2, origin, asset, purpose, now = Math.floor(Date.now() / 1e3)) {
  cutover(env2);
  if (purpose === "admin-recovery" !== (asset.kind === "recovery")) {
    throw new ApiError("TOKEN_INVALID", "Asset purpose mismatch", 401);
  }
  const url = new URL(origin);
  if (url.protocol !== "https:" || url.username || url.password) throw backendUnavailable("Firmware download origin must use HTTPS");
  const expiresAt = now + 300;
  const keyVersion = env2.DOWNLOAD_TOKEN_KEY_VERSION;
  if (!/^[A-Za-z0-9._-]+$/.test(keyVersion)) throw backendUnavailable("Invalid signing key version");
  const signature = await signHmacSha256(firmwareTokenMessage(asset, purpose, expiresAt, keyVersion), keyFor(env2, keyVersion));
  const query = new URLSearchParams({
    tokenVersion: "2",
    assetId: asset.id,
    releaseId: asset.release_id,
    kind: asset.kind,
    purpose,
    expiresAt: String(expiresAt),
    keyVersion,
    signature
  });
  return { downloadUrl: `${url.origin}/api/public/firmware/download?${query}`, expiresAt };
}
__name(signFirmwareDownload, "signFirmwareDownload");
async function verifyFirmwareObject(bucket, asset) {
  const head = await bucket.head(asset.r2Key);
  if (!head || head.size !== asset.sizeBytes || head.customMetadata?.sha256 !== asset.sha256 || head.customMetadata?.kind !== asset.kind) throw new Error("R2 metadata mismatch");
  const object = await bucket.get(asset.r2Key, { onlyIf: { etagMatches: head.etag } });
  if (!object || !("body" in object) || object.size !== asset.sizeBytes) throw new Error("R2 object changed or missing");
  const hash = new crypto.DigestStream("SHA-256");
  let bytes = 0;
  const counter = new TransformStream({
    transform(chunk, controller) {
      bytes += chunk.byteLength;
      if (bytes > asset.sizeBytes) throw new Error("R2 body exceeds registered size");
      controller.enqueue(chunk);
    }
  });
  const [, rawDigest] = await Promise.all([object.body.pipeThrough(counter).pipeTo(hash), hash.digest]);
  const digest = Array.from(new Uint8Array(rawDigest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  if (bytes !== asset.sizeBytes || digest !== asset.sha256) throw new Error("R2 readback mismatch");
  return object.httpEtag;
}
__name(verifyFirmwareObject, "verifyFirmwareObject");

// ../../worker/src/firmware.ts
async function firmwareOperation(action) {
  try {
    return await action();
  } catch (error3) {
    if (error3 instanceof ApiError) throw error3;
    if (error3 instanceof FirmwareSchemaError) {
      throw new ApiError(error3.code, error3.message, error3.code === "FORMAL_RELEASE_REQUIRED" ? 403 : 400);
    }
    throw backendUnavailable();
  }
}
__name(firmwareOperation, "firmwareOperation");
function requireFirmwareJsonHeaders(request) {
  const acceptsJson = request.headers.get("Accept")?.split(",").some((entry) => {
    const [mediaType, ...parameters] = entry.split(";").map((value) => value.trim());
    if (mediaType.toLowerCase() !== "application/json") return false;
    const quality = parameters.filter((value) => /^q\s*=/i.test(value));
    if (quality.length === 0) return true;
    if (quality.length !== 1) return false;
    const match2 = /^q\s*=\s*(0(?:\.\d{0,3})?|1(?:\.0{0,3})?)$/i.exec(quality[0]);
    return !!match2 && Number(match2[1]) > 0;
  });
  if (new URL(request.url).protocol !== "https:" || request.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase() !== "application/json" || !acceptsJson) {
    throw invalidParameter("HTTPS, Content-Type and Accept application/json are required");
  }
}
__name(requireFirmwareJsonHeaders, "requireFirmwareJsonHeaders");
async function readFirmwareJson(request) {
  const reader = request.body?.getReader();
  if (!reader) throw invalidParameter("JSON body is required");
  const chunks = [];
  let length = 0;
  try {
    for (; ; ) {
      const item = await reader.read();
      if (item.done) break;
      length += item.value.byteLength;
      if (length > 1024 * 1024) throw invalidParameter("Firmware metadata exceeds 1 MiB");
      chunks.push(item.value);
    }
  } finally {
    await reader.cancel();
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw invalidParameter("Invalid JSON body");
  }
}
__name(readFirmwareJson, "readFirmwareJson");
async function firmwareAssets(db, releaseId) {
  return (await db.prepare("SELECT * FROM firmware_release_assets WHERE release_id=? ORDER BY kind,base_vcode,file_name").bind(releaseId).all()).results;
}
__name(firmwareAssets, "firmwareAssets");
function usableFirmwareAsset(asset) {
  return asset.r2_state === "available" && !!asset.r2_key && !!asset.r2_etag && /^[0-9a-f]{64}$/.test(asset.sha256) && Number.isSafeInteger(asset.size_bytes) && asset.size_bytes > 0;
}
__name(usableFirmwareAsset, "usableFirmwareAsset");
function requireFirmwareFull(release2, assets) {
  const full = assets.filter((a) => a.kind === "full");
  if (!/^[0-9a-f]{64}$/.test(release2.target_image_sha256) || full.length !== 1 || !usableFirmwareAsset(full[0]) || full[0].base_vcode !== 0 || full[0].base_image_sha256 !== "" || assets.some((a) => !["full", "patch", "recovery"].includes(a.kind) || a.kind === "patch" && (!/^[0-9a-f]{64}$/.test(a.base_image_sha256) || a.base_vcode <= 0 || a.base_vcode >= release2.version_code))) {
    throw backendUnavailable("Firmware release lacks a complete verified full fallback");
  }
  return full[0];
}
__name(requireFirmwareFull, "requireFirmwareFull");

// ../../worker/src/firmware_admin.ts
var FIRMWARE_CHANNEL_ACTIONS = {
  publish: "publish",
  retract: "retract",
  "stop-latest": "stop_latest",
  "resume-latest": "resume_latest",
  "stop-downloads": "stop_downloads",
  "resume-downloads": "resume_downloads"
};
function scope(body) {
  if (body.appId !== "trace" || body.deviceModel !== FIRMWARE_MODEL) throw invalidParameter("Invalid firmware appId/deviceModel");
}
__name(scope, "scope");
function releaseIdentity(value) {
  if (!/^[A-Za-z0-9._-]+$/.test(value) || value.includes("..")) throw invalidParameter("Invalid releaseId");
  return value;
}
__name(releaseIdentity, "releaseIdentity");
function ready(release2) {
  if (!release2 || release2.app_id !== "trace" || release2.device_model !== FIRMWARE_MODEL) throw new ApiError("RELEASE_NOT_FOUND", "Firmware release not found", 404);
  if (release2.archived) throw new ApiError("RELEASE_ARCHIVED", "Firmware release archived", 410);
  if (release2.state === "disabled") throw new ApiError("RELEASE_DISABLED", "Firmware release disabled", 410);
  if (release2.state !== "ready") throw new ApiError("RELEASE_NOT_READY", "Firmware release not ready", 409);
}
__name(ready, "ready");
function listFirmware(env2, url, requestId, channels) {
  return firmwareOperation(async () => {
    for (const key of url.searchParams.keys()) if (!["appId", "deviceModel"].includes(key)) throw invalidParameter("Unknown firmware list parameter");
    for (const key of ["appId", "deviceModel"]) if (url.searchParams.getAll(key).length !== 1) throw invalidParameter("Required firmware scope missing/duplicated");
    scope(Object.fromEntries(url.searchParams));
    const channelRows = (await env2.DB.prepare("SELECT * FROM firmware_channels WHERE app_id=? AND device_model=? ORDER BY name").bind("trace", FIRMWARE_MODEL).all()).results;
    if (channels) return json({ ok: true, requestId, firmwareChannels: channelRows.map((c) => ({
      appId: c.app_id,
      deviceModel: c.device_model,
      channel: c.name,
      ...channelSnapshot(c),
      ...c.legacy_current_release_id ? { legacyPending: true } : {}
    })) });
    const releases = (await env2.DB.prepare("SELECT * FROM firmware_releases WHERE app_id=? AND device_model=? ORDER BY version_code DESC").bind("trace", FIRMWARE_MODEL).all()).results;
    const result = [];
    for (const r of releases) result.push({
      releaseId: r.id,
      appId: r.app_id,
      deviceModel: r.device_model,
      versionName: r.version_name,
      versionCode: r.version_code,
      releaseTag: r.release_tag,
      state: r.state,
      archived: r.archived === 1,
      releaseNotes: r.release_notes,
      targetImageSha256: r.target_image_sha256,
      publishedChannels: channelRows.filter((c) => c.current_release_id === r.id).map((c) => c.name),
      assets: (await firmwareAssets(env2.DB, r.id)).map((a) => ({
        assetId: a.id,
        kind: a.kind,
        fileName: a.file_name,
        sha256: a.sha256,
        sizeBytes: a.size_bytes,
        r2State: a.r2_state,
        baseVersionCode: a.base_vcode,
        baseImageSha256: a.kind === "patch" ? a.base_image_sha256 : null
      }))
    });
    return json({ ok: true, requestId, firmwareReleases: result });
  });
}
__name(listFirmware, "listFirmware");
function channelSnapshot(c) {
  return {
    currentReleaseId: c.current_release_id,
    revision: c.revision,
    disableLatest: c.disable_latest === 1,
    disableDownloads: c.disable_downloads === 1,
    maintenanceMessage: c.maintenance_message
  };
}
__name(channelSnapshot, "channelSnapshot");
function mutateFirmwareChannel(env2, actor, name, action, body) {
  return firmwareOperation(async () => {
    if (!["stable", "beta"].includes(name) || !Object.values(FIRMWARE_CHANNEL_ACTIONS).includes(action)) {
      throw invalidParameter("Invalid firmware channel action");
    }
    const pointerAction = action === "publish" || action === "retract";
    const stopping = action === "stop_latest" || action === "stop_downloads";
    const input = exactObject(body, [
      "appId",
      "deviceModel",
      "expectedRevision",
      "reason",
      ...pointerAction ? ["releaseId"] : stopping ? ["maintenanceMessage"] : []
    ]);
    scope(input);
    const requestedRelease = pointerAction ? releaseIdentity(text(input.releaseId, "releaseId")) : null;
    const revision = integer(input.expectedRevision, "expectedRevision", Number.MAX_SAFE_INTEGER - 1);
    const reason = text(input.reason, "reason");
    const maintenance = input.maintenanceMessage === void 0 ? void 0 : text(input.maintenanceMessage, "maintenanceMessage", true);
    const channel2 = await env2.DB.prepare("SELECT * FROM firmware_channels WHERE app_id=? AND device_model=? AND name=?").bind("trace", FIRMWARE_MODEL, name).first();
    if (!channel2) throw new ApiError("RELEASE_NOT_FOUND", "Firmware channel not found", 404);
    if (channel2.revision !== revision) throw new ApiError("CAS_CONFLICT", "Firmware channel changed", 409);
    const before = channelSnapshot(channel2);
    const releaseId = pointerAction ? requestedRelease : channel2.current_release_id;
    const after = { ...before, currentReleaseId: releaseId, revision: revision + 1 };
    if (action === "stop_latest" || action === "resume_latest") after.disableLatest = stopping;
    if (action === "stop_downloads" || action === "resume_downloads") after.disableDownloads = stopping;
    if (stopping && maintenance !== void 0) after.maintenanceMessage = maintenance;
    if (!pointerAction && !stopping && !after.disableLatest && !after.disableDownloads) after.maintenanceMessage = null;
    const needsReady = pointerAction || !stopping;
    if (needsReady) {
      const target = await env2.DB.prepare("SELECT * FROM firmware_releases WHERE id=?").bind(releaseId).first();
      ready(target);
      const assets = await firmwareAssets(env2.DB, target.id);
      if (assets.some((a) => a.r2_state === "archived" || a.r2_state === "r2_deleted")) throw new ApiError("ASSET_ARCHIVED", "Firmware asset archived", 409);
      if (assets.some((a) => !usableFirmwareAsset(a))) throw new ApiError("RELEASE_INCOMPLETE", "Firmware asset unavailable", 409);
      requireFirmwareFull(target, assets);
      if (pointerAction && !target.release_notes.trim()) throw new ApiError("RELEASE_NOTES_REQUIRED", "Firmware release notes are required", 409);
      if (action === "publish") {
        const current = channel2.current_release_id ? await env2.DB.prepare("SELECT version_code FROM firmware_releases WHERE id=?").bind(channel2.current_release_id).first() : channel2.legacy_current_release_id ? await env2.DB.prepare("SELECT version_code FROM firmware_releases_legacy WHERE id=?").bind(channel2.legacy_current_release_id).first() : null;
        if (current && target.version_code <= current.version_code) throw new ApiError("VERSION_REGRESSION", "Publish must advance firmware version", 409);
      }
      for (const asset of assets) {
        try {
          const etag = await verifyFirmwareObject(env2.RELEASES_BUCKET, {
            r2Key: asset.r2_key,
            kind: asset.kind,
            sha256: asset.sha256,
            sizeBytes: asset.size_bytes
          });
          if (etag !== asset.r2_etag) throw new Error("R2 identity changed");
        } catch {
          throw new ApiError("R2_VERIFY_FAILED", "Firmware R2 readback could not be confirmed", 503);
        }
      }
    }
    const gate = needsReady ? ` AND EXISTS (SELECT 1 FROM firmware_releases r WHERE r.id=?
      AND r.app_id='trace' AND r.device_model=? AND r.state='ready' AND r.archived=0
      AND (SELECT count(*) FROM firmware_release_assets a WHERE a.release_id=r.id AND a.kind='full')=1
      AND NOT EXISTS (SELECT 1 FROM firmware_release_assets a WHERE a.release_id=r.id AND
        (a.r2_state<>'available' OR a.r2_key IS NULL OR length(trim(a.r2_key))=0
         OR a.r2_etag IS NULL OR length(trim(a.r2_etag))=0)))` : "";
    const gateValues = needsReady ? [releaseId, FIRMWARE_MODEL] : [];
    const idempotent = !pointerAction && after.disableLatest === before.disableLatest && after.disableDownloads === before.disableDownloads && after.maintenanceMessage === before.maintenanceMessage;
    const statement = idempotent ? env2.DB.prepare(`SELECT * FROM firmware_channels WHERE id=? AND revision=?${gate}`).bind(channel2.id, revision, ...gateValues) : env2.DB.prepare(`UPDATE firmware_channels SET current_release_id=?,legacy_current_release_id=?,
          disable_latest=?,disable_downloads=?,maintenance_message=?,revision=revision+1,
          last_action=?,last_actor=?,last_actor_type='access',last_request_id=?,last_reason=?,
          last_before_json=?,last_after_json=?,updated_at=datetime('now')
          WHERE id=? AND revision=?${gate} RETURNING *`).bind(
      releaseId,
      pointerAction ? null : channel2.legacy_current_release_id,
      Number(after.disableLatest),
      Number(after.disableDownloads),
      after.maintenanceMessage,
      action,
      actor.email.trim().toLowerCase(),
      actor.requestId,
      reason,
      canonicalJson(before),
      canonicalJson(after),
      channel2.id,
      revision,
      ...gateValues
    );
    const result = await env2.DB.batch([statement]);
    const updated = result[0].results[0];
    if (!updated) throw new ApiError("CAS_CONFLICT", "Firmware channel changed", 409);
    return json({
      ok: true,
      requestId: actor.requestId,
      action,
      channel: updated.name,
      ...channelSnapshot(updated),
      idempotent
    });
  });
}
__name(mutateFirmwareChannel, "mutateFirmwareChannel");
function tombstoneInsert(db, now, actor, key) {
  const sql = `INSERT INTO firmware_admin_idempotency_tombstones
    (actor_canonical,idempotency_key,fingerprint,action,release_id,expired_at,tombstoned_at)
    SELECT actor_canonical,idempotency_key,fingerprint,action,release_id,retained_until,?
    FROM firmware_admin_idempotency WHERE state='completed' AND retained_until<=?
    ${actor === void 0 ? "" : "AND actor_canonical=? AND idempotency_key=?"}
    ON CONFLICT(actor_canonical,idempotency_key) DO NOTHING`;
  return actor === void 0 ? db.prepare(sql).bind(now, now) : db.prepare(sql).bind(now, now, actor, key);
}
__name(tombstoneInsert, "tombstoneInsert");
async function replayResult(db, actor, key, fingerprint, now) {
  const records = await db.batch([
    db.prepare("SELECT * FROM firmware_admin_idempotency_tombstones WHERE actor_canonical=? AND idempotency_key=?").bind(actor, key),
    db.prepare("SELECT * FROM firmware_admin_idempotency WHERE actor_canonical=? AND idempotency_key=?").bind(actor, key)
  ]);
  const t = records[0].results[0];
  const r = records[1].results[0];
  if (t && !("expired_at" in t) || r && !("state" in r)) throw backendUnavailable("Idempotency row shape mismatch");
  const tombstone = t && "expired_at" in t ? t : void 0;
  const row = r && "state" in r ? r : void 0;
  if (row && row.state !== "completed") throw backendUnavailable("Incomplete idempotency result");
  if (tombstone && row && (tombstone.fingerprint !== row.fingerprint || tombstone.action !== row.action || tombstone.release_id !== row.release_id || tombstone.expired_at !== row.retained_until)) throw backendUnavailable("Idempotency integrity failure");
  if (row && now >= row.retained_until) await db.batch([tombstoneInsert(db, now, actor, key)]);
  const original = tombstone ?? row;
  if (!original) return null;
  if (original.fingerprint !== fingerprint) throw new ApiError("IDEMPOTENCY_CONFLICT", "Idempotency request changed", 409);
  if (tombstone || !row || now >= row.retained_until || row.original_expires_at !== null && now >= row.original_expires_at) {
    throw new ApiError("IDEMPOTENCY_RESULT_EXPIRED", "Original idempotency result expired; use a new key", 409);
  }
  const body = JSON.parse(row.response_body_json);
  if (row.status_code !== 200 || body.ok !== true || body.requestId !== row.request_id || body.releaseId !== row.release_id || body.idempotent !== false || body.action !== (row.action === "disable" ? "disable_release" : "issue_recovery_download") || row.action === "recovery-download" && body.expiresAt !== row.original_expires_at) {
    throw backendUnavailable("Idempotency result integrity failure");
  }
  return json({ ...body, idempotent: true }, 200, { "X-Request-Id": row.request_id });
}
__name(replayResult, "replayResult");
function firmwareReleaseAction(request, env2, actor, id, action) {
  return firmwareOperation(async () => {
    const lookupEpoch = Math.floor(Date.now() / 1e3);
    requireFirmwareJsonHeaders(request);
    const releaseId = releaseIdentity(id);
    const body = exactObject(await readFirmwareJson(request), ["appId", "deviceModel", "reason"]);
    scope(body);
    const reason = text(body.reason, "reason");
    const key = request.headers.get("Idempotency-Key");
    if (!key || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(key)) {
      throw invalidParameter("Idempotency-Key must be a lowercase UUIDv4");
    }
    const actorCanonical = actor.email.trim().toLowerCase();
    const path = `/api/admin/firmware/releases/${releaseId}/${action}`;
    const fingerprint = await sha256Hex(canonicalJson({ method: "POST", path, body }));
    const existing = await replayResult(env2.DB, actorCanonical, key, fingerprint, lookupEpoch);
    if (existing) return existing;
    try {
      const release2 = await env2.DB.prepare("SELECT * FROM firmware_releases WHERE id=?").bind(releaseId).first();
      if (!release2 || release2.app_id !== body.appId || release2.device_model !== body.deviceModel) throw new ApiError("RELEASE_NOT_FOUND", "Firmware release not found", 404);
      if (release2.archived) throw new ApiError("RELEASE_ARCHIVED", "Firmware release archived", 410);
      if (release2.state === "disabled") throw new ApiError("RELEASE_DISABLED", "Firmware release disabled", 410);
      const auditId = crypto.randomUUID();
      const statements = [];
      let now;
      let result;
      let expiresAt = null;
      if (action === "disable") {
        if (await env2.DB.prepare("SELECT id FROM firmware_channels WHERE current_release_id=?").bind(releaseId).first()) {
          throw new ApiError("RELEASE_IN_USE", "Firmware release is still referenced", 409);
        }
        now = Math.floor(Date.now() / 1e3);
        statements.push(env2.DB.prepare("UPDATE firmware_releases SET state='disabled',updated_at=datetime('now') WHERE id=? AND state=? AND archived=0").bind(releaseId, release2.state));
        statements.push(env2.DB.prepare(`INSERT INTO audit_logs(id,app_id,actor,actor_type,action,target_type,target_id,request_id,reason,before_json,after_json)
          SELECT ?,?,?,'access','disable_release','firmware_release',?,?,?,?,? WHERE changes()=1`).bind(
          auditId,
          release2.app_id,
          actorCanonical,
          releaseId,
          actor.requestId,
          reason,
          canonicalJson({ state: release2.state, archived: release2.archived }),
          canonicalJson({ state: "disabled", archived: release2.archived })
        ));
        result = { ok: true, requestId: actor.requestId, action: "disable_release", releaseId, state: "disabled", idempotent: false };
      } else {
        ready(release2);
        const recovery = (await firmwareAssets(env2.DB, releaseId)).filter((a) => a.kind === "recovery");
        if (recovery.length !== 1) throw new ApiError("RECOVERY_ASSET_UNAVAILABLE", "Exactly one recovery asset is required", 409);
        const asset = recovery[0];
        if (["archived", "r2_deleted"].includes(asset.r2_state)) throw new ApiError("ASSET_ARCHIVED", "Recovery asset archived", 409);
        if (!usableFirmwareAsset(asset)) throw new ApiError("RECOVERY_ASSET_UNAVAILABLE", "Recovery asset is incomplete", 409);
        try {
          const etag = await verifyFirmwareObject(env2.RELEASES_BUCKET, { r2Key: asset.r2_key, kind: "recovery", sha256: asset.sha256, sizeBytes: asset.size_bytes });
          if (etag !== asset.r2_etag) throw new Error("R2 identity changed");
        } catch {
          throw new ApiError("R2_VERIFY_FAILED", "Recovery R2 readback could not be confirmed", 503);
        }
        if (!env2.FIRMWARE_DOWNLOAD_ORIGIN) throw backendUnavailable("Firmware download origin is not configured");
        now = Math.floor(Date.now() / 1e3);
        const signed = await signFirmwareDownload(env2, env2.FIRMWARE_DOWNLOAD_ORIGIN, asset, "admin-recovery", now);
        expiresAt = signed.expiresAt;
        const identity = { releaseId, assetId: asset.id, kind: "recovery", r2State: asset.r2_state, sha256: asset.sha256, sizeBytes: asset.size_bytes };
        statements.push(env2.DB.prepare(`INSERT INTO audit_logs(id,app_id,actor,actor_type,action,target_type,target_id,request_id,reason,before_json,after_json)
          SELECT ?,?,?,'access','issue_recovery_download','firmware_asset',?,?,?,?,?
          FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id
          WHERE a.id=? AND r.id=? AND r.state='ready' AND r.archived=0 AND a.kind='recovery'
            AND a.r2_state='available' AND a.r2_key=? AND a.r2_etag=? AND a.sha256=? AND a.size_bytes=?`).bind(
          auditId,
          release2.app_id,
          actorCanonical,
          asset.id,
          actor.requestId,
          reason,
          canonicalJson(identity),
          canonicalJson({ ...identity, purpose: "admin-recovery", expiresAt }),
          asset.id,
          releaseId,
          asset.r2_key,
          asset.r2_etag,
          asset.sha256,
          asset.size_bytes
        ));
        result = {
          ok: true,
          requestId: actor.requestId,
          action: "issue_recovery_download",
          releaseId,
          assetId: asset.id,
          kind: "recovery",
          fileName: asset.file_name,
          sha256: asset.sha256,
          sizeBytes: asset.size_bytes,
          ...signed,
          idempotent: false
        };
      }
      statements.unshift(
        env2.DB.prepare("SELECT fingerprint FROM firmware_admin_idempotency_tombstones WHERE actor_canonical=? AND idempotency_key=?").bind(actorCanonical, key),
        env2.DB.prepare("SELECT state FROM firmware_admin_idempotency WHERE actor_canonical=? AND idempotency_key=?").bind(actorCanonical, key),
        env2.DB.prepare(`INSERT INTO firmware_admin_idempotency
          (actor_canonical,idempotency_key,fingerprint,method,canonical_path,action,release_id,state,created_epoch_seconds,retained_until)
          VALUES (?,?,?,'POST',?,?,?,'pending',?,?)`).bind(actorCanonical, key, fingerprint, path, action, releaseId, now, now + 86400)
      );
      statements.push(env2.DB.prepare(`UPDATE firmware_admin_idempotency SET state='completed',status_code=200,
        response_body_json=?,request_id=?,original_expires_at=? WHERE actor_canonical=? AND idempotency_key=?
        AND state='pending' AND EXISTS (SELECT 1 FROM audit_logs WHERE id=?)`).bind(canonicalJson(result), actor.requestId, expiresAt, actorCanonical, key, auditId));
      await env2.DB.batch(statements);
      return json(result, 200, { "X-Request-Id": actor.requestId });
    } catch (error3) {
      const concurrent = await replayResult(env2.DB, actorCanonical, key, fingerprint, Math.floor(Date.now() / 1e3));
      if (concurrent) return concurrent;
      if (error3 instanceof ApiError) throw error3;
      const current = await env2.DB.prepare("SELECT * FROM firmware_releases WHERE id=?").bind(releaseId).first();
      if (current?.archived) throw new ApiError("RELEASE_ARCHIVED", "Firmware release archived", 410);
      if (current?.state === "disabled") throw new ApiError("RELEASE_DISABLED", "Firmware release disabled", 410);
      if (action === "disable" && await env2.DB.prepare("SELECT id FROM firmware_channels WHERE current_release_id=?").bind(releaseId).first()) {
        throw new ApiError("RELEASE_IN_USE", "Firmware release is still referenced", 409);
      }
      throw backendUnavailable("Firmware action did not commit");
    }
  });
}
__name(firmwareReleaseAction, "firmwareReleaseAction");

// api/admin/[[path]].ts
var AdminError = class extends Error {
  constructor(code, message, status) {
    super(message);
    this.code = code;
    this.status = status;
    this.name = "AdminError";
  }
  code;
  status;
  static {
    __name(this, "AdminError");
  }
};
var cachedJwks = null;
var onRequest = /* @__PURE__ */ __name(async (context2) => {
  const requestId = requestIdFrom(context2.request);
  try {
    const actor = await requireAccessActor(context2.request, context2.env, requestId);
    const response = await routeAdminRequest(context2, actor);
    response.headers.set("X-Request-Id", response.headers.get("X-Request-Id") ?? requestId);
    return response;
  } catch (error3) {
    if (new URL(context2.request.url).pathname.startsWith("/api/admin/firmware/") && error3 instanceof AdminError && error3.status === 403 && error3.code === "TOKEN_INVALID") {
      const code = error3.message.includes("CSRF") ? "CSRF_INVALID" : error3.message.includes("origin") ? "ORIGIN_FORBIDDEN" : error3.message.includes("role") ? "ROLE_FORBIDDEN" : "ACCESS_FORBIDDEN";
      const response2 = json2({ errorCode: code, message: error3.message, requestId }, 403);
      response2.headers.set("X-Request-Id", requestId);
      return response2;
    }
    const response = errorJson(error3, requestId);
    response.headers.set("X-Request-Id", requestId);
    return response;
  }
}, "onRequest");
async function routeAdminRequest(context2, actor) {
  const url = new URL(context2.request.url);
  const method = context2.request.method.toUpperCase();
  const route = routeSegments(context2.params.path);
  if (route[0] === "firmware") {
    if (url.protocol !== "https:") throw new AdminError("INVALID_PARAMETER", "HTTPS required", 400);
    if (!["GET", "POST"].includes(method) || url.pathname.endsWith("/") || url.pathname.includes("//")) {
      throw new AdminError("INVALID_PARAMETER", "Unsupported firmware method or path", 400);
    }
    if (method === "POST") {
      requireFirmwareJsonHeaders(context2.request);
      if (url.search || url.pathname.endsWith("/")) throw new AdminError("INVALID_PARAMETER", "Invalid firmware mutation path", 400);
    }
  }
  if (method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }
  if (method !== "GET") {
    requireSameOriginMutation(context2.request, context2.env);
    requireCsrf(context2.request);
  }
  if (method === "GET" && route.length === 1 && route[0] === "session") {
    const existingCsrf = cookieValue(context2.request.headers.get("Cookie"), "trace_admin_csrf");
    const csrfToken = existingCsrf && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(existingCsrf) ? existingCsrf : crypto.randomUUID();
    return json2(
      {
        ok: true,
        environment: context2.env.ENVIRONMENT,
        appId: context2.env.APP_ID,
        actor: actor.email,
        role: actor.role,
        csrfToken
      },
      200,
      {
        "Set-Cookie": csrfCookie(csrfToken)
      }
    );
  }
  if (method === "GET" && route.length === 1 && route[0] === "channels") {
    requireRole(actor, "viewer");
    return listChannels(context2.env, url);
  }
  if (method === "GET" && route.length === 1 && route[0] === "releases") {
    requireRole(actor, "viewer");
    return listReleases(context2.env, url);
  }
  if (method === "GET" && route.length === 1 && route[0] === "storage") {
    requireRole(actor, "viewer");
    return storageSummary(context2.env, url);
  }
  if (method === "GET" && route.length === 1 && route[0] === "announcements") {
    requireRole(actor, "viewer");
    return listAnnouncements(context2.env, url);
  }
  if (method === "POST" && route.length === 1 && route[0] === "announcements") {
    requireRole(actor, "publisher");
    const body = await requestJson(context2.request);
    return saveAnnouncement(context2.env, actor, null, body);
  }
  if (method === "POST" && route.length === 2 && route[0] === "announcements") {
    requireRole(actor, "publisher");
    const body = await requestJson(context2.request);
    return saveAnnouncement(context2.env, actor, route[1], body);
  }
  if (method === "POST" && route.length === 3 && route[0] === "announcements" && route[2] === "delete") {
    requireRole(actor, "publisher");
    return deleteAnnouncement(context2.env, actor, route[1]);
  }
  if (method === "GET" && route.length === 2 && route[0] === "firmware" && route[1] === "releases") {
    requireRole(actor, "viewer");
    return listFirmware(context2.env, url, actor.requestId, false);
  }
  if (method === "GET" && route.length === 2 && route[0] === "firmware" && route[1] === "channels") {
    requireRole(actor, "viewer");
    return listFirmware(context2.env, url, actor.requestId, true);
  }
  if (method === "POST" && route.length === 3 && route[0] === "channels" && route[2] === "publish") {
    const channel2 = parseChannel(route[1]);
    requireRole(actor, channel2 === "stable" ? "owner" : "publisher");
    const body = await requestJson(context2.request);
    return publishRelease(context2.env, actor, channel2, body);
  }
  if (method === "POST" && route.length === 3 && route[0] === "releases" && route[2] === "notes") {
    requireRole(actor, "publisher");
    const body = await requestJson(context2.request);
    return editReleaseNotes(context2.env, actor, route[1], body);
  }
  if (method === "POST" && route.length === 3 && route[0] === "releases" && route[2] === "disable") {
    requireRole(actor, "owner");
    return disableRelease(context2.env, actor, route[1]);
  }
  if (method === "POST" && route.length === 3 && route[0] === "releases" && route[2] === "delete") {
    requireRole(actor, "owner");
    return deleteRelease(context2.env, actor, route[1]);
  }
  if (method === "POST" && route.length === 4 && route[0] === "firmware" && route[1] === "channels") {
    if (!["stable", "beta"].includes(route[2]) || !Object.prototype.hasOwnProperty.call(FIRMWARE_CHANNEL_ACTIONS, route[3])) {
      throw new AdminError("INVALID_PARAMETER", "Invalid firmware channel action", 400);
    }
    const channel2 = route[2];
    requireRole(actor, channel2 === "stable" ? "owner" : "publisher");
    const body = await readFirmwareJson(context2.request);
    const action = FIRMWARE_CHANNEL_ACTIONS[route[3]];
    return mutateFirmwareChannel(context2.env, actor, channel2, action, body);
  }
  if (method === "POST" && route.length === 4 && route[0] === "firmware" && route[1] === "releases" && (route[3] === "disable" || route[3] === "recovery-download")) {
    requireRole(actor, "owner");
    return firmwareReleaseAction(context2.request, context2.env, actor, route[2], route[3]);
  }
  if (route[0] === "firmware") throw new AdminError("INVALID_PARAMETER", "Unsupported firmware endpoint or method", 400);
  throw new AdminError("NOT_FOUND", "Admin route not found", 404);
}
__name(routeAdminRequest, "routeAdminRequest");
async function listChannels(env2, url) {
  const appId = queryString(url, "appId") ?? env2.APP_ID;
  const platform2 = parsePlatform(queryString(url, "platform") ?? "android");
  const result = await env2.DB.prepare(
    `
      SELECT
        c.*,
        r.release_tag,
        r.version_name,
        r.version_code,
        r.state AS release_state
      FROM channels c
      LEFT JOIN releases r ON r.id = c.current_release_id
      WHERE c.app_id = ? AND c.platform = ?
      ORDER BY c.name
    `
  ).bind(appId, platform2).all();
  return json2({ ok: true, channels: result.results });
}
__name(listChannels, "listChannels");
async function listReleases(env2, url) {
  const appId = queryString(url, "appId") ?? env2.APP_ID;
  const platform2 = parsePlatform(queryString(url, "platform") ?? "android");
  const result = await env2.DB.prepare(
    `
      SELECT
        r.*,
        group_concat(c.name) AS published_channels,
        (
          SELECT count(*)
          FROM release_assets a
          WHERE a.release_id = r.id AND a.disabled = 0
        ) AS asset_count,
        (
          SELECT count(*)
          FROM release_assets a
          WHERE a.release_id = r.id AND a.disabled = 0 AND a.r2_state = 'available'
        ) AS r2_available_count,
        (
          SELECT COALESCE(max(a.size_bytes), 0)
          FROM release_assets a
          WHERE a.release_id = r.id
            AND a.disabled = 0
            AND a.platform = r.platform
            AND a.asset_type IN ('apk', 'windows_zip', 'windows_exe')
        ) AS installer_size_bytes,
        (
          SELECT count(*)
          FROM release_assets a
          WHERE a.release_id = r.id AND a.disabled = 0 AND a.r2_state <> 'available'
        ) AS github_fallback_only_count,
        (
          SELECT count(*)
          FROM patches p
          WHERE p.to_release_id = r.id AND p.disabled = 0
        ) AS patch_count
      FROM releases r
      LEFT JOIN channels c ON c.current_release_id = r.id
      WHERE r.app_id = ? AND r.platform = ?
        AND r.archived = 0
        AND EXISTS (
          SELECT 1
          FROM release_assets a
          WHERE a.release_id = r.id
            AND a.disabled = 0
            AND a.r2_state = 'available'
        )
        AND NOT EXISTS (
          SELECT 1
          FROM release_assets a
          WHERE a.release_id = r.id
            AND a.disabled = 0
            AND a.r2_state <> 'available'
        )
      GROUP BY r.id
      ORDER BY r.version_code DESC, r.created_at DESC
      LIMIT 50
    `
  ).bind(appId, platform2).all();
  return json2({ ok: true, releases: result.results });
}
__name(listReleases, "listReleases");
async function storageSummary(env2, url) {
  const appId = queryString(url, "appId") ?? env2.APP_ID;
  const platform2 = parsePlatform(queryString(url, "platform") ?? "android");
  const prefix = `${appId}/`;
  const [r2, trackedRows, trackedTotal, fullyR2Releases] = await Promise.all([
    listR2Usage(env2, prefix),
    env2.DB.prepare(
      `
        SELECT type, count(*) AS objectCount, COALESCE(sum(size_bytes), 0) AS totalSizeBytes
        FROM (
          SELECT asset_type AS type, size_bytes
          FROM release_assets
          WHERE app_id = ?
            AND platform = ?
            AND disabled = 0
            AND r2_state = 'available'
          UNION ALL
          SELECT 'firmware' AS type, a.size_bytes
          FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id
          WHERE r.app_id = ?
            AND r.archived = 0
            AND r.state <> 'disabled'
            AND a.r2_state = 'available'
        )
        GROUP BY type
        ORDER BY type
      `
    ).bind(appId, platform2, appId).all(),
    env2.DB.prepare(
      `
        SELECT
          count(*) AS objectCount,
          COALESCE(sum(size_bytes), 0) AS totalSizeBytes
        FROM (
          SELECT size_bytes
          FROM release_assets
          WHERE app_id = ?
            AND platform = ?
            AND disabled = 0
            AND r2_state = 'available'
          UNION ALL
          SELECT a.size_bytes
          FROM firmware_release_assets a JOIN firmware_releases r ON r.id=a.release_id
          WHERE r.app_id = ?
            AND r.archived = 0
            AND r.state <> 'disabled'
            AND a.r2_state = 'available'
        )
      `
    ).bind(appId, platform2, appId).first(),
    env2.DB.prepare(
      `
        SELECT count(*) AS releaseCount
        FROM releases r
        WHERE r.app_id = ?
          AND r.platform = ?
          AND r.archived = 0
          AND EXISTS (
            SELECT 1
            FROM release_assets a
            WHERE a.release_id = r.id
              AND a.disabled = 0
              AND a.r2_state = 'available'
          )
          AND NOT EXISTS (
            SELECT 1
            FROM release_assets a
            WHERE a.release_id = r.id
              AND a.disabled = 0
              AND a.r2_state <> 'available'
          )
      `
    ).bind(appId, platform2).first()
  ]);
  return json2({
    ok: true,
    storage: {
      prefix,
      r2,
      tracked: {
        objectCount: trackedTotal?.objectCount ?? 0,
        totalSizeBytes: trackedTotal?.totalSizeBytes ?? 0,
        releaseCount: fullyR2Releases?.releaseCount ?? 0,
        byType: trackedRows.results
      }
    }
  });
}
__name(storageSummary, "storageSummary");
async function listAnnouncements(env2, url) {
  const appId = queryString(url, "appId") ?? env2.APP_ID;
  const result = await env2.DB.prepare(
    `
      SELECT id, app_id, title, body, pinned, published, published_at, created_at, updated_at
      FROM announcements
      WHERE app_id = ?
      ORDER BY pinned DESC, COALESCE(published_at, updated_at, created_at) DESC, created_at DESC
      LIMIT 50
    `
  ).bind(appId).all();
  return json2({ ok: true, announcements: result.results });
}
__name(listAnnouncements, "listAnnouncements");
async function saveAnnouncement(env2, actor, announcementId, body) {
  const appId = requireString(body.appId ?? env2.APP_ID, "appId");
  const title2 = boundedString(body.title, "title", 120);
  const content = boundedString(body.body, "body", 8e3);
  const pinned = boolFlag(body.pinned);
  const published = boolFlag(body.published);
  const existing = announcementId ? await env2.DB.prepare("SELECT * FROM announcements WHERE id = ? AND app_id = ? LIMIT 1").bind(announcementId, appId).first() : null;
  if (announcementId && !existing) {
    throw new AdminError("NOT_FOUND", "Announcement not found", 404);
  }
  const id = announcementId ?? `ann_${crypto.randomUUID().replaceAll("-", "")}`;
  await env2.DB.batch([
    env2.DB.prepare("INSERT OR IGNORE INTO apps (id, name) VALUES (?, ?)").bind(appId, appId),
    existing ? env2.DB.prepare(
      `
            UPDATE announcements
            SET
              title = ?,
              body = ?,
              pinned = ?,
              published = ?,
              published_at = CASE
                WHEN ? = 1 AND published_at IS NULL THEN datetime('now')
                ELSE published_at
              END,
              updated_at = datetime('now')
            WHERE id = ?
          `
    ).bind(title2, content, pinned, published, published, id) : env2.DB.prepare(
      `
            INSERT INTO announcements (
              id,
              app_id,
              title,
              body,
              pinned,
              published,
              published_at
            )
            VALUES (?, ?, ?, ?, ?, ?, CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END)
          `
    ).bind(id, appId, title2, content, pinned, published, published),
    env2.DB.prepare(
      `
        INSERT INTO audit_logs (
          id,
          app_id,
          actor,
          actor_type,
          action,
          target_type,
          target_id,
          request_id,
          before_json,
          after_json
        )
        VALUES (?, ?, ?, 'access', ?, 'announcement', ?, ?, ?, ?)
      `
    ).bind(
      crypto.randomUUID(),
      appId,
      actor.email,
      existing ? "edit_announcement" : "create_announcement",
      id,
      actor.requestId,
      existing ? canonicalJson2(announcementSnapshot(existing)) : null,
      canonicalJson2({ title: title2, body: content, pinned: pinned === 1, published: published === 1 })
    )
  ]);
  return json2({ ok: true, announcementId: id });
}
__name(saveAnnouncement, "saveAnnouncement");
async function deleteAnnouncement(env2, actor, announcementId) {
  const announcement = await env2.DB.prepare("SELECT * FROM announcements WHERE id = ? LIMIT 1").bind(announcementId).first();
  if (!announcement) {
    throw new AdminError("NOT_FOUND", "Announcement not found", 404);
  }
  await env2.DB.batch([
    env2.DB.prepare("DELETE FROM announcements WHERE id = ?").bind(announcementId),
    env2.DB.prepare(
      `
        INSERT INTO audit_logs (
          id,
          app_id,
          actor,
          actor_type,
          action,
          target_type,
          target_id,
          request_id,
          before_json,
          after_json
        )
        VALUES (?, ?, ?, 'access', 'delete_announcement', 'announcement', ?, ?, ?, '{"deleted":true}')
      `
    ).bind(
      crypto.randomUUID(),
      announcement.app_id,
      actor.email,
      announcementId,
      actor.requestId,
      canonicalJson2(announcementSnapshot(announcement))
    )
  ]);
  return json2({ ok: true });
}
__name(deleteAnnouncement, "deleteAnnouncement");
async function publishRelease(env2, actor, channelName, body) {
  const appId = requireString(body.appId ?? env2.APP_ID, "appId");
  const platform2 = parsePlatform(body.platform ?? "android");
  const releaseId = requireString(body.releaseId, "releaseId");
  const expectedRevision = requireInt(body.expectedRevision, "expectedRevision");
  const rollback = body.rollback === true;
  const channel2 = await env2.DB.prepare(
    "SELECT * FROM channels WHERE app_id = ? AND platform = ? AND name = ? LIMIT 1"
  ).bind(appId, platform2, channelName).first();
  if (!channel2) throw new AdminError("RELEASE_NOT_FOUND", "Channel not found", 404);
  const target = await env2.DB.prepare("SELECT * FROM releases WHERE id = ? LIMIT 1").bind(releaseId).first();
  if (!target || target.app_id !== appId || target.platform !== platform2) {
    throw new AdminError("RELEASE_NOT_FOUND", "Release not found", 404);
  }
  if (target.state === "disabled") {
    throw new AdminError("RELEASE_DISABLED", "Disabled release cannot be published", 410);
  }
  if (target.archived === 1) {
    throw new AdminError("ASSET_ARCHIVED", "Archived release cannot be published", 409);
  }
  if (target.release_notes.trim() === "") {
    throw new AdminError("RELEASE_NOTES_REQUIRED", "Release notes are required before publish", 409);
  }
  if (channel2.current_release_id && !rollback) {
    const current = await env2.DB.prepare("SELECT version_code FROM releases WHERE id = ? LIMIT 1").bind(channel2.current_release_id).first();
    if (current && target.version_code <= current.version_code) {
      throw new AdminError(
        "VERSION_REGRESSION",
        "Publishing a non-rollback versionCode regression is blocked",
        409
      );
    }
  }
  if (platform2 === "android") {
    await ensureAndroidCompleteness(env2, releaseId);
  }
  const beforeJson = canonicalJson2(channelSnapshot2(channel2));
  const afterJson = canonicalJson2(channelSnapshot2(channel2, releaseId));
  const updatedChannel = await env2.DB.prepare(
    `
      UPDATE channels
      SET
        current_release_id = ?,
        revision = revision + 1,
        last_action = ?,
        last_actor = ?,
        last_actor_type = 'access',
        last_request_id = ?,
        last_before_json = ?,
        last_after_json = ?,
        updated_at = datetime('now')
      WHERE id = ? AND revision = ? AND disable_latest = 0
      RETURNING revision
    `
  ).bind(
    releaseId,
    rollback ? "rollback" : "publish",
    actor.email,
    actor.requestId,
    beforeJson,
    afterJson,
    channel2.id,
    expectedRevision
  ).first();
  if (!updatedChannel) {
    throw new AdminError("CAS_CONFLICT", "Channel revision changed or latest is disabled", 409);
  }
  return json2({ ok: true, revision: updatedChannel.revision });
}
__name(publishRelease, "publishRelease");
async function editReleaseNotes(env2, actor, releaseId, body) {
  const releaseNotes = requireString(body.releaseNotes, "releaseNotes");
  if (releaseNotes.length > 8e3) {
    throw new AdminError("INVALID_PARAMETER", "releaseNotes is too long", 400);
  }
  const release2 = await env2.DB.prepare("SELECT * FROM releases WHERE id = ? LIMIT 1").bind(releaseId).first();
  if (!release2) throw new AdminError("RELEASE_NOT_FOUND", "Release not found", 404);
  const beforeJson = canonicalJson2({ releaseNotes: release2.release_notes });
  const afterJson = canonicalJson2({ releaseNotes });
  await env2.DB.batch([
    env2.DB.prepare("UPDATE releases SET release_notes = ?, updated_at = datetime('now') WHERE id = ?").bind(releaseNotes, releaseId),
    env2.DB.prepare(
      `
        INSERT INTO audit_logs (
          id,
          app_id,
          actor,
          actor_type,
          action,
          target_type,
          target_id,
          request_id,
          before_json,
          after_json
        )
        VALUES (?, ?, ?, 'access', 'edit_notes', 'release', ?, ?, ?, ?)
      `
    ).bind(
      crypto.randomUUID(),
      release2.app_id,
      actor.email,
      releaseId,
      actor.requestId,
      beforeJson,
      afterJson
    ),
    env2.DB.prepare(
      `
        UPDATE channels
        SET
          revision = revision + 1,
          last_action = 'edit_notes',
          last_actor = ?,
          last_actor_type = 'access',
          last_request_id = ?,
          last_before_json = ?,
          last_after_json = ?,
          updated_at = datetime('now')
        WHERE current_release_id = ?
      `
    ).bind(actor.email, actor.requestId, beforeJson, afterJson, releaseId)
  ]);
  return json2({ ok: true });
}
__name(editReleaseNotes, "editReleaseNotes");
async function disableRelease(env2, actor, releaseId) {
  const referenced = await env2.DB.prepare(
    "SELECT id FROM channels WHERE current_release_id = ? LIMIT 1"
  ).bind(releaseId).first();
  if (referenced) {
    throw new AdminError(
      "RELEASE_DISABLED",
      "Published release cannot be disabled before moving the channel",
      409
    );
  }
  const release2 = await env2.DB.prepare("SELECT app_id, state FROM releases WHERE id = ? LIMIT 1").bind(releaseId).first();
  if (!release2) throw new AdminError("RELEASE_NOT_FOUND", "Release not found", 404);
  const result = await env2.DB.prepare(
    "UPDATE releases SET state = 'disabled', updated_at = datetime('now') WHERE id = ?"
  ).bind(releaseId).run();
  if (result.meta.changes !== 1) {
    throw new AdminError("RELEASE_NOT_FOUND", "Release not found", 404);
  }
  await env2.DB.prepare(
    `
      INSERT INTO audit_logs (
        id,
        app_id,
        actor,
        actor_type,
        action,
        target_type,
        target_id,
        request_id,
        before_json,
        after_json
      )
      VALUES (?, ?, ?, 'access', 'disable_release', 'release', ?, ?, ?, '{"state":"disabled"}')
    `
  ).bind(
    crypto.randomUUID(),
    release2.app_id,
    actor.email,
    releaseId,
    actor.requestId,
    canonicalJson2({ state: release2.state })
  ).run();
  return json2({ ok: true });
}
__name(disableRelease, "disableRelease");
async function deleteRelease(env2, actor, releaseId) {
  const referenced = await env2.DB.prepare(
    "SELECT name FROM channels WHERE current_release_id = ? LIMIT 1"
  ).bind(releaseId).first();
  if (referenced) {
    throw new AdminError(
      "RELEASE_IN_USE",
      "Published release cannot be deleted before moving the channel",
      409
    );
  }
  const release2 = await env2.DB.prepare("SELECT * FROM releases WHERE id = ? LIMIT 1").bind(releaseId).first();
  if (!release2) throw new AdminError("RELEASE_NOT_FOUND", "Release not found", 404);
  const assets = await env2.DB.prepare(
    "SELECT id, asset_type, file_name, size_bytes, r2_key, r2_state FROM release_assets WHERE release_id = ?"
  ).bind(releaseId).all();
  const [patchRows, historyRows] = await Promise.all([
    env2.DB.prepare("SELECT count(*) AS count FROM patches WHERE to_release_id = ?").bind(releaseId).first(),
    env2.DB.prepare("SELECT count(*) AS count FROM channel_history WHERE release_id = ?").bind(releaseId).first()
  ]);
  const deletedR2 = await deleteR2ObjectsForRelease(env2, release2, assets.results);
  const assetRowCount = assets.results.length;
  const patchRowCount = patchRows?.count ?? 0;
  const historyRowCount = historyRows?.count ?? 0;
  const hardDeleteRelease = historyRowCount === 0;
  const beforeJson = canonicalJson2({
    release: release2,
    assets: assets.results.map((asset) => ({
      assetType: asset.asset_type,
      fileName: asset.file_name,
      sizeBytes: asset.size_bytes,
      r2Key: asset.r2_key,
      r2State: asset.r2_state
    }))
  });
  const statements = [
    env2.DB.prepare("DELETE FROM patches WHERE to_release_id = ?").bind(releaseId),
    env2.DB.prepare("DELETE FROM release_assets WHERE release_id = ?").bind(releaseId),
    hardDeleteRelease ? env2.DB.prepare("DELETE FROM releases WHERE id = ?").bind(releaseId) : env2.DB.prepare(
      `
            UPDATE releases
            SET
              archived = 1,
              state = 'disabled',
              payload_signature_json = NULL,
              security_payload_json = '{}',
              release_notes = '',
              capabilities_json = '[]',
              fallback_only = 0,
              updated_at = datetime('now')
            WHERE id = ?
          `
    ).bind(releaseId),
    env2.DB.prepare(
      `
        INSERT INTO audit_logs (
          id,
          app_id,
          actor,
          actor_type,
          action,
          target_type,
          target_id,
          request_id,
          before_json,
          after_json
        )
        VALUES (?, ?, ?, 'access', 'delete_release', 'release', ?, ?, ?, ?)
      `
    ).bind(
      crypto.randomUUID(),
      release2.app_id,
      actor.email,
      releaseId,
      actor.requestId,
      beforeJson,
      canonicalJson2({
        deleted: true,
        hardDeletedRelease: hardDeleteRelease,
        retainedReleaseTombstone: !hardDeleteRelease,
        retainedD1HistoryRows: historyRowCount,
        deletedR2Objects: deletedR2.objectCount,
        deletedR2Bytes: deletedR2.totalSizeBytes,
        deletedD1Rows: patchRowCount + assetRowCount + (hardDeleteRelease ? 1 : 0)
      })
    )
  ];
  await env2.DB.batch(statements);
  return json2({
    ok: true,
    hardDeletedRelease: hardDeleteRelease,
    retainedReleaseTombstone: !hardDeleteRelease,
    retainedD1HistoryRows: historyRowCount,
    deletedR2Objects: deletedR2.objectCount,
    deletedR2Bytes: deletedR2.totalSizeBytes,
    deletedD1Rows: patchRowCount + assetRowCount + (hardDeleteRelease ? 1 : 0)
  });
}
__name(deleteRelease, "deleteRelease");
async function ensureAndroidCompleteness(env2, releaseId) {
  const apk = await env2.DB.prepare(
    "SELECT id FROM release_assets WHERE release_id = ? AND platform = 'android' AND asset_type = 'apk' AND disabled = 0 LIMIT 1"
  ).bind(releaseId).first();
  if (!apk) {
    throw new AdminError("BACKEND_UNAVAILABLE", "Android release is missing an APK asset", 503);
  }
}
__name(ensureAndroidCompleteness, "ensureAndroidCompleteness");
async function requireAccessActor(request, env2, requestId) {
  if (!env2.ACCESS_JWT_ISSUER || !env2.ACCESS_JWT_AUD) {
    throw new AdminError("BACKEND_UNAVAILABLE", "Cloudflare Access is not configured", 503);
  }
  const token = request.headers.get("CF-Access-Jwt-Assertion") ?? bearerToken(request);
  if (!token) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT is required", 401);
  }
  const { header, payload, signedData, signature } = parseJwt(token);
  if (header.alg !== "RS256" || typeof header.kid !== "string") {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT algorithm is invalid", 401);
  }
  const nowSeconds = Math.floor(Date.now() / 1e3);
  if (typeof payload.exp !== "number" || !Number.isFinite(payload.exp)) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT expiration is invalid", 401);
  }
  if (payload.exp <= nowSeconds) {
    throw new AdminError("TOKEN_EXPIRED", "Cloudflare Access JWT expired", 401);
  }
  for (const claim of ["nbf", "iat"]) {
    const value = payload[claim];
    if (value !== void 0 && (typeof value !== "number" || !Number.isFinite(value) || value > nowSeconds)) {
      throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT time claim is invalid", 401);
    }
  }
  if (payload.iss !== env2.ACCESS_JWT_ISSUER) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT issuer is invalid", 401);
  }
  if (!audienceMatches(payload.aud, env2.ACCESS_JWT_AUD)) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT audience is invalid", 401);
  }
  const jwk = await jwkForKid(env2.ACCESS_JWT_ISSUER, header.kid);
  const key = await crypto.subtle.importKey(
    "jwk",
    jwk,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["verify"]
  );
  const valid = await crypto.subtle.verify(
    "RSASSA-PKCS1-v1_5",
    key,
    arrayBufferFromBytes(signature),
    new TextEncoder().encode(signedData)
  );
  if (!valid) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT signature is invalid", 401);
  }
  const email = typeof payload.email === "string" ? payload.email.trim().toLowerCase() : "";
  if (!email) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT email is missing", 401);
  }
  return {
    email,
    role: roleForEmail(env2, email),
    requestId
  };
}
__name(requireAccessActor, "requireAccessActor");
async function jwkForKid(issuer, kid) {
  const now = Date.now();
  if (!cachedJwks || cachedJwks.issuer !== issuer || cachedJwks.expiresAt <= now) {
    const response = await fetch(`${issuer.replace(/\/$/, "")}/cdn-cgi/access/certs`, {
      headers: { Accept: "application/json" }
    });
    if (!response.ok) {
      throw new AdminError("BACKEND_UNAVAILABLE", "Could not fetch Cloudflare Access certs", 503);
    }
    cachedJwks = {
      issuer,
      expiresAt: now + 5 * 60 * 1e3,
      jwks: await response.json()
    };
  }
  const key = cachedJwks.jwks.keys.find((candidate) => candidate.kid === kid);
  if (!key || key.kty !== "RSA") {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT key is unknown", 401);
  }
  return key;
}
__name(jwkForKid, "jwkForKid");
function parseJwt(token) {
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT is malformed", 401);
  }
  return {
    header: jsonFromBase64Url(parts[0]),
    payload: jsonFromBase64Url(parts[1]),
    signedData: `${parts[0]}.${parts[1]}`,
    signature: bytesFromBase64Url(parts[2])
  };
}
__name(parseJwt, "parseJwt");
function roleForEmail(env2, email) {
  const owners = emailSet(env2.ADMIN_OWNER_EMAILS);
  const publishers = emailSet(env2.ADMIN_PUBLISHER_EMAILS);
  const viewers = emailSet(env2.ADMIN_VIEWER_EMAILS);
  if (owners.has(email)) return "owner";
  if (publishers.has(email)) return "publisher";
  if (viewers.has(email)) return "viewer";
  throw new AdminError("TOKEN_INVALID", "Cloudflare Access user is not allowed", 403);
}
__name(roleForEmail, "roleForEmail");
function requireRole(actor, required) {
  const rank = { viewer: 1, publisher: 2, owner: 3 };
  if (rank[actor.role] < rank[required]) {
    throw new AdminError("TOKEN_INVALID", "Admin role is not allowed for this action", 403);
  }
}
__name(requireRole, "requireRole");
function requireSameOriginMutation(request, env2) {
  const origin = request.headers.get("Origin");
  const allowed = /* @__PURE__ */ new Set([
    new URL(request.url).origin,
    ...csv(env2.ADMIN_ALLOWED_ORIGINS)
  ]);
  if (!origin || !allowed.has(origin)) {
    throw new AdminError("TOKEN_INVALID", "Admin mutation origin is not allowed", 403);
  }
}
__name(requireSameOriginMutation, "requireSameOriginMutation");
function requireCsrf(request) {
  const header = request.headers.get("X-CSRF-Token");
  const cookie = cookieValue(request.headers.get("Cookie"), "trace_admin_csrf");
  if (!header || !cookie || header !== cookie) {
    throw new AdminError("TOKEN_INVALID", "CSRF token is invalid", 403);
  }
}
__name(requireCsrf, "requireCsrf");
async function requestJson(request) {
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new AdminError("INVALID_PARAMETER", "Request body must be a JSON object", 400);
  }
  return body;
}
__name(requestJson, "requestJson");
function json2(data, status = 200, headers) {
  return Response.json(data, {
    status,
    headers: {
      "Cache-Control": "no-store",
      ...headers
    }
  });
}
__name(json2, "json");
function errorJson(error3, requestId) {
  if (error3 instanceof AdminError || error3 instanceof ApiError) {
    return json2({ errorCode: error3.code, message: error3.message, requestId }, error3.status);
  }
  const message = error3 instanceof Error ? error3.message : String(error3);
  return json2(
    { errorCode: "BACKEND_UNAVAILABLE", message: "Admin backend unavailable", requestId, detail: message },
    503
  );
}
__name(errorJson, "errorJson");
function routeSegments(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}
__name(routeSegments, "routeSegments");
function requestIdFrom(request) {
  const value = request.headers.get("X-Request-Id");
  return value && /^[A-Za-z0-9._:-]{1,128}$/.test(value) ? value : crypto.randomUUID();
}
__name(requestIdFrom, "requestIdFrom");
function queryString(url, key) {
  const value = url.searchParams.get(key);
  return value === "" ? null : value;
}
__name(queryString, "queryString");
function requireString(value, field) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new AdminError("INVALID_PARAMETER", `${field} is required`, 400);
  }
  return value.trim();
}
__name(requireString, "requireString");
function boundedString(value, field, maxLength) {
  const text2 = requireString(value, field);
  if (text2.length > maxLength) {
    throw new AdminError("INVALID_PARAMETER", `${field} is too long`, 400);
  }
  return text2;
}
__name(boundedString, "boundedString");
function boolFlag(value) {
  return value === true || value === 1 || value === "1" ? 1 : 0;
}
__name(boolFlag, "boolFlag");
function requireInt(value, field) {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  if (!Number.isInteger(parsed) || parsed < 0) {
    throw new AdminError("INVALID_PARAMETER", `${field} must be a non-negative integer`, 400);
  }
  return parsed;
}
__name(requireInt, "requireInt");
function parsePlatform(value) {
  if (value === "android" || value === "windows") return value;
  throw new AdminError("INVALID_PARAMETER", "platform must be android or windows", 400);
}
__name(parsePlatform, "parsePlatform");
function parseChannel(value) {
  if (value === "stable" || value === "beta") return value;
  throw new AdminError("INVALID_PARAMETER", "channel must be stable or beta", 400);
}
__name(parseChannel, "parseChannel");
async function listR2Usage(env2, prefix) {
  let cursor;
  let objectCount = 0;
  let totalSizeBytes = 0;
  const byType = /* @__PURE__ */ new Map();
  do {
    const page = await env2.RELEASES_BUCKET.list({ prefix, cursor });
    for (const object of page.objects) {
      const type = assetTypeForR2Key(object.key);
      objectCount += 1;
      totalSizeBytes += object.size;
      const current = byType.get(type) ?? { type, objectCount: 0, totalSizeBytes: 0 };
      current.objectCount += 1;
      current.totalSizeBytes += object.size;
      byType.set(type, current);
    }
    cursor = page.truncated ? page.cursor : void 0;
  } while (cursor);
  return {
    prefix,
    objectCount,
    totalSizeBytes,
    byType: [...byType.values()].sort((left, right) => left.type.localeCompare(right.type))
  };
}
__name(listR2Usage, "listR2Usage");
async function deleteR2ObjectsForRelease(env2, release2, assets) {
  const objects = /* @__PURE__ */ new Map();
  let cursor;
  const prefix = `${release2.app_id}/releases/${release2.version_code}-${release2.release_tag}/`;
  do {
    const page = await env2.RELEASES_BUCKET.list({ prefix, cursor });
    for (const object of page.objects) {
      objects.set(object.key, object.size);
    }
    cursor = page.truncated ? page.cursor : void 0;
  } while (cursor);
  for (const asset of assets) {
    if (!asset.r2_key || objects.has(asset.r2_key)) continue;
    const object = await env2.RELEASES_BUCKET.head(asset.r2_key);
    if (object) objects.set(asset.r2_key, object.size);
  }
  let totalSizeBytes = 0;
  for (const [key, size] of objects) {
    await env2.RELEASES_BUCKET.delete(key);
    totalSizeBytes += size;
  }
  return {
    objectCount: objects.size,
    totalSizeBytes
  };
}
__name(deleteR2ObjectsForRelease, "deleteR2ObjectsForRelease");
function assetTypeForR2Key(key) {
  if (key.includes("/firmware/")) return "firmware";
  if (key.includes("/android/patches/")) return "patch";
  if (key.includes("/manifest/")) return "manifest";
  if (key.includes("/android/")) return "apk";
  if (key.includes("/windows/")) return "windows";
  return "other";
}
__name(assetTypeForR2Key, "assetTypeForR2Key");
function channelSnapshot2(channel2, currentReleaseId = channel2.current_release_id) {
  return {
    id: channel2.id,
    app_id: channel2.app_id,
    platform: channel2.platform,
    name: channel2.name,
    current_release_id: currentReleaseId,
    revision: channel2.revision,
    disable_latest: channel2.disable_latest,
    disable_downloads: channel2.disable_downloads,
    maintenance_admin_only: channel2.maintenance_admin_only,
    maintenance_message: channel2.maintenance_message
  };
}
__name(channelSnapshot2, "channelSnapshot");
function announcementSnapshot(announcement) {
  return {
    id: announcement.id,
    app_id: announcement.app_id,
    title: announcement.title,
    body: announcement.body,
    pinned: announcement.pinned === 1,
    published: announcement.published === 1,
    published_at: announcement.published_at
  };
}
__name(announcementSnapshot, "announcementSnapshot");
function canonicalJson2(value) {
  if (Array.isArray(value)) {
    return `[${value.map((entry) => canonicalJson2(entry)).join(",")}]`;
  }
  if (value && typeof value === "object") {
    return `{${Object.entries(value).filter(([, entryValue]) => entryValue !== void 0).sort(([left], [right]) => left.localeCompare(right)).map(([key, entryValue]) => `${JSON.stringify(key)}:${canonicalJson2(entryValue)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
__name(canonicalJson2, "canonicalJson");
function audienceMatches(aud, expected) {
  return Array.isArray(aud) ? aud.includes(expected) : aud === expected;
}
__name(audienceMatches, "audienceMatches");
function emailSet(value) {
  return new Set(csv(value).map((entry) => entry.toLowerCase()));
}
__name(emailSet, "emailSet");
function csv(value) {
  return (value ?? "").split(",").map((entry) => entry.trim()).filter(Boolean);
}
__name(csv, "csv");
function bearerToken(request) {
  const authorization = request.headers.get("Authorization");
  return authorization?.startsWith("Bearer ") ? authorization.slice("Bearer ".length) : null;
}
__name(bearerToken, "bearerToken");
function jsonFromBase64Url(value) {
  const text2 = new TextDecoder().decode(bytesFromBase64Url(value));
  let parsed;
  try {
    parsed = JSON.parse(text2);
  } catch (error3) {
    if (!(error3 instanceof SyntaxError)) throw error3;
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT payload is invalid", 401);
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT payload is invalid", 401);
  }
  return parsed;
}
__name(jsonFromBase64Url, "jsonFromBase64Url");
function bytesFromBase64Url(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
  let binary;
  try {
    binary = atob(padded);
  } catch (error3) {
    if (!(error3 instanceof DOMException) || error3.name !== "InvalidCharacterError") throw error3;
    throw new AdminError("TOKEN_INVALID", "Cloudflare Access JWT encoding is invalid", 401);
  }
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}
__name(bytesFromBase64Url, "bytesFromBase64Url");
function arrayBufferFromBytes(bytes) {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}
__name(arrayBufferFromBytes, "arrayBufferFromBytes");
function cookieValue(cookieHeader, name) {
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(";")) {
    const [key, ...rest] = part.trim().split("=");
    if (key === name) return rest.join("=");
  }
  return null;
}
__name(cookieValue, "cookieValue");
function csrfCookie(value) {
  return `trace_admin_csrf=${value}; Path=/api/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=3600`;
}
__name(csrfCookie, "csrfCookie");

// ../.wrangler/tmp/pages-Poftct/functionsRoutes-0.5907863941624589.mjs
var routes = [
  {
    routePath: "/api/admin/:path*",
    mountPath: "/api/admin",
    method: "",
    middlewares: [],
    modules: [onRequest]
  }
];

// ../node_modules/path-to-regexp/dist.es2015/index.js
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count3 = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count3--;
          if (count3 === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count3++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count3)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
__name(lexer, "lexer");
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = /* @__PURE__ */ __name(function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  }, "tryConsume");
  var mustConsume = /* @__PURE__ */ __name(function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a2 = tokens[i], nextType = _a2.type, index = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  }, "mustConsume");
  var consumeText = /* @__PURE__ */ __name(function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  }, "consumeText");
  var isSafe = /* @__PURE__ */ __name(function(value2) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char2 = delimiter_1[_i];
      if (value2.indexOf(char2) > -1)
        return true;
    }
    return false;
  }, "isSafe");
  var safePattern = /* @__PURE__ */ __name(function(prefix2) {
    var prev = result[result.length - 1];
    var prevText = prefix2 || (prev && typeof prev === "string" ? prev : "");
    if (prev && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  }, "safePattern");
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
__name(parse, "parse");
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
__name(match, "match");
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.decode, decode = _a === void 0 ? function(x) {
    return x;
  } : _a;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = /* @__PURE__ */ __name(function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    }, "_loop_1");
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
__name(regexpToFunction, "regexpToFunction");
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
__name(escapeString, "escapeString");
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
__name(flags, "flags");
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
__name(regexpToRegexp, "regexpToRegexp");
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
__name(arrayToRegexp, "arrayToRegexp");
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
__name(stringToRegexp, "stringToRegexp");
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token.pattern, ")").concat(token.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
__name(tokensToRegexp, "tokensToRegexp");
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
__name(pathToRegexp, "pathToRegexp");

// ../node_modules/wrangler/templates/pages-template-worker.ts
var escapeRegex = /[.+?^${}()|[\]\\]/g;
function* executeRequest(request) {
  const requestPath = new URL(request.url).pathname;
  for (const route of [...routes].reverse()) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult) {
      for (const handler of route.middlewares.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: mountMatchResult.path
        };
      }
    }
  }
  for (const route of routes) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: true
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult && route.modules.length) {
      for (const handler of route.modules.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: matchResult.path
        };
      }
      break;
    }
  }
}
__name(executeRequest, "executeRequest");
var pages_template_worker_default = {
  async fetch(originalRequest, env2, workerContext) {
    let request = originalRequest;
    const handlerIterator = executeRequest(request);
    let data = {};
    let isFailOpen = false;
    const next = /* @__PURE__ */ __name(async (input, init) => {
      if (input !== void 0) {
        let url = input;
        if (typeof input === "string") {
          url = new URL(input, request.url).toString();
        }
        request = new Request(url, init);
      }
      const result = handlerIterator.next();
      if (result.done === false) {
        const { handler, params, path } = result.value;
        const context2 = {
          request: new Request(request.clone()),
          functionPath: path,
          next,
          params,
          get data() {
            return data;
          },
          set data(value) {
            if (typeof value !== "object" || value === null) {
              throw new Error("context.data must be an object");
            }
            data = value;
          },
          env: env2,
          waitUntil: workerContext.waitUntil.bind(workerContext),
          passThroughOnException: /* @__PURE__ */ __name(() => {
            isFailOpen = true;
          }, "passThroughOnException")
        };
        const response = await handler(context2);
        if (!(response instanceof Response)) {
          throw new Error("Your Pages function should return a Response");
        }
        return cloneResponse(response);
      } else if ("ASSETS") {
        const response = await env2["ASSETS"].fetch(request);
        return cloneResponse(response);
      } else {
        const response = await fetch(request);
        return cloneResponse(response);
      }
    }, "next");
    try {
      return await next();
    } catch (error3) {
      if (isFailOpen) {
        const response = await env2["ASSETS"].fetch(request);
        return cloneResponse(response);
      }
      throw error3;
    }
  }
};
var cloneResponse = /* @__PURE__ */ __name((response) => (
  // https://fetch.spec.whatwg.org/#null-body-status
  new Response(
    [101, 204, 205, 304].includes(response.status) ? null : response.body,
    response
  )
), "cloneResponse");
export {
  pages_template_worker_default as default
};
