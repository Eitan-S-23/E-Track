import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const [mode, label, credential = 'oauth', ownerLabel = 'owner-login-04'] = process.argv.slice(2);
assert.match(ownerLabel, /^owner-login-[0-9]+$/);
assert.ok(['inventory', 'create', 'configure', 'protect', 'readback', 'access-inspect', 'access-policy', 'configure-access', 'deploy', 'gate-check', 'access-log-read'].includes(mode));
assert.ok(['oauth', 'original', 'p41', 'ci'].includes(credential));
assert.ok(credential === 'oauth' || ['protect', 'access-inspect', 'access-policy', 'gate-check', 'access-log-read'].includes(mode));
assert.match(label || '', /^[a-z0-9-]+$/);
const privateDir = path.join(root, '.cache/p43/private/pages');
const publicDir = path.join(root, '.cache/p43/live');
const guard = (...files) => {
  const result = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'pages-preflight', '.', 'preflight', ...files],
    { cwd: root, windowsHide: true, encoding: 'utf8' });
  assert.equal(result.status, 0, 'Pages output preflight failed');
};
guard(privateDir, publicDir);
fs.mkdirSync(privateDir, { recursive: true });
const oauthPath = path.join(root, '.cache/p43/private/platform-login/xdg-config/.wrangler/config/default.toml');
const oauth = fs.readFileSync(oauthPath, 'utf8');
let token = oauth.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1];
const expiry = oauth.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
const approved = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8'));
const account = approved.account_id;
assert.match(account, /^[a-f0-9]{32}$/);
if (credential === 'original') {
  const existing = JSON.parse(fs.readFileSync('D:/github/my/E-Track/app/bluetooth_flutter_Trace/cloudflare/update-service/.github-actions-secrets.staging.local.json', 'utf8'));
  assert.equal(existing.secrets.CLOUDFLARE_ACCOUNT_ID, account);
  token = existing.secrets.CLOUDFLARE_API_TOKEN.trim();
} else if (credential === 'p41' || credential === 'ci') {
  token = fs.readFileSync(`D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/${credential === 'ci' ? 'p41-ci-token.txt' : 'token.txt'}`, 'utf8').trim();
}
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const publicVars = ['ENVIRONMENT', 'APP_ID', 'FIRMWARE_DOWNLOAD_ORIGIN', 'DOWNLOAD_TOKEN_KEY_VERSION', 'FIRMWARE_V2_CUTOVER_EPOCH'];
const projectName = 'e-track-firmware-p43-admin-test';
const projectRoute = `pages/projects/${projectName}`;
const report = { label, startedAt: new Date().toISOString(), accountSourceMatchesApprovedBindings: true,
  authentication: credential === 'oauth' ? 'Successful existing-Edge official OAuth; platform only, not Admin Access' : `Existing ${credential} API credential for the same approved account; not Admin Access`,
  receipts: [], businessMutations: 0, cloudWritesAttempted: 0 };
function save(name, value, isPrivate = false) {
  assert.match(name, /^[a-z0-9-]+\.json$/);
  const target = path.join(isPrivate ? privateDir : publicDir, `${label}-${name}`);
  guard(target);
  fs.writeFileSync(target, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
}
async function api(name, suffix, method = 'GET', body) {
  if (method !== 'GET') {
    assert.ok((['configure', 'configure-access'].includes(mode) && method === 'PATCH' && suffix === projectRoute)
      || (mode === 'protect' && method === 'POST' && suffix === 'access/apps')
      || (mode === 'access-policy' && credential === 'ci' && method === 'POST'
        && suffix === 'access/apps/ca168030-0227-49a5-bd0c-bf030c9c86ea/policies'));
    report.cloudWritesAttempted++;
  }
  const url = `https://api.cloudflare.com/client/v4/accounts/${account}/${suffix}`;
  const result = await fetch(url, { method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
    redirect: 'error', signal: AbortSignal.timeout(30000) });
  const chunks = []; let size = 0;
  for await (const chunk of result.body || []) { size += chunk.length; assert.ok(size <= 4 * 1024 * 1024); chunks.push(chunk); }
  const bytes = Buffer.concat(chunks);
  const json = JSON.parse(bytes.toString('utf8'));
  const receipt = { name, method, suffix, time: new Date().toISOString(), status: result.status,
    cfRay: result.headers.get('cf-ray'), success: json.success === true, bodySha256: sha(bytes), bodyBytes: bytes.length,
    errors: json.errors?.map(e => ({ code: e.code, message: String(e.message ?? e.error).split(token).join('[REDACTED]') })) };
  report.receipts.push(receipt);
  save(`${name}-receipt.json`, receipt);
  save(`${name}.json`, json, true);
  return json;
}
function project(p) {
  return { name: p.name, subdomain: p.subdomain, productionBranch: p.production_branch,
    latestDeployment: p.latest_deployment?.id, canonicalDeployment: p.canonical_deployment?.id,
    source: p.source ? { type: p.source.type, owner: p.source.config?.owner, repoName: p.source.config?.repo_name } : null,
    configs: Object.fromEntries(Object.entries(p.deployment_configs || {}).map(([environment, c]) => [environment, {
      compatibilityDate: c.compatibility_date, compatibilityFlags: c.compatibility_flags,
      d1: c.d1_databases, r2: c.r2_buckets,
      vars: Object.fromEntries(Object.entries(c.env_vars || {}).map(([name, v]) => [name, { type: v.type,
        configured: true, valueVisible: typeof v.value === 'string' && v.value.length > 0,
        ...(publicVars.includes(name) && v.type === 'plain_text' ? { value: v.value } : {}) }]))
    }])) };
}
function ownerIdentity() {
  const observation = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live', `${ownerLabel}.json`), 'utf8'));
  const session = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/private/owner-login', `${ownerLabel}-session.json`), 'utf8'));
  assert.equal(observation.ownerVerified, true, 'A live existing owner role is required before assigning the new Pages owner');
  assert.equal(observation.session.role, 'owner');
  assert.equal(session.body.role, 'owner');
  assert.equal(sha(session.actor), observation.session.authenticatedActorSha256);
  return session.actor;
}
try {
  if (credential === 'oauth' && !(token && Date.parse(expiry) > Date.now())) {
    const base = path.join(root, '.cache/p43/private/platform-login');
    const wranglerLog = path.join(privateDir, `${label}-refresh-wrangler.log`);
    const contained = { HOME: path.join(base, 'home'), USERPROFILE: path.join(base, 'home'),
      APPDATA: path.join(base, 'appdata'), LOCALAPPDATA: path.join(base, 'localappdata'),
      XDG_CONFIG_HOME: path.join(base, 'xdg-config'), XDG_CACHE_HOME: path.join(base, 'xdg-cache'),
      XDG_DATA_HOME: path.join(base, 'xdg-data') };
    guard(oauthPath, wranglerLog, path.join(privateDir, '.wrangler'), ...Object.values(contained));
    const env = { ...process.env, ...contained, CI: 'true', CLOUDFLARE_ACCOUNT_ID: account,
      WRANGLER_LOG_PATH: wranglerLog, WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false' };
    for (const key of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY', 'CLOUDFLARE_EMAIL', 'CF_EMAIL']) delete env[key];
    const args = [path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/wrangler/bin/wrangler.js'),
      'pages', 'project', 'list', '--json'];
    const cli = spawnSync(process.execPath, args, { cwd: privateDir, env, windowsHide: true, encoding: 'utf8',
      timeout: 90000, stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 4 * 1024 * 1024 });
    save('oauth-refresh-cli.json', { args, exitCode: cli.status, signal: cli.signal, stdout: cli.stdout, stderr: cli.stderr }, true);
    report.oauthRefresh = { operation: 'Official Wrangler noninteractive refresh through a read-only Pages list',
      exitCode: cli.status, signal: cli.signal, previousExpiration: expiry, newBrowserLoginPermitted: false };
    const refreshed = fs.readFileSync(oauthPath, 'utf8');
    token = refreshed.match(/^oauth_token\s*=\s*"([^"]+)"/m)?.[1];
    const refreshedExpiry = refreshed.match(/^expiration_time\s*=\s*"([^"]+)"/m)?.[1];
    const scopes = text => [...(text.match(/^scopes\s*=\s*(\[[^\]]*\])/m)?.[1] || '').matchAll(/"([a-z][a-z0-9:_-]+)"/g)].map(m => m[1]).sort();
    assert.deepEqual(scopes(refreshed), scopes(oauth), 'A normal refresh must not expand the granted scopes');
    assert.equal(cli.status, 0, 'Official refresh/read failed; preserve the receipt without another login or replay');
    assert.ok(token && Date.parse(refreshedExpiry) > Date.now(), 'No usable OAuth session after official refresh');
    report.oauthRefresh.expiration = refreshedExpiry;
    report.oauthRefresh.scopesUnchanged = true;
  }
  if (mode === 'access-log-read') {
    assert.equal(credential, 'ci');
    const until = new Date().toISOString();
    const since = '2026-10-17T14:00:00.000Z';
    report.accessLoginObservation = { since, until, events: [], roleNotInferredFromAccessLogin: true,
      reference: 'cloudflare/cloudflare-typescript src/resources/zero-trust/access/logs/access-requests.ts' };
    for (const [name, id] of [['legacy', '0d826613-3097-41ea-ba20-a8174d6822dd'], ['p43', 'ca168030-0227-49a5-bd0c-bf030c9c86ea']]) {
      const query = new URLSearchParams({ since, until, limit: '100', direction: 'desc', app_uid: id, app_uidOp: 'eq',
        fields: 'action,allowed,app_domain,app_uid,connection,created_at,ray_id,user_email' });
      const response = await api(`${name}-login-events`, `access/logs/access_requests?${query}`);
      if (!response.success) { report.accessLoginObservation.unavailable = true; continue; }
      assert.ok(Array.isArray(response.result));
      report.accessLoginObservation.events.push(...response.result.filter(event => event.app_uid === id).map(event => ({
        action: event.action, allowed: event.allowed, appDomain: event.app_domain, appId: event.app_uid,
        identitySha256: event.user_email ? sha(event.user_email.trim().toLowerCase()) : null,
        connection: event.connection, createdAt: event.created_at, rayId: event.ray_id
      })));
    }
  } else if (mode === 'gate-check') {
    assert.equal(credential, 'ci');
    const app = await api('protected-app-readback', 'access/apps/ca168030-0227-49a5-bd0c-bf030c9c86ea');
    const policies = await api('protected-policies-readback', 'access/apps/ca168030-0227-49a5-bd0c-bf030c9c86ea/policies');
    assert.ok(app.success && policies.success);
    assert.equal(app.result.domain, `${projectName}.pages.dev`);
    assert.equal(policies.result.length, 1);
    assert.equal(policies.result[0].decision, 'allow');
    assert.ok(policies.result[0].include.every(rule => rule.email));
    const headersFile = path.join(privateDir, `${label}-origin-headers.txt`);
    const bodyFile = path.join(privateDir, `${label}-origin-body.txt`);
    guard(headersFile, bodyFile);
    for (const file of [headersFile, bodyFile]) assert.ok(!fs.existsSync(file));
    const origin = `https://${projectName}.pages.dev`;
    const cli = spawnSync('curl.exe', ['-q', '--silent', '--show-error', '--proto', '=https', '--connect-timeout', '15', '--max-time', '30',
      '--dump-header', headersFile, '--output', bodyFile, '--write-out', '%{http_code}', origin],
      { cwd: root, windowsHide: true, encoding: 'utf8', timeout: 35000, maxBuffer: 1024 * 1024 });
    save('origin-curl.json', { exitCode: cli.status, signal: cli.signal, stderr: cli.stderr }, true);
    assert.equal(cli.status, 0);
    const headers = fs.readFileSync(headersFile, 'utf8');
    const header = name => [...headers.matchAll(new RegExp(`^${name}:\\s*([^\\r\\n]+)`, 'gmi'))].at(-1)?.[1];
    const location = header('location');
    const next = location ? new URL(location, origin) : null;
    report.unauthenticatedGate = { origin, status: Number(cli.stdout.trim()), cfRay: header('cf-ray'),
      redirect: next ? { origin: next.origin, path: next.pathname, queryOmitted: true } : null,
      accessRedirectVerified: next?.origin === 'https://sulovehuang.cloudflareaccess.com',
      bodySha256: sha(fs.readFileSync(bodyFile)), authenticatedOwnerNotClaimed: true, codeNotYetDeployed: true };
  } else if (mode === 'configure-access') {
    assert.equal(credential, 'oauth');
    const owner = ownerIdentity();
    const app = JSON.parse(fs.readFileSync(path.join(privateDir, 'access-policy-ci-01-isolated-access-app.json'), 'utf8')).result;
    assert.equal(app.id, 'ca168030-0227-49a5-bd0c-bf030c9c86ea');
    assert.equal(app.domain, `${projectName}.pages.dev`);
    assert.ok(app.aud);
    const policy = JSON.parse(fs.readFileSync(path.join(privateDir, 'access-policy-ci-01-isolated-policies-after.json'), 'utf8')).result;
    assert.equal(policy.length, 1);
    assert.ok(policy[0].include.some(rule => rule.email?.email.trim().toLowerCase() === owner));
    const before = await api('project-before-access-config', projectRoute);
    assert.ok(before.success && !before.result.latest_deployment);
    const variables = {
      ACCESS_JWT_ISSUER: { type: 'secret_text', value: 'https://sulovehuang.cloudflareaccess.com' },
      ACCESS_JWT_AUD: { type: 'secret_text', value: app.aud },
      ADMIN_OWNER_EMAILS: { type: 'secret_text', value: owner },
      ADMIN_ALLOWED_ORIGINS: { type: 'secret_text', value: `https://${projectName}.pages.dev` }
    };
    for (const name of Object.keys(variables)) assert.ok(!Object.hasOwn(before.result.deployment_configs.production.env_vars, name), 'Inspect existing Access configuration; do not blindly replay its write');
    let result;
    try {
      result = await api('project-access-config', projectRoute, 'PATCH', { deployment_configs: { production: { env_vars: variables,
        wrangler_config_hash: before.result.deployment_configs.production.wrangler_config_hash } } });
    } catch (error) { report.configurationWriteUnknown = { name: error.name, code: error.code }; }
    const after = await api('project-after-access-config', projectRoute);
    assert.ok(after.success);
    assert.deepEqual(after.result.deployment_configs.preview, before.result.deployment_configs.preview);
    const actual = structuredClone(after.result.deployment_configs.production);
    for (const name of Object.keys(variables)) { assert.equal(actual.env_vars[name].type, 'secret_text'); delete actual.env_vars[name]; }
    assert.deepEqual(actual, before.result.deployment_configs.production);
    report.accessConfiguration = { sourceOwnerObservation: ownerLabel, ownerSha256: sha(owner),
      issuer: variables.ACCESS_JWT_ISSUER.value, audienceSha256: sha(app.aud), origin: variables.ADMIN_ALLOWED_ORIGINS.value,
      secretNamesVerified: Object.keys(variables), configurationReadbackMatches: true,
      existingBindingsAndSigningConfigurationUnchanged: true, previewUnchanged: true,
      writeResponseConfirmed: result?.success === true, realP43SessionStillRequired: true };
  } else if (mode === 'deploy') {
    assert.equal(credential, 'oauth');
    const owner = ownerIdentity();
    const source = '933b790e69e04ee551ad255398e08f12a1b2a107';
    const artifact = path.join(root, '.cache/p43/ci/artifacts-39018754889', `admin-deployment-input-${source}`);
    assert.equal(fs.readFileSync(path.join(artifact, 'source-commit.txt'), 'utf8').trim(), source);
    assert.equal(fs.readFileSync(path.join(artifact, 'source-run.txt'), 'utf8').trim(), '39018754889/1');
    const expected = [
      ['public/_routes.json', 124, '5e6709f7f844688026950a719cb30e514a4e9d4c546a418b6b914672ab866247'],
      ['public/_worker.js/index.js', 107635, '0ea681f19a8b2eec43c289d5637a0794943d5e44550cd46732b9220795043dc7'],
      ['public/index.html', 265348, '94a3337689719a2cc93eeb5820db15926b60abe701b13e5e560869bc39bf9d8c']
    ];
    const verifyInputs = () => {
      assert.deepEqual(fs.readdirSync(path.join(artifact, 'public')).sort(), ['_routes.json', '_worker.js', 'index.html']);
      assert.deepEqual(fs.readdirSync(path.join(artifact, 'public/_worker.js')), ['index.js']);
      for (const [name, size, digest] of expected) { const bytes = fs.readFileSync(path.join(artifact, name)); assert.equal(bytes.length, size); assert.equal(sha(bytes), digest); }
    };
    verifyInputs();
    const before = await api('project-before-deploy', projectRoute);
    assert.ok(before.success);
    assert.ok(!before.result.latest_deployment && !before.result.canonical_deployment, 'Reconcile any previous deployment, never blindly redeploy');
    const config = before.result.deployment_configs.production;
    assert.equal(config.d1_databases.DB.id, '2617e1e1-956f-42ce-a465-da56d84abf06');
    assert.equal(config.r2_buckets.RELEASES_BUCKET.name, 'e-track-firmware-p41-test-releases');
    for (const name of ['ACCESS_JWT_ISSUER', 'ACCESS_JWT_AUD', 'ADMIN_OWNER_EMAILS', 'ADMIN_ALLOWED_ORIGINS']) assert.equal(config.env_vars[name].type, 'secret_text');
    const base = path.join(root, '.cache/p43/private/platform-login');
    const wranglerLog = path.join(privateDir, `${label}-deploy-wrangler.log`);
    const contained = { HOME: path.join(base, 'home'), USERPROFILE: path.join(base, 'home'), APPDATA: path.join(base, 'appdata'),
      LOCALAPPDATA: path.join(base, 'localappdata'), XDG_CONFIG_HOME: path.join(base, 'xdg-config'),
      XDG_CACHE_HOME: path.join(base, 'xdg-cache'), XDG_DATA_HOME: path.join(base, 'xdg-data') };
    guard(wranglerLog, path.join(privateDir, '.wrangler'), artifact, ...Object.values(contained));
    for (let directory = privateDir; directory !== path.dirname(root); directory = path.dirname(directory)) {
      for (const name of ['wrangler.toml', 'wrangler.json', 'wrangler.jsonc']) assert.ok(!fs.existsSync(path.join(directory, name)), 'Do not inherit an unrelated Wrangler configuration');
    }
    const env = { ...process.env, ...contained, CI: 'true', CLOUDFLARE_ACCOUNT_ID: account, WRANGLER_LOG_PATH: wranglerLog,
      WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false' };
    for (const name of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY', 'CLOUDFLARE_EMAIL', 'CF_EMAIL']) delete env[name];
    const args = [path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/wrangler/bin/wrangler.js'),
      'pages', 'deploy', path.join(artifact, 'public'), '--project-name', projectName, '--branch', 'main',
      '--commit-hash', source, '--commit-dirty=false', '--no-bundle', '--upload-source-maps=false'];
    report.deploymentCommandAttempted = true;
    const cli = spawnSync(process.execPath, args, { cwd: privateDir, env, windowsHide: true, encoding: 'utf8',
      timeout: 180000, stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 8 * 1024 * 1024 });
    save('deployment-cli.json', { args, exitCode: cli.status, signal: cli.signal, stdout: cli.stdout, stderr: cli.stderr }, true);
    const after = await api('project-after-deploy', projectRoute);
    assert.ok(after.success, 'Deployment outcome requires reconciliation, not another deployment command');
    save('deployment-readback.json', after.result, true);
    verifyInputs();
    assert.deepEqual(after.result.deployment_configs, before.result.deployment_configs);
    const deployment = after.result.canonical_deployment || after.result.latest_deployment;
    assert.ok(deployment);
    assert.equal(deployment.deployment_trigger.metadata.commit_hash, source);
    assert.equal(deployment.environment, 'production');
    assert.equal(deployment.latest_stage.status, 'success');
    assert.equal(cli.status, 0, 'CLI failure retained despite its reconciled deployment state');
    report.deployment = { id: deployment.id, url: deployment.url, origin: `https://${projectName}.pages.dev`,
      sourceCommit: source, sourceRun: '39018754889/1', ownerIdentitySha256: sha(owner),
      servingFiles: expected.map(([name, sizeBytes, sha256]) => ({ name, sizeBytes, sha256 })),
      inputsUnchanged: true, settingsUnchanged: true, bundledLocally: false, cliExitCode: cli.status,
      actualStage: deployment.latest_stage, realP43SessionStillRequired: true };
  } else if (mode === 'access-inspect' || mode === 'access-policy') {
    assert.equal(credential, 'ci');
    const oldId = '0d826613-3097-41ea-ba20-a8174d6822dd';
    const newId = 'ca168030-0227-49a5-bd0c-bf030c9c86ea';
    const oldApp = await api('legacy-access-app', `access/apps/${oldId}`);
    const oldPolicies = await api('legacy-access-policies', `access/apps/${oldId}/policies`);
    const newApp = await api('isolated-access-app', `access/apps/${newId}`);
    const newPolicies = await api('isolated-access-policies', `access/apps/${newId}/policies`);
    for (const value of [oldApp, oldPolicies, newApp, newPolicies]) assert.ok(value.success);
    assert.equal(oldApp.result.domain, 'trace-update-admin-staging.pages.dev');
    assert.equal(newApp.result.domain, `${projectName}.pages.dev`);
    assert.equal(oldPolicies.result.length, 1, 'Inspect an unexpected existing policy set before choosing operators');
    const sourcePolicy = oldPolicies.result[0];
    assert.equal(sourcePolicy.decision, 'allow');
    assert.ok(sourcePolicy.include.length > 0);
    assert.ok(sourcePolicy.include.every(rule => Object.keys(rule).length === 1 && rule.email
      && Object.keys(rule.email).length === 1 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rule.email.email)),
      'Only the existing explicit individual email allowlist can be reused automatically');
    const payload = { name: 'P4-3 existing Admin operators', decision: 'allow', precedence: 1,
      include: sourcePolicy.include, exclude: sourcePolicy.exclude || [], require: sourcePolicy.require || [] };
    report.existingPolicy = { id: sourcePolicy.id, decision: sourcePolicy.decision,
      explicitEmailHashes: sourcePolicy.include.map(rule => sha(rule.email.email.trim().toLowerCase())),
      requireCount: payload.require.length, excludeCount: payload.exclude.length,
      ownerRoleNotInferredFromAllowlist: true };
    report.isolatedAccess = { id: newId, domain: newApp.result.domain, audiencePresent: !!newApp.result.aud,
      currentPolicies: newPolicies.result.length };
    if (mode === 'access-policy') {
      assert.equal(newPolicies.result.length, 0, 'Do not replay a policy write; inspect any existing policy first');
      let changed;
      try {
        changed = await api('isolated-policy-create', `access/apps/${newId}/policies`, 'POST', payload);
      } catch (error) {
        report.policyWriteUnknown = { name: error.name, code: error.code, causeCode: error.cause?.code };
      }
      const after = await api('isolated-policies-after', `access/apps/${newId}/policies`);
      const oldAfter = await api('legacy-policies-after', `access/apps/${oldId}/policies`);
      assert.ok(after.success && oldAfter.success);
      assert.deepEqual(oldAfter.result, oldPolicies.result);
      assert.equal(after.result.length, 1);
      for (const key of Object.keys(payload)) assert.deepEqual(after.result[0][key], payload[key]);
      report.policyConfigured = true;
      report.policyId = after.result[0].id;
      report.responseStatusConfirmed = changed?.success === true;
      report.legacyPolicyUnchanged = true;
      report.ownerRoleConfigured = false;
    }
  } else if (mode === 'readback') {
    const current = await api('project-final', projectRoute);
    assert.ok(current.success);
    const configured = JSON.parse(fs.readFileSync(path.join(privateDir, 'pages-configure-01-project-after-configure.json'), 'utf8'));
    assert.deepEqual(current.result.deployment_configs, configured.result.deployment_configs);
    assert.ok(!current.result.latest_deployment && !current.result.canonical_deployment);
    const original = await api('original-project-final', 'pages/projects/trace-update-admin-staging');
    const originalBefore = JSON.parse(fs.readFileSync(path.join(privateDir, 'pages-inventory-01-project-trace-update-admin-staging.json'), 'utf8'));
    assert.ok(original.success);
    assert.deepEqual(original.result.deployment_configs, originalBefore.result.deployment_configs);
    assert.equal(original.result.canonical_deployment?.id, originalBefore.result.canonical_deployment?.id);
    const origin = `https://${projectName}.pages.dev`;
    const response = await fetch(origin, { redirect: 'manual', signal: AbortSignal.timeout(30000) });
    const location = response.headers.get('location');
    const next = location ? new URL(location, origin) : null;
    await response.body?.cancel();
    report.isolatedProject = project(current.result);
    report.originalTraceConfigAndDeploymentUnchanged = true;
    report.originProbe = { url: origin, status: response.status, cfRay: response.headers.get('cf-ray'),
      redirect: next ? { origin: next.origin, path: next.pathname, queryOmitted: true } : null,
      ownerLoginEntryReady: false, note: 'No Admin code deployment or Access protection yet' };
  } else if (mode === 'configure') {
    const before = await api('project-before-configure', projectRoute);
    assert.ok(before.success);
    assert.equal(before.result.name, projectName);
    assert.ok(!before.result.latest_deployment, 'Unexpected deployment; reconcile before configuring');
    const testSecrets = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/firmware-test-secrets.json', 'utf8'));
    assert.ok(testSecrets.DOWNLOAD_HMAC_KEY_CURRENT);
    const variables = {
      ENVIRONMENT: { type: 'plain_text', value: 'staging' }, APP_ID: { type: 'plain_text', value: 'trace' },
      DOWNLOAD_TOKEN_KEY_VERSION: { type: 'plain_text', value: 'p41-test-1' },
      FIRMWARE_V2_CUTOVER_EPOCH: { type: 'plain_text', value: '1792039926' },
      FIRMWARE_DOWNLOAD_ORIGIN: { type: 'plain_text', value: 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev' },
      DOWNLOAD_HMAC_KEY_CURRENT: { type: 'secret_text', value: testSecrets.DOWNLOAD_HMAC_KEY_CURRENT }
    };
    assert.deepEqual(Object.keys(before.result.deployment_configs.production.env_vars || {}), []);
    const payload = { deployment_configs: { production: {
      compatibility_date: '2026-06-28', compatibility_flags: ['nodejs_compat'],
      d1_databases: { DB: { id: '2617e1e1-956f-42ce-a465-da56d84abf06' } },
      r2_buckets: { RELEASES_BUCKET: { name: 'e-track-firmware-p41-test-releases' } }, env_vars: variables
    } } };
    const response = await api('project-configure', projectRoute, 'PATCH', payload);
    const after = await api('project-after-configure', projectRoute);
    assert.ok(response.success && after.success, 'Configuration result requires reconciliation, not an automatic replay');
    const actual = after.result.deployment_configs.production;
    assert.deepEqual(actual.d1_databases, payload.deployment_configs.production.d1_databases);
    assert.deepEqual(actual.r2_buckets, payload.deployment_configs.production.r2_buckets);
    for (const key of publicVars) assert.equal(actual.env_vars[key].value, variables[key].value);
    assert.equal(actual.env_vars.DOWNLOAD_HMAC_KEY_CURRENT.type, 'secret_text');
    assert.deepEqual(after.result.deployment_configs.preview, before.result.deployment_configs.preview);
    report.configuredProject = project(after.result);
    report.secretReuse = { name: 'DOWNLOAD_HMAC_KEY_CURRENT', source: 'Existing approved test-secret input; no Worker credential rotation',
      configuredNameReadBack: true, valueNotReadableThroughPagesApi: true, realSignedDownloadNotYetRun: true };
    report.deployed = false;
  } else if (mode === 'protect') {
    const existing = await api('apps-before-protect', 'access/apps?per_page=100');
    assert.ok(existing.success);
    assert.ok(!existing.result.some(app => app.domain === `${projectName}.pages.dev`), 'Existing matching app must be inspected instead of recreated');
    const payload = { name: 'E-Track P4-3 Admin Test', domain: `${projectName}.pages.dev`, type: 'self_hosted',
      session_duration: '1h', app_launcher_visible: false, auto_redirect_to_identity: false, policies: [] };
    const created = await api('app-protect', 'access/apps', 'POST', payload);
    const after = await api('apps-after-protect', 'access/apps?per_page=100');
    assert.ok(after.success, 'Access write must be reconciled before any retry');
    report.matchingApps = after.result.filter(app => app.domain === payload.domain)
      .map(app => ({ id: app.id, name: app.name, domain: app.domain, type: app.type,
        policyCount: app.policies?.length ?? null, audiencePresent: !!app.aud }));
    if (!created.success) process.exitCode = 1;
    else {
      assert.equal(report.matchingApps.length, 1);
      assert.equal(created.result.domain, payload.domain);
      assert.ok(!created.result.policies?.length, 'Unexpected allow policy; do not deploy');
      report.accessApplicationCreated = true;
      report.ownerPolicyConfigured = false;
    }
  } else if (mode === 'create') {
    const inventory = JSON.parse(fs.readFileSync(path.join(publicDir, 'pages-inventory-01-summary.json'), 'utf8'));
    assert.deepEqual(inventory.p43Candidates, []);
    assert.ok(inventory.receipts.find(r => r.name === 'pages-1' && r.status === 200 && r.success));
    const name = 'e-track-firmware-p43-admin-test';
    const base = path.join(root, '.cache/p43/private/platform-login');
    const wranglerLog = path.join(privateDir, `${label}-wrangler.log`);
    guard(wranglerLog, path.join(privateDir, '.wrangler'));
    const env = { ...process.env, HOME: path.join(base, 'home'), USERPROFILE: path.join(base, 'home'),
      APPDATA: path.join(base, 'appdata'), LOCALAPPDATA: path.join(base, 'localappdata'),
      XDG_CONFIG_HOME: path.join(base, 'xdg-config'), XDG_CACHE_HOME: path.join(base, 'xdg-cache'),
      XDG_DATA_HOME: path.join(base, 'xdg-data'), CLOUDFLARE_ACCOUNT_ID: account,
      WRANGLER_LOG_PATH: wranglerLog, WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_SEND_METRICS: 'false' };
    for (const key of ['CLOUDFLARE_API_TOKEN', 'CF_API_TOKEN', 'CLOUDFLARE_API_KEY', 'CF_API_KEY', 'CLOUDFLARE_EMAIL', 'CF_EMAIL']) delete env[key];
    const args = [path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/wrangler/bin/wrangler.js'),
      'pages', 'project', 'create', name, '--production-branch', 'main', '--compatibility-date', '2026-06-28', '--compatibility-flags', 'nodejs_compat'];
    report.cloudWritesAttempted = 1;
    const cli = spawnSync(process.execPath, args, { cwd: privateDir, env, windowsHide: true, encoding: 'utf8', timeout: 120000,
      stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 4 * 1024 * 1024 });
    save('cli.json', { args, exitCode: cli.status, signal: cli.signal, stdout: cli.stdout, stderr: cli.stderr }, true);
    report.cli = { operation: 'Create only the authorized isolated Pages project', exitCode: cli.status, signal: cli.signal };
    const actual = await api('project-after-create', `pages/projects/${name}`);
    assert.ok(actual.success, 'Creation result unresolved; no automatic create replay');
    assert.equal(actual.result.name, name);
    assert.equal(actual.result.subdomain, `${name}.pages.dev`);
    assert.equal(actual.result.production_branch, 'main');
    report.createdProject = project(actual.result);
    report.deployed = false;
    report.accessConfigured = false;
  } else {
  const projects = [];
  for (let page = 1; page <= 20; page++) {
    const json = await api(`pages-${page}`, `pages/projects?page=${page}&per_page=10`);
    assert.ok(json.success, 'Pages list failed; do not infer absence');
    projects.push(...json.result);
    if (json.result.length < 10) break;
    assert.ok(page < 20, 'Project inventory exceeds finite bound');
  }
  report.projects = projects.map(project);
  report.p43Candidates = projects.filter(p => p.name.includes('p43') || p.name.includes('p4-3')).map(p => p.name);
  for (const p of projects.filter(p => p.name === 'trace-update-admin-staging' || report.p43Candidates.includes(p.name))) {
    await api(`project-${p.name}`, `pages/projects/${p.name}`);
  }
  for (const [name, suffix] of [['access-apps', 'access/apps?per_page=100'], ['access-idps', 'access/identity_providers'],
    ['access-org', 'access/organizations']]) {
    const json = await api(name, suffix);
    if (!json.success) continue;
    if (name === 'access-apps') report.accessApps = json.result.map(a => ({ id: a.id, name: a.name, domain: a.domain, type: a.type }));
    if (name === 'access-idps') report.idps = json.result.map(p => ({ id: p.id, name: p.name, type: p.type }));
    if (name === 'access-org') report.accessOrg = { authDomain: json.result.auth_domain, name: json.result.name };
  }
  }
} catch (error) {
  report.failure = { name: error.name, code: error.code, message: String(error.message).split(token).join('[REDACTED]') };
  process.exitCode = 1;
} finally {
  report.endedAt = new Date().toISOString();
  save('summary.json', report);
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
}
