import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const sourceFile = fileURLToPath(import.meta.url);
const root = path.resolve(path.dirname(sourceFile), '..');
const [mode, label] = process.argv.slice(2);
assert.ok(['probe', 'drill'].includes(mode));
assert.match(label || '', /^(?:probe|drill)-[0-9]+$/);
const afterRecovery = process.argv[4] === '--after-recovery';
const afterSetup = process.argv[4] === '--after-setup' || afterRecovery;
assert.ok(process.argv[4] === undefined || (mode === 'drill' && afterSetup));
const directBrowser = process.argv[5] === '--direct-browser';
assert.ok(process.argv[5] === undefined || directBrowser);
const origin = 'https://e-track-firmware-p43-admin-test.pages.dev';
const downloadOrigin = 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev';
const scope = { appId: 'trace', deviceModel: 'e-track-at32f435' };
const low = 'fw_e1abd9e066161562fb72322b81ee7c06bf4719df7d6f89e769811a7460373648';
const high = 'fw_12367eee317a0774a7271cf982ee7f933c6b089336645f9e607501105e72bf0c';
const publicDir = path.join(root, '.cache/p43/live-drill', label);
const privateDir = path.join(root, '.cache/p43/private/live-drill', label);
const profile = path.join(root, '.cache/p43/browser-owner');
const browserLog = path.join(privateDir, 'browser.log');
const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'drill-preflight', '.', 'preflight',
  publicDir, privateDir, profile, browserLog], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(guard.status, 0, 'Full output-root/reparse-point preflight failed');
assert.ok(!fs.existsSync(publicDir) && !fs.existsSync(privateDir), 'Never replace a prior observation');
fs.mkdirSync(publicDir, { recursive: true }); fs.mkdirSync(privateDir, { recursive: true });
const sha = value => createHash('sha256').update(value).digest('hex');
const secrets = new Set();
function scrubText(value) {
  let text = String(value);
  for (const secret of secrets) if (secret && secret.length > 8) text = text.split(secret).join('[PRIVATE]');
  return text.replace(/https?:\/\/[^\s"<>]*\?[^\s"<>]*/g, '[URL_QUERY_PRIVATE]')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '[JWT_PRIVATE]');
}
function sanitized(value) {
  if (Array.isArray(value)) return value.map(sanitized);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => {
    if (['actor', 'actor_canonical', 'last_actor'].includes(key) && typeof item === 'string') return [`${key}_sha256`, sha(item.trim().toLowerCase())];
    if (['downloadUrl', 'idempotencyKey', 'csrfToken'].includes(key)) return [`${key}Sha256`, typeof item === 'string' ? sha(item) : null];
    if (['ip', 'user_agent'].includes(key)) return [key, '[PRIVATE_ORIGINAL]'];
    return [key, sanitized(item)];
  }));
  return typeof value === 'string' ? scrubText(value) : value;
}
function output(name, isPrivate = false) {
  assert.match(name, /^[a-z0-9][a-z0-9._-]*$/);
  const base = isPrivate ? privateDir : publicDir;
  const file = path.resolve(base, name);
  assert.equal(path.dirname(file), base);
  assert.equal(fs.realpathSync(base).toLowerCase(), base.toLowerCase());
  assert.ok(!fs.existsSync(file), 'Evidence files are append-only');
  return file;
}
function save(name, value, isPrivate = false) {
  fs.writeFileSync(output(name, isPrivate), JSON.stringify(isPrivate ? value : sanitized(value), null, 2) + '\n', { flag: 'wx' });
}
function bytes(name, value, isPrivate = false) { fs.writeFileSync(output(name, isPrivate), value, { flag: 'wx' }); }
bytes('collector-source.mjs', fs.readFileSync(sourceFile));
const deployed = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/pages-deploy-02-summary.json'), 'utf8')).deployment;
assert.equal(deployed.sourceCommit, '933b790e69e04ee551ad255398e08f12a1b2a107');
assert.equal(deployed.origin, origin); assert.equal(deployed.actualStage.status, 'success');
const ownerProof = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/owner-login-05.json'), 'utf8'));
assert.equal(ownerProof.ownerVerified, true);
const approved = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8'));
assert.equal(approved.d1_databases[0].database_id, '2617e1e1-956f-42ce-a465-da56d84abf06');
const cloudToken = fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/p41-ci-token.txt', 'utf8').trim();
secrets.add(cloudToken); secrets.add(approved.account_id);
const report = { label, mode, startedAt: new Date().toISOString(), origin, deploymentId: deployed.id,
  productSource: deployed.sourceCommit, collectorSha256: sha(fs.readFileSync(sourceFile)), node: process.version,
  nature: 'Real isolated Access/Admin/D1/public Worker observations; synthetic low sample is cloud-only, no device operation',
  mockResponses: 0, allowedScope: scope, checks: [], screenshots: [], requests: [], console: [],
  browserWrites: 0, blockedOutOfScopeWrites: 0, restored: false,
  roleCoverage: { owner: 'REAL', publisher: 'NO_REAL_SESSION', viewer: 'NO_REAL_SESSION' } };
const emit = value => process.stdout.write(JSON.stringify(sanitized(value)) + '\n');
let sequence = 0;
const serial = name => `${String(++sequence).padStart(3, '0')}-${name}`;
let context, page, session, current, baseline;
let phase = 'read-only';
const keys = [];
const sqlRow = (kind, table, columns, where = '') => `'${kind}',json((SELECT json_group_array(json_object(${columns.map(c => `'${c}',${c}`).join(',')})) FROM ${table}${where}))`;
const snapshotSql = 'SELECT json_object(' + [
  sqlRow('channels', 'firmware_channels', ['id','app_id','device_model','name','current_release_id','revision','disable_latest','disable_downloads','maintenance_message','last_action','last_actor','last_actor_type','last_request_id','last_reason','last_before_json','last_after_json','created_at','updated_at']),
  sqlRow('releases', 'firmware_releases', ['id','app_id','device_model','version_code','version_name','release_tag','state','archived','target_image_sha256','hardware_rev','layout_id','min_boot_version','min_protocol_version','min_app_version_code','registration_json','created_at','updated_at']),
  sqlRow('assets', 'firmware_release_assets', ['id','release_id','kind','file_name','r2_key','sha256','size_bytes','r2_state','base_vcode','base_image_sha256']),
  sqlRow('audit', 'audit_logs', ['id','app_id','actor','actor_type','action','target_type','target_id','request_id','reason','ip','user_agent','before_json','after_json','created_at'], " WHERE target_type IN ('firmware_release','firmware_asset','firmware_channel')"),
  sqlRow('idempotency', 'firmware_admin_idempotency', ['actor_canonical','fingerprint','method','canonical_path','action','release_id','state','status_code','request_id','created_epoch_seconds','retained_until','original_expires_at']),
  "'tombstones',json_array(json_object('count',(SELECT count(*) FROM firmware_admin_idempotency_tombstones)))",
  sqlRow('appConfig', 'app_config', ['app_id','disable_all_downloads'])
].join(',') + ') AS snapshot_json';
async function readD1(name, sql = snapshotSql) {
  assert.match(sql, /^SELECT\b/); assert.ok(!sql.includes(';'));
  const id = serial(name);
  const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${approved.account_id}/d1/database/2617e1e1-956f-42ce-a465-da56d84abf06/query`, {
    method: 'POST', headers: { Authorization: `Bearer ${cloudToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ sql }), redirect: 'error', signal: AbortSignal.timeout(30000)
  });
  const body = Buffer.from(await response.arrayBuffer()); assert.ok(body.length < 2 * 1024 * 1024);
  bytes(`${id}-d1-original.json`, body, true);
  const json = JSON.parse(body.toString('utf8'));
  save(`${id}-d1-receipt.json`, { status: response.status, cfRay: response.headers.get('cf-ray'), observedAt: new Date().toISOString(),
    query: sql, bodySha256: sha(body), bodyBytes: body.length, success: json.success });
  assert.equal(response.status, 200); assert.equal(json.success, true);
  assert.ok(json.result.every(r => r.success && r.meta.rows_written === 0 && !r.meta.changed_db));
  return { id, rows: json.result[0].results };
}
async function snapshot(name) {
  const { id, rows } = await readD1(name);
  assert.equal(rows.length, 1);
  const result = JSON.parse(rows[0].snapshot_json);
  for (const list of Object.values(result)) list.sort((a,b) => String(a.id ?? a.request_id ?? a.app_id ?? '').localeCompare(String(b.id ?? b.request_id ?? b.app_id ?? '')));
  assert.ok(result.idempotency.every(row => row.state === 'completed'), 'Committed pending row');
  for (const row of result.audit) {
    const data = `${row.before_json || ''}${row.after_json || ''}`;
    assert.ok(!/"(?:downloadUrl|signature|token|secret|idempotency_key)"|[?&]signature=/.test(data));
    for (const key of keys) assert.ok(!JSON.stringify(row).includes(key));
  }
  save(`${id}-snapshot.json`, result);
  return result;
}
async function check(id, action) {
  const startedAt = new Date().toISOString();
  try { const result = await action(); report.checks.push({ id, result: 'PASS', startedAt, endedAt: new Date().toISOString() }); emit({ check: id, result: 'PASS' }); return result; }
  catch (error) { report.checks.push({ id, result: 'FAIL', startedAt, error: { name: error.name, message: scrubText(error.message) } }); throw error; }
}
function permittedWrite(url, body) {
  assert.equal(new URL(url).origin, origin);
  assert.equal(body.appId, scope.appId); assert.equal(body.deviceModel, scope.deviceModel);
  const pathname = new URL(url).pathname;
  if (/^\/api\/admin\/firmware\/channels\/(stable|beta)\/(publish|retract|stop-latest|resume-latest|stop-downloads|resume-downloads)$/.test(pathname)) {
    if (body.releaseId) assert.ok([low, high].includes(body.releaseId));
  } else {
    const match = /^\/api\/admin\/firmware\/releases\/([^/]+)\/(disable|recovery-download)$/.exec(pathname);
    assert.ok(match && [low, high].includes(match[1]));
    if (match[2] === 'disable') {
      assert.equal(match[1], low, 'High release may never be disabled');
      assert.ok(phase === 'final-disable' || (phase === 'low-window' && current.channels.some(c => c.current_release_id === low)), 'Conditional disable boundary');
    }
  }
  assert.notEqual(mode, 'probe', 'Read-only probe cannot mutate');
}
async function apiGet(pathname) {
  const response = await context.request.get(origin + pathname, { headers: { Accept: 'application/json' }, maxRedirects: 0, timeout: 30000 });
  const body = await response.json();
  return { response, body };
}
async function screenshot(name, targetPage = page) {
  const file = output(`${name}.png`);
  await targetPage.screenshot({ path: file, fullPage: true, mask: [targetPage.locator('#sideSession'), targetPage.locator('#topSession')] });
  report.screenshots.push({ file: path.basename(file), sha256: sha(fs.readFileSync(file)), origin: new URL(targetPage.url()).origin,
    nature: 'REAL isolated P4-3 Access session; owner email visually masked; no credentials or signed URL displayed' });
}
async function language(lang, targetPage = page) {
  const currentLang = await targetPage.locator('html').getAttribute('lang');
  if (!currentLang.startsWith(lang)) await targetPage.locator('#languageToggle').click();
  assert.ok((await targetPage.locator('html').getAttribute('lang')).startsWith(lang));
}
const channelButton = (targetPage, channel, action) => targetPage.locator(`.firmware-channel-card[data-channel="${channel}"] [data-firmware-action="${action}"]`);
const releaseButton = (targetPage, releaseId, action) => targetPage.locator(`.firmware-release-card[data-release-id="${releaseId}"] [data-firmware-action="${action}"]`);
let expect;
function unchanged(before, after) { assert.deepEqual(after, before); }
const channelRow = (name, state = current) => state.channels.find(row => row.name === name);
const releasePath = (releaseId, action) => `/api/admin/firmware/releases/${releaseId}/${action}`;
function addKey(key) { assert.match(key, /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/); secrets.add(key); if (!keys.includes(key)) keys.push(key); return key; }
const canonical = value => value && typeof value === 'object'
  ? Array.isArray(value) ? `[${value.map(canonical).join(',')}]` : `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`
  : JSON.stringify(value);
async function captureMutation(name, response, pathname, body, key) {
  const id = serial(name); if (key) addKey(key);
  const raw = await response.body(); const result = JSON.parse(raw.toString('utf8'));
  if (result.downloadUrl) secrets.add(result.downloadUrl);
  const requestId = response.headers()['x-request-id'];
  save(`${id}-request.json`, { method: 'POST', origin, pathname, body, idempotencyKey: key ?? null }, true);
  bytes(`${id}-response-original.json`, raw, true);
  const receipt = { id, pathname, body, idempotencyKey: key ?? null, status: response.status(), requestId,
    cfRay: response.headers()['cf-ray'], observedAt: new Date().toISOString(), result,
    originalResponseSha256: sha(raw), originalResponseBytes: raw.length };
  save(`${id}-http.json`, receipt); report.requests.push(sanitized(receipt));
  assert.equal(result.requestId, requestId);
  return { ...receipt, key, responseBody: result };
}
async function post(name, pathname, body, key, headers = {}) {
  permittedWrite(origin + pathname, body); if (key) addKey(key);
  const csrf = (await context.cookies(`${origin}/api/admin/session`)).find(c => c.name === 'trace_admin_csrf')?.value;
  assert.ok(csrf); secrets.add(csrf);
  const requestHeaders = { Accept: 'application/json', 'Content-Type': 'application/json', Origin: origin,
    'X-CSRF-Token': csrf, 'X-Request-Id': randomUUID(), ...(key ? { 'Idempotency-Key': key } : {}), ...headers };
  for (const [name, value] of Object.entries(requestHeaders)) if (value === null) delete requestHeaders[name];
  const response = await context.request.post(origin + pathname, { headers: requestHeaders, data: JSON.stringify(body), maxRedirects: 0, timeout: 45000 });
  const result = await captureMutation(name, response, pathname, body, key);
  if (!result.responseBody.idempotent) assert.equal(result.requestId, requestHeaders['X-Request-Id']);
  return result;
}
async function refreshUi(targetPage = page) {
  await targetPage.locator('#refreshButton').click();
  await expect(targetPage.locator('#refreshButton')).toBeEnabled({ timeout: 45000 });
  if (await targetPage.locator('#firmwareNotice').isVisible()) {
    const id = serial('ui-read-reconciliation');
    save(`${id}.json`, { reason: 'A read failed; use the existing targeted refresh control, never replay a write',
      message: await targetPage.locator('#firmwareNotice').innerText(), observedAt: new Date().toISOString() });
    await targetPage.locator('#firmwareNotice [data-firmware-action="refresh"]').click();
  }
  await expect(targetPage.locator('#firmwareNotice')).toBeHidden({ timeout: 45000 });
  await expect(targetPage.locator('#refreshButton')).toBeEnabled({ timeout: 45000 });
}
async function fillConfirm(targetPage, reason) {
  if (await targetPage.locator('#confirmInput').isVisible()) await targetPage.locator('#confirmInput').fill('stable');
  if (await targetPage.locator('#confirmReason').isVisible()) await targetPage.locator('#confirmReason').fill(reason);
  await expect(targetPage.locator('#confirmAccept')).toBeEnabled();
}
async function finishUi(name, targetPage, pathname, expectedStatus = 200, shot = null) {
  const pending = targetPage.waitForResponse(r => r.request().method() === 'POST' && r.url() === origin + pathname, { timeout: 60000 });
  await targetPage.locator('#confirmAccept').click();
  const response = await pending;
  const request = response.request(); const body = request.postDataJSON();
  const result = await captureMutation(name, response, pathname, body, request.headers()['idempotency-key']);
  assert.equal(result.status, expectedStatus);
  await expect(targetPage.locator('#confirmDialog')).toBeVisible({ timeout: 45000 });
  if (expectedStatus === 200) await expect(targetPage.locator('#confirmTitle')).toHaveText(/Firmware operation confirmed|\u56fa\u4ef6\u64cd\u4f5c\u5df2\u786e\u8ba4/, { timeout: 45000 });
  else await expect(targetPage.locator('#confirmMessage')).toContainText(/confirm again|\u518d\u6b21\u786e\u8ba4/, { timeout: 45000 });
  if (shot) await screenshot(shot, targetPage);
  await targetPage.locator('#confirmAccept').click(); await expect(targetPage.locator('#confirmDialog')).toBeHidden();
  await expect(targetPage.locator('#refreshButton')).toBeEnabled();
  return result;
}
async function channelMutation(name, channel, action, ui = false, releaseId = null, shot = null) {
  const before = current; const old = channelRow(channel);
  const pathname = `/api/admin/firmware/channels/${channel}/${action}`;
  const body = { ...scope, expectedRevision: old.revision, reason: `P43 ${label} ${name}`,
    ...(releaseId ? { releaseId } : {}) };
  let response;
  if (ui) {
    await refreshUi();
    if (action === 'publish') await page.locator(`.firmware-release-card[data-release-id="${releaseId}"] [data-firmware-action="publish"][data-channel="${channel}"]`).click();
    else { if (releaseId) await releaseButton(page, releaseId, 'select').click(); await channelButton(page, channel, action).click(); }
    await fillConfirm(page, body.reason); response = await finishUi(name, page, pathname, 200, shot);
    assert.deepEqual(response.body, body);
  } else response = await post(name, pathname, body);
  assert.equal(response.status, 200);
  const result = response.responseBody; const after = await snapshot(`after-${name}`); const row = channelRow(channel, after);
  const pointer = ['publish','retract'].includes(action);
  const desiredPointer = pointer ? releaseId : old.current_release_id;
  const latest = action.endsWith('latest') ? Number(action.startsWith('stop')) : old.disable_latest;
  const downloads = action.endsWith('downloads') ? Number(action.startsWith('stop')) : old.disable_downloads;
  const noop = !pointer && latest === old.disable_latest && downloads === old.disable_downloads;
  assert.equal(result.idempotent, noop); assert.equal(result.action, action.replaceAll('-', '_'));
  assert.equal(result.channel, channel); assert.equal(result.revision, old.revision + (noop ? 0 : 1));
  assert.equal(row.current_release_id, desiredPointer); assert.equal(result.currentReleaseId, desiredPointer);
  assert.equal(row.disable_latest, latest); assert.equal(row.disable_downloads, downloads);
  assert.equal(result.disableLatest, !!latest); assert.equal(result.disableDownloads, !!downloads);
  assert.equal(row.revision, result.revision);
  assert.deepEqual(after.channels.filter(c => c.name !== channel), before.channels.filter(c => c.name !== channel));
  assert.deepEqual(after.releases, before.releases); assert.deepEqual(after.assets, before.assets);
  assert.deepEqual(after.idempotency, before.idempotency); assert.deepEqual(after.tombstones, before.tombstones);
  const added = after.audit.filter(a => !before.audit.some(b => b.id === a.id));
  assert.equal(added.length, noop ? 0 : 1);
  if (noop) assert.deepEqual(row, old);
  else {
    assert.equal(row.last_request_id, result.requestId); assert.equal(row.last_action, result.action); assert.equal(row.last_reason, body.reason);
    assert.equal(added[0].request_id, result.requestId); assert.equal(added[0].action, result.action);
    assert.equal(added[0].reason, body.reason); assert.equal(added[0].actor.trim().toLowerCase(), session.actor.trim().toLowerCase());
    assert.equal(JSON.parse(added[0].before_json).revision, old.revision);
    assert.equal(JSON.parse(added[0].after_json).revision, row.revision);
  }
  current = after; return response;
}
async function releaseRecorded(name, response, before, expectedNew = 1) {
  const after = await snapshot(`after-${name}`); const added = after.audit.filter(a => !before.audit.some(b => b.id === a.id));
  assert.equal(added.length, expectedNew); assert.deepEqual(after.channels, before.channels); assert.deepEqual(after.assets, before.assets);
  assert.equal(after.idempotency.length, before.idempotency.length + expectedNew);
  if (expectedNew) {
    const row = after.idempotency.find(r => r.request_id === response.requestId);
    assert.ok(row); assert.equal(row.retained_until, row.created_epoch_seconds + 86400);
    assert.equal(row.fingerprint, sha(canonical({ method: 'POST', path: response.pathname, body: response.body })));
    assert.equal(row.actor_canonical, session.actor.trim().toLowerCase()); assert.equal(row.state, 'completed');
    assert.equal(added[0].request_id, response.requestId); assert.equal(added[0].reason, response.body.reason);
  }
  current = after; return after;
}
async function publicGet(name, url, expectedStatus, expectedAsset) {
  assert.equal(new URL(url).origin, downloadOrigin);
  const id = serial(name); const headersFile = output(`${id}-headers.txt`, true); const bodyFile = output(`${id}-body.bin`, true);
  const cli = spawnSync('curl.exe', ['-q','--silent','--show-error','--proto','=https','--connect-timeout','15','--max-time','60',
    '--dump-header',headersFile,'--output',bodyFile,'--write-out','%{http_code}','--config','-'],
    { cwd: root, env: process.env, windowsHide: true, encoding: 'utf8', input: `url = "${url}"\n`, timeout: 65000, maxBuffer: 1024 * 1024 });
  save(`${id}-curl.json`, { exitCode: cli.status, signal: cli.signal, stderr: cli.stderr }, true);
  assert.equal(cli.status, 0, 'Public read transport failed');
  const payload = fs.readFileSync(bodyFile); const headerText = fs.readFileSync(headersFile, 'utf8');
  const header = name => [...headerText.matchAll(new RegExp(`^${name}:\\s*([^\\r\\n]+)`, 'gmi'))].at(-1)?.[1];
  const status = Number(cli.stdout.trim()); let json;
  if (header('content-type')?.includes('json')) json = JSON.parse(payload.toString('utf8'));
  if (json?.asset?.downloadUrl) secrets.add(json.asset.downloadUrl);
  const receipt = { name, urlSha256: sha(url), pathname: new URL(url).pathname, status, requestId: header('x-request-id'),
    cfRay: header('cf-ray'), observedAt: new Date().toISOString(), bodyBytes: payload.length, bodySha256: sha(payload),
    contentType: header('content-type'), contentDigest: header('content-digest'), contentLength: header('content-length'),
    assetType: header('x-trace-asset-type'), assetSource: header('x-trace-asset-source'), body: json };
  save(`${id}-public.json`, receipt); assert.equal(status, expectedStatus);
  if (json?.requestId) assert.equal(json.requestId, receipt.requestId);
  if (expectedAsset) {
    assert.equal(payload.length, expectedAsset.size_bytes); assert.equal(sha(payload), expectedAsset.sha256);
    assert.equal(receipt.contentDigest, `sha-256=:${Buffer.from(expectedAsset.sha256,'hex').toString('base64')}:`);
    assert.equal(receipt.assetType, 'firmware');
  }
  return json;
}
function latestUrl(channel, currentCode, imageSha) {
  return `${downloadOrigin}/api/public/firmware/latest?${new URLSearchParams({ ...scope, channel,
    currentVersionCode: String(currentCode), currentImageSha: imageSha, hardwareRevision: '1', layoutId: '1',
    bootVersion: '1', protocolVersion: '1', appVersionCode: '2100000000' })}`;
}
async function exercise() {
  const prior = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live-drill/probe-03/result.json'), 'utf8'));
  assert.equal(prior.result, 'PASS'); assert.equal(prior.browserWrites, 0);
  report.referencedRealCancellation = { path: '.cache/p43/live-drill/probe-03/result.json', sourceSha256: prior.collectorSha256 };
  phase = 'setup';
  if (!afterSetup) {
  await check('LIVE-02-real-origin-csrf-validation', async () => {
    const before = current; const body = { ...scope, expectedRevision: 0, reason: `P43 ${label} negative validation` };
    const cases = [
      ['origin', body, { Origin: 'https://p43-origin-negative.invalid' }, 403, 'ORIGIN_FORBIDDEN'],
      ['csrf', body, { 'X-CSRF-Token': null }, 403, 'CSRF_INVALID'],
      ['content-type', body, { 'Content-Type': 'text/plain' }, 400, 'INVALID_PARAMETER'],
      ['accept', body, { Accept: 'application/json;q=0' }, 400, 'INVALID_PARAMETER'],
      ['reason', { ...body, reason: ' ' }, {}, 400, 'INVALID_PARAMETER'],
      ['revision-type', { ...body, expectedRevision: '0' }, {}, 400, 'INVALID_PARAMETER'],
      ['unknown-rollback-field', { ...body, rollback: true }, {}, 400, 'INVALID_PARAMETER']
    ];
    for (const [name, input, headers, status, code] of cases) {
      const result = await post(`negative-${name}`, '/api/admin/firmware/channels/stable/stop-latest', input, undefined, headers);
      assert.equal(result.status, status); assert.equal(result.responseBody.errorCode, code);
    }
    unchanged(before, await snapshot('after-negative-validation'));
  });
  for (const channel of ['stable','beta']) for (const action of ['stop-latest','stop-downloads'])
    await check(`LIVE-04-${channel}-${action}`, () => channelMutation(`guard-${channel}-${action}`, channel, action));
  for (const [channel, lang] of [['stable','en'],['beta','zh']]) await check(`LIVE-04-${channel}-publish-high`, async () => {
    await language(lang); await channelMutation(`publish-high-${channel}`, channel, 'publish', true, high, `${lang}-real-publish-success`);
  });
  } else {
    const previous = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live-drill/drill-01/result.json'), 'utf8'));
    assert.equal(previous.restored, true); assert.equal(previous.result, 'FAIL');
    assert.deepEqual(sanitized(current.channels), previous.finalChannels);
    assert.equal(previous.requests.filter(r => r.status === 200 && !r.result.idempotent).length, 6);
    report.continuation = { source: '.cache/p43/live-drill/drill-01/result.json', sourceSha256: previous.collectorSha256,
      completedSetupMutationsNotReplayed: 6, originalFailurePreserved: true,
      remainingBetaUiSuccessCoveredByReturnPublish: true };
  }
  let recovery, concurrentRecovery, earlierRecovery;
  if (!afterRecovery) {
  await check('LIVE-09-ui-recovery-and-exact-replay', async () => {
    const before = current; await refreshUi(); await language('en');
    await releaseButton(page, low, 'recovery-download').click(); await fillConfirm(page, `P43 ${label} UI recovery, cloud-only sample`);
    recovery = await finishUi('recovery-ui', page, releasePath(low,'recovery-download'), 200, 'en-real-recovery-success');
    assert.equal(recovery.responseBody.idempotent, false);
    await releaseRecorded('recovery-ui', recovery, before);
    const asset = current.assets.find(a => a.id === recovery.responseBody.assetId);
    await publicGet('recovery-original-download', recovery.responseBody.downloadUrl, 200, asset);
    const beforeReplay = current;
    const replay = await post('recovery-exact-replay', recovery.pathname, recovery.body, recovery.key);
    assert.equal(replay.status, 200); assert.deepEqual(replay.responseBody, { ...recovery.responseBody, idempotent: true });
    unchanged(beforeReplay, await snapshot('after-recovery-replay'));
  });
  await check('LIVE-09-concurrent-first-requests', async () => {
    const before = current; const key = addKey(randomUUID()); const body = { ...scope, reason: `P43 ${label} concurrent recovery single logical issuance` };
    const pair = await Promise.all([post('recovery-concurrent-a', releasePath(low,'recovery-download'), body, key),
      post('recovery-concurrent-b', releasePath(low,'recovery-download'), body, key)]);
    assert.ok(pair.every(r => r.status === 200)); assert.deepEqual(pair.map(r => r.responseBody.idempotent).sort(), [false,true]);
    concurrentRecovery = pair.find(r => !r.responseBody.idempotent);
    assert.deepEqual(pair.find(r => r.responseBody.idempotent).responseBody, { ...concurrentRecovery.responseBody, idempotent: true });
    await releaseRecorded('concurrent-recovery', concurrentRecovery, before);
    assert.deepEqual(current.releases, before.releases);
  });
  } else {
    const originalDir = path.join(root, '.cache/p43/private/live-drill/drill-03');
    const request = JSON.parse(fs.readFileSync(path.join(originalDir, '002-recovery-ui-request.json'), 'utf8'));
    const result = JSON.parse(fs.readFileSync(path.join(originalDir, '002-recovery-ui-response-original.json'), 'utf8'));
    assert.equal(result.requestId, '9add84bf-d3a2-49c9-9693-37e57ee95d42');
    assert.equal(result.releaseId, low); assert.equal(result.idempotent, false);
    assert.ok(current.idempotency.some(row => row.request_id === result.requestId));
    earlierRecovery = { pathname: request.pathname, body: request.body, key: addKey(request.idempotencyKey), responseBody: result };
    secrets.add(result.downloadUrl);
    report.priorRecovery = { source: '.cache/p43/live-drill/drill-03/result.json', requestId: result.requestId,
      originalIssueNotRepeated: true, responseSha256: sha(fs.readFileSync(path.join(originalDir, '002-recovery-ui-response-original.json'))),
      originalUiObservationTimeoutPreserved: true };
    await check('LIVE-09-authorized-second-issuance-ui-concurrency-replay', async () => {
      const before = current; await refreshUi(); await language('en');
      const pathname = releasePath(low,'recovery-download'); let duplicate;
      let armed = true;
      const concurrentRequest = async route => {
        const request = route.request();
        if (armed && request.method() === 'POST') {
          armed = false; const body = request.postDataJSON(); const key = request.headers()['idempotency-key'];
          permittedWrite(request.url(), body); addKey(key);
          duplicate = post('recovery-concurrent-peer', pathname, body, key).then(value => ({ value }), error => ({ error }));
        }
        await route.fallback();
      };
      await context.route(origin + pathname, concurrentRequest);
      let ui;
      try {
        await releaseButton(page, low, 'recovery-download').click();
        await fillConfirm(page, `P43 ${label} second authorized recovery issuance, concurrent exact-key pair`);
        ui = await finishUi('recovery-concurrent-ui', page, pathname, 200, 'en-real-recovery-success');
      } finally { await context.unroute(origin + pathname, concurrentRequest); }
      assert.ok(duplicate); const peer = await duplicate; if (peer.error) throw peer.error;
      const pair = [ui, peer.value]; assert.ok(pair.every(value => value.status === 200));
      assert.deepEqual(pair.map(value => value.responseBody.idempotent).sort(), [false,true]);
      recovery = concurrentRecovery = pair.find(value => !value.responseBody.idempotent);
      assert.deepEqual(pair.find(value => value.responseBody.idempotent).responseBody, { ...recovery.responseBody, idempotent: true });
      await releaseRecorded('second-recovery', recovery, before);
      assert.deepEqual(current.releases, before.releases);
      assert.equal(current.idempotency.filter(row => row.action === 'recovery-download').length, 2, 'Exactly two authorized logical issuances in the whole exercise');
      const asset = current.assets.find(asset => asset.id === recovery.responseBody.assetId);
      await publicGet('recovery-second-download', recovery.responseBody.downloadUrl, 200, asset);
      const unchangedState = current;
      const replay = await post('recovery-second-exact-replay', recovery.pathname, recovery.body, recovery.key);
      assert.equal(replay.status, 200); assert.deepEqual(replay.responseBody, { ...recovery.responseBody, idempotent: true });
      unchanged(unchangedState, await snapshot('after-second-replay'));
    });
  }
  await check('LIVE-09-fingerprint-and-release-conflicts', async () => {
    const before = current;
    for (const [name, pathname, body] of [['reason', recovery.pathname, { ...recovery.body, reason: recovery.body.reason + ' changed' }],
      ['release', releasePath(high,'recovery-download'), recovery.body]]) {
      const result = await post(`recovery-conflict-${name}`, pathname, body, recovery.key);
      assert.equal(result.status, 409); assert.equal(result.responseBody.errorCode, 'IDEMPOTENCY_CONFLICT');
    }
    unchanged(before, await snapshot('after-release-conflicts'));
  });
  const patch = current.assets.find(a => a.release_id === low && a.kind === 'patch');
  for (const [channel, lang] of [['stable','en'],['beta','zh']]) {
    phase = 'low-window'; await language(lang);
    await check(`LIVE-05-${channel}-retract-low`, () => channelMutation(`retract-${channel}`, channel, 'retract', true, low, `${lang}-real-retract-success`));
    await check(`LIVE-10-${channel}-referenced-disable-and-action-conflict`, async () => {
      const before = current;
      const referenced = await post(`referenced-disable-${channel}`, releasePath(low,'disable'), { ...scope, reason: `P43 ${label} referenced low must reject` }, addKey(randomUUID()));
      assert.equal(referenced.status, 409); assert.equal(referenced.responseBody.errorCode, 'RELEASE_IN_USE');
      const reused = await post(`cross-action-key-${channel}`, releasePath(low,'disable'), recovery.body, recovery.key);
      assert.equal(reused.status, 409); assert.equal(reused.responseBody.errorCode, 'IDEMPOTENCY_CONFLICT');
      unchanged(before, await snapshot(`after-referenced-disable-${channel}`));
    });
    await check(`LIVE-07-${channel}-false-true`, () => channelMutation(`open-latest-${channel}`, channel, 'resume-latest'));
    let selection;
    await check(`LIVE-05-${channel}-version-selection`, async () => {
      selection = await publicGet(`latest-low-client-${channel}`, latestUrl(channel, 20800, patch.base_image_sha256), 200);
      assert.equal(selection.updateAvailable, true); assert.equal(selection.versionCode, 20801); assert.equal(selection.releaseId, low);
      assert.equal(selection.asset.kind, 'patch'); assert.equal(selection.asset.assetId, patch.id);
      for (const code of [20801,30208]) {
        const result = await publicGet(`latest-upgraded-${channel}-${code}`, latestUrl(channel, code, current.releases.find(r => r.id === high).target_image_sha256), 200);
        assert.equal(result.updateAvailable, false); assert.equal(result.errorCode, 'NO_UPDATE'); assert.ok(!result.asset);
      }
      const blocked = await publicGet(`download-stopped-${channel}`, selection.asset.downloadUrl, 503);
      assert.equal(blocked.errorCode, 'CHANNEL_STOPPED');
    });
    await check(`LIVE-07-${channel}-false-false`, async () => {
      await channelMutation(`open-downloads-${channel}`, channel, 'resume-downloads');
      await publicGet(`old-url-open-${channel}`, selection.asset.downloadUrl, 200, patch);
    });
    await check(`LIVE-08-${channel}-resume-noop`, () => channelMutation(`resume-noop-${channel}`, channel, 'resume-downloads'));
    await check(`LIVE-07-${channel}-true-false`, async () => {
      await channelMutation(`stop-latest-${channel}`, channel, 'stop-latest');
      const stopped = await publicGet(`latest-stopped-${channel}`, latestUrl(channel, 20800, patch.base_image_sha256), 200);
      assert.equal(stopped.errorCode, 'CHANNEL_STOPPED'); assert.equal(stopped.updateAvailable, false); assert.ok(!stopped.asset);
      await publicGet(`old-url-latest-stopped-${channel}`, selection.asset.downloadUrl, 200, patch);
    });
    await check(`LIVE-07-${channel}-true-true-old-url-revoked`, async () => {
      await channelMutation(`stop-downloads-${channel}`, channel, 'stop-downloads');
      const blocked = await publicGet(`old-url-blocked-${channel}`, selection.asset.downloadUrl, 503);
      assert.equal(blocked.errorCode, 'CHANNEL_STOPPED');
    });
    await check(`LIVE-08-${channel}-stop-noop`, () => channelMutation(`stop-noop-${channel}`, channel, 'stop-downloads'));
    await check(`LIVE-05-${channel}-publish-high-again`, () => channelMutation(`return-high-${channel}`, channel, 'publish', true, high));
  }
  phase = 'cas';
  for (const [channel, lang] of [['stable','en'],['beta','zh']]) await check(`LIVE-06-${channel}-real-cas-fresh-confirmation`, async () => {
    await language(lang); await refreshUi();
    const other = await context.newPage(); await other.goto(origin, { waitUntil: 'domcontentloaded' });
    await expect(other.locator('#firmwareReleaseList .firmware-release-card')).toHaveCount(2, { timeout: 45000 });
    await other.locator('[data-view-target="firmware"]').click(); await language(lang, other);
    const old = channelRow(channel); const before = current;
    await channelButton(page, channel, 'resume-latest').click(); await fillConfirm(page, `P43 ${label} stale ${channel} intent`);
    await channelButton(other, channel, 'resume-latest').click(); await fillConfirm(other, `P43 ${label} winning ${channel} intent`);
    const winner = await finishUi(`cas-winner-${channel}`, other, `/api/admin/firmware/channels/${channel}/resume-latest`);
    const won = await snapshot(`after-cas-winner-${channel}`); assert.equal(channelRow(channel,won).revision, old.revision + 1);
    assert.equal(won.audit.length, before.audit.length + 1); assert.equal(winner.responseBody.revision, old.revision + 1);
    current = won;
    const conflict = await finishUi(`cas-loser-${channel}`, page, `/api/admin/firmware/channels/${channel}/resume-latest`, 409, `${lang}-real-cas-conflict`);
    assert.equal(conflict.responseBody.errorCode, 'CAS_CONFLICT'); assert.equal(conflict.body.expectedRevision, old.revision);
    unchanged(won, await snapshot(`after-cas-conflict-${channel}`));
    const writes = report.browserWrites;
    await channelButton(page, channel, 'stop-latest').click();
    await expect(page.locator('#confirmMessage')).toContainText(String(old.revision + 1));
    await expect(page.locator('#confirmReason')).toHaveValue(''); assert.equal(report.browserWrites, writes);
    await screenshot(`${lang}-real-fresh-confirmation`); await page.locator('#confirmCancel').click();
    await channelMutation(`cas-restored-${channel}`, channel, 'stop-latest', true);
    await other.close();
  });
  await check('LIVE-09-real-url-expiry-and-old-key', async () => {
    const expiresAt = Math.max(recovery.responseBody.expiresAt, concurrentRecovery.responseBody.expiresAt);
    const delay = Math.max(0, expiresAt * 1000 + 1500 - Date.now()); assert.ok(delay <= 310000);
    emit({ phase: 'REAL_URL_EXPIRY_WAIT', expiresAt, delayMs: delay, databaseClockUnchanged: true });
    if (delay) await new Promise(resolve => setTimeout(resolve, delay));
    const before = current;
    const result = await post('expired-recovery-replay', recovery.pathname, recovery.body, recovery.key);
    assert.equal(result.status, 409); assert.equal(result.responseBody.errorCode, 'IDEMPOTENCY_RESULT_EXPIRED'); assert.ok(!result.responseBody.downloadUrl);
    const expired = await publicGet('expired-recovery-url', recovery.responseBody.downloadUrl, 401);
    assert.equal(expired.errorCode, 'TOKEN_EXPIRED');
    if (earlierRecovery) {
      const originalExpired = await post('earlier-ui-recovery-expired', earlierRecovery.pathname, earlierRecovery.body, earlierRecovery.key);
      assert.equal(originalExpired.status, 409); assert.equal(originalExpired.responseBody.errorCode, 'IDEMPOTENCY_RESULT_EXPIRED');
    }
    unchanged(before, await snapshot('after-expiry'));
  });
  await check('LIVE-11-conditional-low-disable-and-replay', async () => {
    current = await snapshot('pre-disable');
    assert.ok(current.channels.every(c => c.current_release_id === high && c.disable_latest === 1 && c.disable_downloads === 1));
    const lowImage = current.releases.find(r => r.id === low).target_image_sha256;
    assert.ok(!current.assets.some(a => a.kind === 'patch' && a.base_image_sha256 === lowImage));
    assert.ok(current.idempotency.filter(r => r.action === 'recovery-download').every(r => r.original_expires_at <= Math.floor(Date.now()/1000)));
    const backfills = await readD1('low-backfill-dependencies', `SELECT * FROM firmware_backfill_manifests WHERE release_id='${low}'`);
    assert.equal(backfills.rows.length, 0, 'Unresolved external/backfill dependency; do not disable');
    phase = 'final-disable'; const before = current; await refreshUi(); await language('en');
    await releaseButton(page, low, 'disable').click(); await fillConfirm(page, `P43 ${label} final conditional synthetic release disable; comparisons complete and no references`);
    const disabled = await finishUi('final-low-disable', page, releasePath(low,'disable'), 200, 'en-real-final-disable');
    assert.equal(disabled.responseBody.state, 'disabled'); assert.equal(disabled.responseBody.idempotent, false);
    await releaseRecorded('final-disable', disabled, before);
    assert.deepEqual(current.releases.find(r => r.id === high), before.releases.find(r => r.id === high));
    assert.equal(current.releases.find(r => r.id === low).state, 'disabled');
    const state = current;
    const replay = await post('disable-exact-replay', disabled.pathname, disabled.body, disabled.key);
    assert.equal(replay.status, 200); assert.deepEqual(replay.responseBody, { ...disabled.responseBody, idempotent: true });
    const fresh = await post('disable-fresh-key-reject', disabled.pathname, disabled.body, addKey(randomUUID()));
    assert.equal(fresh.status, 410); assert.equal(fresh.responseBody.errorCode, 'RELEASE_DISABLED');
    unchanged(state, await snapshot('after-disable-replays')); report.lowConditionallyDisabled = true;
  });
  await check('LIVE-12-final-state-and-evidence', async () => {
    current = await snapshot('final');
    assert.ok(current.channels.every(c => c.current_release_id === high && c.disable_latest === 1 && c.disable_downloads === 1));
    assert.deepEqual(current.releases.find(r => r.id === high), baseline.releases.find(r => r.id === high));
    assert.deepEqual(current.assets, baseline.assets); assert.equal(current.releases.find(r => r.id === low).state, 'disabled');
    const successful = report.requests.filter(r => r.status === 200 && r.result.idempotent === false);
    assert.equal(current.audit.length - baseline.audit.length, successful.length);
    for (const result of successful) assert.equal(current.audit.filter(a => a.request_id === result.requestId).length, 1);
    for (const lang of ['en','zh']) { await language(lang); await refreshUi(); await screenshot(`${lang}-real-final-state`); }
    report.finalChannels = current.channels; report.businessMutations = successful.length; report.restored = true;
  });
}

async function restoreAfterFailure() {
  if (mode !== 'drill' || !report.requests.some(r => r.status === 200 && !r.result.idempotent)) return;
  current = await snapshot('failure-reconciliation');
  assert.ok(current.channels.every(c => [null,low,high].includes(c.current_release_id)));
  phase = 'restoration';
  for (const channel of ['stable','beta']) {
    if (!channelRow(channel).disable_latest) await channelMutation(`failure-stop-latest-${channel}`, channel, 'stop-latest');
    if (!channelRow(channel).disable_downloads) await channelMutation(`failure-stop-downloads-${channel}`, channel, 'stop-downloads');
    if (channelRow(channel).current_release_id !== high) await channelMutation(`failure-high-${channel}`, channel, 'publish', false, high);
  }
  report.restored = true; report.finalChannels = current.channels;
}
try {
  const playwright = await import(pathToFileURL(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/@playwright/test/index.mjs')));
  expect = playwright.expect;
  context = await playwright.chromium.launchPersistentContext(profile, {
    executablePath: 'C:/Users/SU/AppData/Local/ms-playwright/chromium-1217/chrome-win64/chrome.exe', headless: true,
    viewport: { width: 1440, height: 1080 }, acceptDownloads: false, downloadsPath: privateDir,
    args: ['--disable-breakpad','--disable-crash-reporter','--disable-component-update','--no-default-browser-check',
      ...(directBrowser ? ['--no-proxy-server','--disable-quic'] : [])],
    env: { ...process.env, DEBUG: '', CHROME_LOG_FILE: browserLog }
  });
  report.chromium = context.browser().version();
  const stateSource = afterRecovery ? '.cache/p43/private/live-drill/drill-03/storage-state.json'
    : afterSetup ? '.cache/p43/private/live-drill/drill-01/storage-state.json' : '.cache/p43/private/owner-login/owner-login-05-storage-state.json';
  const authenticatedState = JSON.parse(fs.readFileSync(path.join(root, stateSource), 'utf8'));
  await context.addCookies(authenticatedState.cookies.filter(cookie => [new URL(origin).hostname, 'sulovehuang.cloudflareaccess.com'].includes(cookie.domain.replace(/^\./, ''))));
  report.sessionStateSource = stateSource;
  report.browserTransport = directBrowser ? 'Explicit direct TLS, QUIC disabled; no system or user-browser configuration change' : 'Existing default transport';
  for (const cookie of await context.cookies()) secrets.add(cookie.value);
  await context.route('**/*', async route => {
    const request = route.request();
    if (['GET','HEAD'].includes(request.method())) { await route.continue(); return; }
    try { assert.equal(request.method(), 'POST'); permittedWrite(request.url(), request.postDataJSON()); report.browserWrites++; await route.continue(); }
    catch { report.blockedOutOfScopeWrites++; await route.abort('blockedbyclient'); }
  });
  page = context.pages()[0] || await context.newPage();
  page.on('pageerror', error => report.console.push({ type: 'pageerror', message: scrubText(error.message) }));
  page.on('console', message => { if (['warning','error'].includes(message.type())) report.console.push({ type: message.type(), message: scrubText(message.text()) }); });
  page.on('requestfailed', request => report.console.push({ type: 'requestfailed', method: request.method(),
    origin: new URL(request.url()).origin, pathname: new URL(request.url()).pathname, failure: request.failure()?.errorText }));
  const appCookie = (await context.cookies(`${origin}/api/admin/session`)).find(cookie => cookie.name === 'CF_Authorization');
  const schedulingClaims = appCookie ? JSON.parse(Buffer.from(appCookie.value.split('.')[1], 'base64url').toString('utf8')) : null;
  // Claims here schedule renewal only. The real session API below remains the authentication oracle.
  if (mode === 'drill' && (!schedulingClaims || schedulingClaims.exp - Date.now() / 1000 < 900)) {
    assert.ok((await context.cookies('https://sulovehuang.cloudflareaccess.com')).some(cookie => cookie.name === 'CF_Authorization'));
    await context.clearCookies({ name: 'CF_Authorization', domain: new URL(origin).hostname });
    await page.goto(`${origin}/api/admin/session`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    assert.equal(new URL(page.url()).origin, origin, 'Existing organization SSO did not renew the application session; no OTP is submitted automatically');
    report.sessionRenewal = { existingOrganizationSso: true, localApplicationCookieReplacedOnly: true, interactiveLogin: false,
      observedAt: new Date().toISOString(), roleVerificationFollows: true };
    for (const cookie of await context.cookies()) secrets.add(cookie.value);
  }
  await check('LIVE-02-real-session', async () => {
    const { response, body } = await apiGet('/api/admin/session');
    save('session-original.json', { status: response.status(), headers: response.headers(), body }, true);
    assert.equal(response.status(), 200); assert.equal(body.ok, true); assert.equal(body.role, 'owner');
    assert.equal(sha(body.actor.trim().toLowerCase()), ownerProof.session.authenticatedActorSha256);
    session = body; secrets.add(session.csrfToken); secrets.add(session.actor);
    const cookies = await context.cookies(`${origin}/api/admin/session`);
    assert.ok(cookies.some(c => c.name === 'trace_admin_csrf' && c.value === body.csrfToken && c.secure && c.httpOnly));
    report.owner = { actorSha256: sha(body.actor.trim().toLowerCase()), role: body.role,
      requestId: response.headers()['x-request-id'], csrfMatches: true, issuerAudienceEvidence: 'owner-login-05.json' };
  });
  await check('LIVE-00-current-state', async () => {
    current = baseline = await snapshot('before');
    assert.equal(current.channels.length, 2); assert.equal(current.releases.length, 2); assert.equal(current.assets.length, 6);
    assert.deepEqual(current.channels.map(c => c.name).sort(), ['beta','stable']);
    assert.ok(current.channels.every(c => c.app_id === 'trace' && c.device_model === scope.deviceModel));
    if (afterSetup) assert.ok(current.channels.every(c => c.current_release_id === high && c.revision === 3 && c.disable_latest === 1 && c.disable_downloads === 1));
    else assert.ok(current.channels.every(c => c.current_release_id === null && c.revision === 0 && c.disable_latest === 0 && c.disable_downloads === 0));
    assert.ok(current.releases.every(r => [low,high].includes(r.id) && r.state === 'ready' && r.archived === 0));
    assert.equal(current.releases.find(r => r.id === low).version_code, 20801);
    assert.equal(current.releases.find(r => r.id === high).version_code, 30208);
    assert.ok(current.assets.every(a => a.r2_state === 'available'));
    assert.equal(current.idempotency.length, afterRecovery ? 1 : 0);
  });
  await check('LIVE-01-served-input-ui', async () => {
    const response = await page.goto(origin, { waitUntil: 'domcontentloaded', timeout: 60000 });
    assert.equal(response.status(), 200);
    const html = await response.body(); bytes('served-index.html', html, true);
    report.servedHtml = { sha256: sha(html), sizeBytes: html.length, expectedSha256: '94a3337689719a2cc93eeb5820db15926b60abe701b13e5e560869bc39bf9d8c' };
    assert.equal(sha(html), report.servedHtml.expectedSha256);
    await expect(page.locator('#firmwareReleaseList .firmware-release-card')).toHaveCount(2, { timeout: 45000 });
    await page.locator('[data-view-target="firmware"]').click();
    await expect(page.locator('#firmwareView')).toBeVisible();
    await expect(page.locator('#firmwareView')).not.toContainText('undefined');
    await expect(page.locator('#refreshButton')).toBeEnabled();
  });
  if (mode === 'probe') {
    for (const [lang, channel] of [['en','stable'],['zh','beta']]) await check(`LIVE-03-${lang}-${channel}-cancel`, async () => {
      await language(lang); await releaseButton(page, low, 'select').click();
      await screenshot(`${lang}-real-overview`);
      await channelButton(page, channel, 'retract').click();
      await expect(page.locator('#confirmDetail')).toContainText(lang === 'en' ? 'Upgraded devices will not downgrade' : '\u5df2\u5347\u7ea7\u8bbe\u5907\u4e0d\u4f1a\u964d\u7ea7');
      await expect(page.locator('#confirmDetail')).toContainText('versionCode');
      if (channel === 'stable') await page.locator('#confirmInput').fill('stable');
      await expect(page.locator('#confirmAccept')).toBeDisabled();
      await page.locator('#confirmReason').fill('   '); await expect(page.locator('#confirmAccept')).toBeDisabled();
      await page.locator('#confirmReason').fill(`P43 ${lang} cancel verification, no business request`);
      await expect(page.locator('#confirmAccept')).toBeEnabled(); await screenshot(`${lang}-real-cancel-confirmation`);
      await page.locator('#confirmCancel').click(); await expect(page.locator('#confirmDialog')).toBeHidden();
      assert.equal(report.browserWrites, 0); await screenshot(`${lang}-real-cancelled`);
    });
    await check('LIVE-03-cancel-zero-effect', async () => assert.deepEqual(await snapshot('after-cancel'), baseline));
  } else {
    await exercise();
  }
  report.result = 'PASS';
} catch (error) {
  bytes('failure.txt', String(error.stack || error), true);
  report.result = 'FAIL'; report.failure = { name: error.name, code: error.code, message: scrubText(error.message), detailPrivate: true };
  if (page && !page.isClosed() && page.url() === origin + '/') {
    try { await screenshot('failure-state'); } catch {}
  }
  try { await restoreAfterFailure(); }
  catch (restoreError) { bytes('restoration-failure.txt', String(restoreError.stack || restoreError), true); report.restorationFailure = { name: restoreError.name, detailPrivate: true }; }
  process.exitCode = 1;
} finally {
  if (context) {
    await context.storageState({ path: output('storage-state.json', true) });
    await context.close();
  }
  report.browserClosed = true; report.endedAt = new Date().toISOString();
  report.counts = { passed: report.checks.filter(c => c.result === 'PASS').length, failed: report.checks.filter(c => c.result === 'FAIL').length,
    skipped: 0, warnings: report.console.filter(c => c.type === 'warning').length, errors: report.console.filter(c => ['error','pageerror'].includes(c.type)).length,
    requestFailures: report.console.filter(c => c.type === 'requestfailed').length };
  save('result.json', report); emit(report);
}
