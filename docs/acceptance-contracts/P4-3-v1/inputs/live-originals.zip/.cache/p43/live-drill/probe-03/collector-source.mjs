import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const sourceFile = fileURLToPath(import.meta.url);
const root = path.resolve(path.dirname(sourceFile), '..');
const [mode, label] = process.argv.slice(2);
assert.ok(['probe', 'drill'].includes(mode));
assert.match(label || '', /^(?:probe|drill)-[0-9]+$/);
const origin = 'https://e-track-firmware-p43-admin-test.pages.dev';
const downloadOrigin = 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev';
const scope = { appId: 'trace', deviceModel: 'e-track-at32f435' };
const low = 'fw_e1abd9e066161562fb72322b81ee7c06bf4719df7d6f89e769811a7460373648';
const high = 'fw_12367eee317a0774a7271cf982ee7f933c6b089336645f9e607501105e72bf0c';
const publicDir = path.join(root, '.cache/p43/live-drill', label);
const privateDir = path.join(root, '.cache/p43/private/live-drill', label);
const profile = path.join(root, '.cache/p43/browser-owner');
const browserLog = path.join(privateDir, 'browser.log');
const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'drill-preflight', '.', 'preflight',
  publicDir, privateDir, profile, browserLog], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(guard.status, 0, 'Full output-root/reparse-point preflight failed');
assert.ok(!fs.existsSync(publicDir) && !fs.existsSync(privateDir), 'Never replace a prior observation');
fs.mkdirSync(publicDir, { recursive: true }); fs.mkdirSync(privateDir, { recursive: true });
const sha = value => createHash('sha256').update(value).digest('hex');
const secrets = new Set();
function scrubText(value) {
  let text = String(value);
  for (const secret of secrets) if (secret && secret.length > 8) text = text.split(secret).join('[PRIVATE]');
  return text.replace(/https?:\/\/[^\s"<>]*\?[^\s"<>]*/g, '[URL_QUERY_PRIVATE]')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '[JWT_PRIVATE]');
}
function sanitized(value) {
  if (Array.isArray(value)) return value.map(sanitized);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => {
    if (['actor', 'actor_canonical', 'last_actor'].includes(key) && typeof item === 'string') return [`${key}_sha256`, sha(item.trim().toLowerCase())];
    if (['downloadUrl', 'idempotencyKey', 'csrfToken'].includes(key)) return [`${key}Sha256`, typeof item === 'string' ? sha(item) : null];
    if (['ip', 'user_agent'].includes(key)) return [key, '[PRIVATE_ORIGINAL]'];
    return [key, sanitized(item)];
  }));
  return typeof value === 'string' ? scrubText(value) : value;
}
function output(name, isPrivate = false) {
  assert.match(name, /^[a-z0-9][a-z0-9._-]*$/);
  const base = isPrivate ? privateDir : publicDir;
  const file = path.resolve(base, name);
  assert.equal(path.dirname(file), base);
  assert.equal(fs.realpathSync(base).toLowerCase(), base.toLowerCase());
  assert.ok(!fs.existsSync(file), 'Evidence files are append-only');
  return file;
}
function save(name, value, isPrivate = false) {
  fs.writeFileSync(output(name, isPrivate), JSON.stringify(isPrivate ? value : sanitized(value), null, 2) + '\n', { flag: 'wx' });
}
function bytes(name, value, isPrivate = false) { fs.writeFileSync(output(name, isPrivate), value, { flag: 'wx' }); }
bytes('collector-source.mjs', fs.readFileSync(sourceFile));
const deployed = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/pages-deploy-02-summary.json'), 'utf8')).deployment;
assert.equal(deployed.sourceCommit, '933b790e69e04ee551ad255398e08f12a1b2a107');
assert.equal(deployed.origin, origin); assert.equal(deployed.actualStage.status, 'success');
const ownerProof = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/owner-login-05.json'), 'utf8'));
assert.equal(ownerProof.ownerVerified, true);
const approved = JSON.parse(fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-firmware-setup-20261015/d1-edit-r2/wrangler.json', 'utf8'));
assert.equal(approved.d1_databases[0].database_id, '2617e1e1-956f-42ce-a465-da56d84abf06');
const cloudToken = fs.readFileSync('D:/github/my/E-Track/.cache/p41-dev-20261015/.cache/cf-auth-input/p41-ci-token.txt', 'utf8').trim();
secrets.add(cloudToken); secrets.add(approved.account_id);
const report = { label, mode, startedAt: new Date().toISOString(), origin, deploymentId: deployed.id,
  productSource: deployed.sourceCommit, collectorSha256: sha(fs.readFileSync(sourceFile)), node: process.version,
  nature: 'Real isolated Access/Admin/D1/public Worker observations; synthetic low sample is cloud-only, no device operation',
  mockResponses: 0, allowedScope: scope, checks: [], screenshots: [], requests: [], console: [],
  browserWrites: 0, blockedOutOfScopeWrites: 0, restored: false,
  roleCoverage: { owner: 'REAL', publisher: 'NO_REAL_SESSION', viewer: 'NO_REAL_SESSION' } };
const emit = value => process.stdout.write(JSON.stringify(sanitized(value)) + '\n');
let sequence = 0;
const serial = name => `${String(++sequence).padStart(3, '0')}-${name}`;
let context, page, session, current, baseline;
let phase = 'read-only';
const keys = [];
const sqlRow = (kind, table, columns, where = '') => `'${kind}',json((SELECT json_group_array(json_object(${columns.map(c => `'${c}',${c}`).join(',')})) FROM ${table}${where}))`;
const snapshotSql = 'SELECT json_object(' + [
  sqlRow('channels', 'firmware_channels', ['id','app_id','device_model','name','current_release_id','revision','disable_latest','disable_downloads','maintenance_message','last_action','last_actor','last_actor_type','last_request_id','last_reason','last_before_json','last_after_json','created_at','updated_at']),
  sqlRow('releases', 'firmware_releases', ['id','app_id','device_model','version_code','version_name','release_tag','state','archived','target_image_sha256','hardware_rev','layout_id','min_boot_version','min_protocol_version','min_app_version_code','registration_json','created_at','updated_at']),
  sqlRow('assets', 'firmware_release_assets', ['id','release_id','kind','file_name','r2_key','sha256','size_bytes','r2_state','base_vcode','base_image_sha256']),
  sqlRow('audit', 'audit_logs', ['id','app_id','actor','actor_type','action','target_type','target_id','request_id','reason','ip','user_agent','before_json','after_json','created_at'], " WHERE target_type IN ('firmware_release','firmware_asset','firmware_channel')"),
  sqlRow('idempotency', 'firmware_admin_idempotency', ['actor_canonical','fingerprint','method','canonical_path','action','release_id','state','status_code','request_id','created_epoch_seconds','retained_until','original_expires_at']),
  "'tombstones',json_array(json_object('count',(SELECT count(*) FROM firmware_admin_idempotency_tombstones)))",
  sqlRow('appConfig', 'app_config', ['app_id','disable_all_downloads'])
].join(',') + ') AS snapshot_json';
async function readD1(name, sql = snapshotSql) {
  assert.match(sql, /^SELECT\b/); assert.ok(!sql.includes(';'));
  const id = serial(name);
  const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${approved.account_id}/d1/database/2617e1e1-956f-42ce-a465-da56d84abf06/query`, {
    method: 'POST', headers: { Authorization: `Bearer ${cloudToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ sql }), redirect: 'error', signal: AbortSignal.timeout(30000)
  });
  const body = Buffer.from(await response.arrayBuffer()); assert.ok(body.length < 2 * 1024 * 1024);
  bytes(`${id}-d1-original.json`, body, true);
  const json = JSON.parse(body.toString('utf8'));
  save(`${id}-d1-receipt.json`, { status: response.status, cfRay: response.headers.get('cf-ray'), observedAt: new Date().toISOString(),
    query: sql, bodySha256: sha(body), bodyBytes: body.length, success: json.success });
  assert.equal(response.status, 200); assert.equal(json.success, true);
  assert.ok(json.result.every(r => r.success && r.meta.rows_written === 0 && !r.meta.changed_db));
  return { id, rows: json.result[0].results };
}
async function snapshot(name) {
  const { id, rows } = await readD1(name);
  assert.equal(rows.length, 1);
  const result = JSON.parse(rows[0].snapshot_json);
  for (const list of Object.values(result)) list.sort((a,b) => String(a.id ?? a.request_id ?? a.app_id ?? '').localeCompare(String(b.id ?? b.request_id ?? b.app_id ?? '')));
  assert.ok(result.idempotency.every(row => row.state === 'completed'), 'Committed pending row');
  for (const row of result.audit) {
    const data = `${row.before_json || ''}${row.after_json || ''}`;
    assert.ok(!/"(?:downloadUrl|signature|token|secret|idempotency_key)"|[?&]signature=/.test(data));
    for (const key of keys) assert.ok(!JSON.stringify(row).includes(key));
  }
  save(`${id}-snapshot.json`, result);
  return result;
}
async function check(id, action) {
  const startedAt = new Date().toISOString();
  try { const result = await action(); report.checks.push({ id, result: 'PASS', startedAt, endedAt: new Date().toISOString() }); emit({ check: id, result: 'PASS' }); return result; }
  catch (error) { report.checks.push({ id, result: 'FAIL', startedAt, error: { name: error.name, message: scrubText(error.message) } }); throw error; }
}
function permittedWrite(url, body) {
  assert.equal(new URL(url).origin, origin);
  assert.equal(body.appId, scope.appId); assert.equal(body.deviceModel, scope.deviceModel);
  const pathname = new URL(url).pathname;
  if (/^\/api\/admin\/firmware\/channels\/(stable|beta)\/(publish|retract|stop-latest|resume-latest|stop-downloads|resume-downloads)$/.test(pathname)) {
    if (body.releaseId) assert.ok([low, high].includes(body.releaseId));
  } else {
    const match = /^\/api\/admin\/firmware\/releases\/([^/]+)\/(disable|recovery-download)$/.exec(pathname);
    assert.ok(match && [low, high].includes(match[1]));
    if (match[2] === 'disable') {
      assert.equal(match[1], low, 'High release may never be disabled');
      assert.ok(phase === 'final-disable' || (phase === 'low-window' && current.channels.some(c => c.current_release_id === low)), 'Conditional disable boundary');
    }
  }
  assert.notEqual(mode, 'probe', 'Read-only probe cannot mutate');
}
async function apiGet(pathname) {
  const response = await context.request.get(origin + pathname, { headers: { Accept: 'application/json' }, maxRedirects: 0, timeout: 30000 });
  const body = await response.json();
  return { response, body };
}
async function screenshot(name, targetPage = page) {
  const file = output(`${name}.png`);
  await targetPage.screenshot({ path: file, fullPage: true, mask: [targetPage.locator('#sideSession'), targetPage.locator('#topSession')] });
  report.screenshots.push({ file: path.basename(file), sha256: sha(fs.readFileSync(file)), origin: new URL(targetPage.url()).origin,
    nature: 'REAL isolated P4-3 Access session; owner email visually masked; no credentials or signed URL displayed' });
}
async function language(lang, targetPage = page) {
  const currentLang = await targetPage.locator('html').getAttribute('lang');
  if (!currentLang.startsWith(lang)) await targetPage.locator('#languageToggle').click();
  assert.ok((await targetPage.locator('html').getAttribute('lang')).startsWith(lang));
}
const channelButton = (targetPage, channel, action) => targetPage.locator(`.firmware-channel-card[data-channel="${channel}"] [data-firmware-action="${action}"]`);
const releaseButton = (targetPage, releaseId, action) => targetPage.locator(`.firmware-release-card[data-release-id="${releaseId}"] [data-firmware-action="${action}"]`);
let expect;
try {
  const playwright = await import(pathToFileURL(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/@playwright/test/index.mjs')));
  expect = playwright.expect;
  context = await playwright.chromium.launchPersistentContext(profile, {
    executablePath: 'C:/Users/SU/AppData/Local/ms-playwright/chromium-1217/chrome-win64/chrome.exe', headless: true,
    viewport: { width: 1440, height: 1080 }, acceptDownloads: false, downloadsPath: privateDir,
    args: ['--disable-breakpad','--disable-crash-reporter','--disable-component-update','--no-default-browser-check'],
    env: { ...process.env, DEBUG: '', CHROME_LOG_FILE: browserLog }
  });
  report.chromium = context.browser().version();
  const authenticatedState = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/private/owner-login/owner-login-05-storage-state.json'), 'utf8'));
  await context.addCookies(authenticatedState.cookies.filter(cookie => [new URL(origin).hostname, 'sulovehuang.cloudflareaccess.com'].includes(cookie.domain.replace(/^\./, ''))));
  for (const cookie of await context.cookies()) secrets.add(cookie.value);
  await context.route('**/*', async route => {
    const request = route.request();
    if (['GET','HEAD'].includes(request.method())) { await route.continue(); return; }
    try { assert.equal(request.method(), 'POST'); permittedWrite(request.url(), request.postDataJSON()); report.browserWrites++; await route.continue(); }
    catch { report.blockedOutOfScopeWrites++; await route.abort('blockedbyclient'); }
  });
  page = context.pages()[0] || await context.newPage();
  page.on('pageerror', error => report.console.push({ type: 'pageerror', message: scrubText(error.message) }));
  page.on('console', message => { if (['warning','error'].includes(message.type())) report.console.push({ type: message.type(), message: scrubText(message.text()) }); });
  await check('LIVE-02-real-session', async () => {
    const { response, body } = await apiGet('/api/admin/session');
    save('session-original.json', { status: response.status(), headers: response.headers(), body }, true);
    assert.equal(response.status(), 200); assert.equal(body.ok, true); assert.equal(body.role, 'owner');
    assert.equal(sha(body.actor.trim().toLowerCase()), ownerProof.session.authenticatedActorSha256);
    session = body; secrets.add(session.csrfToken); secrets.add(session.actor);
    const cookies = await context.cookies(`${origin}/api/admin/session`);
    assert.ok(cookies.some(c => c.name === 'trace_admin_csrf' && c.value === body.csrfToken && c.secure && c.httpOnly));
    report.owner = { actorSha256: sha(body.actor.trim().toLowerCase()), role: body.role,
      requestId: response.headers()['x-request-id'], csrfMatches: true, issuerAudienceEvidence: 'owner-login-05.json' };
  });
  await check('LIVE-00-current-state', async () => {
    current = baseline = await snapshot('before');
    assert.equal(current.channels.length, 2); assert.equal(current.releases.length, 2); assert.equal(current.assets.length, 6);
    assert.deepEqual(current.channels.map(c => c.name).sort(), ['beta','stable']);
    assert.ok(current.channels.every(c => c.app_id === 'trace' && c.device_model === scope.deviceModel && c.current_release_id === null
      && c.revision === 0 && c.disable_latest === 0 && c.disable_downloads === 0));
    assert.ok(current.releases.every(r => [low,high].includes(r.id) && r.state === 'ready' && r.archived === 0));
    assert.equal(current.releases.find(r => r.id === low).version_code, 20801);
    assert.equal(current.releases.find(r => r.id === high).version_code, 30208);
    assert.ok(current.assets.every(a => a.r2_state === 'available'));
    assert.equal(current.idempotency.length, 0);
  });
  await check('LIVE-01-served-input-ui', async () => {
    const response = await page.goto(origin, { waitUntil: 'domcontentloaded', timeout: 60000 });
    assert.equal(response.status(), 200);
    const html = await response.body(); bytes('served-index.html', html, true);
    report.servedHtml = { sha256: sha(html), sizeBytes: html.length, expectedSha256: '94a3337689719a2cc93eeb5820db15926b60abe701b13e5e560869bc39bf9d8c' };
    assert.equal(sha(html), report.servedHtml.expectedSha256);
    await expect(page.locator('#firmwareReleaseList .firmware-release-card')).toHaveCount(2, { timeout: 45000 });
    await page.locator('[data-view-target="firmware"]').click();
    await expect(page.locator('#firmwareView')).toBeVisible();
    await expect(page.locator('#firmwareView')).not.toContainText('undefined');
    await expect(page.locator('#refreshButton')).toBeEnabled();
  });
  if (mode === 'probe') {
    for (const [lang, channel] of [['en','stable'],['zh','beta']]) await check(`LIVE-03-${lang}-${channel}-cancel`, async () => {
      await language(lang); await releaseButton(page, low, 'select').click();
      await screenshot(`${lang}-real-overview`);
      await channelButton(page, channel, 'retract').click();
      await expect(page.locator('#confirmDetail')).toContainText(lang === 'en' ? 'Upgraded devices will not downgrade' : '\u5df2\u5347\u7ea7\u8bbe\u5907\u4e0d\u4f1a\u964d\u7ea7');
      await expect(page.locator('#confirmDetail')).toContainText('versionCode');
      if (channel === 'stable') await page.locator('#confirmInput').fill('stable');
      await expect(page.locator('#confirmAccept')).toBeDisabled();
      await page.locator('#confirmReason').fill('   '); await expect(page.locator('#confirmAccept')).toBeDisabled();
      await page.locator('#confirmReason').fill(`P43 ${lang} cancel verification, no business request`);
      await expect(page.locator('#confirmAccept')).toBeEnabled(); await screenshot(`${lang}-real-cancel-confirmation`);
      await page.locator('#confirmCancel').click(); await expect(page.locator('#confirmDialog')).toBeHidden();
      assert.equal(report.browserWrites, 0); await screenshot(`${lang}-real-cancelled`);
    });
    await check('LIVE-03-cancel-zero-effect', async () => assert.deepEqual(await snapshot('after-cancel'), baseline));
  } else {
    throw new Error('Business matrix not installed; do not improvise mutations');
  }
  report.result = 'PASS';
} catch (error) {
  bytes('failure.txt', String(error.stack || error), true);
  report.result = 'FAIL'; report.failure = { name: error.name, code: error.code, message: scrubText(error.message), detailPrivate: true };
  process.exitCode = 1;
} finally {
  if (context) {
    await context.storageState({ path: output('storage-state.json', true) });
    await context.close();
  }
  report.browserClosed = true; report.endedAt = new Date().toISOString();
  report.counts = { passed: report.checks.filter(c => c.result === 'PASS').length, failed: report.checks.filter(c => c.result === 'FAIL').length,
    skipped: 0, warnings: report.console.filter(c => c.type === 'warning').length, errors: report.console.filter(c => ['error','pageerror'].includes(c.type)).length };
  save('result.json', report); emit(report);
}
