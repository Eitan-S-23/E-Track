import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const label = process.argv[2];
assert.match(label || '', /^access-connect-[0-9]+$/);
const base = path.join(root, '.cache/p43/private/access-connect');
const home = path.join(base, 'home');
const tokenDir = path.join(home, '.cloudflared');
const emptyPath = path.join(base, 'no-browser-launch');
const reportPath = path.join(root, '.cache/p43/live', `${label}.json`);
const logPath = path.join(base, `${label}-cli.log`);
const requestPath = path.join(base, `${label}-request.json`);
const failurePath = path.join(base, `${label}-failure.txt`);
const executable = 'D:/github/my/E-Track/.cache/worktrees/p3-4-link-stats/.cache/p3-4-single-ota-20260921/bin/cloudflared.exe';
const app = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/private/pages/access-inspect-ci-01-legacy-access-app.json'), 'utf8')).result;
assert.equal(app.domain, 'trace-update-admin-staging.pages.dev');
assert.equal(app.id, '0d826613-3097-41ea-ba20-a8174d6822dd');
const origin = `https://${app.domain}`;
const appToken = path.join(tokenDir, `${app.domain}-${app.aud}-token`);
const orgToken = path.join(tokenDir, 'sulovehuang.cloudflareaccess.com-org-token');
const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'access-connect-guard', '.', 'preflight',
  base, home, tokenDir, emptyPath, reportPath, logPath, requestPath, failurePath, appToken, orgToken], { cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(guard.status, 0);
for (const file of [reportPath, logPath, requestPath, failurePath]) assert.ok(!fs.existsSync(file), 'Do not overwrite a prior session observation');
for (const dir of [base, home, tokenDir, emptyPath]) fs.mkdirSync(dir, { recursive: true });
assert.equal(fs.readdirSync(emptyPath).length, 0);
const report = { label, startedAt: new Date().toISOString(),
  nature: 'Official cloudflared Access transfer from the user-selected existing Edge; not platform OAuth',
  origin, issuer: 'https://sulovehuang.cloudflareaccess.com',
  binary: { path: executable, sha256: createHash('sha256').update(fs.readFileSync(executable)).digest('hex'), version: '2026.9.1' },
  localEntry: 'http://127.0.0.1:8975/', browserLaunchDisabled: true,
  outsideProfileReadOrCopy: false, automaticOtpRequest: false, businessMutations: 0 };
const log = fs.createWriteStream(logPath, { flags: 'wx' });
const emit = value => process.stdout.write(JSON.stringify(value) + '\n');
let server, child, childClosed, response, timer, childTimer;
function reminder() {
  const session = process.env.CC_SESSION_KEY || '';
  const requester = /^(?:feishu|lark):[^:]+:(ou_[a-z0-9]+)$/.exec(session)?.[1];
  if (!requester || !process.env.CC_PROJECT || !process.env.CC_DATA_DIR) return { delivered: false, reason: 'No verified current requester route' };
  const body = `<at user_id="${requester}">requester</at> P4-3: \u5df2\u67e5\u5230\u4f60\u5728 Edge \u6253\u5f00\u7684 Admin \u4f1a\u8bdd\u9875\u3002\u4e4b\u524d\u89c2\u5bdf\u5668\u53ea\u76ef\u7740\u53e6\u4e00\u4e2a\u6d4f\u89c8\u5668\uff0c\u662f\u6211\u7684\u63a5\u5165\u95ee\u9898\u3002\u8bf7\u5728\u521a\u624d\u6536\u9a8c\u8bc1\u7801\u7684\u540c\u4e00\u4e2a Edge \u4e2d\u6253\u5f00 http://127.0.0.1:8975/ \u5e76\u70b9\u51fb\u63a5\u5165\uff0c\u5982\u51fa\u73b0 Cloudflare Access \u7684\u4f1a\u8bdd\u63a5\u5165\u786e\u8ba4\u5219\u70b9\u51fb\u786e\u8ba4\u3002\u6b64\u6b21\u4f7f\u7528\u5b98\u65b9 cloudflared \u590d\u7528\u5df2\u6709 Access \u767b\u5f55\uff0c\u4e0d\u662f CF \u5e73\u53f0\u91cd\u65b0\u6388\u6743\uff0c\u4e0d\u6362\u8d26\u53f7\uff0c\u4e0d\u9700\u53d1\u9001\u4efb\u4f55 cookie/JWT/\u9a8c\u8bc1\u7801\u3002\u6211\u4e0d\u4f1a\u81ea\u52a8\u91cd\u53d1\u9a8c\u8bc1\u7801\u3002\u5b8c\u6210\u540e\u65e0\u9700\u804a\u5929\u56de\u590d\uff0c\u6211\u4f1a\u76f4\u63a5\u6838\u9a8c owner \u5e76\u7ee7\u7eed\u3002\u5165\u53e3\u4fdd\u7559 15 \u5206\u949f\u3002`;
  const sent = spawnSync('D:/github/my/cc-connect-thread-guard/build/cc-connect.exe', ['send', '--project', process.env.CC_PROJECT, '--session', session, '--stdin'],
    { cwd: root, env: process.env, windowsHide: true, encoding: 'utf8', input: body, timeout: 20000 });
  const receipt = `${sent.stdout || ''}${sent.stderr || ''}`;
  return { delivered: sent.status === 0 && receipt.includes('Message sent successfully.'), exitCode: sent.status,
    receipt: receipt.split(session).join('[SESSION]').split(requester).join('[REQUESTER]') };
}
try {
  await new Promise((resolve, reject) => {
    let started = false;
    server = http.createServer((req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('Referrer-Policy', 'no-referrer');
      res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
      if (req.headers.host !== '127.0.0.1:8975' || req.method !== 'GET') { res.writeHead(403).end('Forbidden'); return; }
      if (req.url === '/health') { res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ entryReady: true, kind: 'P4-3 existing Edge Access session transfer', authStarted: started })); return; }
      const edge = / Edg\/([0-9.]+)/.exec(String(req.headers['user-agent'] || ''))?.[1];
      if (!edge) { res.writeHead(403).end('Use the same already-open Microsoft Edge. No login was started.'); return; }
      if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }).end('<!doctype html><meta charset="utf-8"><title>P4-3 Access \u4f1a\u8bdd\u63a5\u5165</title><h1>\u590d\u7528\u521a\u624d\u7684 Edge Access \u767b\u5f55</h1><p>\u901a\u8fc7 Cloudflare \u5b98\u65b9 cloudflared \u5c06\u6b64\u5e94\u7528\u4f1a\u8bdd\u4fdd\u5b58\u5230 P4-3 \u5de5\u4f5c\u6811\u3002\u4e0d\u662f\u5e73\u53f0\u6388\u6743\uff0c\u4e0d\u589e\u52a0\u6743\u9650\uff0c\u4e0d\u64cd\u4f5c\u65e7 Admin \u4e1a\u52a1\u3002</p><p><a href="/start">\u63a5\u5165\u5df2\u6709 Access \u4f1a\u8bdd</a></p><p>\u4e0d\u8981\u628a cookie\u3001JWT \u6216\u9a8c\u8bc1\u7801\u53d1\u5230\u804a\u5929\u3002</p>');
      } else if (req.url === '/start' && !started && req.headers['sec-fetch-mode'] === 'navigate') {
        started = true; clearTimeout(timer); response = res;
        report.entryBrowser = { family: 'Microsoft Edge', version: edge, userOpened: true, userAgentIsNotAuthorization: true };
        resolve();
      } else res.writeHead(409).end('No additional session transfer started.');
    });
    server.once('error', reject);
    server.listen(8975, '127.0.0.1', () => {
      report.deadline = new Date(Date.now() + 900000).toISOString();
      report.reminder = reminder();
      emit({ label, phase: 'EXISTING_EDGE_ACCESS_ENTRY_READY', url: report.localEntry, deadline: report.deadline, reminderDelivered: report.reminder.delivered });
    });
    timer = setTimeout(() => reject(new Error('Existing Edge entry not opened within the declared bound')), 900000);
  });
  // Cloudflared's Windows browser launcher resolves "cmd" through PATH. Leave it absent rather than launch a different browser.
  const env = { ...process.env, HOME: home, USERPROFILE: home, HOMEDRIVE: path.parse(home).root.slice(0, 2),
    HOMEPATH: home.slice(2), PATH: emptyPath, PATHEXT: '.EXE', NoDefaultCurrentDirectoryInExePath: '1' };
  child = spawn(executable, ['access', 'login', '--quiet', origin], { cwd: base, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let captured = '';
  for (const stream of [child.stdout, child.stderr]) stream.on('data', bytes => { log.write(bytes); captured += bytes.toString('utf8'); });
  childClosed = new Promise(resolve => { child.once('error', error => resolve({ exitCode: null, error: error.name })); child.once('close', (exitCode, signal) => resolve({ exitCode, signal })); });
  childTimer = setTimeout(() => child.kill(), 660000);
  let url;
  for (let i = 0; i < 900 && child.exitCode === null; i++) {
    const match = captured.match(/https:\/\/[^\s]+\/cdn-cgi\/access\/cli\?[^\s]+/);
    if (match) { url = new URL(match[0]); break; }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  if (url) {
    assert.equal(url.origin, origin); assert.equal(url.pathname, '/cdn-cgi/access/cli');
    assert.equal(url.searchParams.get('aud'), app.aud);
    assert.equal(url.searchParams.get('send_org_token'), 'true');
    fs.writeFileSync(requestPath, JSON.stringify({ url: url.toString() }) + '\n', { flag: 'wx' });
    response.writeHead(302, { Location: url.toString() }).end();
    emit({ label, phase: 'OFFICIAL_ACCESS_TRANSFER_IN_EXISTING_EDGE', origin, queryOmitted: true });
  } else {
    assert.ok(fs.existsSync(appToken), 'Official Access transfer URL or cached token not available');
    response.writeHead(200).end('An existing official Access token is being verified.');
  }
  report.cli = await childClosed;
  assert.equal(report.cli.exitCode, 0, 'Official Access transfer did not complete');
  assert.ok(fs.existsSync(appToken) && fs.readFileSync(appToken, 'utf8').trim().split('.').length === 3);
  assert.ok(fs.existsSync(orgToken) && fs.readFileSync(orgToken, 'utf8').trim().split('.').length === 3);
  report.officialAccessTransferComplete = true;
  report.applicationTokenSaved = true;
  report.organizationTokenSaved = true;
  report.ownerRoleStillRequiresLiveSessionEndpoint = true;
} catch (error) {
  fs.writeFileSync(failurePath, String(error.stack || error), { flag: 'wx' });
  report.failure = { name: error.name, code: error.code, detailPrivate: true };
  process.exitCode = 1;
} finally {
  clearTimeout(timer); clearTimeout(childTimer);
  if (child && child.exitCode === null && child.signalCode === null) child.kill();
  if (childClosed && !report.cli) report.cli = await childClosed;
  if (response && !response.writableEnded) response.writeHead(503).end('The session transfer did not complete. No business operation was performed.');
  if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  log.end(); report.endedAt = new Date().toISOString(); report.entryClosed = true;
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' }); emit(report);
}
