import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const label = process.argv[2];
assert.match(label || '', /^owner-login-[0-9]+$/);
const handoffWindow = process.argv[3] === '--handoff-window';
const noReminder = process.argv[3] === '--no-reminder' || handoffWindow;
const forP43 = process.argv[3] === '--p43-from-existing-edge';
const fromExistingEdge = process.argv[3] === '--from-existing-edge' || forP43;
const inspectOnly = process.argv[3] === '--inspect-only' || fromExistingEdge;
assert.ok(process.argv[3] === undefined || noReminder || inspectOnly);
const legacyOrigin = forP43 ? 'https://e-track-firmware-p43-admin-test.pages.dev' : 'https://trace-update-admin-staging.pages.dev';
const issuer = 'https://sulovehuang.cloudflareaccess.com';
const profile = path.join(root, '.cache/p43/browser-owner');
const privateDir = path.join(root, '.cache/p43/private/owner-login');
const reportPath = path.join(root, '.cache/p43/live', `${label}.json`);
const statePath = path.join(privateDir, `${label}-storage-state.json`);
const sessionPath = path.join(privateDir, `${label}-session.json`);
const failurePath = path.join(privateDir, `${label}-failure.txt`);
const browserLog = path.join(privateDir, `${label}-browser.log`);
const downloads = path.join(privateDir, `${label}-downloads`);
const guard = spawnSync(process.execPath, [path.join(root, '.cache/p43-run.cjs'), 'owner-preflight', '.', 'preflight',
  profile, privateDir, reportPath, statePath, sessionPath, failurePath, browserLog, downloads],
{ cwd: root, windowsHide: true, encoding: 'utf8' });
assert.equal(guard.status, 0, 'Owner login path preflight failed');
for (const file of [reportPath, statePath, sessionPath, failurePath, browserLog]) assert.ok(!fs.existsSync(file));
fs.mkdirSync(privateDir, { recursive: true });
const sha = value => createHash('sha256').update(value).digest('hex');
const source = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/private/pages/access-inspect-ci-01-legacy-access-policies.json'), 'utf8'));
assert.equal(source.result.length, 1);
const allowed = source.result[0].include.map(rule => rule.email.email.trim().toLowerCase());
const report = { label, startedAt: new Date().toISOString(), nature: forP43 ? 'Real P4-3 isolated-origin Access session verification' : 'Real Cloudflare Access login and read-only existing owner-role reconciliation',
  account: 'Original project account; no new Cloudflare platform login', issuer, profile,
  sessionEndpoint: `${legacyOrigin}/api/admin/session`, legacyMutations: 0, p43BusinessMutations: 0 };
const emit = value => process.stdout.write(JSON.stringify(value) + '\n');
function notifyRequester() {
  const session = process.env.CC_SESSION_KEY || '';
  const match = /^(?:feishu|lark):[^:]+:(ou_[a-z0-9]+)$/.exec(session);
  if (!match || !process.env.CC_PROJECT || !process.env.CC_DATA_DIR) return { delivered: false, reason: 'No verified current-requester notification route' };
  const body = `<at user_id="${match[1]}">requester</at> P4-3 \u5df2\u53d6\u5f97\u6b63\u786e CI token\uff0cAccess \u4fdd\u62a4\u5df2\u914d\u7f6e\u3002\u73b0\u5728\u9700\u8981\u4e00\u6b21\u771f\u5b9e owner \u9a8c\u8bc1\u7801\u767b\u5f55\uff0c\u4e0d\u662f Cloudflare \u5e73\u53f0\u91cd\u65b0\u6388\u6743\u3002\u8bf7\u5728\u6211\u6253\u5f00\u7684\u5de5\u4f5c\u6811\u4e13\u7528\u6d4f\u89c8\u5668\u7a97\u53e3\u4f7f\u7528\u539f Admin owner \u90ae\u7bb1\u5b8c\u6210 Access \u9a8c\u8bc1\u7801\u767b\u5f55\u3002\u5165\u53e3\u4e3a https://trace-update-admin-staging.pages.dev/api/admin/session\uff0c\u4ec5\u53ea\u8bfb\u6838\u5bf9\u65e2\u6709 owner \u89d2\u8272\uff0c\u4e0d\u64cd\u4f5c\u65e7\u4e1a\u52a1\u3002\u8be5\u4f1a\u8bdd\u7528\u4e8e\u65b0 P4-3 \u9694\u79bb\u7ad9\u70b9\u540e\u7eed\u6f14\u7ec3\u3002\u4e0d\u9700\u53d1\u9001 cookie/JWT/\u9a8c\u8bc1\u7801\uff0c\u5b8c\u6210\u540e\u65e0\u9700\u804a\u5929\u56de\u590d\uff0c\u6211\u4f1a\u81ea\u52a8\u8bfb\u53d6\u7ed3\u679c\u7ee7\u7eed\u3002\u5f53\u524d\u7a97\u53e3\u7b49\u5f85 10 \u5206\u949f\u3002`;
  const result = spawnSync('D:/github/my/cc-connect-thread-guard/build/cc-connect.exe',
    ['send', '--project', process.env.CC_PROJECT, '--session', session, '--stdin'],
    { cwd: root, env: process.env, windowsHide: true, encoding: 'utf8', input: body, timeout: 20000 });
  const receipt = `${result.stdout || ''}${result.stderr || ''}`;
  return { delivered: result.status === 0 && receipt.includes('Message sent successfully.'), exitCode: result.status,
    receipt: receipt.split(session).join('[SESSION]').split(match[1]).join('[REQUESTER]') };
}
let context;
let observed;
let closing = false;
let contextClosed = false;
try {
  const { chromium } = await import(pathToFileURL(path.join(root, 'app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/playwright/index.mjs')));
  context = await chromium.launchPersistentContext(profile, {
    executablePath: 'C:/Users/SU/AppData/Local/ms-playwright/chromium-1217/chrome-win64/chrome.exe', headless: inspectOnly,
    args: ['--disable-breakpad', '--disable-crash-reporter', '--disable-component-update', '--no-default-browser-check'],
    acceptDownloads: false, downloadsPath: downloads, timeout: 30000,
    env: { ...process.env, DEBUG: '', CHROME_LOG_FILE: browserLog }
  });
  report.browserVersion = context.browser()?.version();
  context.on('close', () => { contextClosed = true; });
  if (fromExistingEdge) {
    const connection = JSON.parse(fs.readFileSync(path.join(root, forP43 ? '.cache/p43/live/access-connect-02.json' : '.cache/p43/live/access-connect-01-reconciled.json'), 'utf8'));
    assert.equal(connection.officialAccessTransferComplete, true);
    assert.equal(connection.entryBrowser.family, 'Microsoft Edge');
    const app = JSON.parse(fs.readFileSync(path.join(root, forP43 ? '.cache/p43/private/pages/access-policy-ci-01-isolated-access-app.json' : '.cache/p43/private/pages/access-inspect-ci-01-legacy-access-app.json'), 'utf8')).result;
    assert.equal(app.domain, new URL(legacyOrigin).hostname);
    const tokenDir = path.join(root, '.cache/p43/private/access-connect/home/.cloudflared');
    const appToken = fs.readFileSync(path.join(tokenDir, `${app.domain}-${app.aud}-token`), 'utf8').trim();
    assert.equal(appToken.split('.').length, 3);
    const cookies = [{ name: 'CF_Authorization', value: appToken, domain: app.domain, path: '/', secure: true, httpOnly: true, sameSite: 'Lax' }];
    if (connection.transferableOrganizationToken) {
      const orgToken = fs.readFileSync(path.join(tokenDir, `${new URL(issuer).hostname}-org-token`), 'utf8').trim();
      cookies.push({ name: 'CF_Authorization', value: orgToken, domain: new URL(issuer).hostname, path: '/', secure: true, httpOnly: true, sameSite: 'Lax' });
    }
    await context.addCookies(cookies);
    report.organizationSsoImported = connection.transferableOrganizationToken;
    report.sessionSource = 'Official cloudflared transfer in the existing user-selected Edge; no cookie database export or fabricated identity';
  }
  await context.route(`${legacyOrigin}/api/admin/**`, async route => {
    if (route.request().method() !== 'GET') { report.blockedLegacyMutationAttempts = (report.blockedLegacyMutationAttempts || 0) + 1; await route.abort('blockedbyclient'); }
    else await route.continue();
  });
  const page = context.pages()[0] || await context.newPage();
  context.on('response', async response => {
    if (closing || observed || response.url() !== `${legacyOrigin}/api/admin/session` || response.status() !== 200) return;
    try {
      const body = await response.json();
      if (!body.ok || typeof body.actor !== 'string' || !['owner', 'publisher', 'viewer'].includes(body.role)) return;
      const actor = body.actor.trim().toLowerCase();
      assert.ok(allowed.includes(actor), 'Authenticated actor is outside the existing explicit allowlist');
      observed = { body, actor, role: body.role, requestId: response.headers()['x-request-id'], cfRay: response.headers()['cf-ray'],
        status: response.status(), observedAt: new Date().toISOString() };
    } catch (error) { report.sessionReadError = { name: error.name }; }
  });
  if (inspectOnly) {
    const response = await context.request.get(`${legacyOrigin}/api/admin/session`, { maxRedirects: 0, failOnStatusCode: false, timeout: 30000 });
    let body;
    try { body = await response.json(); } catch {}
    report.reuseInspection = { httpStatus: response.status(), jsonFields: body ? Object.keys(body) : [],
      errorCode: body?.errorCode, role: body?.role, tokenValuesOmitted: true,
      cookieNames: (await context.cookies(`${legacyOrigin}/api/admin/session`)).map(cookie => cookie.name) };
    if (response.status() === 200 && body?.ok && typeof body.actor === 'string' && ['owner', 'publisher', 'viewer'].includes(body.role)) {
      const actor = body.actor.trim().toLowerCase();
      assert.ok(allowed.includes(actor));
      observed = { body, actor, role: body.role, requestId: response.headers()['x-request-id'], cfRay: response.headers()['cf-ray'],
        status: response.status(), observedAt: new Date().toISOString() };
    }
    assert.ok(observed, 'No reusable authenticated existing Admin session in the owned profile');
  } else {
  await page.goto(`${legacyOrigin}/api/admin/session`, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.bringToFront();
  if (!observed) {
    const destination = new URL(page.url());
    assert.ok([legacyOrigin, issuer].includes(destination.origin), 'Unexpected authentication destination');
    report.loginPage = { origin: destination.origin, path: destination.pathname, queryOmitted: true };
    report.reminder = noReminder ? { delivered: false, reason: 'Existing action reminder is not repeated' } : notifyRequester();
    emit({ label, phase: 'REAL_ACCESS_OWNER_LOGIN_REQUIRED', sessionEndpoint: report.sessionEndpoint,
      browserProfile: profile, noOldBusinessWrites: true, reminderDelivered: report.reminder.delivered });
  }
  const deadline = Date.now() + (handoffWindow ? 1800000 : 600000);
  report.loginDeadline = new Date(deadline).toISOString();
  if (handoffWindow) emit({ label, phase: 'BOUNDED_OWNER_WINDOW_READY', deadline: report.loginDeadline,
    sessionEndpoint: report.sessionEndpoint, scope: 'Read-only role verification for P4-3; no platform authorization or business write' });
  while (!observed && Date.now() < deadline && !contextClosed) await new Promise(resolve => setTimeout(resolve, 1000));
  report.observationWindow = { deadline: new Date(deadline).toISOString(), contextClosed, initialPageClosed: page.isClosed(),
    openPages: contextClosed ? 0 : context.pages().length };
  }
  assert.ok(observed, 'No authenticated Access session observed within the owner-login window');
  fs.writeFileSync(sessionPath, JSON.stringify(observed, null, 2) + '\n', { flag: 'wx' });
  const cookies = await context.cookies(`${legacyOrigin}/api/admin/session`);
  assert.ok(cookies.some(cookie => cookie.name === 'CF_Authorization' && cookie.secure), 'Actual Access cookie not found');
  const csrfCookie = cookies.find(cookie => cookie.name === 'trace_admin_csrf' && cookie.value === observed.body.csrfToken);
  await context.storageState({ path: statePath });
  report.session = { authenticatedActorSha256: sha(observed.actor), role: observed.role, requestId: observed.requestId,
    cfRay: observed.cfRay, observedAt: observed.observedAt, accessCookiePresent: true,
    csrfCookieMatches: !!csrfCookie, csrfCookieSecure: csrfCookie?.secure, csrfCookieHttpOnly: csrfCookie?.httpOnly,
    roleSource: forP43 ? 'Actual deployed P4-3 origin session endpoint, verified against the established owner' : 'Existing live Admin session endpoint, not inferred from Cloudflare/GitHub identity or the Access allowlist' };
  if (forP43) {
    const prior = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/live/owner-login-04.json'), 'utf8'));
    assert.equal(report.session.authenticatedActorSha256, prior.session.authenticatedActorSha256);
    const claims = JSON.parse(Buffer.from(cookies.find(cookie => cookie.name === 'CF_Authorization').value.split('.')[1], 'base64url').toString('utf8'));
    const app = JSON.parse(fs.readFileSync(path.join(root, '.cache/p43/private/pages/access-policy-ci-01-isolated-access-app.json'), 'utf8')).result;
    assert.equal(claims.iss, issuer); assert.ok(Array.isArray(claims.aud) && claims.aud.includes(app.aud));
    assert.ok(claims.exp > Date.now() / 1000 && claims.nbf <= Date.now() / 1000);
    report.verifiedSessionMetadata = { issuer: claims.iss, audienceSha256: sha(app.aud), expiresAt: claims.exp, notBefore: claims.nbf,
      sameEstablishedOwner: true, roleSource: 'Real cryptographically authenticated API success; claims inspection is corroborating metadata, not a replacement verifier' };
  }
  report.ownerVerified = observed.role === 'owner';
  if (!page.isClosed()) await page.goto('about:blank');
  assert.ok(report.ownerVerified, 'The authenticated existing role is not owner; do not promote it by assumption');
  emit({ label, phase: 'EXISTING_OWNER_VERIFIED', ...report.session });
} catch (error) {
  fs.writeFileSync(failurePath, String(error.stack || error), { flag: 'wx' });
  report.failure = { name: error.name, code: error.code, detailPrivate: true };
  process.exitCode = 1;
} finally {
  closing = true;
  if (context) await context.close();
  report.browserClosed = true;
  report.endedAt = new Date().toISOString();
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  emit(report);
}
