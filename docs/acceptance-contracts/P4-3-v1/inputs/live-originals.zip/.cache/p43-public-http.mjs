import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const require = createRequire(import.meta.url);
const { ProxyAgent, request } = require('../app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici');
const origin = 'https://e-track-firmware-p41-test.tangjichentudou.workers.dev';
export const publicTransport = { tool: 'Node.js/undici', node: process.version, openssl: process.versions.openssl,
  undici: require('../app/bluetooth_flutter_Trace/cloudflare/update-service/admin/node_modules/undici/package.json').version,
  profile: 'Existing loopback HTTP proxy; HTTP/1.1 CONNECT; Node/OpenSSL certificate verification, no Schannel',
  qualification: '.cache/p43/logs/public-node-probe-01.log' };

export async function readPublic(url) {
  assert.equal(new URL(url).origin, origin);
  const agent = new ProxyAgent({ uri: 'http://127.0.0.1:7897', allowH2: false, requestTls: { rejectUnauthorized: true } });
  try {
    const response = await request(url, { dispatcher: agent, method: 'GET', maxRedirections: 0,
      headersTimeout: 30000, bodyTimeout: 30000, signal: AbortSignal.timeout(60000) });
    const chunks = []; let size = 0;
    for await (const chunk of response.body) { size += chunk.length; assert.ok(size <= 8 * 1024 * 1024); chunks.push(chunk); }
    return { status: response.statusCode, headers: response.headers, body: Buffer.concat(chunks) };
  } finally { await agent.destroy(); }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.equal(process.argv[2], 'probe');
  const response = await readPublic(origin + '/healthz');
  assert.equal(response.status, 200);
  const body = JSON.parse(response.body.toString('utf8')); assert.equal(body.ok, true);
  process.stdout.write(JSON.stringify({ ...publicTransport, status: response.status, observedAt: new Date().toISOString(),
    cfRay: response.headers['cf-ray'], bodySha256: createHash('sha256').update(response.body).digest('hex'), body }) + '\n');
}
