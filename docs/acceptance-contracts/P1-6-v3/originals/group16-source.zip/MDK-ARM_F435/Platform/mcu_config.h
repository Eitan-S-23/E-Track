/*
 * MIT License
 * Copyright (c) 2019-2021 _VIFEXTech
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#ifndef __MCU_CONFIG_H
#define __MCU_CONFIG_H

/*=========================
   MCU configuration
 *=========================*/

/* Platform identification for SdFat SDIO support */
#ifndef __AT32F435_437__
#define __AT32F435_437__
#endif

/* System tick */
#define SYSTICK_TICK_FREQ                   1000 // Hz
#define SYSTICK_PRIORITY                    0

/* Hardware Serial */
#define SERIAL_RX_BUFFER_SIZE               512
#define SERIAL_PREEMPTIONPRIORITY_DEFAULT   1
#define SERIAL_SUBPRIORITY_DEFAULT          3
#define SERIAL_CONFIG_DEFAULT               SERIAL_8N1

/* P3-1 BLE OTA 受控 RX 环（合同 §5.1 要求 >=4KB）。不扩 SERIAL_RX_BUFFER_SIZE
 *（3 实例全局扩容会击穿主 RAM 堆空洞）；BLE 会话活跃期由 UART ISR 回调把
 * 字节分流进 overlay workspace 内的该环，尺寸须为 2 的幂且与 overlay
 * 子分配预算（环 + staging receiver <= 40960B）联动。 */
#define CONFIG_OTA_BLE_RX_RING_SIZE         4096

#define SERIAL_1_ENABLE                     1
#if SERIAL_1_ENABLE
#  define SERIAL_1_USART                    USART1
#  define SERIAL_1_IRQ_HANDLER_DEF()        void USART1_IRQHandler(void)
#endif

#define SERIAL_2_ENABLE                     1
#if SERIAL_2_ENABLE
#  define SERIAL_2_USART                    USART2
#  define SERIAL_2_IRQ_HANDLER_DEF()        void USART2_IRQHandler(void)
#endif

#define SERIAL_3_ENABLE                     0
#if SERIAL_3_ENABLE
#  define SERIAL_3_USART                    USART3
#  define SERIAL_3_IRQ_HANDLER_DEF()        void USART3_IRQHandler(void)
#endif

#define SERIAL_5_ENABLE                     1
#if SERIAL_5_ENABLE
#  define SERIAL_5_UART                    UART5
#  define SERIAL_5_IRQ_HANDLER_DEF()        void UART5_IRQHandler(void)
#endif

/* Wire (Software I2C) */
#define WIRE_USE_FULL_SPEED_I2C             0
#define WIRE_SDA_PIN                        PB7
#define WIRE_SCL_PIN                        PB6
#define WIRE_DELAY                          1
#define WIRE_BEGIN_TIMEOUT                  100 // ms
#define WIRE_BUFF_SIZE                      32

/* SPI Class */
#define SPI_CLASS_AVR_COMPATIBILITY_MODE    1
#define SPI_CLASS_PIN_DEFINE_ENABLE         0

#define SPI_CLASS_1_ENABLE                  1
#if SPI_CLASS_1_ENABLE
#  define SPI_CLASS_1_SPI                   SPI1
#endif

#define SPI_CLASS_2_ENABLE                  1
#if SPI_CLASS_2_ENABLE
#  define SPI_CLASS_2_SPI                   SPI2
#endif

#define SPI_CLASS_3_ENABLE                  0
#if SPI_CLASS_3_ENABLE
#  define SPI_CLASS_3_SPI                   SPI3
#endif

/* WString */
#define WSTRING_MEM_INCLUDE                 "lvgl/lvgl.h"
#define WSTRING_MEM_REALLOC                 lv_mem_realloc
#define WSTRING_MEM_FREE                    lv_mem_free

/* Print */
#define PRINT_PRINTF_BUFFER_LENGTH          128

/* GPIO */
#define GPIO_DRIVE_DEFAULT                  GPIO_DRIVE_STRENGTH_STRONGER

/* External Interrupt  */
#define EXTI_PREEMPTIONPRIORITY_DEFAULT     2
#define EXTI_SUBPRIORITY_DEFAULT            1

/* Timer Interrupt */
#define TIMER_PREEMPTIONPRIORITY_DEFAULT    0
#define TIMER_SUBPRIORITY_DEFAULT           3

/* Tone */
#define TONE_TIMER_DEFAULT                  TIM1
#define TONE_PREEMPTIONPRIORITY_DEFAULT     0
#define TONE_SUBPRIORITY_DEFAULT            1

/* PWM */
#define PWM_RESOLUTION_DEFAULT              1000
#define PWM_FREQUENCY_DEFAULT               10000

#endif
